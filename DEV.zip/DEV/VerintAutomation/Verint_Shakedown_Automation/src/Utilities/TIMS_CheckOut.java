package Utilities;

import java.io.File;
import java.io.FileInputStream;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import jxl.Sheet;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableCell;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;



//To fetch password form TIMS website
public class TIMS_CheckOut {
	
	public static void main(String[] args) throws Exception {
	
		Screen sobj = new Screen ();
		String pwd="";
		File file = new File("C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\files\\IEDriverServer.exe");
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities);
		
		
		JLabel jUserName = new JLabel("User Name");
        JTextField userName = new JTextField();
        JLabel jPassword = new JLabel("Password");
        JTextField password = new JPasswordField();
        Object[] ob = {jUserName, userName, jPassword, password};
        int result = JOptionPane.showConfirmDialog(null, ob, "Please Enter your SF alias Id and Password", JOptionPane.OK_CANCEL_OPTION);
 
        if (result == JOptionPane.OK_OPTION) {
            String userNameValue = userName.getText().toUpperCase();
            String passwordValue = password.getText();
            //System.out.println("userNameValue:"+userNameValue);
           // System.out.println("passwordValue:"+passwordValue);
            driver.get("https://sftims.opr.statefarm.org/TIMS/Pages/MyTestIDs/ViewMyIDs.aspx");
    		Thread.sleep(3000);
			if (sobj.exists( "C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\img\\WindowsSecurity_UserName.png") != null)
			{
				sobj.type("C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\img\\WindowsSecurity_UserName.png","opr\\"+userNameValue);			
				Thread.sleep(1000);
			}
			if (sobj.exists( "C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\img\\WindowsSecurity_Password.png") != null)
			{
				sobj.type("C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\img\\WindowsSecurity_Password.png",passwordValue);			
				Thread.sleep(1000);
			}
			if (sobj.exists( "C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\img\\WindowsSecurity_OK.png") != null)
			{
				sobj.click("C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\img\\WindowsSecurity_OK.png");			
				Thread.sleep(1000);
			}
			if (sobj.exists( "C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\img\\WindowsSecurity_OK1.png") != null)
			{
				sobj.click("C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\img\\WindowsSecurity_OK1.png");			
				Thread.sleep(1000);
			}
			String Uid;
			String testid;
			FileInputStream fig = new FileInputStream("C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\src\\TestData\\Verint_Shakedown_TestData.xls");
			Workbook Wg = Workbook.getWorkbook(fig);			
		    Sheet s = Wg.getSheet("TestIds");  	
		    int rowc=s.getRows();
		    //System.out.println("row count:"+rowc);
		    for (int k=1;k<rowc;k++)
		    {
		    			Uid = s.getCell(0,k).getContents();				
		    			//System.out.println("k val read:"+k);						
						String id;						
						id=Uid.trim().toUpperCase();
						//System.out.println("uid:"+id);
						driver.manage().window().maximize();
						driver.findElement(By.id("MainContent_IDGrid1_txtFilter")).clear();
						driver.findElement(By.id("MainContent_IDGrid1_txtFilter")).sendKeys(id);
						Thread.sleep(3000);
						
						pageload(driver,id);
						
						if (driver.findElement(By.xpath("//div[@id='alertText']")).getText().contains("No results found!")) 
							//if (driver.findElement(By.xpath("//div[@id='MainContent_IDGrid1_SizeSection']/label")).getText().contains("Show") || driver.findElement(By.xpath("//div[@id='alertText']")).getText().contains("No results found!"))
							//if (driver.findElement(By.xpath("//div[@id='alertText']")).getText().contains("No results found!") || driver.findElements(By.xpath("//table[@id='MainContent_IDGrid1_gv']")).size()!=0)
						{
							//System.out.println("inside if");
							break;
						}
						
						for (int p=1;p<10;p++)
						{
							Thread.sleep(2000);
							//System.out.println("label:"+driver.findElement(By.xpath("//div[@id='MainContent_IDGrid1_SizeSection']/label")).getText());
							//System.out.println("label2:"+driver.findElement(By.xpath("//div[@id='alertText']")).getText());
							if (driver.findElement(By.xpath("//div[@id='MainContent_IDGrid1_SizeSection']/label")).getText().contains("Show") || driver.findElement(By.xpath("//div[@id='alertText']")).getText().contains("No results found!")) 
							//if (driver.findElement(By.xpath("//div[@id='alertText']")).getText().contains("No results found!") || driver.findElements(By.xpath("//table[@id='MainContent_IDGrid1_gv']")).size()!=0)
							{
								//System.out.println("inside if");
								break;
							}							
						}
						
						if (driver.findElement(By.xpath("//div[@id='alertText']")).getText().contains("No results found!"))
						{
							if (driver.findElements(By.xpath("//input[@id='btnAlertClose']")).size()!=0)
							{
								driver.findElement(By.xpath("//input[@id='btnAlertClose']")).click();
								System.out.println("No Results found");
								break;
							}
						}
						
						if (driver.findElements(By.xpath("//table[@id='MainContent_IDGrid1_gv']")).size()!=0)
						{
							int rc=driver.findElements(By.xpath("//table[@id='MainContent_IDGrid1_gv']/tbody/tr")).size();
							if (rc>1)
							{				
								//for (int i=2;i<=rc;i++)
								//{
									//Available
									if (driver.findElement(By.xpath("//table[@id='MainContent_IDGrid1_gv']/tbody/tr[2]/td[10]")).getText().contains("Available"))
									{
										testid = driver.findElement(By.xpath("//table[@id='MainContent_IDGrid1_gv']/tbody/tr[2]/td[3]")).getText().trim().toUpperCase();
										if (testid.contains(id))
										{
											driver.findElement(By.xpath("//table[@id='MainContent_IDGrid1_gv']/tbody/tr[2]/td[2]/input[@name='RadioGroup'][@type='radio']")).click();				
											Thread.sleep(2000);
											if (driver.findElements(By.xpath("//input[@id='MainContent_IDGrid1_btnCheckOut']")).size()!=0)
											{
												driver.findElement(By.xpath("//input[@id='MainContent_IDGrid1_btnCheckOut']")).click();
											}											
											Thread.sleep(2000);	
											//pageload(driver);
											if (driver.findElements(By.xpath("//div[@id='MainContent_IDGrid1_pwText']")).size()!=0)
											{
												pwd=driver.findElement(By.xpath("//div[@id='MainContent_IDGrid1_pwText']")).getText().trim();			
											}
											//System.out.println("password:"+pwd);
											Thread.sleep(2000);
											if (driver.findElements(By.xpath("//input[@id='MainContent_IDGrid1_btnPWClose']")).size()!=0)
											{
												driver.findElement(By.xpath("//input[@id='MainContent_IDGrid1_btnPWClose']")).click();			
											}
											
										}
									}
									//checked out by same user id
									//System.out.println("status:"+driver.findElement(By.xpath("//table[@id='MainContent_IDGrid1_gv']/tbody/tr[2]/td[10]")).getText().trim());
									//System.out.println("getval:"+"Checked Out by "+userNameValue);
									else if (driver.findElement(By.xpath("//table[@id='MainContent_IDGrid1_gv']/tbody/tr[2]/td[10]")).getText().trim().contains("Checked Out by "+userNameValue))
									{		
										testid = driver.findElement(By.xpath("//table[@id='MainContent_IDGrid1_gv']/tbody/tr[2]/td[3]")).getText().trim().toUpperCase();
										if (testid.contains(id))
										{
											driver.findElement(By.xpath("//table[@id='MainContent_IDGrid1_gv']/tbody/tr[2]/td[2]/input[@name='RadioGroup'][@type='radio']")).click();				
											Thread.sleep(1000);	
											if (driver.findElements(By.xpath("//input[@id='MainContent_IDGrid1_btnViewPW']")).size()!=0)
											{
												driver.findElement(By.xpath("//input[@id='MainContent_IDGrid1_btnViewPW']")).click();		
											}
											//pageload(driver);
											if (driver.findElements(By.xpath("//div[@id='MainContent_IDGrid1_pwText']")).size()!=0)
											{
												pwd=driver.findElement(By.xpath("//div[@id='MainContent_IDGrid1_pwText']")).getText().trim();			
											}
											//System.out.println("password:"+pwd);
											Thread.sleep(2000);
											if (driver.findElements(By.xpath("//input[@id='MainContent_IDGrid1_btnPWClose']")).size()!=0)
											{
												driver.findElement(By.xpath("//input[@id='MainContent_IDGrid1_btnPWClose']")).click();			
											}
											
										}
									}
									else if (!driver.findElement(By.xpath("//table[@id='MainContent_IDGrid1_gv']/tbody/tr[2]/td[10]")).getText().contains("Checked Out by "+userNameValue))
									{
										System.out.println(driver.findElement(By.xpath("//table[@id='MainContent_IDGrid1_gv']/tbody/tr[2]/td[10]")).getText()+" different User.Try Again.");										
									}
								//}//for
							}// if rc
						}//if
						//System.out.println("k val write:"+k);
						//System.out.println("password:"+pwd);
				        writePassword(driver,pwd,1,k);
					    }//for loop
		   
		//if OK dialog		    
		    Wg.close();
		    fig.close();
		    //remove all status from excel sheets
		    deletestatusFromExcel();
		    
		    driver.close();
		    driver.quit();
		    System.out.println("End of TIMS Checkout");
	    	System.out.println("####################################################################");
		
	}
        
        
	}//main
	
	public static void pageload(WebDriver driver,String id) throws Exception
	{
		for (int g=1;g<=40;g++)
		{
			if (driver.findElement(By.xpath("//table[@id='MainContent_IDGrid1_gv']/tbody/tr[2]/td[3]")).getText().trim().toUpperCase().contains(id))
			{
				break;
			}
			else
			{
				Thread.sleep(2000);
			}
		}
	}
	public static void deletestatusFromExcel() throws Exception
	 {			
		Workbook workbook2 = Workbook.getWorkbook(new File("C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\src\\TestData\\Verint_Shakedown_TestData.xls"));
	    WritableWorkbook copy2 = Workbook.createWorkbook(new File("C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\src\\TestData\\Verint_Shakedown_TestData.xls"), workbook2);
	    WritableSheet sheetb = copy2.getSheet("BO_TestSet"); 
	    
	    WritableCell cell;	    
	    int rowb=sheetb.getRows();	
	   
	    for (int k=1;k<rowb;k++)
	    {	    
	    	
		    Label l = new Label(4, k, "");		   
		    cell = (WritableCell) l;
		    sheetb.addCell(cell);
		   
	    }
	   // copy2.write();
	    WritableSheet sheetd = copy2.getSheet("DPA_TestSet"); 
	    int rowd=sheetd.getRows();	 
	   
	    for (int a=1;a<rowd;a++)
	    {	    
		    Label l = new Label(4, a, "");		   
		    cell = (WritableCell) l;
		    sheetd.addCell(cell);
		   
	    }
	    //copy2.write();
	    WritableSheet sheetq = copy2.getSheet("QM_TestSet"); 
	    int rowq=sheetq.getRows();	    
	    for (int b=1;b<rowq;b++)
	    {	    
		    Label l = new Label(4, b, "");
		    l.setString("");
		    cell = (WritableCell) l;
		    sheetq.addCell(cell);
		    
	    }
	    //copy2.write();
	    WritableSheet sheetw = copy2.getSheet("WFM_TestSet"); 
	    int roww=sheetw.getRows();	    
	    for (int c=1;c<roww;c++)
	    {	    
		    Label l = new Label(4, c, "");		    
		    cell = (WritableCell) l;
		    sheetw.addCell(cell);
		   
	    }
	    copy2.write();
	    copy2.close();   	
	 }
	
	    
	
	
	public static void writePassword(WebDriver driver,String Pwd,int col,int row) throws Exception
	 {			
		Workbook workbook1 = Workbook.getWorkbook(new File("C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\src\\TestData\\Verint_Shakedown_TestData.xls"));
	    WritableWorkbook copy = Workbook.createWorkbook(new File("C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\src\\TestData\\Verint_Shakedown_TestData.xls"), workbook1);
	    WritableSheet sheet2 = copy.getSheet("TestIds"); 
	    
	    WritableCell cell;
	    
	    //System.out.println("excel pwd:"+Pwd);
	    Label l = new Label(col, row, Pwd);
	    cell = (WritableCell) l;
	    sheet2.addCell(cell);
	    copy.write();
	    copy.close();
	   // workbook1.close();	    	
	 }
	
	
	

}//cls
