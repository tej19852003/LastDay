package Utilities;

import java.io.File;
import java.io.FileInputStream;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import jxl.Sheet;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableCell;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;



//To fetch password form TIMS website
public class TIMS_CheckIn {
	
	public static void main(String[] args) throws Exception {
	
		Screen sobj = new Screen ();
		//String pwd="";
		File file = new File("C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\files\\IEDriverServer.exe");
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities);	
		
		JLabel jUserName = new JLabel("User Name");
        JTextField userName = new JTextField();
        JLabel jPassword = new JLabel("Password");
        JTextField password = new JPasswordField();
        Object[] ob = {jUserName, userName, jPassword, password};
        int result = JOptionPane.showConfirmDialog(null, ob, "Please Enter User Id and Password", JOptionPane.OK_CANCEL_OPTION);
 
        if (result == JOptionPane.OK_OPTION) {
            String userNameValue = userName.getText().toUpperCase();
            String passwordValue = password.getText();
           // System.out.println("userNameValue:"+userNameValue);
           // System.out.println("passwordValue:"+passwordValue);
            driver.get("https://sftims.opr.statefarm.org/TIMS/Pages/MyTestIDs/ViewMyIDs.aspx");
    		Thread.sleep(3000);
			if (sobj.exists( "C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\img\\WindowsSecurity_UserName.png") != null)
			{
				sobj.type("C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\img\\WindowsSecurity_UserName.png","opr\\"+userNameValue);			
				Thread.sleep(1000);			
				if (sobj.exists( "C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\img\\WindowsSecurity_Password.png") != null)
				{
					sobj.type("C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\img\\WindowsSecurity_Password.png",passwordValue);			
					Thread.sleep(1000);
				}
				if (sobj.exists( "C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\img\\WindowsSecurity_OK.png") != null)
				{
					sobj.click("C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\img\\WindowsSecurity_OK.png");			
					Thread.sleep(1000);
				}
				if (sobj.exists( "C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\img\\WindowsSecurity_OK1.png") != null)
				{
					sobj.click("C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\img\\WindowsSecurity_OK1.png");			
					Thread.sleep(1000);
				}
			}
			String Uid;
			String testid;
			FileInputStream fig = new FileInputStream("C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\src\\TestData\\Verint_Shakedown_TestData.xls");
			Workbook Wg = Workbook.getWorkbook(fig);			
		    Sheet s = Wg.getSheet("TestIds");  	
		    int rowc=s.getRows();
		    //System.out.println("row count:"+rowc);
		    for (int k=1;k<rowc;k++)
		    {
		    			Uid = s.getCell(0,k).getContents();				
		    			//System.out.println("k val read:"+k);						
						String id;						
						id=Uid.trim().toUpperCase();
						//System.out.println("uid:"+id);
						driver.manage().window().maximize();
						driver.findElement(By.id("MainContent_IDGrid1_txtFilter")).clear();
						driver.findElement(By.id("MainContent_IDGrid1_txtFilter")).sendKeys(id);
						Thread.sleep(3000);		
						
						if (driver.findElement(By.xpath("//div[@id='alertText']")).getText().contains("No results found!"))
						{
							if (driver.findElements(By.xpath("//input[@id='btnAlertClose']")).size()!=0)
							{
								driver.findElement(By.xpath("//input[@id='btnAlertClose']")).click();
								System.out.println("No Results found");
								break;
							}
						}
						
						if (driver.findElements(By.xpath("//table[@id='MainContent_IDGrid1_gv']")).size()!=0)
						{
							int rc=driver.findElements(By.xpath("//table[@id='MainContent_IDGrid1_gv']/tbody/tr")).size();
							if (rc>1)
							{		
									if (driver.findElement(By.xpath("//table[@id='MainContent_IDGrid1_gv']/tbody/tr[2]/td[10]")).getText().trim().contains("Checked Out by "+userNameValue))
									{		
										testid = driver.findElement(By.xpath("//table[@id='MainContent_IDGrid1_gv']/tbody/tr[2]/td[3]")).getText().trim().toUpperCase();
										if (testid.contains(id))
										{
											driver.findElement(By.xpath("//table[@id='MainContent_IDGrid1_gv']/tbody/tr[2]/td[2]/input[@name='RadioGroup'][@type='radio']")).click();				
											Thread.sleep(1000);	
											if (driver.findElements(By.xpath("//input[@id='MainContent_IDGrid1_btnCheckIn']")).size()!=0)
											{
												driver.findElement(By.xpath("//input[@id='MainContent_IDGrid1_btnCheckIn']")).click();	
												Thread.sleep(10000);	
											}							
											
											if (driver.findElements(By.xpath("//div[@id='alertButton']/input[@id='btnAlertClose']")).size()!=0)
											{
												driver.findElement(By.xpath("//div[@id='alertButton']/input[@id='btnAlertClose']")).click();			
											}
											
										}
									}
									if (driver.findElement(By.xpath("//table[@id='MainContent_IDGrid1_gv']/tbody/tr[2]/td[10]")).getText().contains("Available"))
									{
										System.out.println("Available. Already Checked In");										
									}
									if (!driver.findElement(By.xpath("//table[@id='MainContent_IDGrid1_gv']/tbody/tr[2]/td[10]")).getText().contains("Checked Out by "+userNameValue))
									{
										System.out.println(driver.findElement(By.xpath("//table[@id='MainContent_IDGrid1_gv']/tbody/tr[2]/td[10]")).getText()+" different User.Cannot be Checked In.");										
									}
								//}//for
							}// if rc
						}//if
						deletePassword(driver,"",1,k);
					    }//for loop
		   
		//if OK dialog
		    Wg.close();
		    fig.close();
		    driver.close();
		    driver.quit();
        
		
	}
        
        
	}//main
	
	
	
	
	public static void deletePassword(WebDriver driver,String Pwd,int col,int row) throws Exception
	 {			
		Workbook workbook1 = Workbook.getWorkbook(new File("C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\src\\TestData\\Verint_Shakedown_TestData.xls"));
	    WritableWorkbook copy = Workbook.createWorkbook(new File("C:\\DEV\\VerintAutomation\\Verint_Shakedown_Automation\\src\\TestData\\Verint_Shakedown_TestData.xls"), workbook1);
	    WritableSheet sheet2 = copy.getSheet("TestIds"); 
	    
	    WritableCell cell;
	    
	    //System.out.println("excel pwd:"+Pwd);
	    Label l = new Label(col, row, Pwd);
	    cell = (WritableCell) l;
	    sheet2.addCell(cell);
	    copy.write();
	    copy.close();
	   // workbook1.close();	    	
	 }
	
	
	

}//cls
