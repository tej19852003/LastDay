package Utilities;

import java.io.IOException;

public class killprocess {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
		    Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe");
		    //Runtime.getRuntime().exec("taskkill /F /IM iexplore.exe");
		} catch (IOException e) {
		    e.printStackTrace();
		}
	}

}
