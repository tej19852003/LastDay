package WFMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import ScreenObjects.LoginScreen;
import ScreenObjects.ProfilesScreen;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.ManageCoaching;
import ScreenObjects.OrganizationSettings;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM9_CreateCoachingForAgents {
	
	public static ExtentReports extent = ExtentReports.get(WFM9_CreateCoachingForAgents.class);
	
	public static boolean CreateCoachingForAgents() throws Exception
	{		
		
		boolean flag=true;
		String HTMLReportName="WFM9_Create_Coaching_For_Agents"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Create Coaching For Agents");
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("WFM_TestSet");
	    Sheet testID=Wb.getSheet("TestIds");
	    String organizationName = Ws.getCell(5,4).getContents();    
	    String organizationDesc = Ws.getCell(6,4).getContents();
	    String parentOrganization = Ws.getCell(7,4).getContents();
	    String empName=testID.getCell(0,5).getContents();
	    String FirstName=testID.getCell(0,5).getContents();
	    String LastName=Ws.getCell(32,4).getContents();
	    String agentname=Ws.getCell(33,4).getContents();
		
		try
		{			    
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
			LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Organization Settings"))
			//if (driver.findElements(By.linkText("Organization Settings")).size()==0)
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Organization Settings"))
				//if (driver.findElements(By.linkText("Organization Settings")).size()==0)
				{
					extent.log(LogStatus.WARNING, "Not able to select Organization Settings. Please try again");
					return flag=false;
				}			
			}
			//verify whether Organization name is already exist or not		
			Utilities.selectLeftTreeFrame(driver);
			Boolean Temp1=false;
			//String organizationName=".Automation_Organization";
			int rc1=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
			System.out.println("rc1:"+rc1);
			for (int j=1;j<=rc1;j++)
			{
				if (j<=15)
				{
				String orgName=driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).getText();
				System.out.println("orgnameValidation:"+orgName);
				System.out.println("orgnameCreated:"+organizationName);
				Thread.sleep(1000);
				if (orgName.contains(organizationName))
				{
					driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).click();
					Temp1=true;
					break;
				}}
			}
			if (Temp1==true)
			{
				System.out.println("org already exist");
				extent.log(LogStatus.INFO, "Organization Name: "+organizationName+" already exist");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Organization"));				
			}			
			//end of verify organization
			//create organization
			if (Temp1==false)
			{
				Utilities.selectLeftTreeFrame(driver);
				if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,parentOrganization))
				{
					return flag=false;
				}
				Utilities.selectRightPaneView(driver);
				if (!OrganizationSettings.clickCreateOrganization(driver))
				{
					return flag=false;
				}
				OrganizationSettings.setOrganizationName(driver,organizationName);
				OrganizationSettings.setOrganizationDescription(driver,organizationDesc);
				OrganizationSettings.isSelectedDaysAndHoursOfOperation(driver);
				if (!OrganizationSettings.clickSave(driver))
				{
					return flag=false;
				}
				//validation
				Utilities.selectLeftTreeFrame(driver);
				if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,organizationName))
				{
					return flag=false;
				}
			}
			driver.switchTo().defaultContent();
			Thread.sleep(3000);
			VerintHomePageScreen.selectMenuItem(driver,"User Management","user_profiles");
			if(!ProfilesScreen.FindSelect(driver,empName))
			{
				Utilities.selectRightPaneView(driver);
				ProfilesScreen.clickCreate(driver);
				ProfilesScreen.setProfilesLastName(driver, LastName);
				ProfilesScreen.setProfilesFirstName(driver, FirstName);
				Utilities.selectRightPaneView(driver);
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
				if (!ProfilesScreen.clickOrganizationEdit(driver)) // click on organization edit icon
				{
					return flag=false;
				}
				Thread.sleep(6000);			
				String windowName=Utilities.setWindowFocus(driver);			
				ProfilesScreen.selectOrganizationFromListbox(driver,organizationName);		
					
				driver.switchTo().window(windowName);
				RolesSetupScreen.selectRightPaneView(driver);
				if (!ProfilesScreen.clickSave(driver))
				{
					return flag=false;
				}
				ProfilesScreen.verifySuccessMessage(driver);
			}
			else
			{
				System.out.println("user already exist");
			}
			
			//coaching for agents
			driver.switchTo().defaultContent();
			if (!VerintHomePageScreen.selectMenuItem(driver,"Coaching","Manage Coaching"))
			//if (driver.findElements(By.linkText("Manage Coaching")).size()==0)
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Coaching","Manage Coaching"))
				//if (driver.findElements(By.linkText("Manage Coaching")).size()==0)
				{
					extent.log(LogStatus.WARNING, "Not able to select Coaching menu. Please try again");
					return flag=false;
				}			
			}
			Utilities.selectRightPaneView(driver);
			if (!ManageCoaching.clickCreate(driver))
			{
				return flag=false;
			}
			ManageCoaching.setemployee(driver,agentname);
			Thread.sleep(3000);
			ManageCoaching.setReason(driver,"Reason");
			//String datetime=new SimpleDateFormat("MM/dd/YYYY hh:mm a").format(Calendar.getInstance().getTime());
		
			
			DateFormat dateFormat= new SimpleDateFormat("MM/dd/YYYY hh:mm a");

			Calendar c = Calendar.getInstance();    
			c.setTime(new Date());
			c.add(Calendar.DATE, 5);
			String datetime=dateFormat.format(c.getTime());
			
			ManageCoaching.setDateTime(driver,datetime);
			ManageCoaching.setLocation(driver,"Location");
			if (!ManageCoaching.clickSave(driver))
			{
				return flag=false;
			}
			if (!ManageCoaching.clickPending(driver))
			{
				return flag=false;
			}
			ManageCoaching.verifyStatus(driver,datetime,"Pending");
	
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM",HTMLReportName,4,4);
		}
		return flag;
	}


	

}
