package WFMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.CampaignSettings;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM3_CreateCampaign {
	
	public static ExtentReports extent = ExtentReports.get(WFM3_CreateCampaign.class);
	
	public static boolean CreateCampaign() throws Exception
	{		
		boolean flag=true;
		String HTMLReportName="WFM3_Create Campaign"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Create Campaign");	
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("WFM_TestSet");
	    String campName = Ws.getCell(10,3).getContents();
	   	
		try
		{				    
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
			LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings"))
			//if (driver.findElements(By.linkText("Settings")).size()==0)
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings"))
				//if (driver.findElements(By.linkText("Settings")).size()==0)
				{
					extent.log(LogStatus.WARNING, "Not able to select Compaign Settings menu. Please try again");
					return flag=false;
				}			
			}
			//verify whether Compaign name is already exist or not		
			Utilities.selectLeftTreeFrame(driver);
			boolean Temp=false;
			int rc=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
			System.out.println("rc:"+rc);
			for (int i=1;i<=rc;i++)
			{
				if (i<=15)
				{
				String campNameApp=driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr["+i+"]/td/a")).getText();
				System.out.println(i+":"+campNameApp);
				if (campNameApp.contains(campName))
				{
					driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr["+i+"]/td/a")).click();
					Thread.sleep(3000);
					Temp=true;
					break;
				}}
			}
			if (Temp==true)
			{					
				extent.log(LogStatus.PASS, "Compaign Name:"+campName+" already exist");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Campaign"));
			}
					
			//end of verify campaign
			//create campaign
			if (Temp==false)
			{
				Utilities.selectRightPaneView(driver);
				
				if (!CampaignSettings.clickCreateCampaign(driver))
				{
					return flag=false;
				}
				CampaignSettings.setCampaignName(driver,campName);
				CampaignSettings.setCampaignDescription(driver,".AutomationDescCampaign");				
				if (!CampaignSettings.clickSave(driver))
				{
					return flag=false;
				}
				//validation
				Utilities.selectLeftTreeFrame(driver);
				if (!CampaignSettings.selectCampaignFromLeftTreeFrame(driver,campName))
				{
					return flag=false;
				}
			}
	
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM",HTMLReportName,4,3);
		}
		return flag;
	}


	

}
