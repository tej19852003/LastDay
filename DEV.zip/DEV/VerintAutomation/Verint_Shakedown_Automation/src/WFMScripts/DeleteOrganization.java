package WFMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;

import ScreenObjects.OrganizationSettings;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class DeleteOrganization {
	
	public static ExtentReports extent = ExtentReports.get(DeleteOrganization.class);
	
	public static boolean Delete_Organization() throws Exception
	{		
		boolean flag=true;
		String HTMLReportName="DeleteOrganization"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Delete Organization");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("WFM_TestSet");
	    String organizationName = Ws.getCell(5,11).getContents();
	   		
		try
		{		   
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
			LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Organization Settings"))
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					extent.log(LogStatus.FAIL, "Verint Homepage is not displayed");
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Organization Settings"))
				{
					extent.log(LogStatus.WARNING, "Not able to select Organization Settings menu. Please try again.");
					return flag=false;
				}
			}
			String[] OrgName=organizationName.split(",");
			System.out.println("orgname:"+OrgName.length);
			for (int r=0;r<OrgName.length;r++)
			{
				//verify whether Organization name is already exist or not		
				Utilities.selectLeftTreeFrame(driver);
				Boolean Temp1=false;
				
				int rc1=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
				System.out.println("rc1:"+rc1);
				for (int j=1;j<=rc1;j++)
				{
					if (j<=15)
					{
					String orgNameApp=driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).getText();
					System.out.println("orgnameValidation:"+orgNameApp);
					System.out.println("orgnameValidation:"+OrgName[r]);
					Thread.sleep(1000);
					if (orgNameApp.contains(OrgName[r]))
					{
						driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).click();
						Temp1=true;
						break;
					}}
				}
				if (Temp1==true)
				{
					System.out.println("org already exist");
					extent.log(LogStatus.INFO, "Organization Name: "+OrgName[r]+" exist");
					extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Organization"));						
				
					//delete organization
					Utilities.selectRightPaneView(driver);
					if (!OrganizationSettings.clickDelete(driver))
					{
						return flag=false;
					}
					if (!OrganizationSettings.clickDeleteOrg(driver))
					{
						return flag=false;
					}
				}
				else
				{
					extent.log(LogStatus.INFO, "Organization Name: "+OrgName[r]+" does not exist");
				}
			}
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM",HTMLReportName,4,11);
		}
		return flag;
	}

}
