package ScreenObjects;


import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class DataSourceScreen {
	
	public static ExtentReports extent = ExtentReports.get(DataSourceScreen.class);
	public static String lnkPhones="Phones";
	
	public static String btnCreateDataSource="//button[@id='toolbar_DATASOURCE_CREATE_NEW_REQUESTLabel']";
	public static String lstDataSourceType="NewDatasourceType";
	//public static String lstDataSourceType="//span[@id='DATASOURCE_CREATE_NEW_REQUEST_place']/div/table/tbody/tr/td/table[@id='DATASOURCE_CREATE_NEW_REQUESTWrapper']/tbody/tr/td/div/table/tbody/tr/td[2]/span/select[@id='NewDatasourceType']";
	//public static String btnSelect="//button[@id='workpaneMediator_toolbar_CREATE_NEW_DSLabel']";
	public static String btnSelect="//button[@id='toolbar_CREATE_NEW_DSLabel']";
	public static String txtDataSourceName="dataSourceName";
	public static String txtDataSourceDesc="description_0";
	public static String btnSave="//button[@id='workpaneMediator_toolbar_SAVE_ACTIONLabel']";
	//public static String btnSave="//button[@id='toolbar_SAVE_ACTIONLabel']";
	public static String iconlstDSType="//span[@id='NewDatasourceType_0Wrapper']/nobr/img[@id='NewDatasourceType_0Button']";
	public static String btnCreateGroup="//button[@id='toolbar_ADD_ACTIONLabel']";
	public static String btnDeleteGroup="//button[@id='toolbar_DELETE_ACTIONLabel']";
	public static String txtDataSourceGroupName="groupName";
	public static String txtDataSourceGroupDesc="groupDescription";
	public static String txtDataSourceGroupAvgWorkTime="groupAWT_0";
	public static String btnDSGroupSave="//button[@id='workpaneMediator_toolbar_CREATE_NEW_ACTIONLabel']";
	public static String btnDeleteDataSource="//button[@id='workpaneMediator_toolbar_DATASOURCE_DELETE_ACTIONLabel']";
	
	public static boolean clickDeleteDataSource(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			Utilities.selectRightPaneView(driver);
			By delDSBtn=By.xpath(btnDeleteDataSource);
			Utilities.waitForPageLoad(driver,delDSBtn);
			if (driver.findElements(delDSBtn).size()!=0)
			{					
				driver.findElement(delDSBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Delete Data Source button is successful");
				Thread.sleep(3000);
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Delete_OK.png");
				Thread.sleep(3000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Delete Data Source button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickDeleteGroup(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			Utilities.selectRightPaneView(driver);
			By delGroupBtn=By.xpath(btnDeleteGroup);
			Utilities.waitForPageLoad(driver,delGroupBtn);
			if (driver.findElements(delGroupBtn).size()!=0)
			{					
				driver.findElement(delGroupBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Delete Group button is successful");
				Thread.sleep(3000);
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Delete_OK.png");
				Thread.sleep(3000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Delete Group button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickDateSourceGroupSave(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{			
			By saveGroupBtn=By.xpath(btnDSGroupSave);
			Utilities.waitForPageLoad(driver,saveGroupBtn);
			if (driver.findElements(saveGroupBtn).size()!=0)
			{					
				driver.findElement(saveGroupBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Data Source Group Save button is successful");
				Thread.sleep(15000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Data Source Group Save button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean setDataSourceGroupAvgWorkTime(WebDriver driver,String DataSourceAvgWorkTime)
	{
		boolean flag=false;
		try{		
			By dsAvgWorkTimeDesctxt=By.id(txtDataSourceGroupAvgWorkTime);
			Utilities.waitForPageLoad(driver,dsAvgWorkTimeDesctxt);
			if (driver.findElements(dsAvgWorkTimeDesctxt).size()!=0)
			{
				//driver.findElement(dsAvgWorkTimeDesctxt).clear();
				driver.findElement(dsAvgWorkTimeDesctxt).sendKeys(DataSourceAvgWorkTime);
				extent.log(LogStatus.PASS, "Data Source Group Avg Work Time: "+DataSourceAvgWorkTime +" is entered successfully");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Data Source Group Avg Work Time: "+DataSourceAvgWorkTime +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean setDataSourceGroupDescription(WebDriver driver,String DataSourceGroupDescription)
	{
		boolean flag=false;
		try{		
			By dsgDesctxt=By.id(txtDataSourceGroupDesc);
			Utilities.waitForPageLoad(driver,dsgDesctxt);
			if (driver.findElements(dsgDesctxt).size()!=0)
			{
				driver.findElement(dsgDesctxt).clear();
				driver.findElement(dsgDesctxt).sendKeys(DataSourceGroupDescription);
				extent.log(LogStatus.PASS, "Data Source Group Description: "+DataSourceGroupDescription +" is entered successfully");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Data Source Group Name: "+DataSourceGroupDescription +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setDataSourceGroupName(WebDriver driver,String DataSourceGroupName)
	{
		boolean flag=false;
		try{		
			By dsgtxt=By.id(txtDataSourceGroupName);
			Utilities.waitForPageLoad(driver,dsgtxt);
			if (driver.findElements(dsgtxt).size()!=0)
			{
				driver.findElement(dsgtxt).clear();
				driver.findElement(dsgtxt).sendKeys(DataSourceGroupName);
				extent.log(LogStatus.PASS, "Data Source Group Name: "+DataSourceGroupName +" is entered successfully");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Data Source Group Name: "+DataSourceGroupName +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickCreateGroup(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			Utilities.selectRightPaneView(driver);
			By createGroupBtn=By.xpath(btnCreateGroup);
			Utilities.waitForPageLoad(driver,createGroupBtn);
			if (driver.findElements(createGroupBtn).size()!=0)
			{					
				driver.findElement(createGroupBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Create Group button is successful");
				Thread.sleep(15000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Create Group button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean verifyRecordingMode(WebDriver driver,String Extensions) throws Exception
	{	
		Boolean Temp1=false;
		Boolean flag=false;
		try {
			Utilities.selectRightPaneView(driver);
			int recrc=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr")).size();
			//System.out.println("recordingRC:"+recrc);
			for (int d=1;d<=recrc;d++)
			{				
				String extnApp=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+d+"]/th/a/span/span")).getText().trim();
				//System.out.println("extnApp:"+extnApp);
				//System.out.println("Extensions:"+Extensions);				
				if (extnApp.contains(Extensions))
				{
					String recMode=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+d+"]/td[1]")).getText().trim();
					//System.out.println("rec mode:"+recMode);
					if (recMode.contains("Start on Trigger"))
					{
						driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+d+"]/th/a/span/span")).click();
						Temp1=true;
						break;
					}					
				}
			}
			if (Temp1==true)
			{
				//System.out.println("pass");
				extent.log(LogStatus.PASS, "Extensions Primary/Secondary : "+Extensions+" Recording Mode: Start on Trigger  is displayed successfully");
				flag=true;
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "StartOnTrigger"));				
			}
			else
			{
				extent.log(LogStatus.FAIL, "Extensions Primary/Secondary : "+Extensions+" Recording Mode: Start on Trigger  is not displayed");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "StartOnTrigger"));
				return flag =false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;		
		
	}
	
	public static boolean clickPhoneslnk(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{
			driver.switchTo().defaultContent();
			By phoneslnk=By.linkText(lnkPhones);
			Utilities.waitForPageLoad(driver,phoneslnk);
			if (driver.findElements(phoneslnk).size()!=0)
			{					
				driver.findElement(phoneslnk).click();
				extent.log(LogStatus.PASS, "Clicked on Phones link is successful");
				Thread.sleep(8000);
			}else
			{				
				extent.log(LogStatus.INFO, "Clicked on Phones link is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean selectDataSourceName(WebDriver driver,String DataSourceName) throws Exception
	{
		driver.switchTo().defaultContent();		
		Utilities.selectLeftTreeFrame(driver);
		
		/*Robot r = new Robot();
		r.keyPress(KeyEvent.VK_CONTROL);
		r.keyPress(KeyEvent.VK_F);
		r.keyRelease(KeyEvent.VK_CONTROL);
		r.keyRelease(KeyEvent.VK_F);
		Utilities.sikuliType(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\FindText.png", DataSourceName);
		Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\FindText_Close.png");*/
		
		Boolean Temp1=false;
		Boolean flag=false;
		try {
			int valrcdsn=driver.findElements(By.xpath("//table[@id='dataSourceTree_id']/tbody/tr")).size();
			System.out.println("valrcdsn:"+valrcdsn);
			for (int d=1;d<=valrcdsn;d++)
			{
				if (d<=15)
				{
				if (driver.findElements(By.xpath("//img[@id='dataSourceTreehdrImg'][@alt='Opened']")).size()!=0)
				{
					driver.findElement(By.xpath("//img[@id='dataSourceTreehdrImg'][@alt='Opened']")).click();
				}
				String dsnApp=driver.findElement(By.xpath("//table[@id='dataSourceTree_id']/tbody/tr["+d+"]/td/a/span/span")).getText().trim();
				System.out.println("dsnApp:"+dsnApp);
				System.out.println("DataSourceName:"+DataSourceName);
				//driver.findElement(By.xpath("//table[@id='dataSourceTree_id']/tbody/tr["+d+"]/td/a/span/span")).click();
				//Thread.sleep(3000);
				/*if (d==Math.round(valrcdsn/2))
				{
					Utilities.sikuliClick(driver, "C:\\DEV\\VerintShakedownAutomation\\Verint_Shakedown_Automation\\img\\DSN_verticalBar.png");
					//driver.findElement(By.xpath("//table[@id='dataSourceTree_id']/tbody/tr["+d+"]/td/a/span/span")).click();
				}*/
				if (dsnApp.contains(DataSourceName))
				{
					
					System.out.println("d:"+d);					
					driver.findElement(By.xpath("//table[@id='dataSourceTree_id']/tbody/tr["+d+"]/td/a/span/span")).click();
					Temp1=true;
					Thread.sleep(6000);
					break;
					
				}}
			}
			if (Temp1==true)
			{
				System.out.println("pass");
				extent.log(LogStatus.PASS, "Name: "+DataSourceName+" Created/Selected successfully");
				flag=true;
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Datasource"));				
			}
			else
			{
				extent.log(LogStatus.FAIL, "Unable to Create/Select Data Source Name: "+DataSourceName);
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Datasource"));
				return flag =false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;		
		}
	
	public static boolean selectQMDataSourceName(WebDriver driver,String DataSourceName) throws Exception
	{
		driver.switchTo().defaultContent();		
		Utilities.selectLeftTreeFrame(driver);	
		
		Boolean Temp1=false;
		Boolean flag=false;
		try {
			int valrcdsn=driver.findElements(By.xpath("//table[@id='dataSourceTree_id']/tbody/tr")).size();
			System.out.println("valrcdsn:"+valrcdsn);
			for (int d=1;d<=valrcdsn;d++)
			{
				
				if (driver.findElements(By.xpath("//img[@id='dataSourceTreehdrImg'][@alt='Opened']")).size()!=0)
				{
					driver.findElement(By.xpath("//img[@id='dataSourceTreehdrImg'][@alt='Opened']")).click();
				}
				String dsnApp=driver.findElement(By.xpath("//table[@id='dataSourceTree_id']/tbody/tr["+d+"]/td/a/span/span")).getText().trim();
				System.out.println("dsnApp:"+dsnApp);
				System.out.println("DataSourceName:"+DataSourceName);
				//driver.findElement(By.xpath("//table[@id='dataSourceTree_id']/tbody/tr["+d+"]/td/a/span/span")).click();
				//Thread.sleep(3000);
				System.out.println("d:"+Math.round(valrcdsn/2));
				if (d==Math.round(valrcdsn/2))
				{
					System.out.println("dsikuli:"+d);
					Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\UpperArrow.png");
					Thread.sleep(1000);
					Robot r = new Robot();
					r.keyPress(KeyEvent.VK_PAGE_DOWN);
					Thread.sleep(1000);
					r.keyRelease(KeyEvent.VK_PAGE_DOWN);
					//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\DSN_verticalBar.png");
					//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\DSN_verticalBar1.png");
				}
				if (dsnApp.contains(DataSourceName))
				{					
					System.out.println("d:"+d);					
					driver.findElement(By.xpath("//table[@id='dataSourceTree_id']/tbody/tr["+d+"]/td/a/span/span")).click();
					Temp1=true;
					Thread.sleep(6000);
					break;
					
				}
			}
			if (Temp1==true)
			{
				System.out.println("pass");
				extent.log(LogStatus.PASS, "Name: "+DataSourceName+" Created/Selected successfully");
				flag=true;
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "StartOnTriggerDatasource"));				
			}
			else
			{
				extent.log(LogStatus.FAIL, "Unable to Create/Select Data Source Name: "+DataSourceName);
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "StartOnTriggerDatasource"));
				return flag =false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;		
		}



	public static boolean clickSave(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			By saveBtn=By.xpath(btnSave);
			Utilities.waitForPageLoad(driver,saveBtn);
			if (driver.findElements(saveBtn).size()!=0)
			{					
				driver.findElement(saveBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Save button is successful");
				Thread.sleep(15000);
				flag=true;
			}else if (driver.findElements(By.id("workpaneMediator_toolbar_SAVE_ACTIONLabel")).size()!=0)
			{
				driver.findElement(By.id("workpaneMediator_toolbar_SAVE_ACTIONLabel")).click();
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL, "Clicked on Save button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setDataSourcedescription(WebDriver driver,String DataSourceDesc)
	{
		boolean flag=false;
		try{		
			By dsnDesctxt=By.id(txtDataSourceDesc);
			Utilities.waitForPageLoad(driver,dsnDesctxt);
			if (driver.findElements(dsnDesctxt).size()!=0)
			{
				driver.findElement(dsnDesctxt).sendKeys(DataSourceDesc);
				extent.log(LogStatus.PASS, "Data Source Description: "+DataSourceDesc +" is entered successfully");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Data Source Description: "+DataSourceDesc +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean setDataSourcename(WebDriver driver,String DataSourceName)
	{
		boolean flag=false;
		try{		
			By dsntxt=By.id(txtDataSourceName);
			Utilities.waitForPageLoad(driver,dsntxt);
			if (driver.findElements(dsntxt).size()!=0)
			{
				driver.findElement(dsntxt).sendKeys(DataSourceName);
				extent.log(LogStatus.PASS, "Data Source Name: "+DataSourceName +" is entered successfully");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Data Source Name: "+DataSourceName +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickSelect(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			By selectBtn=By.xpath(btnSelect);
			Utilities.waitForPageLoad(driver,selectBtn);
			if (driver.findElements(selectBtn).size()!=0)
			{					
				driver.findElement(selectBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Select button is successful");
				Thread.sleep(5000);
				flag=true;
			}else if (driver.findElements(By.xpath("//table[@id='workpaneMediator_toolbar_CREATE_NEW_DSWrapper']/tbody/tr/td/button[@id='workpaneMediator_toolbar_CREATE_NEW_DSLabel']")).size()!=0) 
			{
				driver.findElement(By.xpath("//table[@id='workpaneMediator_toolbar_CREATE_NEW_DSWrapper']/tbody/tr/td/button[@id='workpaneMediator_toolbar_CREATE_NEW_DSLabel']")).click();
				extent.log(LogStatus.INFO, "Clicked on Select button is successful");
				Thread.sleep(5000);
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL, "Clicked on Select button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickCreateDataSource(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			Utilities.selectRightPaneView(driver);
			By btnCreateDS=By.xpath(btnCreateDataSource);
			Utilities.waitForPageLoad(driver,btnCreateDS);			
			
			if (driver.findElements(btnCreateDS).size()!=0)
			{					
				driver.findElement(btnCreateDS).click();
				extent.log(LogStatus.INFO, "Clicked on Create Data Source button is successful");
				Thread.sleep(4000);
				flag=true;
			}else if (driver.findElements(By.id("workpaneMediator_toolbar_DATASOURCE_CREATE_NEW_REQUESTLabel")).size()!=0)
				{
					driver.findElement(By.id("workpaneMediator_toolbar_DATASOURCE_CREATE_NEW_REQUESTLabel")).click();
					flag=true;
				}
			else
			{
				extent.log(LogStatus.FAIL, "Clicked on Create Data Source button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectDataSourceType(WebDriver driver,String Option) throws Exception
	{
		boolean flag=false;
		try{
			Thread.sleep(3000);
			By lstDStype=By.xpath(iconlstDSType);
			Utilities.waitForPageLoad(driver,lstDStype);
			if (driver.findElements(lstDStype).size()!=0)
			{
				driver.findElement(lstDStype).click();
				Thread.sleep(2000);
				driver.findElement(lstDStype).sendKeys("Operations");
				Robot r = new Robot();
				r.keyPress(KeyEvent.VK_ENTER);
				r.keyRelease(KeyEvent.VK_ENTER);
				extent.log(LogStatus.INFO, "Data Source Type:"+Option+ " is selected");	
				flag=true;			
			}
			else
			{
				extent.log(LogStatus.FAIL, "Select Data Source Type:"+Option+ " is Unsuccessful");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

}

