package ScreenObjects;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

//import Library.DPA_Library;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class AccessRightsScreen {
	
	public static ExtentReports extent = ExtentReports.get(AccessRightsScreen.class);
	public static String btnView="//button[@id='selectionMediator_toolbar_SUBMITLabel']";
	public static String btnEditAccessRights="//button[@id='toolbar_EDIT_ACTIONLabel']";	
	public static String btnSave="//button[@id='workpaneMediator_toolbar_SAVE_ACTIONLabel']";
	
	
	public static boolean select_OrganizationScope_checkbox(WebDriver driver,String Name) throws Exception
	{
		Boolean Temp1=false;
		try {
			Utilities.selectRightPaneView(driver);
			int rcOrg=driver.findElements(By.xpath("//table[@id='scope_2_PC_id']/tbody/tr")).size();
			System.out.println("rcOrg:"+rcOrg);
			for (int a=1;a<=rcOrg;a++)
			{
				String orgApp=driver.findElement(By.xpath("//table[@id='scope_2_PC_id']/tbody/tr["+a+"]/td[2]/label/span")).getText().trim();
				//System.out.println("orgApp:"+orgApp);
				//System.out.println("orgname:"+Name);
				Thread.sleep(1000);
				if (orgApp.contains(Name))
				{		
					if (!driver.findElement(By.xpath("//table[@id='scope_2_PC_id']/tbody/tr["+a+"]/td[1]/span/input[@name='scope_2'][@type='checkbox']")).isSelected())
					{
						driver.findElement(By.xpath("//table[@id='scope_2_PC_id']/tbody/tr["+a+"]/td[1]/span/input[@name='scope_2'][@type='checkbox']")).click();										
						
						//break;
					}
					Temp1=true;
					break;
				}
			}
			if (Temp1==true)
			{
				//System.out.println("pass");
				extent.log(LogStatus.PASS, "Organization Name: "+Name+" Created/Selected successfully");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "AdoptRole"));				
			}
			else
			{
				extent.log(LogStatus.FAIL, "Unable to Create/Select Organization Name: "+Name);
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "AdoptRole"));
				return Temp1 =false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return Temp1;
	
		
	}
	
	public static boolean clickSave(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			By saveBtn=By.xpath(btnSave);
			Utilities.waitForPageLoad(driver,saveBtn);
			if (driver.findElements(saveBtn).size()!=0)
			{					
				driver.findElement(saveBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Save button is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Save button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean select_RoleName_checkbox(WebDriver driver,String RoleName) throws Exception
	{
		boolean flag=false;
		try{
		Utilities.selectRightPaneView(driver);
		String selectRoleNames=RoleName;
		String[] resRole=selectRoleNames.split(";");
		for (int s=0;s<resRole.length;s++)
		{
			String selRole=resRole[s];		
			int rcRole=driver.findElements(By.xpath("//table[@id='roleTableRef']/tbody/tr")).size();
			//System.out.println("rolerc:"+rcRole);
			for (int p=1;p<=rcRole;p++)
			{
				/*System.out.println("p:"+p);
				if (p==10 || p==20 || p==30 ||p==35 || p==40 ||p==45 ||p==48)
				{
					Utilities.sikuliClick(driver,"C:\\DEV\\VerintAutomation\\Verint_Automation\\img\\AccessRights_Verticalbar.png");
				}
				if (p==51 )
				{
					Utilities.sikuliClick(driver,"C:\\DEV\\VerintAutomation\\Verint_Automation\\img\\AccessRights_Verticalbar1.png");
				}*/
				/*if ((p<=30)) 
				{
					String rName=driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody/tr["+p+"]/td[1]/a/span")).getText().trim();
					System.out.println("prevNameApp:"+rName);
					System.out.println("privVal:"+selRole);
					//Thread.sleep(1000);
					if (rName.contains(selRole))
					{
						driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody/tr["+p+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).click();
						break;
				if more than 31 then tbody[2] in the below 
					}
				}*/
				/*if (p>30)
				{
					if (p==53)
							{
						System.out.println("hello");
							}
					int q=p-30;*/
					String rName=driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[1]/tr["+p+"]/td[1]/a/span")).getText().trim();
					//System.out.println("prevNameApp:"+rName);
					//System.out.println("privVal:"+selRole);
					//Thread.sleep(1000);
					if (rName.contains(selRole))
					{
						if (!driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[1]/tr["+p+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).isSelected())
						{
							driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[1]/tr["+p+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).click();
						}
						extent.log(LogStatus.INFO, "Role Name:"+rName+" checkbox is selected");
						extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "AdoptRole"));
						flag=true;
						break;
						
					}
				//}
			}
		}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickEditAccessRights(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			By earBtn=By.xpath(btnEditAccessRights);
			Utilities.waitForPageLoad(driver,earBtn);
			if (driver.findElements(earBtn).size()!=0)
			{					
				driver.findElement(earBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Edit Access Rights button is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Edit Access Rights button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean clickView(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			By viewBtn=By.xpath(btnView);
			Utilities.waitForPageLoad(driver,viewBtn);
			if (driver.findElements(viewBtn).size()!=0)
			{					
				driver.findElement(viewBtn).click();
				extent.log(LogStatus.INFO, "Clicked on View button is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on View button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectEmp_From_AccessRightsFrame(WebDriver driver,String Name) throws Exception
	{
		Boolean Temp1=false;
		try {
			Utilities.selectRightPaneView(driver);
			int rcAccRt=driver.findElements(By.xpath("//div[@id='workPaneWrapper']/div/div/table[@id='workpaneListWrapper']/tbody/tr")).size();
			System.out.println("rcAccRt:"+rcAccRt);
			for (int a=1;a<=rcAccRt;a++)
			{
				if (a<=15)
				{
				String empApp=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+a+"]/th/a/span")).getText().trim();
				//System.out.println("rolenameApp:"+empApp);
				//System.out.println("rolemeCreated:"+Name);
				Thread.sleep(1000);
				if (empApp.contains(Name))
				{					
					driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+a+"]/td[2]/nobr")).click();										
					Temp1=true;
					break;
				}}
			}
			if (Temp1==true)
			{
				//System.out.println("pass");
				extent.log(LogStatus.PASS, "Name: "+Name+" Created/Selected successfully");
				//captureScreenShot(driver,screenshotDir+"OrganizationNameValidation");				
			}
			else
			{
				extent.log(LogStatus.FAIL, "Unable to Create/Select Name: "+Name);
				//captureScreenShot(driver,screenshotDir+"RoleNameValidation");
				return Temp1 =false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return Temp1;
	
		
	}
}

