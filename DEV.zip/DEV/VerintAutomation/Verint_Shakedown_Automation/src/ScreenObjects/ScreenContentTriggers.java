
package ScreenObjects;

import java.io.BufferedReader;
import java.io.FileReader;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.Screen;

import Utilities.Utilities;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class ScreenContentTriggers {
	
	public static Screen sobj = new Screen ();
	public static ExtentReports extent = ExtentReports.get(ScreenContentTriggers.class);
	//public static String tabScreenContentTriggerTable="//table[@id='ctl00_MidPanelContentHolder_gridScreens_ctl00_ctl05_Detail10_ctl04_screenContentTriggerList_ctl00']";
	//public static String tabScreenContentTriggerTableRows="//table[@id='ctl00_MidPanelContentHolder_gridScreens_ctl00_ctl05_Detail10_ctl04_screenContentTriggerList_ctl00']/tbody/tr";
	public static String txtUniqueName="ctl00_MidPanelContentHolder_dockTriggerProperties_C_txtTriggerName";	
	public static String txtDisplayName="ctl00_MidPanelContentHolder_dockTriggerProperties_C_txtDisplayName";
	
	public static String txtAdditionalParameters="ctl00_MidPanelContentHolder_dockTriggerProperties_C_txtAdditionalParameters";
	public static String lstCommandToExecute="ctl00_MidPanelContentHolder_dockTriggerProperties_C_lstCommands_cbCommandList_Input";
	public static String txtEventCode="ctl00_MidPanelContentHolder_dockTriggerProperties_C_txtEventCode";	
		
	public static String txtUserGroup="ctl00_MidPanelContentHolder_dockTriggerProperties_C_cbUserGroups_Input";	
	public static String txtComputerGroup="ctl00_MidPanelContentHolder_dockTriggerProperties_C_cbComputerGroups_Input";
	
	public static String txtWindowBehaviourcriteria="ctl00_MidPanelContentHolder_dockTriggerProperties_C_dlWindowOpenEvents";
	public static String labelSelectedCriteria="//div[@id='ctl00_MidPanelContentHolder_dockSelectedCriteria']/table/tbody/tr/td[2]/div[@id='ctl00_MidPanelContentHolder_dockSelectedCriteria_T']";
	public static String btnAddNewScreen="//input[@id='ctl00_MidPanelContentHolder_btnAddScreen']";
	public static String lstDPAValidatorVersion="//input[@id='dlVersion_Input']";
	public static String btnGo="btnGo";
	public static String lstFind="//input[@id='ctl00_MidPanelContentHolder_lstTriggerNameSearch_lstSearchBy_Input']";
	public static String btnSearch="ctl00_MidPanelContentHolder_lstTriggerNameSearch_btnSearch";
	public static String txtSearchName="//input[@id='ctl00_MidPanelContentHolder_lstTriggerNameSearch_lstSearch_Input']";
	public static String btnSave="ctl00_MidPanelContentHolder_btnSave";
	public static String txtCriteriaValue="ctl00_MidPanelContentHolder_dockSelectedCriteria_C_rptItems_ctl01_criteria_txtValue";
	public static String chkHighlight="//input[@id='ctl00_MidPanelContentHolder_dockSelectedCriteria_C_rptItems_ctl01_criteria_cbHighlight'][@type='checkbox']";
	
	public static String btnActivateChanges="ctl00_MidPanelContentHolder_btnActivateChanges";
	public static String labelTriggerVersion="//span[@id='ctl00_MidPanelContentHolder_lblTriggerVersion']";
	
	public static boolean setAdditionalParameters(WebDriver driver,String AdditionalParameters)
	{
		boolean flag=false;
		try{		
			By addParamtxt=By.id(txtAdditionalParameters);
			Utilities.waitForPageLoad(driver,addParamtxt);
			if (driver.findElements(addParamtxt).size()!=0)
			{
				driver.findElement(addParamtxt).clear();
				driver.findElement(addParamtxt).sendKeys(AdditionalParameters);
				Thread.sleep(2000);
				
					
					extent.log(LogStatus.PASS, "Additional Parameters: "+AdditionalParameters +" is entered successfully");
					flag=true;
				
			}else
			{
				extent.log(LogStatus.FAIL, "Additional Parameters: "+AdditionalParameters +" is NOT entered");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean deleteTrigger(WebDriver driver,String ScreenName) throws Exception
	{
		Boolean flag=false;
		try {
			int rcTrigger=driver.findElements(By.xpath("//table[@id='ctl00_MidPanelContentHolder_gridScreens_ctl00']/tbody/tr")).size();
			System.out.println("rcTrigger:"+rcTrigger);
			if (rcTrigger>0)
			{
				for (int j=1;j<=rcTrigger;j++)
				{
					String ScreenNameApp=driver.findElement(By.xpath("//table[@id='ctl00_MidPanelContentHolder_gridScreens_ctl00']/tbody/tr[1]/td[2]")).getText().trim();
					System.out.println("ScreenNameApp:"+ScreenNameApp);
					System.out.println("ScreenNameApp:"+ScreenName);
					
					if (ScreenNameApp.contains(ScreenName))
					{
						System.out.println("match");
						if (driver.findElements(By.xpath("//table[@id='ctl00_MidPanelContentHolder_gridScreens_ctl00']/tbody/tr[1]/td[8]/input[@id='ctl00_MidPanelContentHolder_gridScreens_ctl00_ctl04_gbcbtnDelete']")).size()!=0)
						{
							driver.findElement(By.xpath("//table[@id='ctl00_MidPanelContentHolder_gridScreens_ctl00']/tbody/tr[1]/td[8]/input[@id='ctl00_MidPanelContentHolder_gridScreens_ctl00_ctl04_gbcbtnDelete']")).click();
						
							if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Delete_OK.png")!=null)
							{
								sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Delete_OK.png");
								flag=true;
							}
						}
						Thread.sleep(3000);						
						break;
					}
				}
				if (flag==true)
				{
					System.out.println("deletetrigger - pass");
					extent.log(LogStatus.PASS, "Trigger/Screen Name:"+ScreenName+" deleted Successfully");
					flag=true;
					//captureScreenShot(driver,screenshotDir+"OrganizationNameValidation");				
				}
				else
				{
					extent.log(LogStatus.INFO, "No Records were displayed/Not able to delete Trigger/Screen Name:"+ScreenName);
					//captureScreenShot(driver,screenshotDir+"RoleNameValidation");	
					flag=false;
				}
			}
			else
			{
				extent.log(LogStatus.FAIL, "Trigger is not displayed");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean clickActivateChanges(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{			
			By actChangesBtn=By.id(btnActivateChanges);
			Utilities.waitForPageLoad(driver,actChangesBtn);
			if (driver.findElements(actChangesBtn).size()!=0)
			{					
				driver.findElement(actChangesBtn).click();
				System.out.println("inside activate changes");
				extent.log(LogStatus.INFO, "Clicked on Activate Changes is successful");
				Thread.sleep(3000);
				flag=true;
			}else
			{
				System.out.println("not inside activatechanges");
				extent.log(LogStatus.FAIL, "Clicked on Activate Changes is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectHighlight(WebDriver driver)
	{
		boolean flag=false;
		try{		
			By highchk=By.xpath(chkHighlight);
			Utilities.waitForPageLoad(driver,highchk);
			if (driver.findElements(highchk).size()!=0)
			{
				Thread.sleep(2000);
				//driver.findElement(highchk).click();
				driver.findElement(By.xpath("//div[@id='ctl00_MidPanelContentHolder_ctl00_MidPanelContentHolder_dockSelectedCriteria_C_rptItemsPanel']/table/tbody/tr[1]/td[6]/span/input[@name='ctl00$MidPanelContentHolder$dockSelectedCriteria$C$rptItems$ctl01$criteria$cbHighlight'][@type='checkbox']")).click();
				Thread.sleep(2000);
				extent.log(LogStatus.PASS, "Highlight checkbox is selected successfully");
				flag=true;		
			}else
			{
				extent.log(LogStatus.FAIL, "Not able to select Highlight checkbox");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean setCriteriaValue(WebDriver driver,String CriteriaValue)
	{
		boolean flag=false;
		try{		
			By valuetxt=By.id(txtCriteriaValue);
			Utilities.waitForPageLoad(driver,valuetxt);
			if (driver.findElements(valuetxt).size()!=0)
			{
				//driver.findElement(valuetxt).clear();
				driver.findElement(valuetxt).sendKeys(CriteriaValue);
				Thread.sleep(2000);
				//if (driver.findElement(valuetxt).getText().contains(CriteriaValue))
				
					extent.log(LogStatus.PASS, "Criteria Value: "+CriteriaValue +" is entered successfully");
					flag=true;
				
			}else
			{
				extent.log(LogStatus.FAIL, "Criteria Value: "+CriteriaValue +" is NOT entered");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static void clickSave(WebDriver driver) throws Exception
	{
		try{			
			By saveBtn=By.id(btnSave);
			Utilities.waitForPageLoad(driver,saveBtn);
			if (driver.findElements(saveBtn).size()!=0)
			{					
				driver.findElement(saveBtn).click();
				System.out.println("inside save");
				extent.log(LogStatus.INFO, "Clicked on Save is successful");
				Thread.sleep(3000);
			}else
			{
				System.out.println("not inside search");
				extent.log(LogStatus.FAIL, "Clicked on Save is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static boolean selectCommandToExecute(WebDriver driver,String Command) throws Exception
	{
		boolean flag=false;
		try{
			By commandLst=By.id(lstCommandToExecute);
			Utilities.waitForPageLoad(driver,commandLst);
			if (driver.findElements(commandLst).size()!=0)
			{					
				System.out.println("inside command dropdown");
				driver.findElement(commandLst).click();
				Thread.sleep(2000);				
				int rcCommand=driver.findElements(By.xpath("//div[@id='ctl00_MidPanelContentHolder_dockTriggerProperties_C_lstCommands_cbCommandList_DropDown']/div/ul/li")).size();
				//driver.findElement(By.xpath("//div[@id='ctl00_MidPanelContentHolder_dockTriggerProperties_C_lstCommands_cbCommandList_DropDown']/div/ul/li[5]")).click();
				for (int c=1;c<=rcCommand;c++)
				{
					WebElement list=driver.findElement(By.xpath("//div[@id='ctl00_MidPanelContentHolder_dockTriggerProperties_C_lstCommands_cbCommandList_DropDown']/div/ul/li["+c+"]"));
					if (list.getText().trim().contains(Command))
					{
						System.out.println("list item:"+list.getText());
						list.click();
						Thread.sleep(3000);
						break;
					}
				}
				
			}else
			{
				extent.log(LogStatus.FAIL, "Not able to select "+Command+ " from Find dropdown");
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setDisplayName(WebDriver driver,String DisplayName)
	{
		boolean flag=false;
		try{		
			By disptxt=By.id(txtDisplayName);
			Utilities.waitForPageLoad(driver,disptxt);
			if (driver.findElements(disptxt).size()!=0)
			{
				driver.findElement(disptxt).clear();
				driver.findElement(disptxt).sendKeys(DisplayName);
				Thread.sleep(2000);
				
					
					extent.log(LogStatus.PASS, "Display Name: "+DisplayName +" is entered successfully");
					flag=true;
				
			}else
			{
				extent.log(LogStatus.FAIL, "Display Name: "+DisplayName +" is NOT entered");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean setUniqueName(WebDriver driver,String UniqueName)
	{
		boolean flag=false;
		try{		
			By uniquetxt=By.id(txtUniqueName);
			Utilities.waitForPageLoad(driver,uniquetxt);
			if (driver.findElements(uniquetxt).size()!=0)
			{
				driver.findElement(uniquetxt).clear();
				driver.findElement(uniquetxt).sendKeys(UniqueName);
				Thread.sleep(2000);
				//System.out.println(driver.findElement(uniquetxt).;
				//if (driver.findElement(uniquetxt).getText().trim().contains(UniqueName))
				
				//{
					extent.log(LogStatus.PASS, "Unique Name: "+UniqueName +" is entered successfully");	
					flag=true;
				/*//}
				else
				{
					flag=false;
				}*/
			}else
			{
				extent.log(LogStatus.FAIL, "Unique Name: "+UniqueName +" is NOT entered");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickCapturedTrigger(WebDriver driver,String ScreenName) throws Exception
	{	
		Boolean Temp1=false;
		String screenNameApp="";
		try {
			int rcTrigger=driver.findElements(By.xpath("//table[@id='ctl00_MidPanelContentHolder_gridScreens_ctl00']/tbody/tr")).size();
			System.out.println("rcTrigger:"+rcTrigger);
			if (rcTrigger>0)
			{
				for (int j=1;j<=rcTrigger;j++)
				{
					screenNameApp=driver.findElement(By.xpath("//table[@id='ctl00_MidPanelContentHolder_gridScreens_ctl00']/tbody/tr[1]/td[2]")).getText().trim();
					System.out.println("screenNameApp:"+screenNameApp);
					System.out.println("screenName:"+ScreenName);
					
					if (screenNameApp.contains(ScreenName))
					{
						System.out.println("match");
						extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Trigger"));
						driver.findElement(By.xpath("//input[@title='Add New Trigger']")).click();
						//driver.findElement(By.xpath("////table[@id='ctl00_MidPanelContentHolder_gridScreens_ctl00']/tbody/tr[2]/td[2]/table/tbody/tr[1]/td[1]/table/tbody/tr[2]/td[1]/input[@title='Add New Trigger']")).click();
						//driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).click();
						Temp1=true;
						break;
					}
				}
				if (Temp1==true)
				{
					System.out.println("click trigger - pass");
					extent.log(LogStatus.PASS, "Clicked on Captured Trigger is Successful");
					//captureScreenShot(driver,screenshotDir+"OrganizationNameValidation");				
				}
				else
				{
					extent.log(LogStatus.FAIL, "Not able to click on Captured Trigger."+screenNameApp+" is displayed");
					extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Trigger"));
					//captureScreenShot(driver,screenshotDir+"RoleNameValidation");
					return Temp1 =false;
				}
			}
			else
			{
				extent.log(LogStatus.FAIL, "Trigger is not displayed");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return Temp1;
		
	}
	
	
	public static boolean setSearchByName(WebDriver driver,String UniqueName)
	{
		Boolean flag=false;
		try{		
			By searchNametxt=By.xpath(txtSearchName);
			Utilities.waitForPageLoad(driver,searchNametxt);
			if (driver.findElements(searchNametxt).size()!=0)
			{
				driver.findElement(searchNametxt).clear();
				driver.findElement(searchNametxt).sendKeys(UniqueName);
				Thread.sleep(2000);
				extent.log(LogStatus.PASS, "Search Name: "+UniqueName +" is entered successfully");		
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Search Name: "+UniqueName +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickSearch(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{			
			By searchBtn=By.id(btnSearch);
			Utilities.waitForPageLoad(driver,searchBtn);
			if (driver.findElements(searchBtn).size()!=0)
			{					
				driver.findElement(searchBtn).click();
				System.out.println("inside search");
				extent.log(LogStatus.INFO, "Clicked on Search is successful");
				Thread.sleep(3000);
				flag=true;
			}else
			{
				System.out.println("not inside search");
				extent.log(LogStatus.FAIL, "Clicked on Search is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean selectFind(WebDriver driver,String Name) throws Exception
	{
		boolean flag=false;
		try{
			By findLst=By.xpath(lstFind);
			Utilities.waitForPageLoad(driver,findLst);
			if (driver.findElements(findLst).size()!=0)
			{					
				System.out.println("inside Find dropdown");
				driver.findElement(findLst).click();
				Thread.sleep(2000);
				if (Name.contains("Screen Name"))
				{
					driver.findElement(By.xpath("//div[@id='ctl00_MidPanelContentHolder_lstTriggerNameSearch_lstSearchBy_DropDown']/div/ul/li[3]")).click();
					extent.log(LogStatus.INFO, Name+ " selected from Find dropdown");
					Thread.sleep(1000);
					flag=true;
				}
				else
				{
					extent.log(LogStatus.INFO, " Please select Screen Name and try again");
					return flag=false;
				}
			
				
			}else
			{
				extent.log(LogStatus.FAIL, "Not able to select "+Name+ " from Find dropdown");
				flag=false;
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static void selectDPAValidatorVersion(WebDriver driver,String Version) throws Exception
	{
		try{
			WebElement validator = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.name("winAddScreen")));
			driver.switchTo().frame(validator);
			By lstVersion=By.xpath(lstDPAValidatorVersion);
			Utilities.waitForPageLoad(driver,lstVersion);
			if (driver.findElements(lstVersion).size()!=0)
			{					
				
				driver.findElement(lstVersion).click();
				Thread.sleep(2000);
				if (Version.contains("32 bit"))
				{
					driver.findElement(By.xpath("//div[@id='dlVersion_DropDown']/div/ul/li[1]")).click();
				}
				else if (Version.contains("64 bit"))
				{
					driver.findElement(By.xpath("//div[@id='dlVersion_DropDown']/div/ul/li[2]")).click();
				}
				
				/*List<WebElement> liList = driver.findElements(By.xpath("//div[@id='dlVersion_DropDown']/div/ul/li"));
				 System.out.println("list count:"+liList.size()); 
				liList.get(1).click();*/
				extent.log(LogStatus.INFO, Version+ " selected from DPA Validator Version dropdown");
				Thread.sleep(1000);
			}else
			{
				extent.log(LogStatus.FAIL, "Not able to select "+Version+ " selected from DPA Validator Version dropdown");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static void clickAddNewScreen(WebDriver driver) throws Exception
	{
		try{
			By addnewscreenBtn=By.xpath(btnAddNewScreen);
			Utilities.waitForPageLoad(driver,addnewscreenBtn);
			if (driver.findElements(addnewscreenBtn).size()!=0)
			{					
				driver.findElement(addnewscreenBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Add New Screen button is successful");
				Thread.sleep(8000);
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Add New Screen button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	//@SuppressWarnings("resource")
	public static String filePathTriggerVersion(WebDriver driver,String Path) throws Exception
	{		
		String versiondef="";
		try{
			//get version number from .def file
			//String TestFile = "C:\\DEV\\PcMonTrig2.def";
			FileReader FR = new FileReader(Path);
			BufferedReader BR = new BufferedReader(FR);
			String Content = "";	  
			
			while((Content = BR.readLine())!= null)
			{
				System.out.println("line:"+Content);
				//String defVersion=Content;
				String[] defVersion=Content.split(" ");
				versiondef=defVersion[1].trim();	
				System.out.println("def file version:"+versiondef);
				break;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return versiondef;
	}
	
	public static String checkTriggerVersion(WebDriver driver) throws Exception
	{
		String versionNum="";
		By triggerverlabel=By.xpath(labelTriggerVersion);
		Utilities.waitForPageLoad(driver,triggerverlabel);
		if (driver.findElements(By.id("ctl00_MidPanelContentHolder_btnActivateChanges")).size()!=0)
		{
			driver.findElement(By.id("ctl00_MidPanelContentHolder_btnActivateChanges")).click();
			Thread.sleep(3000);
		}
		if (driver.findElements(triggerverlabel).size()!=0)
		{			
			String triggerVersion=driver.findElement(triggerverlabel).getText();
			String[] version=triggerVersion.split(":");
			if (version.length>0)
			{
				versionNum=version[1].trim();
				extent.log(LogStatus.PASS, "Trigger Version:"+versionNum+ " is displayed");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Trigger"));
				System.out.println("App version:"+versionNum);
			}
		}
		else
		{
			extent.log(LogStatus.FAIL, "Trigger Version is not displayed");
		}
		return versionNum;
	}
	
	
	
	public static void verifyScreenContentTriggerProperties(WebDriver driver) throws Exception
	{
		//Utilities.waitForPageLoad(driver,By.id(txtUniqueName));
		Thread.sleep(5000);
		//verify trigger properties
		if (driver.findElements(By.id(txtUniqueName)).size()!=0)											   
		{
			extent.log(LogStatus.PASS, "Trigger Properties : Unique Name is displayed as Expected");			
		}
		else
		{
			extent.log(LogStatus.FAIL, "Trigger Properties : Unique Name is NOT displayed as Expected");
		}
		Thread.sleep(2000);
		if (driver.findElements(By.id(txtDisplayName)).size()!=0)
		{
			extent.log(LogStatus.PASS, "Trigger Properties : Display Name is displayed as Expected");			
		}
		else
		{
			extent.log(LogStatus.FAIL, "Trigger Properties : Display Name is NOT displayed as Expected");
		}
		Thread.sleep(2000);
		if (driver.findElements(By.id(txtEventCode)).size()!=0)
		{
			extent.log(LogStatus.PASS, "Trigger Properties : Event Code is displayed as Expected");			
		}
		else
		{
			extent.log(LogStatus.FAIL, "Trigger Properties : Event Code is NOT displayed as Expected");
		}
		Thread.sleep(2000);
		/*if (driver.findElements(By.id("ctl00_MidPanelContentHolder_dockTriggerProperties_C_lstCommands_cbCommandList_Input")).size()!=0 )
		{								 ctl00_MidPanelContentHolder_dockTriggerProperties_C_lstCommands_cbCommandList_Input
			
		}*/
		if (driver.findElements(By.id(txtAdditionalParameters)).size()!=0)
		{
			extent.log(LogStatus.PASS, "Trigger Properties : Additional Parameters is displayed as Expected");			
		}
		else
		{
			extent.log(LogStatus.FAIL, "Trigger Properties : Additional Parameters is NOT displayed as Expected");
		}
		Thread.sleep(2000);
		/*if (driver.findElements(By.id(txtUserGroup)).size()!=0 )
		{
			extent.log(LogStatus.PASS, "Trigger Properties : User Group is displayed as Expected");			
		}
		else
		{
			extent.log(LogStatus.FAIL, "Trigger Properties : User Group is NOT displayed as Expected");
		}
		Thread.sleep(2000);
		if (driver.findElements(By.id(txtComputerGroup)).size()!=0)
		{
			extent.log(LogStatus.PASS, "Trigger Properties : Computer Group is displayed as Expected");			
		}
		else
		{
			extent.log(LogStatus.FAIL, "Trigger Properties : Computer Group is NOT displayed as Expected");
		}
		Thread.sleep(2000);
		if (driver.findElements(By.id(txtWindowBehaviourcriteria)).size()!=0 )					
		{
			extent.log(LogStatus.PASS, "Trigger Properties : Window Behaviour criteria is displayed as Expected");			
		}
		else
		{
			extent.log(LogStatus.FAIL, "Trigger Properties :  Window Behaviour criteria is NOT displayed as Expected");
		}*/
		Thread.sleep(2000);
		String criteria=driver.findElement(By.xpath(labelSelectedCriteria)).getText();
		if (criteria.contains("Selected Criteria"))
		{
			extent.log(LogStatus.PASS, "Selected Criteria is displayed as Expected");			
		}
		else
		{
			extent.log(LogStatus.FAIL, "Selected Criteria is NOT displayed as Expected");
		}
		
	}
	
	/*public static void selectScreenContentTrigger(WebDriver driver,String TriggerName) throws Exception
	{
		if (driver.findElements(By.xpath(tabScreenContentTriggerTable)).size()!=0)
		{
			extent.log(LogStatus.PASS, "Screen Content Triggers Table is displayed");
			int sctrc=driver.findElements(By.xpath(tabScreenContentTriggerTableRows)).size();
			System.out.println("sctrc:"+sctrc);
			if (sctrc!=0)
			{
				for (int s=1;s<=sctrc;s++)				
				{
					String triggerNameApp=driver.findElement(By.xpath("//table[@id='ctl00_MidPanelContentHolder_gridScreens_ctl00_ctl05_Detail10_ctl04_screenContentTriggerList_ctl00']/tbody/tr["+s+"]/td[3]/a")).getText().trim();
					System.out.println("triggerApp:"+triggerNameApp);
					System.out.println("send:"+TriggerName);					
					Thread.sleep(5000);
					if	(TriggerName=="")
					{
						System.out.println("select trigger inside");
						//driver.findElement(By.linkText(triggerNameApp)).click();
						driver.findElement(By.xpath("//table[@id='ctl00_MidPanelContentHolder_gridScreens_ctl00_ctl05_Detail10_ctl04_screenContentTriggerList_ctl00']/tbody/tr[1]/td[3]/a")).click();
						//driver.findElement(By.xpath("//table[@id='ctl00_MidPanelContentHolder_gridScreens_ctl00_ctl05_Detail10_ctl04_screenContentTriggerList_ctl00']/tbody/tr[1]/td[3]/a")).click();
						break;
					}
					if (triggerNameApp.contains(TriggerName))
					{
						driver.findElement(By.linkText(TriggerName)).click();
						//driver.findElement(By.xpath("//table[@id='ctl00_MidPanelContentHolder_gridScreens_ctl00_ctl05_Detail10_ctl04_screenContentTriggerList_ctl00']/tbody/tr["+s+"]/td[3]/a")).click();
						break;
					}
				
					
					Thread.sleep(5000);
				}
			}
			else
			{
				extent.log(LogStatus.WARNING, "No data/rows found under Screen Content Triggers Table");				
			}
		}
		else
		{
			extent.log(LogStatus.FAIL, "Screen Content Triggers Table is NOT displayed");
		}
	}*/
	public static void clickGo(WebDriver driver) throws Exception
	{
		try{
			//div[@class='buttonPanel']/
			/*WebElement validator = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.name("winAddScreen")));
			driver.switchTo().frame(validator);*/
			Thread.sleep(10000);
			By goBtn=By.id(btnGo);
			Utilities.waitForPageLoad(driver,goBtn);
			if (driver.findElements(goBtn).size()!=0)
			{					
				driver.findElement(goBtn).click();
				System.out.println("inside go");
				extent.log(LogStatus.INFO, "Clicked on Go button is successful");
				Thread.sleep(3000);
			}else
			{
				System.out.println("not inside go");
				extent.log(LogStatus.FAIL, "Clicked on Go button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	

}
