package ScreenObjects;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.relevantcodes.extentreports.LogStatus;
import Utilities.Utilities;
import com.relevantcodes.extentreports.ExtentReports;


public class LoginScreen {
	
	public static ExtentReports extent = ExtentReports.get(LoginScreen.class);	
	public static String txtUsername="username";
	public static String txtPassword="password";
	public static String btnLogin="loginToolbar_LOGINLabel";

	public static void launchVerint(WebDriver driver,String URL) throws Exception
	{		
		//Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe");
		//Runtime.getRuntime().exec("taskkill /F /IM iexplore.exe");
		Runtime.getRuntime().exec( "wscript C:/DEV/cookies.vbs" );
		Thread.sleep(15000);
		driver.get(URL);
		extent.log(LogStatus.INFO, "Navigated to "+URL);
		Thread.sleep(4000);
		
		Set<String> handles = driver.getWindowHandles();
		for(String handle : handles)
		{
			if(!driver.equals(handle))
			{            
				driver.switchTo().window(handle);            
			}
		}   
		Utilities.Logout(driver);
		extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "LoginScreen"));
		Thread.sleep(2000);
		driver.manage().window().maximize();
	}
	
	public static boolean verifyLoginPageLaunched(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try {			
			By uidtxt=By.id(txtUsername);
			Utilities.waitForPageLoad(driver,uidtxt);
			if (driver.findElements(uidtxt).size()!=0)
			{
				extent.log(LogStatus.INFO, "Verint Login page launched successfully");
			}else
			{
				extent.log(LogStatus.FAIL, "Verint Login page NOT launched");
				//Utilities.captureScreenShot(driver,screenshotDir+"Login");
				return flag =false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;			
	}
	public static boolean setTextInUsername(WebDriver driver,String Username)
	{
		boolean flag=true;
		try{		
			By uidtxt=By.id(txtUsername);
			Utilities.waitForPageLoad(driver,uidtxt);
			if (driver.findElements(uidtxt).size()!=0)
			{
				driver.findElement(uidtxt).sendKeys(Username);
				extent.log(LogStatus.PASS, "User ID: "+Username +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "User ID: "+Username +" is NOT entered");
				return flag =false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static void setTextInPassword(WebDriver driver,String Password) throws Exception
	{
		try{
			By pwd=By.id(txtPassword);
			Utilities.waitForPageLoad(driver,pwd);
			if (driver.findElements(pwd).size()!=0)
			{
				driver.findElement(pwd).sendKeys(Password);	
				extent.log(LogStatus.PASS, "Password: ******* is entered successfully");
			}else
			{
				extent.log(LogStatus.FAIL, "Password: ******* is NOT entered");
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void clickLogin(WebDriver driver) throws Exception
	{		
		try{
			By btn=By.id(btnLogin);
			Utilities.waitForPageLoad(driver,btn);
			if (driver.findElements(btn).size()!=0)
			{					
				driver.findElement(btn).click();
				Thread.sleep(1000);
				extent.log(LogStatus.PASS, "Clicked on Login button is successful");
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Login button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

}
