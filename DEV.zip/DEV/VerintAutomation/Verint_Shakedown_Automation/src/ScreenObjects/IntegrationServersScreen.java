package ScreenObjects;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class IntegrationServersScreen {
	
	public static ExtentReports extent = ExtentReports.get(IntegrationServersScreen.class);
	public static String btnEditConfig="//button[@id='Toolbar_8_EDIT_ACTIONLabel']";
	public static String btnAssignRight="//button[@id='sbox4_tb_ASSIGN_RIGHTLabel']";
	public static String btnSave="//button[@id='Toolbar_7_EDIT_ACTIONLabel']";
	
	public static boolean clickSave(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			Utilities.selectRightPaneView(driver);
			By saveBtn=By.xpath(btnSave);
			Utilities.waitForPageLoad(driver,saveBtn);
			if (driver.findElements(saveBtn).size()!=0)
			{					
				driver.findElement(saveBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Save button is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Save button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickAssignRight(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			Utilities.selectRightPaneView(driver);
			By assignRtBtn=By.xpath(btnAssignRight);
			Utilities.waitForPageLoad(driver,assignRtBtn);
			if (driver.findElements(assignRtBtn).size()!=0)
			{					
				driver.findElement(assignRtBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Assign Right button is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Assign Right button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectSelectedComponents(WebDriver driver,String ComponentName) throws Exception
	{
		Boolean flag=false;
		try {
			Utilities.selectRightPaneView(driver);
			int rc=driver.findElements(By.xpath("//table[@id='sbox4_dstTable']/tbody/tr")).size();
			for (int s=1;s<=rc;s++)
			{
				String compNameApp=driver.findElement(By.xpath("//table[@id='sbox4_dstTable']/tbody/tr["+s+"]/td/a/span")).getText().trim();
				System.out.println("verifyselectcompNameApp:"+compNameApp+";"+ComponentName);
				if (compNameApp.contains(ComponentName))
				{
					driver.findElement(By.xpath("//table[@id='sbox4_dstTable']/tbody/tr["+s+"]/td/a/span")).click();
					extent.log(LogStatus.PASS, "Component Name: "+ComponentName+" is displayed under Selected Components");
					flag=true;
					break;
				}
			}
			if (flag==false)
			{
				extent.log(LogStatus.FAIL, "Component Name: "+ComponentName+" is NOT displayed under Selected Components");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "AdaptorSettings"));
			}else 
			{
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "AdaptorSettings"));
			}
				
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;	
	}
	public static boolean verifySelectedComponents(WebDriver driver,String ComponentName) throws Exception
	{
		Boolean flag=false;
		try {
			Utilities.selectRightPaneView(driver);
			int rc=driver.findElements(By.xpath("//table[@id='sbox4_dstTable']/tbody/tr")).size();
			for (int s=1;s<=rc;s++)
			{
				String compNameApp=driver.findElement(By.xpath("//table[@id='sbox4_dstTable']/tbody/tr["+s+"]/td/a/span")).getText().trim();
				System.out.println("verifyselectcompNameApp:"+compNameApp+";"+ComponentName);
				if (compNameApp.contains(ComponentName))
				{
					driver.findElement(By.xpath("//table[@id='sbox4_dstTable']/tbody/tr["+s+"]/td/a/span")).click();
					extent.log(LogStatus.PASS, "Component Name: "+ComponentName+" is displayed under Selected Components");
					flag=true;
					break;
				}
			}
			if (flag==false)
			{
				extent.log(LogStatus.INFO, "Component Name: "+ComponentName+" is NOT displayed under Selected Components");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;	
	}
	public static boolean selectAvailableComponents(WebDriver driver,String ComponentName) throws Exception
	{
		Boolean flag=false;
		try {
			Utilities.selectRightPaneView(driver);
			int rc=driver.findElements(By.xpath("//table[@id='sbox4_srcTable']/tbody/tr")).size();
			for (int s=1;s<=rc;s++)
			{
				String compNameApp=driver.findElement(By.xpath("//table[@id='sbox4_srcTable']/tbody/tr["+s+"]/td/a/span")).getText().trim();
				System.out.println("selectAvialcompNameApp:"+compNameApp+";"+ComponentName);
				if (compNameApp.contains(ComponentName))
				{
					driver.findElement(By.xpath("//table[@id='sbox4_srcTable']/tbody/tr["+s+"]/td/a/span")).click();
					extent.log(LogStatus.PASS, "Available Component Name: "+ComponentName+" selected successfully");
					flag=true;
					break;
				}
			}
			if (flag==false)
			{
				extent.log(LogStatus.FAIL, "Not able to select Available Component Name: "+ComponentName);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;	
	}
	
	public static boolean selectIntegrationPackageName(WebDriver driver,String PackageName) throws Exception
	{
		Boolean flag=false;
		try {
			Utilities.selectLeftTreeFrame(driver);
			Thread.sleep(1000);			
			String integrationServer;
			int rc=driver.findElements(By.xpath("//div[@id='SingleColTree2r0Nodes']/div")).size();
			System.out.println("size:"+rc);
			for (int i=0;i<rc/2;i++)
			{
				integrationServer=driver.findElement(By.xpath("//div[@id='SingleColTree2r0r"+i+"']/nobr/a/span/span")).getText();
				System.out.println("IS:"+integrationServer);
				if (integrationServer.contains(PackageName))
				{
					driver.findElement(By.xpath("//div[@id='SingleColTree2r0r"+i+"']/nobr/a/span/span")).click();
					extent.log(LogStatus.PASS, "Integration Package Name: "+PackageName+" selected successfully");
					flag=true;
					break;
				}
			}
			if (flag==false)
			{
				extent.log(LogStatus.FAIL, "Unable to select Integration Package Name: "+PackageName);
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;			
	}
	public static boolean selectIntegrationServerName(WebDriver driver,String ServerName) throws Exception
	{
		Boolean Temp1=false;
		try {
			
			int rcIS=driver.findElements(By.xpath("//div[@id='MCList3Wrapper']/table/tbody/tr")).size();
			System.out.println("rcOrg:"+rcIS);
			for (int s=1;s<=rcIS;s++)
			{
				if (s<=10)
				{
				String serverApp=driver.findElement(By.xpath("//div[@id='MCList3Wrapper']/table/tbody/tr["+s+"]/th/a/span")).getText().trim();
				System.out.println("serverApp:"+serverApp);
				System.out.println("ServerName:"+ServerName);
				Thread.sleep(1000);
				if (serverApp.contains(ServerName))
				{					
					driver.findElement(By.xpath("//div[@id='MCList3Wrapper']/table/tbody/tr["+s+"]/th/a/span")).click();										
					Temp1=true;
					break;
				}}
			}
			if (Temp1==true)
			{
				System.out.println("pass");
				extent.log(LogStatus.PASS, "Server Name: "+ServerName+" Created/Selected successfully");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "IntegrationServer"));				
			}
			else
			{
				extent.log(LogStatus.FAIL, "Unable to Create/Select Server Name: "+ServerName);
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "IntegrationServer"));
				return Temp1 =false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return Temp1;	
	}
	
	public static boolean clickEditConfiguration(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			By editConfigBtn=By.xpath(btnEditConfig);
			Utilities.waitForPageLoad(driver,editConfigBtn);
			if (driver.findElements(editConfigBtn).size()!=0)
			{					
				driver.findElement(editConfigBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Edit Configuration button is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Edit Configuration button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
}

