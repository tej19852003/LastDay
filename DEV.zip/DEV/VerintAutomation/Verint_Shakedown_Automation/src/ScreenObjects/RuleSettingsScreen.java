package ScreenObjects;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class RuleSettingsScreen {

	public static ExtentReports extent = ExtentReports.get(Impact360Screen.class);
	public static String btnCreate="//button[@id='toolbar_CREATE_RULELabel']";
	public static String txtRulename="ruleName";
	public static String txtRuledesc="ruleDescription";
	public static String btnRuleSave="toolbar_SAVE_RULELabel";
	public static String btnYes="toolbar_CREATE_RULE_YES_DIALOGLabel";
	//public static String lnkSchedule="//span[@id='RULE_SCHEDULE_spn_id']/a";
	public static String lnkSchedule="Schedule";
	//public static String lnkCondition="//span[@id='RULE_CONDITIONS_spn_id']/a";
	public static String lnkCondition="Condition";
	public static String lnkSettings="Settings";
	public static String btnScheduleSave="toolbar_SAVE_RULE_SCHEDULELabel";
	public static String btnAdd="FREE_EXP_DYNAMIC_LIST_toolbar_ADD_ACTIONLabel";
	public static String imgSelectAttribute="//img[@id='freeExpAttributeID_0_IMGID_img_id']";
	public static String imgConditionValue="//img[@id='freeExpInputValue_0_IMGID'][@alt='Select']";
	public static String btnSet="//button[@id='workpaneMediator_toolbar_POPUP_JSFUNCTIONLabel']";
	public static String btnConditionSave="//button[@id='toolbar_SAVE_RULE_CONDITIONLabel']";
	public static String labelTxtMsg="//div[@id='workPaneWrapper']/table[@id='viewfindPane_tbl_id']/tbody/tr/td[2]/div[1]/div";
	public static String btnDelete="//button[@id='toolbar_DELETE_RULELabel']";
	
	
	public static boolean clickSettinglnk(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{
			driver.switchTo().defaultContent();
			By settingslnk=By.linkText(lnkSettings);
			Utilities.waitForPageLoad(driver,settingslnk);
			if (driver.findElements(settingslnk).size()!=0)
			{					
				driver.findElement(settingslnk).click();
				extent.log(LogStatus.PASS, "Clicked on Settings link is successful");
				Thread.sleep(8000);
			}else
			{
				//driver.findElement(schedulelnk).click();
				extent.log(LogStatus.INFO, "Clicked on Settings link is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickDelete(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{
			driver.switchTo().defaultContent();
			Utilities.selectRightPaneView(driver);
			By delbtn=By.xpath(btnDelete);
			Utilities.waitForPageLoad(driver,delbtn);
			if (driver.findElements(delbtn).size()!=0)
			{					
				driver.findElement(delbtn).click();
				extent.log(LogStatus.PASS, "Clicked on Delete button is successful");
				Thread.sleep(6000);
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Delete button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectRule(WebDriver driver,String RuleName) throws Exception
	{
		driver.switchTo().defaultContent();		
		Utilities.selectLeftTreeFrame(driver);
		Boolean Temp1=false;
		try {
			int valrcRule=driver.findElements(By.xpath("//table[@id='ruleSelectionLIST_TBL_NAME']/tbody/tr")).size();
			//System.out.println("valrcrule:"+valrcRule);
			for (int p=1;p<=valrcRule;p++)
			{
				if (p<=15)
				{
				String rulenameApp=driver.findElement(By.xpath("//table[@id='ruleSelectionLIST_TBL_NAME']/tbody/tr["+p+"]/td/div/nobr/a/span")).getText().trim();
				//System.out.println("rulenameApp:"+rulenameApp);
				//System.out.println("rulenameCreated:"+RuleName);
				
				if (rulenameApp.contains(RuleName))
				{
					driver.findElement(By.xpath("//table[@id='ruleSelectionLIST_TBL_NAME']/tbody/tr["+p+"]/td/div/nobr/a/span")).click();					
					Temp1=true;
					break;
				}}
			}
			if (Temp1==true)
			{
				//System.out.println("pass");
				extent.log(LogStatus.PASS, "Name: "+RuleName+" Created/Selected successfully");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "RecordingRule"));				
			}
			else
			{
				extent.log(LogStatus.FAIL, "Unable to Create/Select Ruler Name: "+RuleName);
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "RecordingRule"));
				return Temp1 =false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return Temp1;
		
	}
	
	public static boolean verifyRule(WebDriver driver,String RuleName) throws Exception
	{
		driver.switchTo().defaultContent();		
		Utilities.selectLeftTreeFrame(driver);
		Boolean Temp1=false;
		try {
			int valrcRule=driver.findElements(By.xpath("//table[@id='ruleSelectionLIST_TBL_NAME']/tbody/tr")).size();
			//System.out.println("valrcrule:"+valrcRule);
			for (int p=1;p<=valrcRule;p++)
			{
				if (p<=15)
				{
				String rulenameApp=driver.findElement(By.xpath("//table[@id='ruleSelectionLIST_TBL_NAME']/tbody/tr["+p+"]/td/div/nobr/a/span")).getText().trim();
				//System.out.println("rulenameApp:"+rulenameApp);
				//System.out.println("rulenameCreated:"+RuleName);
				
				if (rulenameApp.contains(RuleName))
				{
					driver.findElement(By.xpath("//table[@id='ruleSelectionLIST_TBL_NAME']/tbody/tr["+p+"]/td/div/nobr/a/span")).click();					
					Temp1=true;
					break;
				}}
			}
			if (Temp1==true)
			{
				//System.out.println("pass");
				extent.log(LogStatus.INFO, "Name: "+RuleName+" already exist");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "RecordingRule"));				
			}
			else
			{
				extent.log(LogStatus.INFO, "RuleName:"+RuleName+" does not exist. Please create.");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "RecordingRule"));
				return Temp1 =false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return Temp1;
		
	}
	
	
	
	public static boolean verifySuccessMessage(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{
			By messageTxt=By.xpath(labelTxtMsg);
			//Utilities.waitForPageLoad(driver,impDomUserBtn);
			Thread.sleep(6000);
			//System.out.println("msg:"+driver.findElement(messageTxt));
			if (driver.findElements(messageTxt).size()!=0)
			{					
				String msg=driver.findElement(By.xpath("//div[@id='workPaneWrapper']/table[@id='viewfindPane_tbl_id']/tbody/tr/td[2]/div[1]/div")).getText();
				if (msg.contains("Successfully"))
				{
					extent.log(LogStatus.PASS, "Message:"+msg+" is displayed");
					Thread.sleep(3000);
					extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "RecordingRule"));
				}
				else
				{
					extent.log(LogStatus.FAIL, "Message:"+msg+" is displayed");
					extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "RecordingRule"));
					return flag=false;
				}
			}else
			{
				extent.log(LogStatus.WARNING, "Success message is not displayed");
				return flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean clickConditionSave(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{
			driver.switchTo().defaultContent();
			Utilities.selectRightPaneView(driver);
			By condSavebtn=By.xpath(btnConditionSave);
			Utilities.waitForPageLoad(driver,condSavebtn);
			if (driver.findElements(condSavebtn).size()!=0)
			{					
				driver.findElement(condSavebtn).click();
				extent.log(LogStatus.PASS, "Clicked on Condition - Save button is successful");
				Thread.sleep(6000);
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Condition - Save button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectConditionValue(WebDriver driver, String ConditionValue) throws Exception
	{
		boolean flag=true;
		boolean Temp1=false;
		String mainWind="";
		try{
			By condValimg=By.xpath(imgConditionValue);
			Utilities.waitForPageLoad(driver,condValimg);
			if (driver.findElements(condValimg).size()!=0)
			{					
				driver.findElement(condValimg).click();				
				extent.log(LogStatus.PASS, "Clicked on Condition Value Selection icon is successful");
				Thread.sleep(6000);
				mainWind=Utilities.setWindowFocus(driver);
				Thread.sleep(2000);
				//System.out.println("rows:"+driver.findElements(By.xpath("//table[@id='employeeOrganizationSelectorPC_id']/tbody/tr")).size());
				if (driver.findElements(By.xpath("//table[@id='employeeOrganizationSelectorPC_id']/tbody/tr")).size()!=0)
				{
					int rcOrg=driver.findElements(By.xpath("//table[@id='employeeOrganizationSelectorPC_id']/tbody/tr")).size();
					//System.out.println("rcOrg:"+rcOrg);
					for (int p=1;p<=rcOrg;p++)
					{
						String orgApp=driver.findElement(By.xpath("//table[@id='employeeOrganizationSelectorPC_id']/tbody/tr["+p+"]/td[2]/label/span")).getText().trim();
						//System.out.println("orgApp:"+orgApp);
						//System.out.println("orgname:"+ConditionValue);
						Thread.sleep(1000);
						if (orgApp.contains(ConditionValue))
						{					
							driver.findElement(By.xpath("//table[@id='employeeOrganizationSelectorPC_id']/tbody/tr["+p+"]/td[1]/span/input[@name='checkedOrgID'][@type='radio']")).click();										
							Temp1=true;
							break;
						}
					}
					if (Temp1==true)
					{
						//System.out.println("pass");
						extent.log(LogStatus.PASS, "Condition Value : "+ConditionValue+" Selected successfully");
						if (driver.findElements(By.xpath(btnSet)).size()!=0)
						{
							driver.findElement(By.xpath(btnSet)).click();
							Thread.sleep(3000);
							extent.log(LogStatus.INFO, "Clicked on Set button in Condition Value Selection popup window");
						}
						else
						{
							extent.log(LogStatus.WARNING, "Not able to Clicked on Set button in Condition Value Selection popup window");
							return flag=false;
						}
						//captureScreenShot(driver,screenshotDir+"OrganizationNameValidation");				
					}
					else
					{
						extent.log(LogStatus.FAIL, "Unable to Select Condition Value : "+ConditionValue);
						//captureScreenShot(driver,screenshotDir+"RoleNameValidation");
						return flag =false;
					}
				}
				else
				{
					extent.log(LogStatus.FAIL, "Condition Value Selection popup window is not displayed");
				}			
			}
			else
			{
				extent.log(LogStatus.FAIL, "Clicked on Condition Value Selection is un successful");
				return flag=false;
			}
				
		}catch (Exception e) {
			e.printStackTrace();
		}
		driver.switchTo().window(mainWind);
		return flag;
	}
	
	public static boolean selectAttribute(WebDriver driver,String AttributName) throws Exception
	{		
		boolean flag=true;
		boolean Temp=false;
		try{
			By attimg=By.xpath(imgSelectAttribute);
			Utilities.waitForPageLoad(driver,attimg);
			if (driver.findElements(attimg).size()!=0)
			{					
				driver.findElement(attimg).click();				
				extent.log(LogStatus.PASS, "Clicked on Add button is successful");
				Thread.sleep(2000);
				int rulerc=driver.findElements(By.xpath("//table[@id='AttributeTree_id']/tbody/tr")).size();
				//System.out.println("rulerowc:"+rulerc);
				for (int p=1;p<=rulerc;p++)
				{
					String attributName=driver.findElement(By.xpath("//table[@id='AttributeTree_id']/tbody/tr["+p+"]/th/a/span")).getText().trim();
					//System.out.println("attributNameApp:"+attributName);
					//System.out.println("AttributName:"+AttributName);
					Thread.sleep(1000);
					if (attributName.contains(AttributName))
					{
						driver.findElement(By.xpath("//table[@id='AttributeTree_id']/tbody/tr["+p+"]/th/a/span")).click();
						Temp=true;
						break;
						
					}
				}
				if (Temp==false)
				{
					return flag=false;
				}
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Select Attribute is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickAdd(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{
			driver.switchTo().defaultContent();
			Utilities.selectRightPaneView(driver);
			By addbtn=By.id(btnAdd);
			Utilities.waitForPageLoad(driver,addbtn);
			if (driver.findElements(addbtn).size()!=0)
			{					
				driver.findElement(addbtn).click();
				extent.log(LogStatus.PASS, "Clicked on Add button is successful");
				Thread.sleep(6000);
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Add button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickConditionlnk(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{
			driver.switchTo().defaultContent();
			By conditionlnk=By.linkText(lnkCondition);
			Utilities.waitForPageLoad(driver,conditionlnk);
			if (driver.findElements(conditionlnk).size()!=0)
			{					
				driver.findElement(conditionlnk).click();
				extent.log(LogStatus.PASS, "Clicked on Condition link is successful");
				Thread.sleep(15000);
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Condition link is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickScheduleSave(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{
			driver.switchTo().defaultContent();
			Utilities.selectRightPaneView(driver);
			By scheduleSavebtn=By.id(btnScheduleSave);
			Utilities.waitForPageLoad(driver,scheduleSavebtn);
			if (driver.findElements(scheduleSavebtn).size()!=0)
			{					
				driver.findElement(scheduleSavebtn).click();
				extent.log(LogStatus.PASS, "Clicked on Schedule - Save button is successful");
				Thread.sleep(4000);
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Schedule Save button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickSchedulelnk(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{
			driver.switchTo().defaultContent();
			By schedulelnk=By.linkText(lnkSchedule);
			Utilities.waitForPageLoad(driver,schedulelnk);
			if (driver.findElements(schedulelnk).size()!=0)
			{					
				driver.findElement(schedulelnk).click();
				extent.log(LogStatus.PASS, "Clicked on Schedule link is successful");
				Thread.sleep(8000);
			}else
			{
				driver.findElement(schedulelnk).click();
				extent.log(LogStatus.INFO, "Clicked on Schedule link is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean clickYes(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{
			By yesbtn=By.id(btnYes);
			Utilities.waitForPageLoad(driver,yesbtn);
			if (driver.findElements(yesbtn).size()!=0)
			{					
				driver.findElement(yesbtn).click();
				extent.log(LogStatus.PASS, "Clicked on Yes button is successful");
				Thread.sleep(4000);
			}else
			{
				extent.log(LogStatus.INFO, "Yes button is not displayed");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static void setTextInRuleDescription(WebDriver driver,String RuleDesc) throws Exception
	{
		try{		
			By ruledesctxt=By.name(txtRuledesc);
			Utilities.waitForPageLoad(driver,ruledesctxt);
			if (driver.findElements(ruledesctxt).size()!=0)
			{
				driver.findElement(ruledesctxt).clear();
				driver.findElement(ruledesctxt).sendKeys(RuleDesc);
				extent.log(LogStatus.PASS, "Rule Description: "+RuleDesc +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Rule Description: "+RuleDesc +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void setTextInRulename(WebDriver driver,String RuleName) throws Exception
	{
		try{		
			By ruleNametxt=By.name(txtRulename);
			Utilities.waitForPageLoad(driver,ruleNametxt);
			if (driver.findElements(ruleNametxt).size()!=0)
			{
				driver.findElement(ruleNametxt).clear();
				driver.findElement(ruleNametxt).sendKeys(RuleName);
				extent.log(LogStatus.PASS, "Rule Name: "+RuleName +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Rule Name: "+RuleName +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static boolean clickRuleSave(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{
			By rsavebtn=By.id(btnRuleSave);
			Utilities.waitForPageLoad(driver,rsavebtn);
			if (driver.findElements(rsavebtn).size()!=0)
			{					
				driver.findElement(rsavebtn).click();
				extent.log(LogStatus.PASS, "Clicked on Rule - Save button is successful");
				Thread.sleep(4000);
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Rule - Save button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickCreate(WebDriver driver) throws Exception
	{
		boolean flag=true;
		try{
			By createBtn=By.xpath(btnCreate);
			
			Utilities.waitForPageLoad(driver,createBtn);
			if (driver.findElements(createBtn).size()!=0)
			{					
				driver.findElement(createBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Rule Settings - Create button is successful");
				Thread.sleep(4000);
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked onRule Settings - Create button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
}
