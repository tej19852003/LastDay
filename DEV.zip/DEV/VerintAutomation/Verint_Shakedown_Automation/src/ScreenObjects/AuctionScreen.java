package ScreenObjects;


import org.apache.bcel.generic.DADD;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import org.python.core.exceptions;

import bsh.util.Util;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import Utilities.Utilities;

public class AuctionScreen 
{
	public static ExtentReports extent = ExtentReports.get(WorkQueuesScreen.class);
	public static String txtauctionName="auctionName";
	public static String btnschedulePeriod="//button[@id='workpaneMediator_toolbar_spSelectorPC_ID']";
	public static String sboxiddongfor="biddingFor";
	public static String icondeadline="_dpOBTWrapper";
	public static String btnSaveAuction="//button[@id='workpaneMediator_toolbar_SAVE_ACTIONLabel']";
	public static String txtsperiod="workpaneMediator_toolbar_spSelectorPC_ID";
	public static String linkauction="//div[@id='listWrapper']//table[@id='listLIST_TBL_NAME']//tbody//tr//td//div[@class='treeNode']//nobr//a";
	public static String clickEmpTab="//div[@id='categoryTasks']//table[@id='TLTABLE']//tbody//tr//td[contains(@title,'Employees')]//div//span//a";
	public static String btnAddtoauction="toolbar_ADD_TO_AUCTION_ACTIONLabel";
	public static String clickBidTab="//div[@id='categoryTasks']//table[@id='TLTABLE']//tbody//tr//td[contains(@title,'Bid Options')]//div//span//a";
	public static String clickScheduleTab="//div[@id='categoryTasks']//table[@id='TLTABLE']//tbody//tr//td[contains(@title,'Schedules')]//div//span//a";
	public static String clickSettingsTab="//div[@id='categoryTasks']//table[@id='TLTABLE']//tbody//tr//td[contains(@title,'Settings')]//div//span//a";
	public static String btnSaveAuctionPopUp="//button[@id='workpaneMediator_toolbar_ADD_TO_AUCTION_ACTIONLabel']";
	public static String iconemployee="//span[@id='bidderID_0Wrapper']//nobr//img[@id='bidderID_0Button']";
	public static String txtdeadline="deadline_0";
	public static String btncloseauction="//button[@id='workpaneMediator_toolbar_CLOSE_AUCTION_MENULabel']";
	public static String btndelauction="//button[@id='workpaneMediator_toolbar_DELETE_ACTIONLabel']";
	
	
	
	public static boolean setAuctionName(WebDriver driver,String AuctionName)throws Exception
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By auctionNametxt=By.name(txtauctionName);
			Utilities.waitForPageLoad(driver,auctionNametxt);
			if (driver.findElements(auctionNametxt).size()!=0)
			{
				driver.findElement(auctionNametxt).clear();
				driver.findElement(auctionNametxt).sendKeys(AuctionName);
				extent.log(LogStatus.PASS,"Auction Name" + AuctionName + "is enetered successfully");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL, "Auction Name" + AuctionName + "is not enetered successfully");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
		
	}
	
	
	public static boolean setdeadline_auction(WebDriver driver,String deadline)
	{
		boolean flag=false;
		
		try
		{
			Utilities.selectRightPaneView(driver);
			By deadlinetxt=By.id(txtdeadline);
			Utilities.waitForPageLoad(driver,deadlinetxt);
			if(driver.findElements(deadlinetxt).size()!=0)
			{
				driver.findElement(deadlinetxt).clear();
				driver.switchTo().alert().accept();
				driver.findElement(deadlinetxt).sendKeys(deadline);
				extent.log(LogStatus.PASS,"ddeadline for the auction:"+deadline+" is enetered");
				flag=true;
						
			}
			else
			{
				extent.log(LogStatus.FAIL,"ddeadline for the auction:"+deadline+" is  not enetered");
			}
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clickSave(WebDriver driver)throws Exception
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By btnSave=By.xpath(btnSaveAuction);
			Utilities.waitForPageLoad(driver,btnSave);
			if(driver.findElements(btnSave).size()!=0)
			{
				driver.findElement(btnSave).click();
				extent.log(LogStatus.PASS,"clicked on save button is successfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"clicked on save button is not successfull");
			}
			
		}catch (Exception e)
		{
			e.printStackTrace();
		}
		return flag;
		
	}
	
	public static  boolean setbiddingFor(WebDriver driver,String Biddingfor)
	{
		boolean flag=false;
		try
		{
			
		By biddigfortxt=By.name(sboxiddongfor);
		Utilities.waitForPageLoad(driver,biddigfortxt);
		if (driver.findElements(biddigfortxt).size()!=0)
		{
			driver.findElement(biddigfortxt).clear();
			driver.findElement(biddigfortxt).sendKeys(Biddingfor);
			extent.log(LogStatus.PASS,"Value" + Biddingfor + "is enetered successfully");
			flag=true;
		}
		else
		{
			extent.log(LogStatus.FAIL, "Value" + Biddingfor + "is not enetered successfully");
		}
		}catch (Exception e) 
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean setDeadlline(WebDriver driver,String deadline)
	{
		boolean flag=false;
		try
		{
			//driver.findElement(By.id(icondeadline)).click();
			Utilities.setWindowFocus(driver);
			driver.findElement(By.id("isAddAllWaiting_0Button")).click();
			Select sbox=new Select(driver.findElement(By.id("isAddAllWaiting")));
			sbox.selectByVisibleText("Only Selected and Waiting");
			Thread.sleep(2000);
			By deadlinetxt= By.id(txtdeadline);
			Utilities.waitForPageLoad(driver,deadlinetxt);
			if(driver.findElements(deadlinetxt).size()!=0)
			{
				driver.findElement(deadlinetxt).clear();
				driver.switchTo().alert().accept();
				driver.findElement(deadlinetxt).sendKeys(deadline);
				extent.log(LogStatus.PASS,"value" + deadline + "is entered successfully");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL, "value" + deadline + "is not  entered successfully");
			}
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickSchedulePeriod(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By btnSperiod=By.id(txtsperiod);
			Utilities.waitForPageLoad(driver, btnSperiod);
			if(driver.findElements(btnSperiod).size()!=0)
			{
				driver.findElement(btnSperiod).click();
				flag=true;
				extent.log(LogStatus.PASS,"clicked on schedule icon is sucessfull");
			}
			else
			{
				extent.log(LogStatus.FAIL,"clicked on schedule icon is not sucessfull");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean setPeriod(WebDriver driver,String campName,String Period)
	{
		boolean flag=false;
		try
		{
			
				
				//Utilities.setWindowFocus(driver);
				driver.findElement(By.xpath("//span[@id='campaignID_0Wrapper']//nobr//img[@id='campaignID_0Button']")).click();
				Thread.sleep(2000);
				Select sbox=new Select(driver.findElement(By.id("campaignID")));
				sbox.selectByVisibleText(campName);
				Thread.sleep(2000);
				driver.findElement(By.id("sPID_0Button")).click();
				Select sbox1=new Select(driver.findElement(By.id("sPID")));
				sbox1.selectByVisibleText(Period);
				driver.findElement(By.id("workpaneMediator_toolbar_SET_ACTIONLabel")).click();
				extent.log(LogStatus.PASS,"campaign name and schedule period is set successfully");
				flag=true;
			
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean SelectAuction(WebDriver driver,String auction)
	{
		boolean flag=false;
		try
		{
			Utilities.selectLeftTreeFrame(driver);
			Utilities.selectLeftTreeFrame(driver);
	    	int rows=driver.findElements(By.xpath("//div[@id='listWrapper']//table[@id='listLIST_TBL_NAME']//tbody//tr")).size();
	    	System.out.println("no of rows in auction table is:"+ rows);
	    	if(rows>0)
	    	{
	    		for(int i=1;i<=rows;i++)
	    		{
	    			String aname=driver.findElement(By.xpath("//div[@id='listWrapper']//table[@id='listLIST_TBL_NAME']//tbody//tr["+i+"]//td//div[@class='treeNode']//nobr//a")).getAttribute("innerText");
			    	System.out.println("auction name is: " + aname);
			    	if(aname.contains(auction))
			    	{
			    		driver.findElement(By.xpath("//div[@id='listWrapper']//table[@id='listLIST_TBL_NAME']//tbody//tr["+i+"]//td//div[@class='treeNode']//nobr//a")).click();
			    		flag=true;
			    		break;
			    	}
	    		}
	    		
		    	
	    	}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	
	public static boolean clickEmpTab(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			//Utilities.selectLeftTreeFrame(driver);
			By emptabLink=By.xpath(clickEmpTab);
			Utilities.waitForPageLoad(driver,emptabLink);
			if(driver.findElements(emptabLink).size()!=0)
			{
				driver.findElement(emptabLink).click();
				flag=true;
				extent.log(LogStatus.PASS,"employee tab is selected");
			}
			else
			{
				extent.log(LogStatus.FAIL,"employee tab is not getting selected");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clickScheduleTab(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			//Utilities.selectLeftTreeFrame(driver);
			By scheduletabLink=By.xpath(clickScheduleTab);
			Utilities.waitForPageLoad(driver,scheduletabLink);
			if(driver.findElements(scheduletabLink).size()!=0)
			{
				driver.findElement(scheduletabLink).click();
				flag=true;
				extent.log(LogStatus.PASS,"Schedule tab is selected");
			}
			else
			{
				extent.log(LogStatus.FAIL,"Schedule tab is not getting selected");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clickSettingsTab(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			//Utilities.selectLeftTreeFrame(driver);
			By settingtabLink=By.xpath(clickSettingsTab);
			Utilities.waitForPageLoad(driver,settingtabLink);
			if(driver.findElements(settingtabLink).size()!=0)
			{
				driver.findElement(settingtabLink).click();
				flag=true;
				extent.log(LogStatus.PASS,"Setting tab is selected");
			}
			else
			{
				extent.log(LogStatus.FAIL,"setting tab is not getting selected");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clickAddtoAuction(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			int rowscount=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']//tbody//tr")).size();
	    	for(int i=0;i<=rowscount;i++)
	    	{
	    	String status=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']//tbody//tr[contains(@id,'workpaneListr"+i+"')]//td[contains(@id,'workpaneListr"+i+"c1')]")).getText();
	    	if(status.contains("Waiting"))
	    	{	
			driver.findElement(By.xpath("//table[@id='workpaneListWrapper']//tbody//tr[contains(@id,'workpaneListr"+i+"')]//th[contains(@id,'workpaneListr"+i+"c0')]//a")).click();
			break;
	    	}
	    	}
			By btnAdd_auction=By.id(btnAddtoauction);	
			Utilities.waitForPageLoad(driver,btnAdd_auction);								
			if(driver.findElements(btnAdd_auction).size()!=0)
			{
				driver.findElement(btnAdd_auction).click();
				flag=true;
				extent.log(LogStatus.PASS,"  add to auction button is clicked");
			}
			else
			{
				extent.log(LogStatus.FAIL,"add to auction button is not clicked");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clickBidTab(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			//Utilities.selectLeftTreeFrame(driver);
			By bidtabLink=By.xpath(clickBidTab);
			Utilities.waitForPageLoad(driver,bidtabLink);
			if(driver.findElements(bidtabLink).size()!=0)
			{
				driver.findElement(bidtabLink).click();
				flag=true;
				extent.log(LogStatus.PASS,"Bid option tab is selected");
			}
			else
			{
				extent.log(LogStatus.FAIL,"Bid option tab is not getting selected");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clickSaveAuction(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.setWindowFocus(driver);
			By btnsave_popup=By.xpath(btnSaveAuctionPopUp);
			Utilities.waitForPageLoad(driver,btnsave_popup);
			if(driver.findElements(btnsave_popup).size()!=0)
			{
				driver.findElement(btnsave_popup).click();
				flag=true;
				extent.log(LogStatus.PASS,"clicked on add button in pop up is sucessfull");
			}
			else
			{
				extent.log(LogStatus.FAIL,"clicked on add button in pop up is not successfull");
				flag=false;
			}
		}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			return flag;
		
	}
	
	
	public static boolean SelectEmployee(WebDriver driver,String ename)
	{
		boolean flag=true;
		try
		{
			Utilities.selectRightPaneView(driver);
			By iconemp=By.xpath(iconemployee);
			Utilities.waitForPageLoad(driver, iconemp);
			if(driver.findElements(iconemp).size()!=0)
			{
				driver.findElement(iconemp).click();
				Thread.sleep(1000);
				driver.findElement(iconemp).sendKeys(ename);
				Thread.sleep(3000);				
				extent.log(LogStatus.INFO, "employee Name:"+ename+" is selected from View Listbox");	
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to select employee Name:"+ename+" from View Listbox");
				
				return flag=false;
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
		
	}
	
	public static boolean clickcloseauction(WebDriver driver)
	{
		boolean flag=true;
		try
		{
			Utilities.selectRightPaneView(driver);
			By closeauc=By.xpath(btncloseauction);
			Utilities.waitForPageLoad(driver, closeauc);
			if(driver.findElements(closeauc).size()!=0)
			{
				driver.findElement(closeauc).click();
				Thread.sleep(1000);	
				driver.findElement(By.id("workpaneMediator_toolbar_CLOSE_AUCTION_ACTIONLabel")).click();
				extent.log(LogStatus.PASS,"close auction button is clicked");	
				flag=true;
			}
			else
			{
				extent.log(LogStatus.PASS,"close auction button is not clicked");
				
				return flag=false;
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickdeleteauction(WebDriver driver)
	{
		boolean flag=true;
		try
		{
			Utilities.selectRightPaneView(driver);
			By delauc=By.xpath(btndelauction);
			Utilities.waitForPageLoad(driver, delauc);
			if(driver.findElements(delauc).size()!=0)
			{
				driver.findElement(delauc).click();
				Thread.sleep(1000);	
				
//				driver.findElement(By.id("workpaneMediator_toolbar_CLOSE_AUCTION_ACTIONLabel")).click();
				extent.log(LogStatus.PASS,"delete auction button is clicked");	
				flag=true;
			}
			else
			{
				extent.log(LogStatus.PASS,"close auction button is not clicked");
				
				return flag=false;
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
}
