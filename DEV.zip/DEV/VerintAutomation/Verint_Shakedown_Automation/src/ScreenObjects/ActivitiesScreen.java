package ScreenObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class ActivitiesScreen {
	
	public static ExtentReports extent = ExtentReports.get(ActivitiesScreen.class);
	public static String btnCreateActivity="//button[@id='toolbar_ADD_ACTIONLabel']";
	public static String txtActivityName="activityName";
	public static String txtActivityDesc="activityDescription";
	public static String btnSave="//button[@id='toolbar_CREATE_NEW_ACTIONLabel']";
	public static String btnDeleteActivity="//button[@id='toolbar_DELETE_ACTIONLabel']";
	
	public static boolean deleteActivityName(WebDriver driver,String ActivityName) throws Exception
	{
		boolean flag=false;
		try{
			Utilities.selectRightPaneView(driver);
			By delBtn=By.xpath(btnDeleteActivity);
			Utilities.waitForPageLoad(driver,delBtn);
			if (driver.findElements(delBtn).size()!=0)
			{					
				driver.findElement(delBtn).click();
				Thread.sleep(3000);
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Delete_OK.png");				
				extent.log(LogStatus.PASS, "Clicked on Delete Activity button is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Delete Activity button is unsuccessful");
				flag=false;
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean verifyActivityName(WebDriver driver,String ActivityName) throws Exception
	{
		boolean flag=false;	
		Utilities.selectRightPaneView(driver);
		int rc=driver.findElements(By.xpath("//table[@id='activityTableRef']/tbody/tr")).size();
		System.out.println("rc:"+rc);
		for (int i=1;i<=rc;i++)
		{
			if (i<=15)
			{
			String ActivityNameApp=driver.findElement(By.xpath("//table[@id='activityTableRef']/tbody/tr["+i+"]/th/a/span")).getText();
			//System.out.println("ActivityNameApp:"+ActivityNameApp);
			if (ActivityNameApp.contains(ActivityName))
			{
				driver.findElement(By.xpath("//table[@id='activityTableRef']/tbody/tr["+i+"]/th/a/span")).click();
				System.out.println("ActivityNameApp is selected");
				flag=true;				
				break;
			}}
		}
		if (flag==true)
		{
			extent.log(LogStatus.PASS, "Activity Name: "+ActivityName+" is already exist/Created");
			extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Activity"));
		}
		else
		{
			extent.log(LogStatus.INFO, "Activity Name: "+ActivityName+" does not exist. Please create Activity");
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Activity"));
			return flag=false;
		}	
		return flag;
	}
	
	/*public static boolean selectActivityName(WebDriver driver,String ActivityName) throws Exception
	{
		boolean flag=false;	
		Utilities.selectRightPaneView(driver);
		int rc=driver.findElements(By.xpath("//table[@id='activityTableRef']/tbody/tr")).size();
		System.out.println("rc:"+rc);
		for (int i=1;i<=rc;i++)
		{
			String ActivityNameApp=driver.findElement(By.xpath("//table[@id='activityTableRef']/tbody/tr["+i+"]/th/a/span")).getText();
			if (ActivityNameApp.contains(ActivityName))
			{
				driver.findElement(By.xpath("//table[@id='activityTableRef']/tbody/tr["+i+"]/th/a/span")).click();
				System.out.println("ActivityNameApp is selected");
				flag=true;				
				break;
			}
		}
		if (flag==true)
		{
			extent.log(LogStatus.PASS, "Activity Name: "+ActivityName+" Created/Selected successfully");
		}
		else
		{
			extent.log(LogStatus.WARNING, "Not able to select Activity Name: "+ActivityName);
			return flag=false;
		}	
		return flag;
	}*/
	
	public static boolean clickSave(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			Utilities.selectRightPaneView(driver);
			By saveBtn=By.xpath(btnSave);
			Utilities.waitForPageLoad(driver,saveBtn);
			if (driver.findElements(saveBtn).size()!=0)
			{					
				driver.findElement(saveBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Save button is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Save button is unsuccessful");
				flag=false;
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean setActivityDescription(WebDriver driver,String ActivityDesc) throws Exception
	{
		boolean flag=false;
		try{		
			By actDesctxt=By.id(txtActivityDesc);
			Utilities.waitForPageLoad(driver,actDesctxt);
			if (driver.findElements(actDesctxt).size()!=0)
			{
				driver.findElement(actDesctxt).clear();
				driver.findElement(actDesctxt).sendKeys(ActivityDesc);
				extent.log(LogStatus.PASS, "Activity Description : "+ActivityDesc +" is entered successfully");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Activity Description : "+ActivityDesc +" is NOT entered");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean setActivityName(WebDriver driver,String ActivityName) throws Exception
	{
		boolean flag=false;
		try{		
			By actNametxt=By.id(txtActivityName);
			Utilities.waitForPageLoad(driver,actNametxt);
			if (driver.findElements(actNametxt).size()!=0)
			{
				driver.findElement(actNametxt).clear();
				driver.findElement(actNametxt).sendKeys(ActivityName);
				extent.log(LogStatus.PASS, "Activity Name : "+ActivityName +" is entered successfully");
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Activity Name : "+ActivityName +" is NOT entered");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean clickCreateActivity(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			Utilities.selectRightPaneView(driver);
			By CreateActivityBtn=By.xpath(btnCreateActivity);
			Utilities.waitForPageLoad(driver,CreateActivityBtn);
			if (driver.findElements(CreateActivityBtn).size()!=0)
			{					
				driver.findElement(CreateActivityBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Create Activity button is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Create Activity button is unsuccessful");
				flag=false;
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
}

