package ScreenObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import org.sikuli.script.Screen;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class ProfilesScreen {
	
	public static Screen sobj = new Screen ();
	public static ExtentReports extent = ExtentReports.get(ProfilesScreen.class);
	public static String btnCreate="//button[@id='toolbar_ADD_ACTIONLabel']";
	public static String txtLastName="lastName_0";
	public static String txtFirstName="firstName_0";
	public static String imgOrganizationEdit="//table[@id='adminFormCollapsibleContainer_wrapper_tbl_id border=']/tbody/tr/td/div[2]/table/tbody/tr[11]/td[2]/img[@alt='edit']";
	public static String iconlstOrganization="//span[@id='orgId_0Wrapper']/nobr/img[@id='orgId_0Button']";
	public static String lstOrganization="//select[@id='orgId']";
	public static String btnSet="workpaneMediator_toolbar_POPUP_JSFUNCTIONLabel";
	public static String btnSave="//button[@id='toolbar_SAVE_ACTIONLabel']";
	public static String btnImportDomainUsers="//button[@id='toolbar_OpenObjectBrowserLabel']";
	public static String labelErrMsg="//div[@id='workPaneWrapper']/table[@id='viewfindPane_tbl_id']/tbody/tr/td[2]/table[@id='pageMessages_bttn_tbl_id']/tbody/tr/td[1]/div";
	public static String labelTxtMsg="//div[@id='workPaneWrapper']/table[@id='viewfindPane_tbl_id']/tbody/tr/td[2]/div[1]/div";
	public static String btnImport="//button[@id='toolbar_POPUP_UPLOADLabel']";
	public static String txtNumLines="//input[@id='numLines']";
	public static String btnSelectAll="//button[@id='toolbar_POPUP_JSFUNCTIONLabel']";
	public static String labelImportTxtMsg="//div[@id='workPaneWrapper']/div[1]/div";
	public static String btnDelete="//button[@id='toolbar_DELETE_ACTIONLabel']";
	public static String iconlstView="//span[@id='peopleFilter_listbox_0Wrapper']/nobr/img[@id='peopleFilter_listbox_0Button']";
	public static String btnSaveAs="//button[@id='tableTB_TOOLBAR_SAVEASLabel']";
	public static String txtFilterNewName="//input[@name='saveAsName']";
	public static String btnFilterNewNameSave="//button[@id='DlgToolbar_DIALOG_OKLabel']";
	public static String txtFind="//input[@name='peopleFilter_find']";
	public static String iconorg="//img[@id='orgId_0Button']";
	public static String clickskillstab="//div[@id='categoryTasks']//table[@id='TLTABLE']//tbody//tr//td[contains(@title,'Skills')]//div//span//a";
	public static String btnaddskill="//button[@id='skillsToolbar_POPUP_SKILLLabel']";
	
	
	public static boolean FindSelect(WebDriver driver,String Name)
	{
		boolean flag=true;
		try{
			Utilities.selectLeftTreeFrame(driver);
			//driver.switchTo().defaultContent();
			
			/*//view--All Employees
			By iconViewlst=By.xpath(iconlstView);
			Utilities.waitForPageLoad(driver,iconViewlst);
			if (driver.findElements(iconViewlst).size()!=0)
			{					
				String view=driver.findElement(By.xpath("//span[@id='peopleFilter_listbox_0Wrapper']/nobr/input")).getText().trim();
				System.out.println("view item:"+view);
				if (view!="All Current")
				{
				driver.findElement(iconViewlst).click();
				Thread.sleep(1000);
				driver.findElement(iconViewlst).sendKeys("All Current");
				Thread.sleep(1000);
				driver.findElement(iconViewlst).sendKeys(Keys.ENTER);
				Thread.sleep(2000);			
				Robot r = new Robot();
				r.keyPress(KeyEvent.VK_ENTER);
				r.keyRelease(KeyEvent.VK_ENTER);
				Thread.sleep(2000);
				extent.log(LogStatus.INFO, "Option: All Current is selected from View Listbox");	
				}
			}else
			{
				extent.log(LogStatus.FAIL, "Not able to select Option:All Current  from View Listbox");
				return flag=false;
			}			
			//End of View	
*/			By findtxt=By.xpath(txtFind);
			Utilities.waitForPageLoad(driver,findtxt);
			if (driver.findElements(findtxt).size()!=0)
			{							
				driver.findElement(findtxt).clear();
				driver.findElement(findtxt).sendKeys(Name);
				Thread.sleep(1000);
				driver.findElement(findtxt).sendKeys(Keys.ENTER);
				Thread.sleep(5000);
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Delete_OK.png") != null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Delete_OK.png");
					extent.log(LogStatus.INFO, "Search Name through Find : "+Name+" not found.");					
					return flag=false;
				}
				if	(sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\UserNoMatchesFound.png") != null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\UserNoMatchesFound.png");
					extent.log(LogStatus.INFO, "Search Name through Find : "+Name+" not found.");					
					return flag=false;
				}
				if (flag==true)
				{
					Utilities.selectLeftTreeFrame(driver);
					int valrcProf=driver.findElements(By.xpath("//table[@id='psLIST_TBL_NAME']/tbody/tr")).size();
					System.out.println("valrcPriv:"+valrcProf);
					for (int j=1;j<=valrcProf;j++)
					{
						//if (j<=15)
						//{
						String profilenameApp=driver.findElement(By.xpath("//table[@id='psLIST_TBL_NAME']/tbody/tr["+j+"]/td/div/nobr/a/span")).getText().trim();
											
						if (profilenameApp.contains(Name))
						{
							driver.findElement(By.xpath("//table[@id='psLIST_TBL_NAME']/tbody/tr["+j+"]/td/div/nobr/a/span")).click();
							//driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).click();
							flag=true;
							break;
						}//}
					}
					if (flag==true)
					{
						//System.out.println("pass");
						extent.log(LogStatus.PASS, "Name: "+Name+" Created/Selected/imported successfully");
						extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Profile"));				
					}
					else
					{
						extent.log(LogStatus.FAIL, "Unable to Create/Select/import Profile/user Name: "+Name);
						extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Profile"));
						flag=false;
						
					}
				}
				
				//extent.log(LogStatus.PASS, "Profile First Name: "+Name +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Find text field is NOT displayed");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static void clickFilterNewNameSave(WebDriver driver) throws Exception
	{
		try{
			By saveFilterBtn=By.xpath(btnFilterNewNameSave);
			Utilities.waitForPageLoad(driver,saveFilterBtn);
			if (driver.findElements(saveFilterBtn).size()!=0)
			{					
				driver.findElement(saveFilterBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Filter New Name - Save button is successful");
				Thread.sleep(4000);
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Filter New Name - Save button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void setFilterNewName(WebDriver driver,String FilterName)
	{
		try{		
			By filterNametxt=By.xpath(txtFilterNewName);
			Utilities.waitForPageLoad(driver,filterNametxt);
			if (driver.findElements(filterNametxt).size()!=0)
			{
				driver.findElement(filterNametxt).sendKeys(FilterName);
				Thread.sleep(2000);
				extent.log(LogStatus.PASS, "Profile First Name: "+FilterName +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Profile First Name: "+FilterName +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void clickSaveAs(WebDriver driver) throws Exception
	{
		try{
			By saveAsBtn=By.xpath(btnSaveAs);
			Utilities.waitForPageLoad(driver,saveAsBtn);
			if (driver.findElements(saveAsBtn).size()!=0)
			{					
				driver.findElement(saveAsBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Save As button is successful");
				Thread.sleep(3000);
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Save As button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void selectOrg_CreateFilter(WebDriver driver,String OrgName) throws Exception
	{
		//driver.switchTo().defaultContent();
		String selectOrg=OrgName;
		String[] resOrg=selectOrg.split(";");
		for (int s=0;s<resOrg.length;s++)
		{
			String selOrg=resOrg[s];		
			int prc=driver.findElements(By.xpath("//table[@id='orgTreePC_id']/tbody/tr")).size();
			System.out.println("privtablerc:"+prc);
			for (int p=2;p<=prc;p++)
			{
				String orgName=driver.findElement(By.xpath("//table[@id='orgTreePC_id']/tbody/tr["+p+"]/td[2]/label/span")).getText().trim();
				//System.out.println("orgNameApp:"+orgName);
				//System.out.println("privVal:"+selOrg);
				if (orgName.contains(selOrg))
				{
					driver.findElement(By.xpath("//table[@id='orgTreePC_id']/tbody/tr["+p+"]/td[1]/span/input[@name='checkedOrgID'][@type='checkbox']")).click();
					extent.log(LogStatus.INFO, "Organization Name:"+OrgName+" checkbox is selected");					
					break;
					
				}
			}
		}
	}
	
	public static boolean selectView(WebDriver driver,String Option) throws Exception
	{
		boolean flag=true;
		try{
			
			Utilities.selectLeftTreeFrame(driver);
			By iconViewlst=By.xpath(iconlstView);
			Utilities.waitForPageLoad(driver,iconViewlst);
			if (driver.findElements(iconViewlst).size()!=0)
			{					
				driver.findElement(iconViewlst).click();
				Thread.sleep(1000);
				driver.findElement(iconViewlst).sendKeys(Option);
				Thread.sleep(3000);				
				extent.log(LogStatus.INFO, "Option:"+Option+" is selected from View Listbox");				
			}else
			{
				extent.log(LogStatus.FAIL, "Not able to select Option:"+Option+" from View Listbox");
				return flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickDelete(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			Utilities.selectRightPaneView(driver);
			By deleteBtn=By.xpath(btnDelete);
			Utilities.waitForPageLoad(driver,deleteBtn);
			if (driver.findElements(deleteBtn).size()!=0)
			{					
				driver.findElement(deleteBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Delete button is successful");
				flag=true;
				Thread.sleep(8000);
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Delete button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static void verifyImportSuccessMessage(WebDriver driver) throws Exception
	{
		
		try{
			By messageTxt=By.xpath(labelImportTxtMsg);
			//Utilities.waitForPageLoad(driver,impDomUserBtn);
			Thread.sleep(6000);
			//System.out.println("err:"+driver.findElement(messageTxt));
			if (driver.findElements(messageTxt).size()!=0)
			{					
				String msg=driver.findElement(messageTxt).getText();
				if (msg.contains("successfully imported"))
					extent.log(LogStatus.PASS, "Message:"+msg+" is displayed");
				else
					extent.log(LogStatus.FAIL, "Not able to Import");				
			}else
			{
				extent.log(LogStatus.FAIL, "Not able to Import");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void clickSelectAll(WebDriver driver) throws Exception
	{
		try{
			By selectAllBtn=By.xpath(btnSelectAll);
			Utilities.waitForPageLoad(driver,selectAllBtn);
			if (driver.findElements(selectAllBtn).size()!=0)
			{					
				driver.findElement(selectAllBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Select All button is successful");
				Thread.sleep(4000);
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Select All button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void setNumberOfLinesStartOfFile(WebDriver driver,String lines)
	{
		try{		
			By numLinestxt=By.xpath(txtNumLines);
			Utilities.waitForPageLoad(driver,numLinestxt);
			if (driver.findElements(numLinestxt).size()!=0)
			{
				driver.findElement(numLinestxt).sendKeys(lines);
				extent.log(LogStatus.PASS, "Number of Lines: "+lines +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Number of Lines: "+lines +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static boolean clickImport(WebDriver driver) throws Exception
	{
		boolean flag=true;
		try{
			By importBtn=By.xpath(btnImport);
			Utilities.waitForPageLoad(driver,importBtn);
			if (driver.findElements(importBtn).size()!=0)
			{					
				driver.findElement(importBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Import button is successful");
				Thread.sleep(5000);
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Import button is unsuccessful");
				return flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static void verifySuccessMessage(WebDriver driver) throws Exception
	{
		
		try{
			By messageTxt=By.xpath(labelTxtMsg);
			//Utilities.waitForPageLoad(driver,impDomUserBtn);
			Thread.sleep(6000);
			//System.out.println("err:"+driver.findElement(messageTxt));
			if (driver.findElements(messageTxt).size()!=0)
			{					
				String msg=driver.findElement(By.xpath("//div[@id='workPaneWrapper']/table[@id='viewfindPane_tbl_id']/tbody/tr/td[2]/div[1]/div")).getText();
				extent.log(LogStatus.PASS, "Message:"+msg+" is displayed");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "ProfileMsg"));
				Thread.sleep(3000);
			}else
			{
				extent.log(LogStatus.WARNING, "Updated Successfully message is NOT displayed");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "ProfileMsg"));
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static boolean checkErrorMessage(WebDriver driver) throws Exception
	{
		boolean flag=true;
		try{
			
			By errmsg=By.xpath(labelErrMsg);
			//Utilities.waitForPageLoad(driver,impDomUserBtn);
			Thread.sleep(4000);
			//System.out.println("err:"+driver.findElement(errmsg));
			if (driver.findElements(errmsg).size()!=0)
			{			
				if (driver.findElement(errmsg).getText().contains("could not")) 
				{
					extent.log(LogStatus.WARNING, "Error Message:"+driver.findElement(errmsg).getText()+" is displayed");
					extent.log(LogStatus.WARNING, "", "", Utilities.captureScreenShot(driver, "Profile"));
					return flag=false;
				}
				if (driver.findElement(errmsg).getText().contains("already in use")) 
				{
					extent.log(LogStatus.WARNING, "Error Message:"+driver.findElement(errmsg).getText()+" is displayed");
					extent.log(LogStatus.WARNING, "", "", Utilities.captureScreenShot(driver, "Profile"));
					return flag=false;
				}
				
			}else
			{				
				extent.log(LogStatus.INFO, "No error message is displayed");
				
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean clickImportDomainUsers(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			By impDomUserBtn=By.xpath(btnImportDomainUsers);
			Utilities.waitForPageLoad(driver,impDomUserBtn);
			if (driver.findElements(impDomUserBtn).size()!=0)
			{					
				driver.findElement(impDomUserBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Import Domain Users button is successful");
				Thread.sleep(4000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Import Domain Users button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectProfile(WebDriver driver,String ProfileName) throws Exception
	{
		
		Utilities.selectLeftTreeFrame(driver);
		Boolean Temp1=false;
		try {
			int valrcProf=driver.findElements(By.xpath("//table[@id='psLIST_TBL_NAME']/tbody/tr")).size();
			//System.out.println("valrcPriv:"+valrcProf);
			for (int j=1;j<=valrcProf;j++)
			{
				if (j<=15)
				{
				String profilenameApp=driver.findElement(By.xpath("//table[@id='psLIST_TBL_NAME']/tbody/tr["+j+"]/td/div/nobr/a/span")).getText().trim();
				//System.out.println("profilenameApp:"+profilenameApp);
				//System.out.println("profilenameCreated:"+ProfileName);
				
				if (profilenameApp.contains(ProfileName))
				{
					driver.findElement(By.xpath("//table[@id='psLIST_TBL_NAME']/tbody/tr["+j+"]/td/div/nobr/a/span")).click();
					//driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).click();
					Temp1=true;
					break;
				}}
			}
			if (Temp1==true)
			{
				//System.out.println("pass");
				extent.log(LogStatus.PASS, "Name: "+ProfileName+" Created/Selected/imported successfully");
				//captureScreenShot(driver,screenshotDir+"OrganizationNameValidation");				
			}
			else
			{
				extent.log(LogStatus.FAIL, "Unable to Create/Select/import Profile/user Name: "+ProfileName);
				//captureScreenShot(driver,screenshotDir+"RoleNameValidation");
				return Temp1 =false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return Temp1;
		
	}
	
	public static boolean clickSave(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			Utilities.selectRightPaneView(driver);
			By saveBtn=By.xpath(btnSave);
			Utilities.waitForPageLoad(driver,saveBtn);
			if (driver.findElements(saveBtn).size()!=0)
			{					
				driver.findElement(saveBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Save button is successful");
				Thread.sleep(4000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Save button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static void selectOrganizationFromListbox(WebDriver driver,String Option) throws Exception
	{
		try{
			By iconlst=By.xpath(iconlstOrganization);
			Utilities.waitForPageLoad(driver,iconlst);
			if (driver.findElements(iconlst).size()!=0)
			{					
				driver.findElement(iconlst).click();
				//Thread.sleep(2000);
				driver.findElement(By.xpath(lstOrganization)).sendKeys(Option);
				Thread.sleep(3000);
				driver.findElement(By.id(btnSet)).click();
				extent.log(LogStatus.INFO, "Option:"+Option+" is selected from Organization Listbox");				
			}else
			{
				extent.log(LogStatus.FAIL, "Not able to select Option:"+Option+" from Organization Listbox");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static boolean clickOrganizationEdit(WebDriver driver) throws Exception
	{
		boolean flag=true;
		try{	
			//Utilities.selectRightPaneView(driver);
			By imgOrgEdit=By.xpath(imgOrganizationEdit);
			Utilities.waitForPageLoad(driver,imgOrgEdit);
			if (driver.findElements(imgOrgEdit).size()!=0)
			{					
				driver.findElement(imgOrgEdit).click();
				extent.log(LogStatus.INFO, "Clicked on Organization Edit Image is successful");
				Thread.sleep(4000);
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Organization Edit Image is unsuccessful");
				return flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static void setProfilesFirstName(WebDriver driver,String FirstName)
	{
		try{		
			By firstNametxt=By.id(txtFirstName);
			Utilities.waitForPageLoad(driver,firstNametxt);
			if (driver.findElements(firstNametxt).size()!=0)
			{
				driver.findElement(firstNametxt).sendKeys(FirstName);
				extent.log(LogStatus.PASS, "Profile First Name: "+FirstName +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Profile First Name: "+FirstName +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void setProfilesLastName(WebDriver driver,String LastName)
	{
		try{		
			By lastNametxt=By.id(txtLastName);
			Utilities.waitForPageLoad(driver,lastNametxt);
			if (driver.findElements(lastNametxt).size()!=0)
			{
				driver.findElement(lastNametxt).sendKeys(LastName);
				extent.log(LogStatus.PASS, "Profile Last Name: "+LastName +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Profile Last Name: "+LastName +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void clickCreate(WebDriver driver) throws Exception
	{
		try{
			By createBtn=By.xpath(btnCreate);
			Utilities.waitForPageLoad(driver,createBtn);
			if (driver.findElements(createBtn).size()!=0)
			{					
				driver.findElement(createBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Create button is successful");
				Thread.sleep(4000);
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Create button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static boolean SelectOrg(WebDriver driver,String orgName)
	{
		boolean flag=false;
		try
		{
			By orgicon=By.xpath(iconorg);
			Utilities.waitForPageLoad(driver,orgicon);
			if(driver.findElements(orgicon).size()!=0)
			{
				driver.findElement(orgicon).click();
				Select sbox=new Select(driver.findElement(By.id("orgId")));
				sbox.selectByVisibleText(orgName);
				Thread.sleep(2000);
				extent.log(LogStatus.PASS,"Organization"+orgName+ " is selected sucessfully");
				flag=true;
				
			}
			else
			{
				extent.log(LogStatus.FAIL,"not able to select organization");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clickskillsTab(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			//Utilities.selectLeftTreeFrame(driver);
			By skilltabLink=By.xpath(clickskillstab);
			Utilities.waitForPageLoad(driver,skilltabLink);
			if(driver.findElements(skilltabLink).size()!=0)
			{
				driver.findElement(skilltabLink).click();
				flag=true;
				extent.log(LogStatus.PASS,"skills tab is selected");
			}
			else
			{
				extent.log(LogStatus.FAIL,"skills tab is not getting selected");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clickAddskillbtn(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			//Utilities.selectLeftTreeFrame(driver);
			By Addbtn=By.xpath(btnaddskill);
			Utilities.waitForPageLoad(driver,Addbtn);
			if(driver.findElements(Addbtn).size()!=0)
			{
				driver.findElement(Addbtn).click();
				flag=true;
				extent.log(LogStatus.PASS,"Add skill button is clicked sucessfully");
			}
			else
			{
				extent.log(LogStatus.FAIL,"Add skill button is not clicked sucessfully");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setSkill(WebDriver driver,String skill)throws Exception
	{
		boolean flag=false;
		//Utilities.setWindowFocus(driver);
		try
		{
			int rows=driver.findElements(By.xpath("//div[@id='availableSkillsTableWrapper']//table[@id='availableSkillsTableRef']//tr")).size();
			System.out.println("no of rows are:" + rows);
			for(int j=0;j<rows;j+=2)
			{
				String sname=driver.findElement(By.xpath("//div[@id='availableSkillsTableWrapper']//table[@id='availableSkillsTableRef']//tr[contains(@id,'availableSkillsTabler"+j+"')]//th[contains(@id,'availableSkillsTabler"+j+"c0')]")).getText();
				System.out.println("shift name is:" + sname);
				if(sname.contains(skill))
				{
					driver.findElement(By.xpath("//div[@id='availableSkillsTableWrapper']//table[@id='availableSkillsTableRef']//tr[contains(@id,'availableSkillsTabler"+j+"')]//th[contains(@id,'availableSkillsTabler"+j+"c0')]")).click();
					break;
				}
				
			}
			driver.findElement(By.xpath("//button[@id='workpaneMediator_toolbar_addSkillsLabel']")).click();
			flag=true;
		}
		catch(Exception e){
			e.printStackTrace();
			
		}
		return flag;
	}
	

}

