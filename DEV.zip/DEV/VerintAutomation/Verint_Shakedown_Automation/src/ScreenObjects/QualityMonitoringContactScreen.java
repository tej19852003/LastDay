package ScreenObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.sikuli.script.Screen;



import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class QualityMonitoringContactScreen {

	public static ExtentReports extent = ExtentReports.get(Impact360Screen.class);
	public static String lstEvalForm="formInfo_ddFormName";
	public static Screen sobj = new Screen ();
	
	public static boolean setTextInRemarkBy(WebDriver driver,String RemarkByText) throws Exception
	{
		boolean flag=true;
		Thread.sleep(3000);
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);			
		driver.switchTo().frame("FR_REMARK");
		
		if (driver.findElements(By.xpath("//table[@id='remarkMainTable']/tbody/tr[1]/td/a/img[@id='CollapseImage']")).size()!=0)
		{
			driver.findElement(By.xpath("//table[@id='remarkMainTable']/tbody/tr[1]/td/a/img[@id='CollapseImage']")).click();
		}
		else
		{
			extent.log(LogStatus.FAIL,"Not able to click/expand Remark By field");
			return flag=false;
		}
		Thread.sleep(2000);
		if (driver.findElements(By.xpath("//table[@id='remarkMainTable']/tbody/tr[2]/td/textarea[@id='remarkText']")).size()!=0)
		{
			driver.findElement(By.xpath("//table[@id='remarkMainTable']/tbody/tr[2]/td/textarea[@id='remarkText']")).clear();
			driver.findElement(By.xpath("//table[@id='remarkMainTable']/tbody/tr[2]/td/textarea[@id='remarkText']")).sendKeys(RemarkByText);
			extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QM05_07_14_Playback_EvalForm_RemarksBy"));
			Thread.sleep(4000);
		}
		else
		{
			extent.log(LogStatus.FAIL,"Remark By field is not displayed");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "QM05_07_14_Playback_EvalForm_RemarksBy"));
			return flag=false;
		}
		if (driver.findElement(By.xpath("//table[@id='remarkMainTable']/tbody/tr[2]/td/textarea[@id='remarkText']")).getText().contains(RemarkByText))
		{
			extent.log(LogStatus.PASS,"Remark By:"+RemarkByText+" entered successfully");
		}
		else
		{
			extent.log(LogStatus.FAIL,"Remark By:"+RemarkByText+" NOT able to enter");
			return flag=false;
		}
		
		return flag;
	}
	
	public static boolean selectItemFromEvalForm(WebDriver driver,String FormName) throws Exception
	{
		
		boolean flag=false;
		Thread.sleep(3000);
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);			
		driver.switchTo().frame("FR_EVALUATION");
		 
		 WebElement sel = driver.findElement(By.id(lstEvalForm));
		 List<WebElement> lists = sel.findElements(By.tagName("option"));
		 if (lists.size()!=0)
		 {			 	
			 System.out.println("Evaluation Form items count :"+lists.size());
		     for(WebElement element: lists)  
		     {
		         String lstValues = element.getText();
		         System.out.println("valueApp:"+lstValues);
		         //System.out.println("value:"+FormName);
		         if (lstValues.contains(FormName))
		         {
		        	element.click();
		        	extent.log(LogStatus.PASS,"Evaluation Form value:"+FormName+" selected");
		        	Thread.sleep(5000);
		        	flag=true;
		        	break;
		         }
		         //extent.log(LogStatus.INFO,"Evaluation Form value:"+lstValues);
		     }
		 }
		 else
		 {
			 extent.log(LogStatus.FAIL,"No items/Not able to select option from Evaluation Form");
			 return flag=false;
		 }	
		 if (flag==false)
		 {
			 extent.log(LogStatus.INFO,"Not able to select option:"+FormName+" from Evaluation Form");			 
		 }
		 return flag;
		
		
	}
	
	public static boolean getItemsFromEvalFormListbox(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		Thread.sleep(3000);
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);			
		driver.switchTo().frame("FR_EVALUATION");
		 
		 WebElement sel = driver.findElement(By.id(lstEvalForm));
		 List<WebElement> lists = sel.findElements(By.tagName("option"));
		 if (lists.size()!=0)
		 {
			 extent.log(LogStatus.PASS,"Evaluation Form items count :"+lists.size());			
		     for(WebElement element: lists)  
		     {
		         String lstValues = element.getText();
		         extent.log(LogStatus.INFO,"Evaluation Form value:"+lstValues);
		     }
		 }
		 else
		 {
			 extent.log(LogStatus.FAIL,"No items were displayed in the Evaluation Form");
			 return flag=false;
		 }	
		 return flag;
		
	}
}
