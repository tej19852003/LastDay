package ScreenObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.python.modules.thread.thread;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class PulseScreen 
{
	public static ExtentReports extent = ExtentReports.get(WorkQueuesScreen.class);
	public static String iconCampaign="//span[@id='queueFilter_listbox_0Wrapper']//nbor//img[@id='queueFilter_listbox_0Button']";
	
	
	public static boolean setcampaign(WebDriver driver,String campName)
	{
		boolean flag=true;
		try
		{
			Utilities.selectLeftTreeFrame(driver);
			By iconcamp=By.xpath(iconCampaign);
			Utilities.waitForPageLoad(driver,iconcamp);
			if(driver.findElements(iconcamp).size()!=0)
			{
				driver.findElement(iconcamp).click();
				Thread.sleep(2000);
				driver.findElement(iconcamp).sendKeys(campName);
				Thread.sleep(2000);
				extent.log(LogStatus.INFO,"Campaign Name:"+campName+" is selected from View Listbox");
			}
			else
			{
				extent.log(LogStatus.INFO,"Not able to select Campaign Name:"+campName+" from View Listbox");
				return flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	
	public static boolean selectqueue(WebDriver driver,String workqueue)
	{
		Boolean Temp=false;
		try{
			Utilities.selectLeftTreeFrame(driver);
			int rc=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
			System.out.println("rc:"+rc);
			/*if (rc>0)
			{
				driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr[1]/td/a")).click();
			}*/
			for (int i=1;i<=rc;i++)
			{
				
				if (i<=15)
				{
				String queuename=driver.findElement(By.xpath("//table[@id='queueTree_id']/tbody/tr["+i+"]/td/a")).getText();
				System.out.println(workqueue);
				if (queuename.contains(workqueue))
				{
					driver.findElement(By.xpath("//table[@id='queueTree_id']/tbody/tr["+i+"]/td/a")).click();
					Thread.sleep(3000);
					Temp=true;
					break;
				}}
			}
			if (Temp==true)
			{					
				extent.log(LogStatus.PASS, "work queue:"+workqueue+" is  selected successfully");	
				//extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Campaign"));
			}
			else
			{
				extent.log(LogStatus.FAIL, "Work Queue:"+workqueue+" NOT displayed ");
				//extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Campaign"));
				return Temp=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	
		return Temp;
	}
}
