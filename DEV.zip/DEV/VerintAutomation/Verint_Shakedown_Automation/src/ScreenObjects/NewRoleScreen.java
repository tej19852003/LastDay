package ScreenObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.relevantcodes.extentreports.LogStatus;

import Utilities.Utilities;
import com.relevantcodes.extentreports.ExtentReports;

//Create New Role, Create new role from Exisitng, View/Edit Role
public class NewRoleScreen {
	
	public static ExtentReports extent = ExtentReports.get(NewRoleScreen.class);
	public static String txtRolename="roleName";
	public static String txtRoledesc="description";
	public static String btnPrivilegeClosed="//button[@id='tableHeaderImageButton'][@title='Closed']";
	public static String btnPrivilegeOpened="//button[@id='tableHeaderImageButton'][@title='Opened']";
	public static String btnSave="workpaneMediator_toolbar_SAVE_ACTIONLabel";
	
	public static void selectDPAPrivilege(WebDriver driver) throws Exception
	{
		int prc=driver.findElements(By.xpath("//table[@id='privTree_id']/tbody/tr")).size();
		System.out.println("privtablerc:"+prc);
		boolean Temp=false;
		for (int p=1;p<=prc;p++)
		{
					String DPAprevName=driver.findElement(By.xpath("//table[@id='privTree_id']/tbody/tr["+p+"]/th/a/span")).getText().trim();
					System.out.println("prevNameApp:"+DPAprevName);
					System.out.println("PrivilegeName:Desktop Process Analytics");
					//Thread.sleep(1000);
					if (DPAprevName.contains("Desktop Process Analytics"))
					{
						//expand DPA 
						System.out.println("rc:"+driver.findElements(By.xpath("//table[@id='privTree_id']/tbody/tr["+p+"]/th/img[@class='treeNorgie'][@alt='Closed']")).size());
						if (driver.findElements(By.xpath("//table[@id='privTree_id']/tbody/tr["+p+"]/th/img[@class='treeNorgie'][@alt='Closed']")).size()!=0)
						{
							driver.findElement(By.xpath("//table[@id='privTree_id']/tbody/tr["+p+"]/th/img[@class='treeNorgie'][@alt='Closed']")).click();
							extent.log(LogStatus.INFO, "Privilege:Desktop Process Analytics is expanded");
							//expand Admin
							int q=p+1;
							for (int a=q;a<=prc;a++)
							{
								String AdminprevName=driver.findElement(By.xpath("//table[@id='privTree_id']/tbody/tr["+a+"]/th/a/span")).getText().trim();
								if (AdminprevName.contains("Admin"))
								{
									if (driver.findElements(By.xpath("//table[@id='privTree_id']/tbody/tr["+a+"]/th/img[@class='treeNorgie'][@alt='Closed']")).size()!=0)
									{
										driver.findElement(By.xpath("//table[@id='privTree_id']/tbody/tr["+a+"]/th/img[@class='treeNorgie'][@alt='Closed']")).click();
										extent.log(LogStatus.INFO, "Privilege:Admin is expanded");
										Thread.sleep(2000);
									}					
									//DPA admin checkbox
									int b=a+1;
									String DPAAdminprevName=driver.findElement(By.xpath("//table[@id='privTree_id']/tbody/tr["+b+"]/th/a/span")).getText().trim();
									System.out.println("chiildprevNameApp:"+DPAAdminprevName);
									System.out.println("AdminselPriv:DPA Admin");
									Thread.sleep(1000);
									if (DPAAdminprevName.contains("DPA Admin"))
									{
										driver.findElement(By.xpath("//table[@id='privTree_id']/tbody/tr["+b+"]/th/a/span/input[@name='privID'][@type='checkbox']")).click();
										extent.log(LogStatus.INFO, "Privilege: DPA Admin checkbox is selected");
										break;								
									}
								}
							}
						}
					}
					//expand App Analysis Logging
					if (DPAprevName.contains("App Analysis Logging"))
					{
						if (driver.findElements(By.xpath("//table[@id='privTree_id']/tbody/tr["+p+"]/th/img[@class='treeNorgie'][@alt='Closed']")).size()!=0)
						{
							driver.findElement(By.xpath("//table[@id='privTree_id']/tbody/tr["+p+"]/th/img[@class='treeNorgie'][@alt='Closed']")).click();
							extent.log(LogStatus.INFO, "Privilege: App Analysis Logging is expanded");
							Thread.sleep(2000);
						}					
						//App Analysis Logging check box
						int c=p+1;
						String AppAnalysisprevName=driver.findElement(By.xpath("//table[@id='privTree_id']/tbody/tr["+c+"]/th/a/span")).getText().trim();
						System.out.println("AppAnalysisprevNameApp:"+AppAnalysisprevName);
						System.out.println("AdminselPriv:App Analysis Logging");
						Thread.sleep(1000);
						if (AppAnalysisprevName.contains("App Analysis Logging"))
						{
							driver.findElement(By.xpath("//table[@id='privTree_id']/tbody/tr["+c+"]/th/a/span/input[@name='privID'][@type='checkbox']")).click();
							extent.log(LogStatus.INFO, "Privilege: App Analysis Logging checkbox is selected");
							//break;								
						}
					}
					//expand Application Event Triggering
					if (DPAprevName.contains("Application Event Triggering"))
					{
						if (driver.findElements(By.xpath("//table[@id='privTree_id']/tbody/tr["+p+"]/th/img[@class='treeNorgie'][@alt='Closed']")).size()!=0)
						{
							driver.findElement(By.xpath("//table[@id='privTree_id']/tbody/tr["+p+"]/th/img[@class='treeNorgie'][@alt='Closed']")).click();
							extent.log(LogStatus.INFO, "Privilege: Application Event Triggering is expanded");
							Thread.sleep(2000);
						}					
						//Application Event Triggering check box
						int d=p+1;
						String AppEventTrigprevName=driver.findElement(By.xpath("//table[@id='privTree_id']/tbody/tr["+d+"]/th/a/span")).getText().trim();
						System.out.println("Application Event TriggeringApp:"+AppEventTrigprevName);
						System.out.println("Application Event TriggeringPriv:Application Event Triggering");
						Thread.sleep(1000);
						if (AppEventTrigprevName.contains("Application Event Triggering"))
						{
							driver.findElement(By.xpath("//table[@id='privTree_id']/tbody/tr["+d+"]/th/a/span/input[@name='privID'][@type='checkbox']")).click();
							extent.log(LogStatus.INFO, "Privilege: Application Event Triggering checkbox is selected");
							//break;								
						}
					}
					//expand Live Information
					if (DPAprevName.contains("Live Information"))
					{
						if (driver.findElements(By.xpath("//table[@id='privTree_id']/tbody/tr["+p+"]/th/img[@class='treeNorgie'][@alt='Closed']")).size()!=0)
						{
							driver.findElement(By.xpath("//table[@id='privTree_id']/tbody/tr["+p+"]/th/img[@class='treeNorgie'][@alt='Closed']")).click();
							extent.log(LogStatus.INFO, "Privilege: Live Information is expanded");
							Thread.sleep(2000);
						}					
						//Live Information check box
						int e=p+1;
						String LiveInfoName=driver.findElement(By.xpath("//table[@id='privTree_id']/tbody/tr["+e+"]/th/a/span")).getText().trim();
						System.out.println("LiveInfoNameApp:"+LiveInfoName);
						System.out.println("LiveInfoNamePriv:Live Information");
						Thread.sleep(1000);
						if (LiveInfoName.contains("Live Information"))
						{
							driver.findElement(By.xpath("//table[@id='privTree_id']/tbody/tr["+e+"]/th/a/span/input[@name='privID'][@type='checkbox']")).click();
							extent.log(LogStatus.INFO, "Privilege: Live Information checkbox is selected");
							//break;								
						}
					}
					//expand Process Logging
					if (DPAprevName.contains("Process Logging"))
					{
						if (driver.findElements(By.xpath("//table[@id='privTree_id']/tbody/tr["+p+"]/th/img[@class='treeNorgie'][@alt='Closed']")).size()!=0)
						{
							driver.findElement(By.xpath("//table[@id='privTree_id']/tbody/tr["+p+"]/th/img[@class='treeNorgie'][@alt='Closed']")).click();
							extent.log(LogStatus.INFO, "Privilege: Process Logging is expanded");
							Thread.sleep(2000);
						}					
						//Process Logging check box
						int f=p+1;
						String ProcessLoggingName=driver.findElement(By.xpath("//table[@id='privTree_id']/tbody/tr["+f+"]/th/a/span")).getText().trim();
						System.out.println("ProcessLoggingNameApp:"+ProcessLoggingName);
						System.out.println("Process LoggingPriv:Process Logging");
						Thread.sleep(1000);
						if (ProcessLoggingName.contains("Process Logging"))
						{
							driver.findElement(By.xpath("//table[@id='privTree_id']/tbody/tr["+f+"]/th/a/span/input[@name='privID'][@type='checkbox']")).click();
							extent.log(LogStatus.INFO, "Privilege: Live Information checkbox is selected");
							Temp=true;
							//break;								
						}
					}
			if (Temp==true)
				break;
		}		
	}
	
	public static void selectInteractionsAnalyticsPrivilege(WebDriver driver,String PrivilegeName,String Privilege) throws Exception
	{
		//expand privilege
		int prc=driver.findElements(By.xpath("//table[@id='privTree_id']/tbody/tr")).size();
		//System.out.println("privtablerc:"+prc);
		for (int p=1;p<=prc;p++)
		{
			String prevName=driver.findElement(By.xpath("//table[@id='privTree_id']/tbody/tr["+p+"]/th/a/span")).getText().trim();
			//System.out.println("prevNameApp:"+prevName);
			//System.out.println("PrivilegeName:"+PrivilegeName);
			//Thread.sleep(1000);
			if (prevName.contains(PrivilegeName))
			{
				//System.out.println("rc:"+driver.findElements(By.xpath("//table[@id='privTree_id']/tbody/tr["+p+"]/th/img[@class='treeNorgie'][@alt='Closed']")).size());
				if (driver.findElements(By.xpath("//table[@id='privTree_id']/tbody/tr["+p+"]/th/img[@class='treeNorgie'][@alt='Closed']")).size()!=0)
				{
					driver.findElement(By.xpath("//table[@id='privTree_id']/tbody/tr["+p+"]/th/img[@class='treeNorgie'][@alt='Closed']")).click();
					extent.log(LogStatus.INFO, "Privilege:"+PrivilegeName+" is expanded");
					String selectPrivileges=Privilege;
					String[] resPriv=selectPrivileges.split(";");
					for (int s=0;s<resPriv.length;s++)
					{
						String selPriv=resPriv[s];		
						//int prc=driver.findElements(By.xpath("//table[@id='privTree_id']/tbody/tr")).size();
						//System.out.println("privtablerc:"+prc);
						for (int pr=p;pr<=prc;pr++)
						{
							String childprevName=driver.findElement(By.xpath("//table[@id='privTree_id']/tbody/tr["+pr+"]/th/a/span")).getText().trim();
							//System.out.println("chiildprevNameApp:"+childprevName);
							//System.out.println("childselPriv:"+selPriv);
							//Thread.sleep(1000);
							if (childprevName.contains(selPriv))
							{
								driver.findElement(By.xpath("//table[@id='privTree_id']/tbody/tr["+pr+"]/th/a/span/input[@name='privID'][@type='checkbox']")).click();
								extent.log(LogStatus.INFO, "Privilege:"+selPriv+" checkbox is selected");
								break;
								
							}
						}
					}
					break;
				}
			}
			/*else
			{
				extent.log(LogStatus.WARNING, "Privilege:"+PrivilegeName+" not found/expanded");
			}*/
		}
		//
		
	}
	
	public static boolean clickSave(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{
			By savebtn=By.id(btnSave);
			Utilities.waitForPageLoad(driver,savebtn);
			if (driver.findElements(savebtn).size()!=0)
			{					
				driver.findElement(savebtn).click();
				extent.log(LogStatus.PASS, "Clicked on Save button is successful");
				Thread.sleep(4000);
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Save button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static void selectPrivilege(WebDriver driver,String Privilege) throws Exception
	{
		String selectPrivileges=Privilege;
		String[] resPriv=selectPrivileges.split(";");
		for (int s=0;s<resPriv.length;s++)
		{
			String selPriv=resPriv[s];		
			int prc=driver.findElements(By.xpath("//table[@id='privTree_id']/tbody/tr")).size();
			//System.out.println("privtablerc:"+prc);
			for (int p=1;p<=prc;p++)
			{
				String prevName=driver.findElement(By.xpath("//table[@id='privTree_id']/tbody/tr["+p+"]/th/a/span")).getText().trim();
				//System.out.println("prevNameApp:"+prevName);
				//System.out.println("privVal:"+selPriv);
				//Thread.sleep(1000);
				if (prevName.contains(selPriv))
				{
					driver.findElement(By.xpath("//table[@id='privTree_id']/tbody/tr["+p+"]/th/a/span/input[@name='privID'][@type='checkbox']")).click();
					extent.log(LogStatus.INFO, "Previlige Name:"+prevName+"check box is selected");
					//extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Privilege"));
					Thread.sleep(2000);
					break;
					
				}
			}
		}
	}
	
	public static void expandPrivilege(WebDriver driver) throws Exception
	{
		try{		
			By privilegeClosed=By.xpath(btnPrivilegeClosed);
			By privilegeOpened=By.xpath(btnPrivilegeOpened);
			if ( driver.findElements(privilegeClosed).size()!=0 )
			{
				driver.findElement((privilegeClosed)).click(); //click on save
				extent.log(LogStatus.INFO, "Clicked on Previlige icon to expand");
				//captureScreenShot(driver,"SaveButton");
			}
			else if ( driver.findElements(privilegeOpened).size()!=0 )
			{				
				extent.log(LogStatus.INFO, "Privilege icon already expanded");
				//captureScreenShot(driver,"SaveButton");
			}			
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on Privilege button");
				//captureScreenShot(driver,screenshotDir+"PrivilegeButton");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static boolean setTextInRolename(WebDriver driver,String RoleName) throws Exception
	{
		boolean flag=false;
		try{		
			By roleNametxt=By.name(txtRolename);
			Utilities.waitForPageLoad(driver,roleNametxt);
			if (driver.findElements(roleNametxt).size()!=0)
			{
				driver.findElement(roleNametxt).clear();
				driver.findElement(roleNametxt).sendKeys(RoleName);
				extent.log(LogStatus.PASS, "Role Name: "+RoleName +" is entered successfully");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Role Name: "+RoleName +" is NOT entered");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static void setTextInRoleDescription(WebDriver driver,String RoleDesc) throws Exception
	{
		try{		
			By roledesctxt=By.name(txtRoledesc);
			Utilities.waitForPageLoad(driver,roledesctxt);
			if (driver.findElements(roledesctxt).size()!=0)
			{
				driver.findElement(roledesctxt).clear();
				driver.findElement(roledesctxt).sendKeys(RoleDesc);
				extent.log(LogStatus.PASS, "Role Description: "+RoleDesc +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Role Description: "+RoleDesc +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
		
	

}
