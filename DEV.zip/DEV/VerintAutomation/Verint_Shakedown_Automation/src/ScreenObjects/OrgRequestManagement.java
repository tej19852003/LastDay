package ScreenObjects;

import java.awt.Robot;
import java.awt.event.KeyEvent;


import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import org.sikuli.script.Screen;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class OrgRequestManagement {
	
	public static Screen sobj = new Screen ();
	public static ExtentReports extent = ExtentReports.get(OrgRequestManagement.class);
	public static String btnCreate="//button[@id='toolbar_ADD_ACTIONLabel']";
	public static String txtTimeOffPoolname="poolName";
	public static String lstMonth="//input[@id='timeOffCalendarPCMonth_0']";	
	public static String iconyear="//span[@id='timeOffCalendarPCYear_0Wrapper']//nobr//img[@id='timeOffCalendarPCYear_0Button']";
	public static String lstYear="//select[@id='timeOffCalendarPCYear']";	
	public static String btnSave="//button[@id='workpaneMediator_toolbar_SAVE_ACTIONLabel']";
												
	public static String iconEdit="//table[@id='TimeOffPoolAssignmentPC_wrapper_tbl_id border=']/tbody/tr[1]/td[1]/div[2]/img[@alt='edit']";										
	public static String lstTimeOffPool="//span[@id='poolId_0Wrapper']/nobr/img[@id='poolId_0Button']";
	public static String btnSet="//button[@id='workpaneMediator_toolbar_POPUP_JSFUNCTIONLabel']";
	public static String txtVacationDefPerDay="//input[@title='Vacation, Default Per Day']";
	public static String VacationDefPerWeek="//input[@title='Vacation, Default Per Week']";
	public static String txtVacationBalance="//input[@title='Vacation, Balance']";
	public static String txtVacationDateLastUpdated="//input[@title='Vacation, Date Last Updated']";
	public static String btnTimeOffSave="//button[@id='toolbar_SAVE_ACTIONLabel']";
	public static String btncreateNewRule="//button[@id='toolbar_NEW_RULE_DIALOG_NAMELabel']";
	public static String btnCreateNewAutoProcessingRuleTimeOff="//table[@id='toolbar_NEW_TIME_OFFWrapper']/tbody/tr[1]/td[1]/button[@id='toolbar_NEW_TIME_OFFLabel']";
	public static String lstAutoProcessing_TimeOffType="//span[@id='timeOffActivityId_0Wrapper']/nobr/img[@id='timeOffActivityId_0Button']";
	public static String btnSaveApplied="//button[@id='toolbar_APPLY_RULELabel']";
	public static String btnDeleteTimeOffPoolName="//button[@id='toolbar_DELETE_ACTIONLabel']";
	
	
	
	public static boolean clickDeleteTimeOffPool(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			By delBtn=By.xpath(btnDeleteTimeOffPoolName);
			Utilities.waitForPageLoad(driver,delBtn);
			if (driver.findElements(delBtn).size()!=0)
			{					
				driver.findElement(delBtn).click();
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Delete_OK.png");
				extent.log(LogStatus.INFO, "Clicked on Delete button is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Delete button is unsuccessful");
				flag=false;
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean verifyTimeOffPoolName(WebDriver driver,String TimeOffPoolNameName) throws Exception
	{
		Utilities.selectRightPaneView(driver);
		Boolean flag=false;
		try {
			int timerc=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr")).size();
			System.out.println("timerc:"+timerc);
			for (int j=1;j<=timerc;j++)
			{
				String timenameApp=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/th/a/span")).getText().trim();
				System.out.println("timepoolApp:"+timenameApp);
				System.out.println("TimeOffPoolNameName:"+TimeOffPoolNameName);
				Thread.sleep(1000);
				if (timenameApp.contains(TimeOffPoolNameName))
				{
					driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/th/a/span")).click();
					//driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).click();
					flag=true;
					break;
				}
			}
			if (flag==true)
			{
				System.out.println("pass");
				extent.log(LogStatus.PASS, "Work queue Name: "+TimeOffPoolNameName+" created/selected successfully");
				//captureScreenShot(driver,screenshotDir+"OrganizationNameValidation");				
			}
			else
			{
				extent.log(LogStatus.INFO, "Work queue Name: "+TimeOffPoolNameName+ " does not exist");
				//captureScreenShot(driver,screenshotDir+"RoleNameValidation");
				return flag =false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;		
	}
	
	public static boolean selectAutoProcessCriteria_Approval(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{		
			if (driver.findElements(By.xpath("//table[@id='lcPC_wrapper_tbl_id']/tbody/tr[2]/td[1]/span/input[@name='approvedFlag'][@type='checkbox']")).size()!=0)
				driver.findElement(By.xpath("//table[@id='lcPC_wrapper_tbl_id']/tbody/tr[2]/td[1]/span/input[@name='approvedFlag'][@type='checkbox']")).click();
			if (driver.findElements(By.xpath("//table[@id='lcPC_wrapper_tbl_id']/tbody/tr[4]/td[1]/span/input[@name='approveChoice'][@type='radio']")).size()!=0)
				driver.findElement(By.xpath("//table[@id='lcPC_wrapper_tbl_id']/tbody/tr[4]/td[1]/span/input[@name='approveChoice'][@type='radio']")).click();
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectAutoProcessing_TimeOffType(WebDriver driver,String TimeOffType) throws Exception
	{
		boolean flag=false;
		try{		
			By timeOffTypelst=By.xpath(lstAutoProcessing_TimeOffType);
			Utilities.waitForPageLoad(driver,timeOffTypelst);
			if (driver.findElements(timeOffTypelst).size()!=0)
			{
				driver.findElement(timeOffTypelst).click();
				Thread.sleep(2000);				
				driver.findElement(timeOffTypelst).sendKeys(TimeOffType);
				Thread.sleep(3000);
				Robot r = new Robot();
				r.keyPress(KeyEvent.VK_ENTER);
				r.keyRelease(KeyEvent.VK_ENTER);
				extent.log(LogStatus.PASS, "Time Off Type: "+TimeOffType +" is selected successfully");	
				flag=true;				
			}else
			{
				extent.log(LogStatus.FAIL, "Time Off Type: "+TimeOffType +" is NOT selected");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickCreateNewAutoProcessingRuleTimeOff(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			By newRuleBtn=By.xpath(btnCreateNewAutoProcessingRuleTimeOff);
			Utilities.waitForPageLoad(driver,newRuleBtn);
			if (driver.findElements(newRuleBtn).size()!=0)
			{					
				driver.findElement(newRuleBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Create New Auto Processing Rule -Time Off button is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Create New Auto Processing Rule -Time Off button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean clickCreateNewRule(WebDriver driver) throws Exception
	{		
		boolean flag=false;
		try{
			
			By ruleBtn=By.xpath(btncreateNewRule);
			Utilities.waitForPageLoad(driver,ruleBtn);
			if (driver.findElements(ruleBtn).size()!=0)
			{					
				driver.findElement(ruleBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Create New Rule button is successful");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Create New Rule button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean verifyAutoProcessingRequestON(WebDriver driver,String RequestType) throws Exception
	{
		Utilities.selectRightPaneView(driver);
		Boolean flag=false;
		try {
			int valrc=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr")).size();
			System.out.println("valrcPriv:"+valrc);
			for (int j=1;j<=valrc;j++)
			{
				String reqTypeApp=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/td[1]")).getText().trim();
				System.out.println("reqTypeApp:"+reqTypeApp);
				System.out.println("reqType:"+RequestType);
				Thread.sleep(1000);
				if (reqTypeApp.contains(RequestType))
				{
					if (driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/th/a/span/span/input[@name='appliedRuleIds'][@type='checkbox']")).size()!=0)
					{
						if (driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/th/a/span/span/input[@name='appliedRuleIds'][@type='checkbox']")).isSelected())
						{
							System.out.println("already checked");
							extent.log(LogStatus.PASS, "Auto Processing - Request Type: "+RequestType+" is ON by default");
							extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "AutoProcessing"));
							flag=true;
							break;
						}
						else
						{													
							driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/th/a/span/span/input[@name='appliedRuleIds'][@type='checkbox']")).click();	
							Thread.sleep(2000);
							System.out.println("now checked");
							if (driver.findElements(By.xpath("//table[@id='toolbar_APPLY_RULEWrapper']/tbody/tr[1]/td[1]/button[@id='toolbar_APPLY_RULELabel']")).size()!=0)
							{
								System.out.println("save applied");
								driver.findElement(By.xpath("//table[@id='toolbar_APPLY_RULEWrapper']/tbody/tr[1]/td[1]/button[@id='toolbar_APPLY_RULELabel']")).click();
								extent.log(LogStatus.PASS, "Auto Processing - Request Type: "+RequestType+" is ON");
								extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "AutoProcessing"));
								flag=true;
								break;
							}						
						}
					}
					else
					{
						flag=false;
					}
				}
			}
			if (flag==false)
			
			{
				extent.log(LogStatus.INFO, "Auto Processing - Request Type: "+RequestType+" NOT exist");				
				return flag =false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;		
	}
	public static boolean clickSaveApplied(WebDriver driver) throws Exception
	{		
		boolean flag=false;
		try{
			
			By saveBtn=By.xpath(btnSaveApplied);
			Utilities.waitForPageLoad(driver,saveBtn);
			if (driver.findElements(saveBtn).size()!=0)
			{					
				driver.findElement(saveBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Save Applied button is successful");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Save Applied button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean clickTimeOffSave(WebDriver driver) throws Exception
	{		
		boolean flag=false;
		try{
			
			By saveBtn=By.xpath(btnTimeOffSave);
			Utilities.waitForPageLoad(driver,saveBtn);
			if (driver.findElements(saveBtn).size()!=0)
			{					
				driver.findElement(saveBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Save button is successful");
				Thread.sleep(6000);
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "TimeOffSave"));
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Save button is unsuccessful");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "TimeOffSave"));
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static void setTextInVacationDateLastUpdated(WebDriver driver,String DateLastUpdate) throws Exception
	{
		try{		
			By datetxt=By.xpath(txtVacationDateLastUpdated);
			Utilities.waitForPageLoad(driver,datetxt);
			if (driver.findElements(datetxt).size()!=0)
			{
				driver.findElement(datetxt).clear();
				driver.findElement(datetxt).sendKeys(DateLastUpdate);
				extent.log(LogStatus.PASS, "Date Last Update: "+DateLastUpdate +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Date Last Update: "+DateLastUpdate +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void setTextInVacationBalance(WebDriver driver,String Balance) throws Exception
	{
		try{		
			By baltxt=By.xpath(txtVacationBalance);
			Utilities.waitForPageLoad(driver,baltxt);
			if (driver.findElements(baltxt).size()!=0)
			{
				driver.findElement(baltxt).clear();
				driver.findElement(baltxt).sendKeys(Balance);
				extent.log(LogStatus.PASS, "Vacation Balance: "+Balance +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Vacation Balance: "+Balance +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void setTextInVacationDefPerWeek(WebDriver driver,String Weeks) throws Exception
	{
		try{		
			By weektxt=By.xpath(VacationDefPerWeek);
			Utilities.waitForPageLoad(driver,weektxt);
			if (driver.findElements(weektxt).size()!=0)
			{
				driver.findElement(weektxt).clear();
				driver.findElement(weektxt).sendKeys(Weeks);
				extent.log(LogStatus.PASS, "Vacation Default Per Week: "+Weeks +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Vacation Default Per Week: "+Weeks +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void setTextInVacationDefPerDay(WebDriver driver,String Days) throws Exception
	{
		try{		
			By daytxt=By.xpath(txtVacationDefPerDay);
			Utilities.waitForPageLoad(driver,daytxt);
			if (driver.findElements(daytxt).size()!=0)
			{
				driver.findElement(daytxt).clear();
				driver.findElement(daytxt).sendKeys(Days);
				extent.log(LogStatus.PASS, "Vacation Default Per Day: "+Days +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Vacation Default Per Day: "+Days +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static boolean clickSet(WebDriver driver) throws Exception
	{		
		boolean flag=false;
		try{
			
			By setBtn=By.xpath(btnSet);
			Utilities.waitForPageLoad(driver,setBtn);
			if (driver.findElements(setBtn).size()!=0)
			{					
				driver.findElement(setBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Set button is successful");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Set button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean selectTimeOffPool(WebDriver driver,String TimeOffPool) throws Exception
	{
		boolean flag=false;
		try{		
			By timeOffPoollst=By.xpath(lstTimeOffPool);
			Utilities.waitForPageLoad(driver,timeOffPoollst);
			if (driver.findElements(timeOffPoollst).size()!=0)
			{
				driver.findElement(timeOffPoollst).click();
				Thread.sleep(2000);				
				driver.findElement(timeOffPoollst).sendKeys(TimeOffPool);
				Thread.sleep(3000);
							
				extent.log(LogStatus.PASS, "Time Off Pool: "+TimeOffPool +" is selected successfully");	
				flag=true;				
			}else
			{
				extent.log(LogStatus.FAIL, "Time Off Pool: "+TimeOffPool +" is NOT selected");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickEditIcon(WebDriver driver) throws Exception
	{		
		boolean flag=false;
		try{
			driver.switchTo().defaultContent();
			Utilities.selectRightPaneView(driver);
			By editIcon=By.xpath(iconEdit);
			Utilities.waitForPageLoad(driver,editIcon);
			if (driver.findElements(editIcon).size()!=0)
			{					
				driver.findElement(editIcon).click();
				extent.log(LogStatus.PASS, "Clicked on Edit icon is successful");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Edit icon is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static boolean clickSave(WebDriver driver) throws Exception
	{		
		boolean flag=false;
		try{
			driver.switchTo().defaultContent();
			Utilities.selectRightPaneView(driver);
			By savebtn=By.xpath(btnSave);
			Utilities.waitForPageLoad(driver,savebtn);
			if (driver.findElements(savebtn).size()!=0)
			{					
				driver.findElement(savebtn).click();
				extent.log(LogStatus.PASS, "Clicked on Save button is successful");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Save button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean setAllocatedTimeOffHours(WebDriver driver,String Hours) throws Exception
	{
		boolean flag=false;
		try{		
			for (int h=2;h<=6;h++)
			{
				if (driver.findElements(By.xpath("//table[@id='timeOffCalendarPCWrapper']/tbody/tr[2]/td[1]/table/tbody/tr[4]/td["+h+"]/span/input[@id='dayValue_0']")).size()!=0)
				{
					driver.findElement(By.xpath("//table[@id='timeOffCalendarPCWrapper']/tbody/tr[2]/td[1]/table/tbody/tr[4]/td["+h+"]/span/input[@id='dayValue_0']")).sendKeys(Hours);
					flag=true;
				}
				else
				{
					flag=false;
				}
			}	
			if (flag==true)
			{
				extent.log(LogStatus.PASS, "Hours:"+Hours+" entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Hours:"+Hours+" NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectYear(WebDriver driver,String Year) throws Exception
	{
		boolean flag=false;
		try{		
			By yearlst=By.xpath(iconyear);
			Utilities.waitForPageLoad(driver,yearlst);
			if (driver.findElements(yearlst).size()!=0)
			{
				driver.findElement(yearlst).click();
				Thread.sleep(3000);
				Select sbox=new Select(driver.findElement(By.xpath(lstYear)));
				sbox.selectByVisibleText(Year);
				//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
				//driver.findElement(By.xpath(lstYear)).sendKeys(Year);
				System.out.println("year is:"+Year);
				Thread.sleep(3000);
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK1.png");
				Thread.sleep(5000);
				//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
				//System.out.println("year:"+driver.findElement(yearlst).getText().trim());
				/*if (!driver.findElement(yearlst).getText().trim().contains(Year))
				{
					driver.findElement(yearlst).click();
					Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
					driver.findElement(yearlst).sendKeys(Year);
					Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
				}*/
				extent.log(LogStatus.PASS, "Year Name: "+Year +" is selected successfully");	
				flag=true;				
			}else
			{
				extent.log(LogStatus.FAIL, "Year Name: "+Year +" is NOT selected");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean selectMonth(WebDriver driver,String Month) throws Exception
	{
		boolean flag=false;
		try{		
			By monthlst=By.xpath(lstMonth);
			Utilities.waitForPageLoad(driver,monthlst);
			if (driver.findElements(monthlst).size()!=0)
			{
				driver.findElement(monthlst).click();
				Thread.sleep(3000);
				//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
				driver.findElement(monthlst).sendKeys(Month);
				Thread.sleep(3000);
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
				Thread.sleep(5000);
				//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
				System.out.println("month:"+driver.findElement(monthlst).getText().trim());
				/*if (!driver.findElement(monthlst).getText().trim().contains(Month))
				{
					driver.findElement(monthlst).click();
					Thread.sleep(3000);
					Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
					driver.findElement(monthlst).sendKeys(Month);
					Thread.sleep(3000);
					Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
					Thread.sleep(5000);
				}*/
				extent.log(LogStatus.PASS, "Month Name: "+Month +" is selected successfully");	
				flag=true;				
			}else
			{
				extent.log(LogStatus.FAIL, "Month Name: "+Month +" is NOT selected");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static void setTextInTimeOffPoolName(WebDriver driver,String TimeOffPoolName) throws Exception
	{
		try{		
			By timeOffPoolnametxt=By.id(txtTimeOffPoolname);
			Utilities.waitForPageLoad(driver,timeOffPoolnametxt);
			if (driver.findElements(timeOffPoolnametxt).size()!=0)
			{
				driver.findElement(timeOffPoolnametxt).clear();
				driver.findElement(timeOffPoolnametxt).sendKeys(TimeOffPoolName);
				extent.log(LogStatus.PASS, "Time Off Pool Name: "+TimeOffPoolName +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Time Off Pool Name: "+TimeOffPoolName +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static boolean clickCreateTimeOffPoolName(WebDriver driver) throws Exception
	{		
		boolean flag=false;
		try{
			driver.switchTo().defaultContent();
			Utilities.selectRightPaneView(driver);
			By createbtn=By.xpath(btnCreate);
			Utilities.waitForPageLoad(driver,createbtn);
			if (driver.findElements(createbtn).size()!=0)
			{					
				driver.findElement(createbtn).click();
				extent.log(LogStatus.PASS, "Clicked on Create button is successful");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Create button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
}

