package ScreenObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class ShiftScreen
{
	public static ExtentReports extent = ExtentReports.get(ShiftScreen.class);
	public static String btncreateshift="//button[@id='toolbar_ADD_ACTIONLabel']";
	public static String txtshiftname="shift_name";
	public static String txtdesc="shift_description";
	public static String strttime="//table[@id='startTimesMinsSinceMidnight_table']//tbody//tr//td[@col='8']";
	public static String strttime2="//table[@id='startTimesMinsSinceMidnight_table']//tbody//tr//td[@col='16']";
	public static String btnsave="//button[@id='toolbar_CREATE_NEW_ACTIONLabel']";
	
	
	public static boolean clickcreateshift(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By createshift_btn=By.xpath(btncreateshift);
			Utilities.waitForPageLoad(driver,createshift_btn);
			if(driver.findElements(createshift_btn).size()!=0)
			{
				driver.findElement(createshift_btn).click();
				flag=true;
				extent.log(LogStatus.PASS,"Clcked on create button is sucessfull");
			}
			else
			{ 
				extent.log(LogStatus.FAIL,"Clcked on create button is not sucessfull");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}

	public static boolean setshiftName(WebDriver driver,String shiftName) throws Exception
	{
		boolean flag=false;
		try{		
			By shiftnametxt=By.name(txtshiftname);
			Utilities.waitForPageLoad(driver,shiftnametxt);
			if (driver.findElements(shiftnametxt).size()!=0)
			{
				driver.findElement(shiftnametxt).clear();
				driver.findElement(shiftnametxt).sendKeys(shiftName);
				extent.log(LogStatus.PASS, "Work pattern Name"+shiftName +" is entered successfully");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Work pattern Name "+shiftName +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean setshiftDescription(WebDriver driver,String shiftDesc) throws Exception
	{
		boolean flag=false;
		try{		
			By shiftDesctxt=By.name(txtdesc);
			Utilities.waitForPageLoad(driver,shiftDesctxt);
			if (driver.findElements(shiftDesctxt).size()!=0)
			{
				driver.findElement(shiftDesctxt).clear();
				driver.findElement(shiftDesctxt).sendKeys(shiftDesc);
				extent.log(LogStatus.PASS, "Work pattern Description "+shiftDesc +" is entered successfully");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Work pattern Description "+shiftDesc +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setshiftstartTime(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{		
			By shiftstarttime=By.xpath(strttime);
			Utilities.waitForPageLoad(driver,shiftstarttime);
			if (driver.findElements(shiftstarttime).size()!=0)
			{
				driver.findElement(shiftstarttime).click();
				extent.log(LogStatus.PASS, "Shift start time is entered sucessfully");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Shift start time is not entered sucessfully");	
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean setshiftstartTime2(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{		
			By shiftstarttime2=By.xpath(strttime2);
			Utilities.waitForPageLoad(driver,shiftstarttime2);
			if (driver.findElements(shiftstarttime2).size()!=0)
			{
				driver.findElement(shiftstarttime2).click();
				extent.log(LogStatus.PASS, "Shift start time is entered sucessfully");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Shift start time is not entered sucessfully");	
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickSave(WebDriver driver) throws Exception
	{		
		boolean flag=false;
		try{	
			Utilities.selectRightPaneView(driver);
			By saveBtn=By.xpath(btnsave);
			Utilities.waitForPageLoad(driver,saveBtn);
			if (driver.findElements(saveBtn).size()!=0)
			{					
				driver.findElement(saveBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Save button is successful");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Save button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean Shiftexist(WebDriver driver,String shiftname) throws Exception
	{
		Utilities.selectRightPaneView(driver);
		boolean Temp=false;
		driver.findElement(By.name("itemToFind")).clear();
    	driver.findElement(By.name("itemToFind")).sendKeys(shiftname);
    	driver.findElement(By.xpath("//button[@id='toolbar_FIND_ACTIONLabel']")).click();
    	Thread.sleep(2000);
    	List<WebElement> li=driver.findElements(By.xpath("//table[@id='shiftTableRef']//tr[@class='tblRow']"));
    	System.out.println("++++"+ li.size());
    	if(driver.findElements(By.xpath("//table[@id='shiftTableRef']//tr[@class='tblRow']//td")).size()!=0)
    	{
    		for(WebElement elt:li)
        	{
        		//System.out.println("**************");
        		System.out.println(elt.findElement(By.tagName("td")).getAttribute("innerText"));
        		String wname=elt.findElement(By.tagName("td")).getAttribute("innerText");
        		if(wname.contains(shiftname))
        		{
        			System.out.println("shift name is"+wname);
        			Temp=true;
        			break;
        		}
        	}
    	}
    	else
    	{
    		Temp=false;
    	}
    	return Temp;
    	
	}
	
	public static boolean deleteshift(WebDriver driver,String shiftName) throws Exception
	{
		boolean flag=false;
		try
		{
			driver.findElement(By.name("itemToFind")).clear();
	    	driver.findElement(By.name("itemToFind")).sendKeys(shiftName);
	    	driver.findElement(By.xpath("//button[@id='toolbar_FIND_ACTIONLabel']")).click();
	    	List<WebElement> li=driver.findElements(By.xpath("//table[@id='shiftTableRef']//tr[@class='tblRow']"));
	    	System.out.println(li.size());
	    	if(li.size()>0)
	    	{
	    		for(WebElement elt:li)
	        	{
	        		//System.out.println("**************");
	        		System.out.println(elt.findElement(By.tagName("td")).getAttribute("innerText"));
	        		String wname=elt.findElement(By.tagName("td")).getAttribute("innerText");
	        		if(wname.contains(shiftName))
	        		{
	        			elt.findElement(By.tagName("td")).click();
	        			driver.findElement(By.id("toolbar_DELETE_ACTIONLabel")).click();
	        			Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\btnok_camp.png");
	        			System.out.println("Shift deleted");
	        			flag=true;
	        			break;
	        		}
	        	}
	    	}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
}
