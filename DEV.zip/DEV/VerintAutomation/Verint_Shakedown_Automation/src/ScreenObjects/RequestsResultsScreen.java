package ScreenObjects;



import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

//import Library.DPA_Library;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class RequestsResultsScreen {
	
	public static ExtentReports extent = ExtentReports.get(RequestsResultsScreen.class);	
	public static String txtReportName="rffName_0"; //input
	public static String txtReportNote="note"; //textarea
	public static String btnRunNow="//button[@id='toolbar_RUN_NOW_ACTIONLabel']";
	
	public static boolean clickRunNow(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			Utilities.selectRightPaneView(driver);
			By runNowBtn=By.xpath(btnRunNow);
			Utilities.waitForPageLoad(driver,runNowBtn);
			if (driver.findElements(runNowBtn).size()!=0)
			{					
				driver.findElement(runNowBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Run Now button is successful");
				Thread.sleep(16000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Run Now button is unsuccessful");
				flag=false;
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean setReportNote(WebDriver driver,String ReportNote)
	{
		Boolean flag=false;
		try{				
			By notetxt=By.id(txtReportNote);
			Utilities.waitForPageLoad(driver,notetxt);
			if (driver.findElements(notetxt).size()!=0)
			{
				driver.findElement(notetxt).sendKeys(ReportNote);
				extent.log(LogStatus.PASS, "Report Note: "+ReportNote +" is entered successfully");		
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Report Note: "+ReportNote +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;	
	}
	public static boolean setReportName(WebDriver driver,String ReportName)
	{
		Boolean flag=false;
		try{				
			By nametxt=By.id(txtReportName);
			Utilities.waitForPageLoad(driver,nametxt);
			if (driver.findElements(nametxt).size()!=0)
			{
				driver.findElement(nametxt).sendKeys(ReportName);
				extent.log(LogStatus.PASS, "Report Name: "+ReportName +" is entered successfully");		
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Report Name: "+ReportName +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;	
	}
	
	public static boolean selectReportSelection(WebDriver driver,String ReportSelection) throws Exception
	{
		Boolean flag=false;
		try {
			Utilities.selectLeftTreeFrame(driver);
			Thread.sleep(3000);	
			//if (driver.findElements(By.xpath("//div[@id='reportTreer0']/nobr/a/span/span")).size()==0)
			if (driver.findElements(By.xpath("//div[@id='reportTreer0']")).size()==0)
			{
				extent.log(LogStatus.FAIL, "Report Selection data is not displayed");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "WFMReport"));
				return flag=false;				
			}
			//if (Utilities.SearchItem(driver, ReportSelection))
			//{  
			if (driver.findElements(By.xpath("//div[@id='reportTreer0']/nobr/a/span/span")).size()!=0)
			{
				driver.findElement(By.xpath("//div[@id='reportTreer0']/nobr/a/span/span")).click();
			}
			/*Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\UpperArrow.png");
			Thread.sleep(1000);
			Robot r = new Robot();
			r.keyPress(KeyEvent.VK_PAGE_DOWN);
			Thread.sleep(1000);
			r.keyRelease(KeyEvent.VK_PAGE_DOWN);*/
			//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\ReportSelection_Verticalbar.png");
				for (int i=0;i<=25;i++)
				{
					String reportSelApp=driver.findElement(By.xpath("//div[@id='reportTreer"+i+"Nodes']/div/nobr/a/span/span")).getText();
					System.out.println("reportSelApp:"+reportSelApp);
					if (reportSelApp.contains(ReportSelection))
					{
						driver.findElement(By.xpath("//div[@id='reportTreer"+i+"Nodes']/div/nobr/a/span/span")).click();
						extent.log(LogStatus.PASS, "Report Selection: "+ReportSelection+" selected successfully");
						flag=true;
						//extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "WFMReport"));
						break;
					}
				}
				if (flag==false)
				{
					extent.log(LogStatus.FAIL, "Unable to select Report Selection: "+ReportSelection);
					//extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "WFMReport"));
				}
			//}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;			
	}
}

