package ScreenObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import com.thoughtworks.selenium.webdriven.commands.GetText;

public class WorkRulesScreen 
{
	public static ExtentReports extent = ExtentReports.get(WorkQueuesScreen.class);
	public static String txtfindEmployee="peopleFilter_find";
	public static String btnAdd="workPatternToolbar_POPUP_WORKPATTERNLabel";
	public static String btnSave="toolbar_SAVE_ACTIONLabel";
	
	
	public static boolean findEmployee(WebDriver driver,String EmployeeName)
	{
		boolean flag=false;
		try
		{
			Utilities.selectLeftTreeFrame(driver);
			By txtName=By.name(txtfindEmployee);
			Utilities.waitForPageLoad(driver,txtName);
			if(driver.findElements(txtName).size()!=0)
			{
				driver.findElement(txtName).clear();
				driver.findElement(txtName).sendKeys(EmployeeName,Keys.ENTER);
				flag=true;
				extent.log(LogStatus.PASS,EmployeeName +" is entered sucessfully");
			}
			else
			{
				extent.log(LogStatus.FAIL,EmployeeName + "is not searched");
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
		
	}
	
	public static boolean SelectEmployee(WebDriver driver,String EmployeeName) throws Exception
	{
		boolean flag=false;
		Utilities.selectLeftTreeFrame(driver);
		int no= driver.findElements(By.xpath("//div[@id='psWrapper']//table[@id='psLIST_TBL_NAME']//tbody//tr")).size();
		System.out.println("no of rows are:" + no);
		//String empname=driver.findElement(By.xpath("//table[@id='psLIST_TBL_NAME']//tbody//tr[1]//td[2]//div//nobr//a")).getText();
		for(int i=1;i<no;i++)
		{
			String empname=driver.findElement(By.xpath("//table[@id='psLIST_TBL_NAME']//tbody//tr["+i+"]//td//div//nobr//a")).getText();
			System.out.println("emp name is:"+ empname );
			if(empname.contains(EmployeeName))
			{
				driver.findElement(By.xpath("//table[@id='psLIST_TBL_NAME']//tbody//tr["+i+"]//td//div//nobr//a")).click();
				Thread.sleep(2000);
				break;
				
			}
			flag=true;
		}
		if(flag==true)
		{
			extent.log(LogStatus.PASS,EmployeeName +"is selected sucessfully");
		}
		else
		{
			extent.log(LogStatus.FAIL,EmployeeName + " does not exist");
			return flag=false;
		}
		return flag;
	
	}
	
	public static boolean clickAdd(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By btnAddwp=By.id(btnAdd);
			Utilities.waitForPageLoad(driver,btnAddwp);
			if(driver.findElements(btnAddwp).size()!=0)
			{
				driver.findElement(btnAddwp).click();
				extent.log(LogStatus.PASS,"clicked on Add work pattern is sucessfull");
				Thread.sleep(6000);
				flag = true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"clicked on add work pattren is not sucessfull");
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return flag;
	}
	
	
	public static boolean clickSave(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By Savebtn=By.id(btnSave);
			Utilities.waitForPageLoad(driver,Savebtn);
			if(driver.findElements(Savebtn).size()!=0)
			{
				driver.findElement(Savebtn).click();
				extent.log(LogStatus.PASS,"clicked on save button is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"clicked on save button is not sucessfull");
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}
	
	public static  boolean clickAddworkPattern(WebDriver driver,String workPatternName)
	
	{
		boolean flag=false;
		try
	{
		/*Utilities.setWindowFocus(driver);
		driver.switchTo().frame("oRightPaneContent");
        driver.findElement(By.xpath("//button[@id='workPatternToolbar_POPUP_WORKPATTERNLabel']")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//button[@id='workpaneMediator_toolbar_NEXT_ACTIONLabel']")).click();
        Thread.sleep(2000);
		int no=driver.findElements(By.xpath("//div[@id='tableWrapper']//table[@id='tableRef']//tr")).size();
		System.out.println("no of rows are:" + no);
		for(int i=1;i<no;i+=2)
		{
			String wpname=driver.findElement(By.xpath("//div[@id='tableWrapper']//table[@id='tableRef']//tr[contains(@id,'tabler"+i+"')]//td[contains(@id,'tabler"+i+"c1')]")).getText();
			System.out.println("shift name is:" + wpname);
			if(wpname.contains(workPatternName))
			{
				driver.findElement(By.xpath("//div[@id='tableWrapper']//table[@id='tableRef']//tr[contains(@id,'tabler"+i+"')]//td[contains(@id,'tabler"+i+"c1')]")).click();
				break;
			}
		}*/
			
			driver.findElement(By.name("itemToFind")).sendKeys(workPatternName);
	    	driver.findElement(By.xpath("//button[@id='workpaneMediator_toolbar_FIND_ACTIONLabel']")).click();
	    	Thread.sleep(2000);
	    	List<WebElement> li1=driver.findElements(By.xpath("//table[@id='tableRef']//tr[@class='tblRow']"));
			System.out.println(li1.size());
			for(WebElement elt:li1)
			{
				//System.out.println("**************");
				System.out.println(elt.findElement(By.tagName("td")).getAttribute("innerText"));
				String wname=elt.findElement(By.tagName("td")).getAttribute("innerText");
				if(wname.contains(workPatternName))
				{
					//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
					elt.findElement(By.tagName("td")).click();
					flag=true;
					break;
				}
			}
		driver.findElement(By.xpath("//button[@id='workpaneMediator_toolbar_addWorkPatternsLabel']")).click();
		flag=true;
	}catch(Exception e)
	{
		e.printStackTrace();
	}
		return flag;
		
		
	}
	
	public static boolean sethours(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			//driver.findElement(By.name("hoursPC__minPaid__input")).clear();
			driver.findElement(By.name("hoursPC__minPaid__input")).sendKeys("8");
			//driver.findElement(By.name("hoursPC__maxPaid__input")).clear();
			driver.findElement(By.name("hoursPC__maxPaid__input")).sendKeys("40");
			//driver.findElement(By.name("hoursPC__otPerDay__input")).clear();
			driver.findElement(By.name("hoursPC__otPerDay__input")).sendKeys("4");
			//driver.findElement(By.name("hoursPC__otPerWeek__input")).clear();
			driver.findElement(By.name("hoursPC__otPerWeek__input")).sendKeys("20");
			
			flag=true;
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean WorkPatternexist(WebDriver driver,String Wname) throws Exception
	{
		Utilities.selectRightPaneView(driver);
		boolean Temp=false;
		
    	List<WebElement> li=driver.findElements(By.xpath("//table[@id='workPatternTableRef']//tr[@class='tblRow']"));
    	System.out.println("++++"+ li.size());
    	if(driver.findElements(By.xpath("//table[@id='workPatternTableRef']//tr[@class='tblRow']//th")).size()!=0)
    	{
    		for(WebElement elt:li)
        	{
        		//System.out.println("**************");
        		System.out.println(elt.findElement(By.tagName("th")).getAttribute("innerText"));
        		String wname=elt.findElement(By.tagName("th")).getAttribute("innerText");
        		if(wname.contains(Wname))
        		{
        			System.out.println("work pattern name is"+wname);
        			Temp=true;
        			break;
        		}
        	}
    	}
    	else
    	{
    		Temp=false;
    	}
    	return Temp;
    	
	}
	
}
