package ScreenObjects;

import java.util.Iterator;
import java.util.Set;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.sikuli.script.Screen;

import Utilities.Utilities;

public class Impact360Screen {
	public static Screen sobj = new Screen ();
	public static ExtentReports extent = ExtentReports.get(Impact360Screen.class);
	public static String btnQMSearch="HomePageLeftMenu1_HomePageExpertMenu__ctl2_MainLabel";
	public static String btnQMReports="HomePageLeftMenu1_HomePageExpertMenu__ctl7_MainLabel";
	
	public static void closeQM(WebDriver driver) throws Exception
	{		
		Set<String> windowIds2 = driver.getWindowHandles();
		System.out.println("windows size:"+windowIds2.size());
		if (windowIds2.size() >=2)
		{
			Iterator<String> itererator2 = windowIds2.iterator(); 			
			String mainWinID2 = itererator2.next();//main window 
			Thread.sleep(1000);	
			String  popWindow2 = itererator2.next();//popup window
			Thread.sleep(2000);	
			driver.switchTo().window(popWindow2);
			System.out.println("title"+driver.getTitle());
			driver.close();
			Thread.sleep(3000);
			driver.switchTo().window(mainWinID2);
		}
		
	}
	public static void clickQMReports(WebDriver driver) throws Exception
	{
		try{
			By qmReports=By.id(btnQMReports);
			driver.switchTo().frame(1);
			Utilities.waitForPageLoad(driver,qmReports);
			if (driver.findElements(qmReports).size()!=0)
			{					
				driver.findElement(qmReports).click();
				extent.log(LogStatus.INFO, "Clicked on QM - Reports button is successful");
				Thread.sleep(4000);
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on QM - Reports button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static boolean clickQMSearch(WebDriver driver) throws Exception
	{
		boolean flag=true;
		try{
			Thread.sleep(4000);
			//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Search.png");
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Search.png")!= null)
			{
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QM05_07_14_Playback_EvalForm_RemarksBy"));
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Search.png");
				extent.log(LogStatus.INFO, "Clicked on QM - Search button is successful");
				Thread.sleep(5000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Clicked on QM - Search button is unsuccessful");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "QM05_07_14_Playback_EvalForm_RemarksBy"));
				flag=false;
			}
			
			/*By qmSearch=By.id(btnQMSearch);
			driver.switchTo().defaultContent();
			driver.switchTo().frame(1);
			Thread.sleep(4000);
			Utilities.waitForPageLoad(driver,qmSearch);
			if (driver.findElements(qmSearch).size()!=0)
			{					
				driver.findElement(qmSearch).click();
				extent.log(LogStatus.INFO, "Clicked on QM - Search button is successful");
				Thread.sleep(5000);
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on QM - Search button is unsuccessful");
				flag=false;
			}*/
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
}
