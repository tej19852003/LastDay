package ScreenObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.sikuli.script.Screen;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class QualityMonitoringSearchScreen {

	public static ExtentReports extent = ExtentReports.get(Impact360Screen.class);
	public static String btnExecuteSearch="Search_btnExecuteSearch_btnExecuteSearch";
	public static Screen sobj = new Screen ();
	
	public static boolean selectContactsStartTime(WebDriver driver,String Userid) throws Exception
	{
		Thread.sleep(4000);		
	    Boolean flag=false;
	    String callName="";
	    String Agent="";
		
	    if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_No.png")==null)
		{
			/*Thread.sleep(5000);
			driver.switchTo().defaultContent();
			driver.switchTo().frame(0);
			Thread.sleep(2000);	
		    driver.switchTo().frame("Grid");		   
		    Thread.sleep(2000);	*/
		    
		    
		    Thread.sleep(5000);	
			driver.switchTo().defaultContent();
			Utilities.switchFrame(driver,"FR_GRID");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"Grid");
			Thread.sleep(2000);
		    
		    
		    
		    
			int rcCall=driver.findElements(By.xpath("//table[@id='POG1']/tbody/tr")).size();
			System.out.println("callRC:"+rcCall);			
			if (rcCall>1)
			{
				extent.log(LogStatus.PASS, "Contact results are displayed successfully");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QMCall"));
				//flag=true;			
			}
			else
			{
				extent.log(LogStatus.WARNING,"Contacts results were not displayed");
				extent.log(LogStatus.WARNING, "", "", Utilities.captureScreenShot(driver, "QMCall"));
				return flag =false;
			}				
		}
		else
		{
			extent.log(LogStatus.FAIL, "Message : No contacts were found. Try to broaden the search parameters. is diplayed ");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "QMCall"));	
			return flag=false;
		}  
	    
	    
		int rcCall=driver.findElements(By.xpath("//table[@id='POG1']/tbody/tr")).size();
		System.out.println("callRC:"+rcCall);
		int j;
		if (rcCall>1)
		{
			for (j=2;j<=rcCall;j++)
			{	
				driver.manage().window().maximize();
				
				Agent=driver.findElement(By.xpath("//table[@id='POG1']/tbody/tr["+j+"]/td[4]")).getText().trim();
				System.out.println("agent:"+j+";"+Agent);
				System.out.println("uid:"+Utilities.Globlocators.getProperty("UserName"));
				if (j==25)
				{
					if (Utilities.sikuliExist(driver,(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Downarrow.png")))
					{
						Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Downarrow.png");
						System.out.println("clicked");
					}
					else
					{
						System.out.println("not");
					}
				}
				if (Userid=="")
				{System.out.println("inside  null");
					callName=driver.findElement(By.xpath("//table[@id='POG1']/tbody/tr["+j+"]/td[1]/a")).getText().trim();
					System.out.println("callName:"+callName);		
					extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QMCall"));
					driver.findElement(By.xpath("//table[@id='POG1']/tbody/tr["+j+"]/td[1]/a")).click();
					//extent.log(LogStatus.PASS,"Call Name - "+callName+" selected successfully");
					flag=true;
					break;
				}
				if (Userid!=null)
				{
					if (Agent.contains(Utilities.Globlocators.getProperty("UserName")))
					{	System.out.println("inside not null");					
						callName=driver.findElement(By.xpath("//table[@id='POG1']/tbody/tr["+j+"]/td[1]/a")).getText().trim();
						System.out.println("callName:"+callName);		
						extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QMCall"));
						driver.findElement(By.xpath("//table[@id='POG1']/tbody/tr["+j+"]/td[1]/a")).click();
						//extent.log(LogStatus.PASS,"Call Name - "+callName+" selected successfully");
						flag=true;
						break;		
					}
				}
			}
		}
		else
		{
			extent.log(LogStatus.WARNING,"Contacts Start Time links were were not displayed");
			extent.log(LogStatus.WARNING, "", "", Utilities.captureScreenShot(driver, "QMCall"));
			return flag =false;
		}
		if (flag==true)
		{
			System.out.println("pass");
			extent.log(LogStatus.PASS, "Contact Start Link Name: "+callName+" selected successfully");
			extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QMCall"));				
		}	
		else
		{
			extent.log(LogStatus.PASS, "Agent name:"+Utilities.Globlocators.getProperty("UserName")+" not found");
			flag=false;
		}
		return flag; 
	}
	
	public static boolean clickExecuteSearch(WebDriver driver) throws Exception
	{
		 Boolean flag=false;
		try{
			By executeSearch=By.id(btnExecuteSearch);
			driver.switchTo().defaultContent();
			driver.switchTo().frame("FR_HEADER");
			Utilities.waitForPageLoad(driver,executeSearch);
			if (driver.findElements(executeSearch).size()!=0)
			{					
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QM05_07_14_Playback_EvalForm_RemarksBy"));
				driver.findElement(executeSearch).click();
				extent.log(LogStatus.INFO, "Clicked on QM Search - Execute Search button is successful");
				Thread.sleep(4000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on QM Search - Execute Search button is unsuccessful");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QM05_07_14_Playback_EvalForm_RemarksBy"));
				return flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
}
