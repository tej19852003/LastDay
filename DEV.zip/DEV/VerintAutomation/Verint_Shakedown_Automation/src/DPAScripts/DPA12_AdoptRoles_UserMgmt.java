package DPAScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import ScreenObjects.LoginScreen;

import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.AccessRightsScreen;
import ScreenObjects.ProfilesScreen;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;


public class DPA12_AdoptRoles_UserMgmt {
	
	public static ExtentReports extent = ExtentReports.get(DPA12_AdoptRoles_UserMgmt.class);
	
	public static boolean DPA12_AdoptRoles() throws Exception
	{
	
		boolean flag=true;	
		String HTMLReportName="DPA12_Adopt_Roles"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "AdoptRoles_UserManagement");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("DPA_TestSet");
	    String organizationName = Ws.getCell(5,4).getContents();
	    String roleName = Ws.getCell(8,4).getContents();
	    String userLastName = Ws.getCell(12,4).getContents();
	    
		
	try
	{
		LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
		 
		if (!LoginScreen.verifyLoginPageLaunched(driver))
		{
			return flag=false;
		}
		LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
		LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
		LoginScreen.clickLogin(driver);
		if (!VerintHomePageScreen.verifyVerintHomePage(driver))
		{
			return flag=false;
		}		
		//AddUser To Organization
		if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Access Rights"))
		//Thread.sleep(3000);
		//if (driver.findElements(By.linkText("Access Rights")).size()==0)
		{
			Utilities.Logout(driver);
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Access Rights"))
			//if (driver.findElements(By.linkText("Organization Settings")).size()==0)
			{
				extent.log(LogStatus.WARNING, "Access Rights section is not displayed. Please try again");				
				return flag=false;
			}
			
		}
		Thread.sleep(3000);
		Utilities.selectLeftTreeFrame(driver);
		//verify User exist or not
		if (!ProfilesScreen.FindSelect(driver, userLastName))
		{			
			extent.log(LogStatus.WARNING, "User does not exist. Please execute Import Domain New User script.");
			extent.log(LogStatus.WARNING, "", "", Utilities.captureScreenShot(driver, "AdoptRole"));
			return flag=false;			
		}
		if (!AccessRightsScreen.clickView(driver))
		{
			return flag=false;
		}
		if (!ProfilesScreen.selectProfile(driver, userLastName))
		{
			return flag=false;
		}
		if (!AccessRightsScreen.selectEmp_From_AccessRightsFrame(driver,userLastName))
		{
			return flag=false;
		}
		Utilities.selectRightPaneView(driver);
		if (!AccessRightsScreen.clickEditAccessRights(driver))
		{
			return flag=false;
		}
		if (!AccessRightsScreen.select_RoleName_checkbox(driver,roleName))
		{
			return flag=false;
		}
		if (!AccessRightsScreen.select_OrganizationScope_checkbox(driver,organizationName))
		{
			return flag=false;
		}
		
		
		if (!AccessRightsScreen.clickSave(driver))
		{
			return flag=false;
		}
	}catch(Exception e){
		System.out.println(e);
	}finally{
		Utilities.Logout(driver);
		driver.close();
		driver.quit();
		Wb.close();
		fis.close();
		Utilities.verintScriptStatus(flag,"DPA",HTMLReportName,4,4);
	}
	return flag;
	}
	
}
