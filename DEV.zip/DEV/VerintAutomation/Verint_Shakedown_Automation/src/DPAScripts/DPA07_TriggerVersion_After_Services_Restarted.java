package DPAScripts;

import java.io.File;

import java.text.SimpleDateFormat;
import java.util.Date;


import ScreenObjects.DPAHomePageScreen;
import ScreenObjects.LoginScreen;

import ScreenObjects.ScreenContentTriggers;
import ScreenObjects.VerintHomePageScreen;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.os.WindowsUtils;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.Screen;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class DPA07_TriggerVersion_After_Services_Restarted {
	
	public static ExtentReports extent = ExtentReports.get(DPA07_TriggerVersion_After_Services_Restarted.class);
	public static Screen sobj = new Screen ();
	public static boolean Check_TriggerVersion_AfterServicesRestarted() throws Exception
	{		
		boolean flag=true;
		//String parentWinHandle="";
		String HTMLReportName="DPA07_Check_TriggerVersion_AfterServicesRestarted"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Check Trigger Version After Services Restarted");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 	
		
		/*FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_DPA"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("DPA_TestSet");
	    String UniqueWindowName = Ws.getCell(13,6).getContents();*/
	    
		try
		{		   
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
			LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			VerintHomePageScreen.selectMenuItem(driver,"Tracking","DesktopProcessAnalytics_Menu");			
			/*if (!DPAHomePageScreen.selectMenuItem(driver,"Administration","Triggers","Screen Content Triggers"))//Administration tab - triggers menu item
			{
					WebElement tabName1 = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.linkText("Administration")));
					Actions action1 = new Actions(driver);
					action1.moveToElement(tabName1).build().perform();
					Thread.sleep(2000);		
					//driver.findElement(By.linkText(menuItem)).click(); //
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Trigger.png");
					//Thread.sleep(1000);
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Impact360_Text.png");
					
					//Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Trigger.png");
					//Thread.sleep(2000);
					//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Text.png");
					//driver.findElement(By.xpath("//div[@id='ctl00_StaticMainMenuControl1_TopLevelMenu']/ul/li[2]/div/ul/li[2]/a")).click();
					if (driver.findElements(By.linkText("Screen Content Trigger")).size()!=0)
					{
						//driver.findElement(By.linkText("Screen Content Trigger")).click();	
						if ( driver.findElements(By.linkText("Screen Name")).size()!=0)
						{
							extent.log(LogStatus.PASS, "Screen Content Triggers page is displayed");							
						}
						else
						{
							extent.log(LogStatus.FAIL, "Screen Content Triggers page is NOT displayed.Please try again.");
							return flag=false;
						}
					}
			}*/
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Administration_blue.png")!=null)
			{
				sobj.mouseMove(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Administration_blue.png");
			}
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Administration.png")!=null)
			{
				sobj.mouseMove(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Administration.png");
			}
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Trigger.png");					
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Impact360_Text.png");
			if (driver.findElements(By.linkText("Screen Content Trigger")).size()!=0)
			{							
				if ( driver.findElements(By.linkText("Screen Name")).size()!=0)
				{
					extent.log(LogStatus.PASS, "Screen Content Triggers page is displayed");							
				}
				else
				{
					extent.log(LogStatus.FAIL, "Screen Content Triggers page is NOT displayed.Please try again.");
					return flag=false;
				}
			}
			
			
			String triggerversion=ScreenContentTriggers.checkTriggerVersion(driver); //trigger version
			WindowsUtils.tryToKillByName("DCUApp.exe"); //kill DCUApp
			Thread.sleep(10000);
			WindowsUtils.tryToKillByName("DCUApp.exe"); //kill DCUApp
			String filepathVersion=ScreenContentTriggers.filePathTriggerVersion(driver,Utilities.Globlocators.getProperty("PcMontrig2Path"));
			
			if (triggerversion.contains(filepathVersion))
			{
				extent.log(LogStatus.PASS, "Trigger version:"+triggerversion+" PcMonTrig2.def version:"+filepathVersion+" ;Version numbers are matched");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL, "Trigger version:"+triggerversion+" PcMonTrig2.def version:"+filepathVersion+" ;Version numbers are NOT matched");System.out.println("Trigger version:"+triggerversion+" PcMonTrig2.def version:"+filepathVersion+" ;Version Numbers are not matched");
				flag=false;
			}
		
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			/*Wb.close();
			fis.close();*/
			Utilities.verintScriptStatus(flag,"DPA",HTMLReportName,4,9);
			
		}
		return flag;
	}

}
