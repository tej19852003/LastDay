package DPAScripts;

import java.io.File;
import java.io.FileInputStream;

import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import ScreenObjects.DPAHomePageScreen;
import ScreenObjects.LoginScreen;

import ScreenObjects.ScreenContentTriggers;
import ScreenObjects.VerintHomePageScreen;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import org.sikuli.script.*;
public class DPA02_View_Modify_Trigger {
	
	public static ExtentReports extent = ExtentReports.get(DPA02_View_Modify_Trigger.class);
	public static Screen sobj = new Screen ();
	public static boolean View_Modify_Trigger() throws Exception
	{		
		String HTMLReportName="DPA02_View_Modify_Trigger"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		boolean flag=true;
		//String parentWinHandle="";
		Utilities.testcaseSetup(HTMLReportName, "View Modify Trigger");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("DPA_TestSet");
	    String ScreenName = Ws.getCell(13,7).getContents();
	    String UniqueName = Ws.getCell(14,7).getContents();
	    String DisplayName = Ws.getCell(15,7).getContents();	
	    String CommandToExecute = Ws.getCell(16,7).getContents();
	    //String CriteriaValue = Ws.getCell(17,7).getContents();
		
		try
		{		   
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
			LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			VerintHomePageScreen.selectMenuItem(driver,"Tracking","DesktopProcessAnalytics_Menu");
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Error.png") != null || sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_AuthorisationError.png") != null)
			{
				extent.log(LogStatus.FAIL, "Application/Authorisation error is displayed");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Trigger"));
				return flag=false;
			}
			/*if (!DPAHomePageScreen.selectMenuItem(driver,"Administration","Triggers","Screen Content Triggers"))//Administration tab - triggers menu item
			{
					WebElement tabName1 = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.linkText("Administration")));
					Actions action1 = new Actions(driver);
					action1.moveToElement(tabName1).build().perform();
					Thread.sleep(2000);		
					//driver.findElement(By.linkText(menuItem)).click(); //
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Trigger.png");
					//Thread.sleep(1000);
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Impact360_Text.png");
					
					//Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Trigger.png");
					//Thread.sleep(2000);
					//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Text.png");
					//driver.findElement(By.xpath("//div[@id='ctl00_StaticMainMenuControl1_TopLevelMenu']/ul/li[2]/div/ul/li[2]/a")).click();
					if (driver.findElements(By.linkText("Screen Content Trigger")).size()!=0)
					{
						//driver.findElement(By.linkText("Screen Content Trigger")).click();	
						if ( driver.findElements(By.linkText("Screen Name")).size()!=0)
						{
							extent.log(LogStatus.PASS, "Screen Content Triggers page is displayed");							
						}
						else
						{
							extent.log(LogStatus.FAIL, "Screen Content Triggers page is NOT displayed.Please try again.");
							return flag=false;
						}
					}
			}*/
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Administration_blue.png")!=null)
			{
				sobj.mouseMove(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Administration_blue.png");
			}
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Administration.png")!=null)
			{
				sobj.mouseMove(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Administration.png");
			}
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Trigger.png");					
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Impact360_Text.png");
			Thread.sleep(3000);
			if (driver.findElements(By.linkText("Screen Content Trigger")).size()!=0)
			{							
				if ( driver.findElements(By.linkText("Screen Name")).size()!=0)
				{
					extent.log(LogStatus.PASS, "Screen Content Triggers page is displayed");							
				}
				else
				{
					extent.log(LogStatus.FAIL, "Screen Content Triggers page is NOT displayed.Please try again.");
					return flag=false;
				}
			}
			//verify trigger version
			String VersionNumber=ScreenContentTriggers.checkTriggerVersion(driver);
			if (!ScreenContentTriggers.selectFind(driver,"Screen Name"))
			{
				return flag=false;
			}
			ScreenContentTriggers.setSearchByName(driver,ScreenName);
			ScreenContentTriggers.clickSearch(driver);
			if (!ScreenContentTriggers.clickCapturedTrigger(driver,ScreenName))
			{
				return flag=false;
			}
			Thread.sleep(4000);
			if (!ScreenContentTriggers.setUniqueName(driver, UniqueName))
			{
				return flag=false;
			}
			if (!ScreenContentTriggers.setDisplayName(driver,DisplayName))
			{
				return flag=false;
			}
			ScreenContentTriggers.selectCommandToExecute(driver,CommandToExecute);
			Thread.sleep(4000);
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Verticalbar.png");
			boolean temp=false;
			for (int i=1;i<=4;i++)
			{									
				Thread.sleep(2000);
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Trigger_Control.png")!=null)
				{			
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Trigger_Control.png");
					Thread.sleep(1000);
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AvailableCriteria_Calc.png");
					sobj.doubleClick(Utilities.Globlocators.getProperty("imagesPath")+"\\Trigger_Control.png");
					Thread.sleep(1000);
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AvailableCriteria_Calc.png");
					Thread.sleep(1000);
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Trigger_Control.png");
					Thread.sleep(1000);
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AvailableCriteria_Calc.png");
					Thread.sleep(1000);
					sobj.doubleClick(Utilities.Globlocators.getProperty("imagesPath")+"\\Trigger_Control.png");
					Thread.sleep(2000);	
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AvailableCriteria_Calc.png");
					Thread.sleep(1000);
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Trigger_Control.png");
					Thread.sleep(2000);	
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AvailableCriteria_Calc.png");
					Thread.sleep(1000);
					sobj.doubleClick(Utilities.Globlocators.getProperty("imagesPath")+"\\Trigger_Control.png");
					Thread.sleep(2000);	
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AvailableCriteria_Calc.png");
					Thread.sleep(1000);
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Trigger_Control.png");
					Thread.sleep(2000);	
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AvailableCriteria_Calc.png");
					Thread.sleep(1000);
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Trigger_Control.png");
				}
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Verticalbar_half.png");
				Thread.sleep(3000);				
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Highlight.png")!=null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Highlight.png");
					temp=true;
				}
				else
				{
					temp=false;
				}
				Thread.sleep(3000);
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Verticalbar.png");
				Thread.sleep(2000);
				if (temp==true)
				{
					break;
				}			
			}
			Thread.sleep(4000);	
			if (temp==false)
			{
				extent.log(LogStatus.FAIL, "Highlight checkbox is not displayed. Please try again.");
				return flag=false;
			}
			Thread.sleep(4000);	
			ScreenContentTriggers.clickSave(driver);
			Thread.sleep(5000);
			if (!ScreenContentTriggers.clickActivateChanges(driver))
			{
				return flag=false;
			}
			
			String VersionNumberUpdated=ScreenContentTriggers.checkTriggerVersion(driver);
			
			if (Integer.parseInt(VersionNumber)< Integer.parseInt(VersionNumberUpdated))
			{
				extent.log(LogStatus.PASS, "Trigger Version:"+VersionNumber+" updated to :"+VersionNumberUpdated);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Trigger Version:"+VersionNumber+" updated to :"+VersionNumberUpdated);
				flag=false;
			}
			
			//DPAHomePageScreen.close_DPA(driver,parentWinHandle);	
			
		
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"DPA",HTMLReportName,4,7);
		}
		return flag;
	}

}
