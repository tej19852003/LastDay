package BOScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.DataSourceScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.OrganizationSettings;

import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.WorkQueuesScreen;
import Utilities.Utilities;

public class Create_Map_DataSourceGroups {
	
	public static ExtentReports extent = ExtentReports.get(Create_Map_DataSourceGroups.class);
	
	public static boolean CreateMapDataSourceGroups() throws Exception
	{
		boolean flag=true;
		boolean temp=false;
		String HTMLReportName="Create_Map_DataSourceGroups"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Create Map DataSourceGroups");
				
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("BO_TestSet");
	    String organizationName = Ws.getCell(5,5).getContents();
	    String DataSourceName = Ws.getCell(9,5).getContents();
	    String WorkqueueName = Ws.getCell(11,5).getContents();
	    String DataSourceGroupName = Ws.getCell(14,5).getContents();
	    String DataSourceGroupDesc = Ws.getCell(15,5).getContents();
	    String DataSourceAvgWorkTime = Ws.getCell(16,5).getContents();    
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
			LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"System Management","Data Sources"))
			//Thread.sleep(5000);
			//if (driver.findElements(By.linkText("Settings")).size()==0)
			{
				Utilities.Logout(driver);				
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"System Management","Data Sources"))
				//if (driver.findElements(By.linkText("Settings")).size()==0)
				{
					extent.log(LogStatus.WARNING, "Settings section is not displayed. Please try again.");
					return flag=false;
				}
			}			
			Utilities.selectLeftTreeFrame(driver);
			if (!DataSourceScreen.selectDataSourceName(driver, DataSourceName))
			{
				return flag=false;
			}	
			//select Data source groups link/tab
			driver.switchTo().defaultContent();
			//span id -- 3_BBM_ORG_WORKLOADS_GROUPS_spn_id
			if (driver.findElements(By.linkText("Data Source Groups")).size()!=0)
			{
				driver.findElement(By.linkText("Data Source Groups")).click();
				extent.log(LogStatus.INFO, "Data Source Groups link/tab is selected");				
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to select Data Source Groups link/tab");	
				return flag=false;
			}
			//check whether DSG exist or not.
			Utilities.selectRightPaneView(driver);
			int valrcWq=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr")).size();
			System.out.println("valrcPriv:"+valrcWq);
			for (int j=1;j<=valrcWq;j++) 
			{
				if (j<=15)
				{
				String dsgnameApp=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/th/a/span")).getText().trim();
				System.out.println("dsgnameApp:"+dsgnameApp);
				System.out.println("DataSourceGroupName:"+DataSourceGroupName);
				Thread.sleep(3000);
				if (dsgnameApp.contains(DataSourceGroupName))
				{
					driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/th")).click();
					//driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).click();
					temp=true;
					break;
				}
				}
			}
			if (temp==true)
			{
				System.out.println("DSG pass");
				extent.log(LogStatus.PASS, "Data Source Group Name: "+WorkqueueName+" created/selected successfully");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "DataSourceGroup"));				
			}
			if (temp==false)
			{				
				if (!DataSourceScreen.clickCreateGroup(driver))
				{
					return flag=false;
				}
				if (!DataSourceScreen.setDataSourceGroupName(driver,DataSourceGroupName))
				{
					return flag=false;
				}
				if (!DataSourceScreen.setDataSourceGroupDescription(driver,DataSourceGroupDesc))
				{
					return flag=false;
				}
				if (!DataSourceScreen.setDataSourceGroupAvgWorkTime(driver,DataSourceAvgWorkTime))
				{
					return flag=false;
				}
				if (!DataSourceScreen.clickDateSourceGroupSave(driver))
				{
					return flag=false;
				}
			}
			Thread.sleep(3000);
			driver.switchTo().defaultContent();
			if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Work Queue Group Mapping"))
			//if (driver.findElements(By.linkText("Work Queue Group Mapping")).size()==0)
			{
				Utilities.Logout(driver);				
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Work Queue Group Mapping"))
				//if (driver.findElements(By.linkText("Work Queue Group Mapping")).size()==0)
				{
					extent.log(LogStatus.WARNING, "Work Queue Group Mapping section is not displayed. Please try again.");
					return flag=false;
				}
			}
			Utilities.selectLeftTreeFrame(driver);
			if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,organizationName))
			{
				return flag=false;
			}
			//select .Automation_Workqueue 
			Utilities.selectRightPaneView(driver);
			if (!WorkQueuesScreen.selectWorkqueue(driver,WorkqueueName))
			{
				return flag=false;
			}
			if (!WorkQueuesScreen.clickEditworkqueue(driver))
			{
				return flag=false;
			}
			if (!WorkQueuesScreen.selectItemAvailableDSG(driver,DataSourceName)) //select DSG from list box - Available DSG
			{
				return flag=false;
			}
			Thread.sleep(4000);
			if (!WorkQueuesScreen.selectDSGMapped(driver,DataSourceGroupName))
			{
				return flag=false;
			}
			if (!WorkQueuesScreen.clickAssignRight(driver))
			{
				return flag=false;
			}
			if (!WorkQueuesScreen.selectMappedDSG(driver,DataSourceGroupName))
			{
				return flag=false;
			}
			if (!WorkQueuesScreen.clickSaveMapping(driver))
			{
				return flag=false;
			}
			//validation
			if (!WorkQueuesScreen.validateDSGMapping(driver,WorkqueueName,DataSourceGroupName))
			{
				return flag=false;
			}
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"BO",HTMLReportName,4,5);
		}
		return flag;
	}
}
