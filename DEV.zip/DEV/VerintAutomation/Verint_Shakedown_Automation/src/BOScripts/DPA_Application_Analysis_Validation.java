package BOScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.ApplicationAnalysisReportsScreen;
import ScreenObjects.DPAHomePageScreen;

import ScreenObjects.LoginScreen;

import ScreenObjects.VerintHomePageScreen;
import Utilities.Utilities;

public class DPA_Application_Analysis_Validation {
	
	public static ExtentReports extent = ExtentReports.get(DPA_Application_Analysis_Validation.class);
	public static Screen sobj = new Screen ();
	public static boolean DPAApplicationAnalysisValidation() throws Exception
	{
		boolean flag=true;
		String HTMLReportName="DPA_Application_Analysis_Validation"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "DPA Application Analysis Validation");
				
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		//driver.manage().deleteAllCookies();
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("BO_TestSet");
	  
	    String ReportType = Ws.getCell(19,6).getContents();
	    String DateRange = Ws.getCell(20,6).getContents();
	    String FilterOption = Ws.getCell(21,6).getContents();
	    String FilterValue = Utilities.getPassword(driver, 0, 1);
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
			LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			VerintHomePageScreen.selectMenuItem(driver,"Tracking","DesktopProcessAnalytics_Menu");
			
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Error.png") != null || sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_AuthorisationError.png") != null)
				{
					extent.log(LogStatus.FAIL, "Application/Authorisation error is displayed");
					extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Trigger"));
					return flag=false;
				}
			
			
			//Utilities.windowsSecurityCredentials(driver,Utilities.Globlocators.getProperty("WindowsSecurityUserName"),Utilities.Globlocators.getProperty("WindowsSecurityPassword"));
			if (!DPAHomePageScreen.selectMenuItem(driver,"Reports","Application Analysis Reports",""))//Administration tab - triggers menu item
			{	
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Error.png") != null || sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_AuthorisationError.png") != null)
				{
					extent.log(LogStatus.FAIL, "Application/Authorisation error is displayed");
					extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Trigger"));
					return flag=false;
				}
					driver.manage().window().maximize();
					Thread.sleep(2000);	
					WebElement tabName1 = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.linkText("Reports")));
					Actions action1 = new Actions(driver);
					action1.moveToElement(tabName1).build().perform();
					Thread.sleep(2000);							
					driver.findElement(By.xpath("//div[@id='ctl00_StaticMainMenuControl1_TopLevelMenu']/ul/li[1]/div/ul/li[2]/a")).click();
					extent.log(LogStatus.INFO, "Application Analysis Reports menu item is selected from Reports tab");
					Thread.sleep(10000);
					if (driver.findElements(By.xpath("//input[@id='ctl00_MidPanelContentHolder_btnDisplayReport']")).size()!=0)
					{
						extent.log(LogStatus.PASS, "Application Analysis Reports page is displayed");
						extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "AppAnalysisReport"));
						flag=true;
					}
					else
					{
						extent.log(LogStatus.FAIL, "Application Analysis Reports page is NOT displayed");
						extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "AppAnalysisReport"));
						return flag=false;
					}
			}
			
			//report type
			if (!ApplicationAnalysisReportsScreen.selectReportType(driver,ReportType))
			{
				return flag=false;
			}
			//date range
			if (!ApplicationAnalysisReportsScreen.selectDateRange(driver,DateRange))
			{
				return flag=false;
			}
			//filters
			if (!ApplicationAnalysisReportsScreen.selectFilters(driver,FilterOption,FilterValue)) 
			{
				return flag=false;
			}
			/*if (!ApplicationAnalysisReportsScreen.clickAddFilter(driver)) //click on Add filter
			{
				return flag=false;
			}*/
			
			if (!ApplicationAnalysisReportsScreen.clickDisplayReport(driver))
			{
				return flag=false;
			}
			if (!ApplicationAnalysisReportsScreen.verifyReportName(driver,ReportType))
			{
				return flag=false;
			}
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"BO",HTMLReportName,4,6);
		}
		return flag;
	}
}
