package BOScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.ActivitiesScreen;

import ScreenObjects.LoginScreen;
import ScreenObjects.OrganizationSettings;

import ScreenObjects.VerintHomePageScreen;
import Utilities.Utilities;

public class DPA_SecondaryLine_Adherence_Validation {
	
	public static ExtentReports extent = ExtentReports.get(DPA_SecondaryLine_Adherence_Validation.class);
	
	public static boolean DPASecondaryLineAdherenceValidation() throws Exception
	{
		boolean flag=true;
		String HTMLReportName="DPA_SecondaryLine_Adherence_Validation"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "DPA Secondary Line Adherence Validation");
				
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("BO_TestSet");
	  
	    String OrganizationName = Ws.getCell(5,8).getContents();
	    String ActivityName = Ws.getCell(26,8).getContents();
	    String ActivityDescription = Ws.getCell(27,8).getContents();	   
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
			LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Activiteis"))
			//Thread.sleep(5000);
			//if (driver.findElements(By.linkText("Activities")).size()==0)
			{
				Utilities.Logout(driver);				
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Activiteis"))		
				//if (driver.findElements(By.linkText("Activities")).size()==0)
				{
					extent.log(LogStatus.WARNING, "Activities section is not displayed. Please try again.");
					return flag=false;
				}
			}	
			
			if (!ActivitiesScreen.verifyActivityName(driver,ActivityName))
			{			
				Utilities.selectLeftTreeFrame(driver);
				if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver, OrganizationName))
				{
					return flag=false;
				}
				if (!ActivitiesScreen.clickCreateActivity(driver))
				{
					return flag=false;
				}
				if (!ActivitiesScreen.setActivityName(driver, ActivityName))
				{
					return flag=false;
				}
				if (!ActivitiesScreen.setActivityDescription(driver, ActivityDescription))
				{
					return flag=false;
				}
				if (!ActivitiesScreen.clickSave(driver))
				{
					return flag=false;
				}
				if (!ActivitiesScreen.verifyActivityName(driver,ActivityName))
				{
					return flag=false;
				}
				if (!ActivitiesScreen.deleteActivityName(driver,ActivityName))
				{
					return flag=false;
				}
								
			}
			/*if (!ActivitiesScreen.verifyActivityName(driver,ActivityName))
			{
				if (!ActivitiesScreen.deleteActivityName(driver,ActivityName))
				{
					return flag=false;
				}
			}*/
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"BO",HTMLReportName,4,8);
		}
		return flag;
	}
}
