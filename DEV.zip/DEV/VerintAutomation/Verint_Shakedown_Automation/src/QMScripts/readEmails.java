package QMScripts;

import java.io.IOException;

 
public class readEmails {
	public static void OutlookReadEmail() throws Exception
	{
	
		try {
		      Runtime.getRuntime().exec( "wscript C:/DEV/outlook.vbs" );
		   }
		   catch( IOException e ) {
		      System.out.println(e);
		      System.exit(0);
		   }
		}
 
	
}