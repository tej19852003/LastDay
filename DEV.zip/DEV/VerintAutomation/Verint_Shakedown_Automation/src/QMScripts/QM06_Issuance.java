package QMScripts;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.Date;

import Utilities.Utilities;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class QM06_Issuance {
	
	public static ExtentReports extent = ExtentReports.get(QM06_Issuance.class);
	public static String HTMLReportName="QM06_VerifyIssuances"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());	
	
	public static void QM06_Issuance_Workstation() throws Exception
	{			
		Utilities.testcaseSetup(HTMLReportName, "Verify Issuances In the Workstation");		
		Issuance(Utilities.Globlocators.getProperty("PopupClientLogFileName"),"Popup Client Issuance");
		Issuance(Utilities.Globlocators.getProperty("PlaybackLogFileName"),"Playback Issuance");
		Issuance(Utilities.Globlocators.getProperty("FormDesignerFileName"),"Form Designer Issuance");
		Issuance(Utilities.Globlocators.getProperty("ScreenCaptureLogFileName"),"Screen Capture Issuance");			
		Issuance(Utilities.Globlocators.getProperty("AIMLogiFileName"),"AIM Issuance");		
	}
	
	
	public static boolean Issuance(String LogFileName,String IssuanceName) throws Exception
	{
		boolean flag=true;
		try{		
			System.out.println("LogFileName:"+"C:\\PROD\\ISS\\LOGS\\"+LogFileName);
		    if (!Utilities.folderExist("C:\\PROD","Folder"))
		    {
		    	extent.log(LogStatus.FAIL, "C:\\PROD folder is not displayed");
		    	return flag=false;
		    }
		    if (!Utilities.folderExist("C:\\PROD\\ISS","Folder"))
		    {
		    	extent.log(LogStatus.FAIL, "C:\\PROD\\ISS folder is not displayed");
		    	return flag=false;
		    }
		    if (!Utilities.folderExist("C:\\PROD\\ISS\\LOGS","Folder"))
		    {
		    	extent.log(LogStatus.FAIL, "C:\\PROD\\ISS\\LOGS is not displayed");
		    	return flag=false;
		    }
		    if (!Utilities.folderExist("C:\\PROD\\ISS\\LOGS\\"+LogFileName, "File"))
		    {
		    	extent.log(LogStatus.FAIL, "C:\\PROD\\ISS\\LOGS\\"+LogFileName+" is not displayed");
		    	return flag=false;
		    }
		    //verify time of log file
		    String path="C:\\PROD\\ISS\\LOGS\\"+LogFileName;
		    System.out.println(path);
		    Process proc = Runtime.getRuntime().exec("cmd /c dir \"" + path + "\" /tc");
	 		BufferedReader br = 
	 		   new BufferedReader(
	 		      new InputStreamReader(proc.getInputStream()));
	 		
	 		String data ="";
	 		for(int i=0; i<6; i++){
	 			data = br.readLine();
	 			System.out.println(data);
	 		}
	 		extent.log(LogStatus.INFO, "Time of creation of log file - "+LogFileName+": "+data);
	 		System.out.println("Extracted value : " + data);
		    //read Installation was successful
	 		FileReader FR = new FileReader("C:\\PROD\\ISS\\LOGS\\"+LogFileName);
			BufferedReader BR = new BufferedReader(FR);
			System.out.println(BR);
			String Content = "";
			boolean temp=false;
			//Loop to read all lines one by one from file and print It.
			while((Content = BR.readLine())!= null)
			{
				if (Content.contains("The installation was successful"))
				{
					temp=true;
					break;
				}
				
			}
			if (temp)
				extent.log(LogStatus.PASS, "Log File Name - "+LogFileName+" : The installation was successful message is displayed as Expected");
			else
			{
				extent.log(LogStatus.FAIL, "Log File Name - "+LogFileName+" : The installation was successful message is NOT displayed");
				return flag=false;
			}
		}catch(Exception e){
			System.out.println(e);
		}finally{				
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,3);
		}
			
		return flag;
	}

}
