package ScreenObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class ShiftScreen
{
	public static ExtentReports extent = ExtentReports.get(ShiftScreen.class);
	public static String btncreateshift="//button[@id='toolbar_ADD_ACTIONLabel']";
	public static String txtshiftname="shift_name";
	public static String txtdesc="shift_description";
	public static String strttime="//table[@id='startTimesMinsSinceMidnight_table']//tbody//tr//td[@col='8']";
	public static String strttime2="//table[@id='startTimesMinsSinceMidnight_table']//tbody//tr//td[@col='16']";
	public static String btnsave="//button[@id='toolbar_CREATE_NEW_ACTIONLabel']";
	public static String btnaddbreak="//button[@id='shiftEventToolbar_POPUP_SHIFT_EVENTLabel']";
	public static String iconactivity="//span[@id='activityID__input_0Wrapper']//nobr//img[@id='activityID__input_0Button']";
	
	
	
	public static boolean clickcreateshift(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By createshift_btn=By.xpath(btncreateshift);
			Utilities.waitForPageLoad(driver,createshift_btn);
			if(driver.findElements(createshift_btn).size()!=0)
			{
				driver.findElement(createshift_btn).click();
				flag=true;
				extent.log(LogStatus.PASS,"Clcked on create button is sucessfull");
			}
			else
			{ 
				extent.log(LogStatus.FAIL,"Clcked on create button is not sucessfull");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}

	
	public static boolean clickaddbreak(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By addshift_btn=By.xpath(btnaddbreak);
			Utilities.waitForPageLoad(driver,addshift_btn);
			if(driver.findElements(addshift_btn).size()!=0)
			{
				driver.findElement(addshift_btn).click();
				flag=true;
				extent.log(LogStatus.PASS,"Clcked on add break button is sucessfull");
			}
			else
			{ 
				extent.log(LogStatus.FAIL,"Clcked on add break button is not sucessfull");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean setshiftName(WebDriver driver,String shiftName) throws Exception
	{
		boolean flag=false;
		try{		
			By shiftnametxt=By.name(txtshiftname);
			Utilities.waitForPageLoad(driver,shiftnametxt);
			if (driver.findElements(shiftnametxt).size()!=0)
			{
				driver.findElement(shiftnametxt).clear();
				driver.findElement(shiftnametxt).sendKeys(shiftName);
				extent.log(LogStatus.PASS, "Work pattern Name"+shiftName +" is entered successfully");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Work pattern Name "+shiftName +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean setshiftDescription(WebDriver driver,String shiftDesc) throws Exception
	{
		boolean flag=false;
		try{		
			By shiftDesctxt=By.name(txtdesc);
			Utilities.waitForPageLoad(driver,shiftDesctxt);
			if (driver.findElements(shiftDesctxt).size()!=0)
			{
				driver.findElement(shiftDesctxt).clear();
				driver.findElement(shiftDesctxt).sendKeys(shiftDesc);
				extent.log(LogStatus.PASS, "Work pattern Description "+shiftDesc +" is entered successfully");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Work pattern Description "+shiftDesc +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setshiftstartTime(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{		
			By shiftstarttime=By.xpath(strttime);
			Utilities.waitForPageLoad(driver,shiftstarttime);
			if (driver.findElements(shiftstarttime).size()!=0)
			{
				driver.findElement(shiftstarttime).click();
				extent.log(LogStatus.PASS, "Shift start time is entered sucessfully");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Shift start time is not entered sucessfully");	
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean setshiftstartTime2(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{		
			By shiftstarttime2=By.xpath(strttime2);
			Utilities.waitForPageLoad(driver,shiftstarttime2);
			if (driver.findElements(shiftstarttime2).size()!=0)
			{
				driver.findElement(shiftstarttime2).click();
				extent.log(LogStatus.PASS, "Shift start time is entered sucessfully");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Shift start time is not entered sucessfully");	
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickSave(WebDriver driver) throws Exception
	{		
		boolean flag=false;
		try{	
			Utilities.selectRightPaneView(driver);
			By saveBtn=By.xpath(btnsave);
			Utilities.waitForPageLoad(driver,saveBtn);
			if (driver.findElements(saveBtn).size()!=0)
			{					
				driver.findElement(saveBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Save button is successful");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Save button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean Shiftexist(WebDriver driver,String shiftname) throws Exception
	{
		Utilities.selectRightPaneView(driver);
		boolean Temp=false;
		driver.findElement(By.name("itemToFind")).clear();
    	driver.findElement(By.name("itemToFind")).sendKeys(shiftname);
    	driver.findElement(By.xpath("//button[@id='toolbar_FIND_ACTIONLabel']")).click();
    	Thread.sleep(2000);
    	List<WebElement> li=driver.findElements(By.xpath("//table[@id='shiftTableRef']//tr[@class='tblRow']"));
    	System.out.println("++++"+ li.size());
    	if(driver.findElements(By.xpath("//table[@id='shiftTableRef']//tr[@class='tblRow']//td")).size()!=0)
    	{
    		for(WebElement elt:li)
        	{
        		//System.out.println("**************");
        		System.out.println(elt.findElement(By.tagName("td")).getAttribute("innerText"));
        		String wname=elt.findElement(By.tagName("td")).getAttribute("innerText");
        		if(wname.contains(shiftname))
        		{
        			System.out.println("shift name is"+wname);
        			Temp=true;
        			break;
        		}
        	}
    	}
    	else
    	{
    		Temp=false;
    	}
    	return Temp;
    	
	}
	
	public static boolean deleteshift(WebDriver driver,String shiftName) throws Exception
	{
		boolean flag=false;
		try
		{
			driver.findElement(By.name("itemToFind")).clear();
	    	driver.findElement(By.name("itemToFind")).sendKeys(shiftName);
	    	driver.findElement(By.xpath("//button[@id='toolbar_FIND_ACTIONLabel']")).click();
	    	List<WebElement> li=driver.findElements(By.xpath("//table[@id='shiftTableRef']//tr[@class='tblRow']"));
	    	System.out.println(li.size());
	    	if(li.size()>0)
	    	{
	    		for(WebElement elt:li)
	        	{
	        		//System.out.println("**************");
	        		System.out.println(elt.findElement(By.tagName("td")).getAttribute("innerText"));
	        		String wname=elt.findElement(By.tagName("td")).getAttribute("innerText");
	        		if(wname.contains(shiftName))
	        		{
	        			elt.findElement(By.tagName("td")).click();
	        			driver.findElement(By.id("toolbar_DELETE_ACTIONLabel")).click();
	        			Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\btnok_camp.png");
	        			System.out.println("Shift deleted");
	        			flag=true;
	        			break;
	        		}
	        	}
	    	}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	
	public static boolean setshiftbreak(WebDriver driver,String shiftEvent)throws Exception
	{
		boolean flag=false;
		//Utilities.setWindowFocus(driver);
		try
		{
			/*int rows=driver.findElements(By.xpath("//div[@id='shiftTableWrapper']//table[@id='shiftTableRef']//tr")).size();
			System.out.println("no of rows are:" + rows);
			for(int j=1;j<rows;j+=2)
			{
				String sname=driver.findElement(By.xpath("//div[@id='shiftTableWrapper']//table[@id='shiftTableRef']//tr[contains(@id,'shiftTabler"+j+"')]//td[contains(@id,'shiftTabler"+j+"c1')]")).getAttribute("innerText");
				System.out.println("shift name is:" + sname);
				if(sname.contains(ShiftName))
				{
					driver.findElement(By.xpath("//div[@id='shiftTableWrapper']//table[@id='shiftTableRef']//tr[contains(@id,'shiftTabler"+j+"')]//td[contains(@id,'shiftTabler"+j+"c1')]")).click();
					break;
				}
				
			}*/
			
			List<WebElement> li1=driver.findElements(By.xpath("//table[@id='shiftEventTableRef']//tr[@class='tblRow']"));
			System.out.println(li1.size());
			for(WebElement elt:li1)
			{
				//System.out.println("**************");
				System.out.println(elt.findElement(By.tagName("th")).getAttribute("innerText"));
				String wname=elt.findElement(By.tagName("th")).getAttribute("innerText");
				if(wname.contains(shiftEvent))
				{
					//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
					elt.findElement(By.tagName("th")).click();
					extent.log(LogStatus.PASS,"shift event:"+shiftEvent+"is added successfully");
					flag=true;
					break;
				}
			}
			driver.findElement(By.xpath("//button[@id='workpaneMediator_toolbar_addShiftEventsLabel']")).click();
			flag=true;
		}
		catch(Exception e){
			e.printStackTrace();
			
		}
		return flag;
	}
	
	
	public static boolean setActivity(WebDriver driver,String Activity)
	{
		boolean flag=true;
		try{			
			//Utilities.selectLeftTreeFrame(driver);
			By activityicon=By.xpath(iconactivity);
			Utilities.waitForPageLoad(driver,activityicon);
			if (driver.findElements(activityicon).size()!=0)
			{					
				driver.findElement(activityicon).click();
				Thread.sleep(1000);
				Select sbox1=new Select(driver.findElement(By.id("activityID__input")));
				sbox1.selectByVisibleText(Activity);
				//driver.findElement(iconSchPeriod).sendKeys(Period);
				Thread.sleep(3000);				
				extent.log(LogStatus.INFO, "Activity:"+Activity+" is selected from View Listbox");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Not able to select Activity:"+Activity+" from View Listbox");
				return flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
}
