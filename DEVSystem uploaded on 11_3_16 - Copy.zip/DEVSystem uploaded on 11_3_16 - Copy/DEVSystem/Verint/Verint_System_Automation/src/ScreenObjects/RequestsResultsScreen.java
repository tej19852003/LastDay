package ScreenObjects;



import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

//import Library.DPA_Library;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class RequestsResultsScreen {
	
	public static ExtentReports extent = ExtentReports.get(RequestsResultsScreen.class);	
	public static String txtReportName="rffName_0"; //input
	public static String txtReportNote="note"; //textarea
	public static String btnRunNow="//button[@id='toolbar_RUN_NOW_ACTIONLabel']";
	public static String btndel="//button[@id='toolbar_DELETE_ACTIONLabel']";
	
	public static boolean clickRunNow(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			Utilities.selectRightPaneView(driver);
			By runNowBtn=By.xpath(btnRunNow);
			Utilities.waitForPageLoad(driver,runNowBtn);
			if (driver.findElements(runNowBtn).size()!=0)
			{					
				driver.findElement(runNowBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Run Now button is successful");
				Thread.sleep(16000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Run Now button is unsuccessful");
				flag=false;
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean setReportNote(WebDriver driver,String ReportNote)
	{
		Boolean flag=false;
		try{				
			By notetxt=By.id(txtReportNote);
			Utilities.waitForPageLoad(driver,notetxt);
			if (driver.findElements(notetxt).size()!=0)
			{
				driver.findElement(notetxt).sendKeys(ReportNote);
				extent.log(LogStatus.PASS, "Report Note: "+ReportNote +" is entered successfully");		
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Report Note: "+ReportNote +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;	
	}
	public static boolean setReportName(WebDriver driver,String ReportName)
	{
		Boolean flag=false;
		try{				
			By nametxt=By.id(txtReportName);
			Utilities.waitForPageLoad(driver,nametxt);
			if (driver.findElements(nametxt).size()!=0)
			{
				driver.findElement(nametxt).sendKeys(ReportName);
				extent.log(LogStatus.PASS, "Report Name: "+ReportName +" is entered successfully");		
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Report Name: "+ReportName +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;	
	}
	
	public static boolean selectReportSelection(WebDriver driver,String ReportSelection) throws Exception
	{
		Boolean flag=false;
		try {
			Utilities.selectLeftTreeFrame(driver);
			Thread.sleep(1000);	
			/*if (driver.findElements(By.xpath("//div[@id='reportTreer0']/nobr/a/span/span")).size()!=0)
			{
				driver.findElement(By.xpath("//div[@id='reportTreer0']/nobr/a/span/span")).click();
				Thread.sleep(6000);
			}*/
			//if (Utilities.SearchItem(driver, ReportSelection))
			//{  
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\ReportSelection_Verticalbar.png");
				for (int i=1;i<=25;i++)
				{
					String reportSelApp=driver.findElement(By.xpath("//div[@id='reportTreer"+i+"Nodes']/div/nobr/a/span/span")).getText();
					System.out.println("reportSelApp:"+reportSelApp);
					if (reportSelApp.contains(ReportSelection))
					{
						driver.findElement(By.xpath("//div[@id='reportTreer"+i+"Nodes']/div/nobr/a/span/span")).click();
						extent.log(LogStatus.PASS, "Report Selection: "+ReportSelection+" selected successfully");
						flag=true;
						//extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "WFMReport"));
						break;
					}
				}
				if (flag==false)
				{
					extent.log(LogStatus.FAIL, "Unable to select Report Selection: "+ReportSelection);
					//extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "WFMReport"));
				}
			//}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;			
	}
	
	
	
	public static boolean reportExist(WebDriver driver,String reportName)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			List<WebElement> li=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']//tbody//tr[@class='tblRow']"));
			System.out.println("list size is:"+li.size());
			if(driver.findElements(By.xpath("//table[@id='workpaneListWrapper']//tr[@class='tblRow']//th")).size()!=0)
	    	{
			for(WebElement elt:li)
			{
				System.out.println(elt.findElement(By.tagName("th")).getAttribute("innerText"));
        		String rname=elt.findElement(By.tagName("th")).getAttribute("innerText");
        		if(rname.contains(reportName))
        		{
        			elt.findElement(By.tagName("th")).click();
        			extent.log(LogStatus.PASS,"report is selected successfully");
        			flag=true;
        			break;
        		}
			}
	    	}
			else
			{
				flag=false;
			}
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	
	public static boolean clickdelete(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			Utilities.selectRightPaneView(driver);
			By delbtn=By.xpath(btndel);
			Utilities.waitForPageLoad(driver,delbtn);
			if (driver.findElements(delbtn).size()!=0)
			{					
				driver.findElement(delbtn).click();
				
				extent.log(LogStatus.PASS, "Clicked on delete button is successful");
				Thread.sleep(16000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on delete button is unsuccessful");
				flag=false;
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean selectformat(WebDriver driver,String format)
	{
		boolean flag=false;
		try
		{
			//Utilities.selectRightPaneView(driver);
			driver.findElement(By.xpath("//img[@id='RSP_FORMAT_OPTION_FN_0Button']")).click();
			Select sbox=new Select(driver.findElement(By.xpath("//select[@id='RSP_FORMAT_OPTION_FN']")));
			sbox.selectByVisibleText(format);
			extent.log(LogStatus.PASS,"Format :"+format+" is selected from listbox");
			flag=true;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
}

