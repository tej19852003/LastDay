package ScreenObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;
import org.python.modules.thread.thread;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class PulseScreen 
{
	public static ExtentReports extent = ExtentReports.get(WorkQueuesScreen.class);
	public static String iconCampaign="//span[@id='queueFilter_listbox_0Wrapper']//nobr//img[@id='queueFilter_listbox_0Button']";
	public static String btnview="//button[@id='selectionMediator_toolbar_SUBMITLabel']";
	
	public static boolean setcampaign(WebDriver driver,String campName)
	{
		boolean flag=true;
		try
		{
			Utilities.selectLeftTreeFrame(driver);
			By iconcamp=By.xpath(iconCampaign);
			Utilities.waitForPageLoad(driver,iconcamp);
			if(driver.findElements(iconcamp).size()!=0)
			{
				driver.findElement(iconcamp).click();
				Thread.sleep(2000);
				driver.findElement(iconcamp).sendKeys(campName);
				Thread.sleep(2000);
				extent.log(LogStatus.INFO,"Campaign Name:"+campName+" is selected from View Listbox");
			}
			else
			{
				extent.log(LogStatus.INFO,"Not able to select Campaign Name:"+campName+" from View Listbox");
				return flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean selectCampaign(WebDriver driver,String Campname)
	{
		boolean flag=true;
		try{			
			Utilities.selectLeftTreeFrame(driver);
			By iconCamp=By.xpath(iconCampaign);
			Utilities.waitForPageLoad(driver,iconCamp);
			if (driver.findElements(iconCamp).size()!=0)
			{					
				driver.findElement(iconCamp).click();
				Thread.sleep(1000);
				Select sbox1=new Select(driver.findElement(By.id("queueFilter_listbox")));
				sbox1.selectByVisibleText(Campname);
				//driver.findElement(iconSchPeriod).sendKeys(Period);
				Thread.sleep(3000);				
				extent.log(LogStatus.INFO, "campaign:"+Campname+" is selected from View Listbox for forecast screen");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Not able to select campaign:"+Campname+" from View Listbox");
				return flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	
	public static boolean selectqueue(WebDriver driver,String workqueue)
	{
		Boolean Temp=false;
		try{
			Utilities.selectLeftTreeFrame(driver);
			int rc=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
			System.out.println("rc:"+rc);
			/*if (rc>0)
			{
				driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr[1]/td/a")).click();
			}*/
			for (int i=1;i<=rc;i++)
			{
				
				if (i<=15)
				{
				String queuename=driver.findElement(By.xpath("//table[@id='queueTree_id']/tbody/tr["+i+"]/td/a")).getText();
				System.out.println(workqueue);
				if (queuename.contains(workqueue))
				{
					driver.findElement(By.xpath("//table[@id='queueTree_id']/tbody/tr["+i+"]/td/a")).click();
					Thread.sleep(3000);
					Temp=true;
					break;
				}}
			}
			if (Temp==true)
			{					
				extent.log(LogStatus.PASS, "work queue:"+workqueue+" is  selected successfully");	
				//extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Campaign"));
			}
			else
			{
				extent.log(LogStatus.FAIL, "Work Queue:"+workqueue+" NOT displayed ");
				//extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Campaign"));
				return Temp=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	
		return Temp;
	}
	
	
	public static boolean clickview(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectLeftTreeFrame(driver);
			By viewbtn=By.xpath(btnview);
			Utilities.waitForPageLoad(driver,viewbtn);
			if(driver.findElements(viewbtn).size()!=0)
			{
				driver.findElement(viewbtn).click();
				extent.log(LogStatus.PASS,"clicked on view button is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"not able to click on view button");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
}
