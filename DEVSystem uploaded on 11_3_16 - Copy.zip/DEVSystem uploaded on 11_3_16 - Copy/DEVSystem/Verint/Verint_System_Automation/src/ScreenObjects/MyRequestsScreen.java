package ScreenObjects;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class MyRequestsScreen {
	
	public static ExtentReports extent = ExtentReports.get(MyRequestsScreen.class);
	public static String btnCreateNewRequest="//button[@id='toolbar_CREATE_NEW_REQUESTLabel']";
	public static String btnCreateNewRequestTimeOff="//table[@id='toolbar_POPUP_TIMEOFF_REQUEST_FORM_ACTIONWrapper']/tbody/tr[1]/td[1]/button[@id='toolbar_POPUP_TIMEOFF_REQUEST_FORM_ACTIONLabel']";
	
	public static String lstMonth="//input[@id='timeOffCalMonth_0']";	
	public static String lstYear="//input[@id='timeOffCalYear_0']";
	
	public static String lstTimeOffType="//span[@id='timeOffType_0Wrapper']/nobr/img[@id='timeOffType_0Button']";
	
	public static String txtStartDate="//span[@BP_OBJ_TYPE='DATE_PICKER']/input[@id='dateChoice_START_1']";
	public static String txtEndDate="//span[@BP_OBJ_TYPE='DATE_PICKER']/input[@id='dateChoice_END_1']";
	public static String btnCalcEstimate="//button[@id='workpaneMediator_toolbar_CALCULATE_TO_7857Label']";
	public static String btnSave="//button[@id='workpaneMediator_toolbar_SAVE_ACTIONLabel']";
	public static String btnDone="//button[@id='workpaneMediator_toolbar_DONE_ACTIONLabel']";
	public static String btncreateShiftswap="//button[@id='toolbar_POPUP_SHIFTSWAP_REQUEST_FORM_ACTIONLabel']";
	public static String iconswap="//img[@id='agentID_0Button']";
	public static String txtswapdate="//span[@BP_OBJ_TYPE='DATE_PICKER']/input[@id='requestDate1_0']";
	public static String txtpickupdate="//span[@BP_OBJ_TYPE='DATE_PICKER']/input[@id='requestDate2_0']";
	public static String txtresponsedeadline="//span[@BP_OBJ_TYPE='DATE_PICKER']/input[@id='expiration_0']";
	public static String rdbtnconfirmswap="//span[@BP_OBJ_TYPE='CHOICE_INPUT']/input[@id='isNegotiable_false_0']";
	public static String btnshiftsave="//button[@id='workpaneMediator_toolbar_SAVE_ACTIONLabel']";
	public static String btncontinue="//button[@id='workpaneMediator_toolbar_APPROVE_ACTIONLabel']";
	public static String btnshiftrequest="//button[@id='toolbar_POPUP_CUSTSHIFT_REQUEST_FORM_ACTIONLabel']";
	public static String shiftstartdate="//span[@BP_OBJ_TYPE='DATE_PICKER']/input[@id='shiftStartDate_0']";
	
	
	public static boolean clickCreateNewRequestDone(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			By doneBtn=By.xpath(btnDone);
			Utilities.waitForPageLoad(driver,doneBtn);
			if (driver.findElements(doneBtn).size()!=0)
			{					
				driver.findElement(doneBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Done buttton button is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Done button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean clickCreateNewRequestSave(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			By saveBtn=By.xpath(btnSave);
			Utilities.waitForPageLoad(driver,saveBtn);
			if (driver.findElements(saveBtn).size()!=0)
			{					
				driver.findElement(saveBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Save buttton button is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Save button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean clickCalculateEstimate(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			By calcEstimateBtn=By.xpath(btnCalcEstimate);
			Utilities.waitForPageLoad(driver,calcEstimateBtn);
			if (driver.findElements(calcEstimateBtn).size()!=0)
			{					
				driver.findElement(calcEstimateBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Calculate Estimate buttton button is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Calculate Estimate button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static void setTimeOffChoicesEndDate(WebDriver driver,String EndDate) throws Exception
	{
		try{		
			By endDatetxt=By.xpath(txtEndDate);
			Utilities.waitForPageLoad(driver,endDatetxt);
			if (driver.findElements(endDatetxt).size()!=0)
			{
				//driver.findElement(endDatetxt).click();
				driver.findElement(endDatetxt).sendKeys(EndDate);
				extent.log(LogStatus.PASS, "End Date: "+EndDate +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "End Date: "+EndDate +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void setTimeOffChoicesStartDate(WebDriver driver,String StartDate) throws Exception
	{
		try{		
			By startDatetxt=By.xpath(txtStartDate);
			Utilities.waitForPageLoad(driver,startDatetxt);
			if (driver.findElements(startDatetxt).size()!=0)
			{
				//driver.findElement(startDatetxt).click();
				driver.findElement(startDatetxt).sendKeys(StartDate);
				extent.log(LogStatus.PASS, "Start Date: "+StartDate +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Start Date: "+StartDate +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static boolean selectTimeOffType(WebDriver driver,String TimeOffType) throws Exception
	{
		boolean flag=false;
		try{		
			By timeOffTypelst=By.xpath(lstTimeOffType);
			Utilities.waitForPageLoad(driver,timeOffTypelst);
			if (driver.findElements(timeOffTypelst).size()!=0)
			{
				driver.findElement(timeOffTypelst).click();
				Thread.sleep(2000);				
				driver.findElement(timeOffTypelst).sendKeys(TimeOffType);
				Thread.sleep(3000);
				Robot r = new Robot();
				r.keyPress(KeyEvent.VK_ENTER);
				r.keyRelease(KeyEvent.VK_ENTER);
				extent.log(LogStatus.PASS, "Time Off Type: "+TimeOffType +" is selected successfully");	
				flag=true;				
			}else
			{
				extent.log(LogStatus.FAIL, "Time Off Type: "+TimeOffType +" is NOT selected");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean selectYear(WebDriver driver,String Year) throws Exception
	{
		boolean flag=false;
		try{		
			By yearlst=By.xpath(lstYear);
			Utilities.waitForPageLoad(driver,yearlst);
			if (driver.findElements(yearlst).size()!=0)
			{
				driver.findElement(yearlst).click();
				Thread.sleep(3000);				
				driver.findElement(yearlst).sendKeys(Year);
				Thread.sleep(3000);
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK1.png");
				Thread.sleep(5000);				
				extent.log(LogStatus.PASS, "Year Name: "+Year +" is selected successfully");	
				flag=true;				
			}else
			{
				extent.log(LogStatus.FAIL, "Year Name: "+Year +" is NOT selected");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean selectMonth(WebDriver driver,String Month) throws Exception
	{
		boolean flag=false;
		try{		
			By monthlst=By.xpath(lstMonth);
			Utilities.waitForPageLoad(driver,monthlst);
			if (driver.findElements(monthlst).size()!=0)
			{
				driver.findElement(monthlst).click();
				Thread.sleep(3000);				
				driver.findElement(monthlst).sendKeys(Month);
				Thread.sleep(3000);
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
				Thread.sleep(5000);				
				System.out.println("month:"+driver.findElement(monthlst).getText().trim());				
				extent.log(LogStatus.PASS, "Month Name: "+Month +" is selected successfully");	
				flag=true;				
			}else
			{
				extent.log(LogStatus.FAIL, "Month Name: "+Month +" is NOT selected");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickCreateNewRequest_TimeOff(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			By newReqTimeBtn=By.xpath(btnCreateNewRequestTimeOff);
			Utilities.waitForPageLoad(driver,newReqTimeBtn);
			if (driver.findElements(newReqTimeBtn).size()!=0)
			{					
				driver.findElement(newReqTimeBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Create New Request - Time Off button is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Create New Request - Time Off button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean clickCreateNewRequest(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			By newReqBtn=By.xpath(btnCreateNewRequest);
			Utilities.waitForPageLoad(driver,newReqBtn);
			if (driver.findElements(newReqBtn).size()!=0)
			{					
				driver.findElement(newReqBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Create New Request button is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Create New Request button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clickCreateNewRequest_shiftswap(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			By shiftswapBtn=By.xpath(btncreateShiftswap);
			Utilities.waitForPageLoad(driver,shiftswapBtn);
			if (driver.findElements(shiftswapBtn).size()!=0)
			{					
				driver.findElement(shiftswapBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Create New Request - Shift swap button is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Create New Request - shift swap button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean selectshiftswapwith(WebDriver driver,String empname)
	{
		
		boolean flag=false;
		try
		{
			Utilities.setWindowFocus(driver);
			By swapicon=By.xpath(iconswap);
			Utilities.waitForPageLoad(driver,swapicon);
			if(driver.findElements(swapicon).size()!=0)
			{
				driver.findElement(swapicon).click();
				/*driver.findElement(By.id("agentID_0")).clear();
				driver.findElement(By.id("agentID_0")).sendKeys(empname);*/
				Select sbox=new Select(driver.findElement(By.id("agentID")));
				sbox.selectByVisibleText(empname);
				flag=true;
				extent.log(LogStatus.PASS,"employee Name"+empname+ " is selected sucessfully");
			}
			else
			{
				flag=false;
				extent.log(LogStatus.FAIL,"employee Name"+empname+ " is not selected");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean setswapdate(WebDriver driver,String swapDate) throws Exception
	{
		boolean flag=true;
		try{		
			By swapDatetxt=By.xpath(txtswapdate);
			Utilities.waitForPageLoad(driver,swapDatetxt);
			if (driver.findElements(swapDatetxt).size()!=0)
			{
				driver.findElement(swapDatetxt).clear();
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
				driver.findElement(swapDatetxt).sendKeys(swapDate);
				Thread.sleep(4000);
				/*Robot r = new Robot();
				r.keyPress(KeyEvent.VK_TAB);
				r.keyRelease(KeyEvent.VK_TAB);*/
				extent.log(LogStatus.PASS, "Start Date: "+swapDate +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Start Date: "+swapDate +" is NOT entered");
				flag=false;
			}
			
		}catch (Exception e) 
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setpickupDate(WebDriver driver,String pickupDate) throws Exception
	{
		boolean flag=true;
		try{	
			System.out.println("pickup date is" + pickupDate);
			By pickupDatetxt=By.xpath(txtpickupdate);
			Utilities.waitForPageLoad(driver,pickupDatetxt);
			if (driver.findElements(pickupDatetxt).size()!=0)
			{
				driver.findElement(pickupDatetxt).clear();
				driver.switchTo().alert().accept();
				//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
				//Thread.sleep(2000);
				driver.findElement(pickupDatetxt).sendKeys(pickupDate);
				Thread.sleep(4000);
				/*Robot r = new Robot();
				r.keyPress(KeyEvent.VK_TAB);
				r.keyRelease(KeyEvent.VK_TAB);*/
				extent.log(LogStatus.PASS, "Start Date: "+pickupDate +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Start Date: "+pickupDate +" is NOT entered");
				flag=false;
			}
			
		}catch (Exception e) 
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setresponse(WebDriver driver,String deadline)
	{
		boolean flag=false;
		try
		{
			
			By deadlinetxt= By.xpath(txtresponsedeadline);
			Utilities.waitForPageLoad(driver,deadlinetxt);
			if(driver.findElements(deadlinetxt).size()!=0)
			{
				driver.findElement(deadlinetxt).clear();
				driver.switchTo().alert().accept();
				Thread.sleep(2000);
				//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
				driver.findElement(deadlinetxt).sendKeys(deadline);
				Thread.sleep(4000);
				
				extent.log(LogStatus.PASS,"value" + deadline + "is entered successfully");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL, "value" + deadline + "is not  entered successfully");
			}
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clickshiftsave(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			By savebtn=By.xpath(btnshiftsave);
			Utilities.waitForPageLoad(driver,savebtn);
			if(driver.findElements(savebtn).size()!=0)
			{
				driver.findElement(savebtn).click();
				flag=true;
				extent.log(LogStatus.PASS,"clicked on save btton is successfull");
			}
			else
			{
				flag=false;
				extent.log(LogStatus.FAIL,"clicked on save button is unsucessfull");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clickDone(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			By doneBtn=By.xpath(btnDone);
			Utilities.waitForPageLoad(driver,doneBtn);
			if (driver.findElements(doneBtn).size()!=0)
			{					
				driver.findElement(doneBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Done buttton button is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Done button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean confirmswap(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			//Utilities.setWindowFocus(driver);
			By confirmswaprdbtn=By.xpath(rdbtnconfirmswap);
			Utilities.waitForPageLoad(driver,confirmswaprdbtn);
			if(driver.findElements(confirmswaprdbtn).size()!=0)
			{
				driver.findElement(confirmswaprdbtn).click();
				flag=true;
				extent.log(LogStatus.PASS,"Confirm swap radio button is selected");
				
			}
			else
			{
				flag=false;
				extent.log(LogStatus.FAIL,"Confirm swap radio button is not selected");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			
		}
		return flag;
	}
	
	public static boolean clickContinue(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.setWindowFocus(driver);
			By continuebtn=By.xpath(btncontinue);
			Utilities.waitForPageLoad(driver,continuebtn);
			if(driver.findElements(continuebtn).size()!=0)
			{
				driver.findElement(continuebtn).click();
				flag=true;
				extent.log(LogStatus.PASS,"clicked on continue btton is successfull");
			}
			else
			{
				flag=false;
				extent.log(LogStatus.FAIL,"clicked on continue button is unsucessfull");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickCreateNewRequest_shiftChange(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			By newReqShiftBtn=By.xpath(btnshiftrequest);
			Utilities.waitForPageLoad(driver,newReqShiftBtn);
			if (driver.findElements(newReqShiftBtn).size()!=0)
			{					
				driver.findElement(newReqShiftBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Create New Request - Shift request and change button is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Create New Request - Shift request and change button  is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static void setShiftrequestStartDate(WebDriver driver,String StartDate) throws Exception
	{
		try{		
			By startDatetxt=By.xpath(shiftstartdate);
			Utilities.waitForPageLoad(driver,startDatetxt);
			if (driver.findElements(startDatetxt).size()!=0)
			{
				driver.findElement(startDatetxt).click();
				driver.findElement(startDatetxt).clear();
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
				//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK1.png");
				driver.findElement(startDatetxt).sendKeys(StartDate);
				extent.log(LogStatus.PASS, "Start Date: "+StartDate +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Start Date: "+StartDate +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static boolean setextensionType(WebDriver driver,String data)
	{
		boolean flag=false;
		try
		{
			/*System.out.println("dta is:" +data);
			Select sbox=new Select(driver.findElement(By.xpath("//select[@id='extBeforeID']")));
			//sbox.selectByVisibleText(data);
			sbox.selectByValue("3");
			System.out.println("fgfgfgfgfgf");*/
			//Thread.sleep(4000);
			driver.findElement(By.xpath("//img[@id='extBeforeID_0Button']")).click();
			Select sbox=new Select(driver.findElement(By.xpath("//select[@id='extBeforeID']")));
			sbox.selectByVisibleText(data);
			Thread.sleep(3000);
			extent.log(LogStatus.PASS,"Extension type:"+data+" is selected from list box");
			flag=true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
}

