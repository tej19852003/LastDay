package ScreenObjects;

import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WorkQueuesScreen {
	
	public static ExtentReports extent = ExtentReports.get(WorkQueuesScreen.class);
	public static String btnCreateworkqueue="//button[@id='toolbar_ADD_ACTIONLabel']";
	public static String txtqueueName="queueName";
	public static String txtqueueDesc="queueDescription";
	public static String iconlstMedia="//span[@id='mediaId_0Wrapper']/nobr/img[@id='mediaId_0Button']";
	public static String btnSaveworkqueue="//button[@id='workpaneMediator_toolbar_SAVE_ACTIONLabel']";
	public static String btnEditworkqueue="//button[@id='toolbar_EDIT_ACTIONLabel']";
	public static String iconlstAvailableDSG="//span[@id='datasourceID_0Wrapper']/nobr/img[@id='datasourceID_0Button']";
	public static String btnAssignRight="//button[@id='workpaneMediator_assignmentbox_tb_ASSIGN_RIGHTLabel']";
	public static String btnSaveMapping="//button[@id='workpaneMediator_toolbar_SAVE_ACTIONLabel']";
	public static String btnDeleteworkqueue="//button[@id='toolbar_DELETE_ACTIONLabel']";
	
	public static boolean clickDeleteworkqueue(WebDriver driver) throws Exception
	{		
		boolean flag=false;
		try{	
			Utilities.selectRightPaneView(driver);
			By delBtn=By.xpath(btnDeleteworkqueue);
			Utilities.waitForPageLoad(driver,delBtn);
			if (driver.findElements(delBtn).size()!=0)
			{					
				driver.findElement(delBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Delete work queue button is successful");
				Thread.sleep(3000);
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Delete_OK1.png");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Delete work queue button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean validateDSGMapping(WebDriver driver,String WorkqueueName,String DataSourceGroupName) throws Exception
	{
		Boolean flag=false;
		try {
			int valrcWq=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr")).size();
			System.out.println("valrcPriv:"+valrcWq);
			for (int j=1;j<=valrcWq;j++)
			{
				if (j<=15)
				{
				String WqnameApp=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/th/a/span")).getText().trim();
				System.out.println("WqnameAppApp:"+WqnameApp);
				System.out.println("WqnameAppCreated:"+WorkqueueName);
				Thread.sleep(1000);
				if (WqnameApp.contains(WorkqueueName))
				{
					String dsgMapping=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/td[5]")).getText().trim();
					System.out.println("dsgMapping:"+dsgMapping);
					if (dsgMapping.contains(DataSourceGroupName))
						{
						driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/td[5]")).click();
						flag=true;
						}
					//driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/th/a/span")).click();
					//driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).click();
					
					break;
				}}
			}
			if (flag==true)
			{
				System.out.println("pass");
				extent.log(LogStatus.PASS, "Data Source Group Name: "+DataSourceGroupName+" mapped successfully");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "DataSourceGroup"));				
			}
			else
			{
				extent.log(LogStatus.FAIL, "Mapping of Data Source Group Name: "+DataSourceGroupName+ " is NOT successful");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "DataSourceGroup"));
				return flag =false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
		
	}
	
	public static boolean clickSaveMapping(WebDriver driver) throws Exception
	{		
		boolean flag=false;
		try{	
			Utilities.selectRightPaneView(driver);
			By saveMappingBtn=By.xpath(btnSaveMapping);
			Utilities.waitForPageLoad(driver,saveMappingBtn);
			if (driver.findElements(saveMappingBtn).size()!=0)
			{					
				driver.findElement(saveMappingBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Save Mapping button is successful");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Save Mapping button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean selectMappedDSG(WebDriver driver,String DataSourceGroup) throws Exception
	{
		Boolean flag=false;
		try {
			int dsgMaprc=driver.findElements(By.xpath("//table[@id='workpaneMediator_assignmentbox_dstRef']/tbody/tr")).size();
			System.out.println("dsgMaprc:"+dsgMaprc);
			for (int j=1;j<=dsgMaprc;j++)
			{
				String dsgApp=driver.findElement(By.xpath("//table[@id='workpaneMediator_assignmentbox_dstRef']/tbody/tr["+j+"]/th/a/span")).getText().trim();
				System.out.println("WqnameAppApp:"+dsgApp);
				System.out.println("DataSourceGroup:"+DataSourceGroup);
				//String mapped=driver.findElement(By.xpath("//table[@id='workpaneMediator_assignmentbox_srcRef']/tbody/tr["+j+"]/td")).getText().trim();
				
				Thread.sleep(1000);
				if (dsgApp.contains(DataSourceGroup))
				{
					driver.findElement(By.xpath("//table[@id='workpaneMediator_assignmentbox_dstRef']/tbody/tr["+j+"]/th/a/span")).click();
					//driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).click();
					flag=true;
					break;
				}
			}
			if (flag==true)
			{
				System.out.println("pass");
				extent.log(LogStatus.PASS, " Mapped Data Source Group: "+DataSourceGroup+" created/selected successfully");
				//captureScreenShot(driver,screenshotDir+"OrganizationNameValidation");				
			}
			else
			{
				extent.log(LogStatus.INFO, "Mapped Data Source Group: "+DataSourceGroup+ " does not exist");
				//captureScreenShot(driver,screenshotDir+"RoleNameValidation");
				return flag =false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
		
	}
	
	public static boolean clickAssignRight(WebDriver driver) throws Exception
	{		
		boolean flag=false;
		try{	
			Utilities.selectRightPaneView(driver);
			By assignrtBtn=By.xpath(btnAssignRight);
			Utilities.waitForPageLoad(driver,assignrtBtn);
			if (driver.findElements(assignrtBtn).size()!=0)
			{					
				driver.findElement(assignrtBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Assign Right button is successful");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Assign Right button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectDSGMapped(WebDriver driver,String DataSourceGroup) throws Exception
	{
		Boolean flag=false;
		try {
			int dsgMaprc=driver.findElements(By.xpath("//table[@id='workpaneMediator_assignmentbox_srcRef']/tbody/tr")).size();
			System.out.println("dsgMaprc:"+dsgMaprc);
			for (int j=1;j<=dsgMaprc;j++)
			{
				String dsgApp=driver.findElement(By.xpath("//table[@id='workpaneMediator_assignmentbox_srcRef']/tbody/tr["+j+"]/th/a/span")).getText().trim();
				System.out.println("WqnameAppApp:"+dsgApp);
				System.out.println("DataSourceGroup:"+DataSourceGroup);
				String mapped=driver.findElement(By.xpath("//table[@id='workpaneMediator_assignmentbox_srcRef']/tbody/tr["+j+"]/td")).getText().trim();
				System.out.println("mapped:"+mapped);
				Thread.sleep(1000);
				if (dsgApp.contains(DataSourceGroup) & (mapped!="Mapped"))
				{
					driver.findElement(By.xpath("//table[@id='workpaneMediator_assignmentbox_srcRef']/tbody/tr["+j+"]/th/a/span")).click();
					//driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).click();
					flag=true;
					break;
				}
			}
			if (flag==true)
			{
				System.out.println("pass");
				extent.log(LogStatus.PASS, "Data Source Group: "+DataSourceGroup+" created/selected successfully");
				//captureScreenShot(driver,screenshotDir+"OrganizationNameValidation");				
			}
			else
			{
				extent.log(LogStatus.WARNING, "Data Source Group: "+DataSourceGroup+ " does not exist OR already mapped");
				//captureScreenShot(driver,screenshotDir+"RoleNameValidation");
				return flag =false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
		
	}
	
	public static boolean selectItemAvailableDSG(WebDriver driver,String Option) throws Exception
	{
		boolean flag=false;
		try{
			Thread.sleep(3000);
			By lstDSG=By.xpath(iconlstAvailableDSG);
			Utilities.waitForPageLoad(driver,lstDSG);
			if (driver.findElements(lstDSG).size()!=0)
			{
				driver.findElement(lstDSG).click();
				Thread.sleep(2000);
				driver.findElement(lstDSG).sendKeys(Option);
				Robot r = new Robot();
				r.keyPress(KeyEvent.VK_ENTER);
				r.keyRelease(KeyEvent.VK_ENTER);
				extent.log(LogStatus.INFO, "Work queue Media:"+Option+ " is selected");	
				flag=true;	
				Thread.sleep(4000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Work queue Media:"+Option+ " is Unsuccessful");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickEditworkqueue(WebDriver driver) throws Exception
	{		
		boolean flag=false;
		try{	
			Utilities.selectRightPaneView(driver);
			By editwqBtn=By.xpath(btnEditworkqueue);
			Utilities.waitForPageLoad(driver,editwqBtn);
			if (driver.findElements(editwqBtn).size()!=0)
			{					
				driver.findElement(editwqBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Edit work queu button is successful");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Edit work queue button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectWorkqueue(WebDriver driver,String WorkqueueName) throws Exception
	{
		Boolean flag=false;
		try {
			int valrcWq=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr")).size();
			System.out.println("valrcPriv:"+valrcWq);
			for (int j=1;j<=valrcWq;j++)
			{
				if (j<=15)
				{
				String WqnameApp=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/th/a/span")).getText().trim();
				System.out.println("WqnameAppApp:"+WqnameApp);
				System.out.println("WqnameAppCreated:"+WorkqueueName);
				Thread.sleep(3000);
				if (WqnameApp.contains(WorkqueueName))
				{
					driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/th")).click();
					//driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).click();
					flag=true;
					break;
				}}
			}
			if (flag==true)
			{
				System.out.println("pass");
				extent.log(LogStatus.PASS, "Work queue Name: "+WorkqueueName+" created/selected successfully");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Workqueue"));				
			}
			else
			{
				extent.log(LogStatus.INFO, "Work queue Name: "+WorkqueueName+ " does not exist");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Workqueue"));
				return flag =false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
		
	}
	
	public static boolean clickSave(WebDriver driver) throws Exception
	{		
		boolean flag=false;
		try{	
			Utilities.selectRightPaneView(driver);
			By saveBtn=By.xpath(btnSaveworkqueue);
			Utilities.waitForPageLoad(driver,saveBtn);
			if (driver.findElements(saveBtn).size()!=0)
			{					
				driver.findElement(saveBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Save button is successful");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Save button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setWorkqueueDescription(WebDriver driver,String WorkqueueDesc) throws Exception
	{
		boolean flag=false;
		try{		
			By wqDesctxt=By.id(txtqueueDesc);
			Utilities.waitForPageLoad(driver,wqDesctxt);
			if (driver.findElements(wqDesctxt).size()!=0)
			{
				driver.findElement(wqDesctxt).clear();
				driver.findElement(wqDesctxt).sendKeys(WorkqueueDesc);
				extent.log(LogStatus.PASS, "Work queue Description : "+WorkqueueDesc +" is entered successfully");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Work queue Description : "+WorkqueueDesc +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setWorkqueueName(WebDriver driver,String WorkqueueName) throws Exception
	{
		boolean flag=false;
		try{		
			By wqNametxt=By.id(txtqueueName);
			Utilities.waitForPageLoad(driver,wqNametxt);
			if (driver.findElements(wqNametxt).size()!=0)
			{
				driver.findElement(wqNametxt).clear();
				driver.findElement(wqNametxt).sendKeys(WorkqueueName);
				extent.log(LogStatus.PASS, "Work queue Name : "+WorkqueueName +" is entered successfully");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Work queue Name : "+WorkqueueName +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean selectWorkqueueMedia(WebDriver driver,String Option) throws Exception
	{
		boolean flag=false;
		try{
			Thread.sleep(3000);
			By lstMedia=By.xpath(iconlstMedia);
			Utilities.waitForPageLoad(driver,lstMedia);
			if (driver.findElements(lstMedia).size()!=0)
			{
				driver.findElement(lstMedia).click();
				Thread.sleep(2000);
				driver.findElement(lstMedia).sendKeys(Option);
				Robot r = new Robot();
				r.keyPress(KeyEvent.VK_ENTER);
				r.keyRelease(KeyEvent.VK_ENTER);
				extent.log(LogStatus.INFO, "Work queue Media:"+Option+ " is selected");	
				flag=true;			
			}
			else
			{
				extent.log(LogStatus.FAIL, "Work queue Media:"+Option+ " is Unsuccessful");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickworkqueue(WebDriver driver) throws Exception
	{		
		boolean flag=false;
		try{	
			Utilities.selectRightPaneView(driver);
			By wqBtn=By.xpath(btnCreateworkqueue);
			Utilities.waitForPageLoad(driver,wqBtn);
			if (driver.findElements(wqBtn).size()!=0)
			{					
				driver.findElement(wqBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Create work queue button is successful");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Create work queue button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
}

