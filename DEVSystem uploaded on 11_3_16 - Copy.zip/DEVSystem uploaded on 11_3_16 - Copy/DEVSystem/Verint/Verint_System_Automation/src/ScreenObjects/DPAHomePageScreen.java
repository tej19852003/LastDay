package ScreenObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.LogStatus;


import Utilities.Utilities;
import com.relevantcodes.extentreports.ExtentReports;


public class DPAHomePageScreen {
	
	public static ExtentReports extent = ExtentReports.get(DPAHomePageScreen.class);
	public static Screen sobj = new Screen ();
	public static String lnkAdministration="Administration";
	public static String lnkReports="Reports";
	public static String lnkSystem="System";
	public static String lnkScreenContentTriggers="Screen Content Triggers";
	public static String lnkScreenName="Screen Name";
	

	public static boolean DPAHomePage_Reports(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try {			
			Thread.sleep(2000);
			if ((driver.findElements(By.linkText(lnkAdministration)).size()==0))
			{		
				extent.log(LogStatus.PASS, "DPA Home page : Administration tab is NOT dispalyed as Expected");			
			}
			else
			{
				extent.log(LogStatus.FAIL, "DPA Home page - Administration tab is dispalyed");	
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "DPAAdmin"));
				return flag =false;
			}
			if ((driver.findElements(By.linkText(lnkSystem)).size()==0))
			{		
				extent.log(LogStatus.PASS, "DPA Home page : System tab is NOT dispalyed as Expected");			
			}
			else
			{
				extent.log(LogStatus.FAIL, "DPA Home page - System tab is dispalyed");	
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "DPASystem"));
				return flag =false;
			}
			if (driver.findElements(By.linkText(lnkReports)).size()!=0)
			{		
				extent.log(LogStatus.PASS, "DPA Home page : Reports tab only dispalyed successfully");	
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "DPAReports"));
			}
			else
			{
				extent.log(LogStatus.FAIL, "DPA Home page - Reports tab is NOT dispalyed");	
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "DPAReports"));
				return flag =false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}	
		return flag;
	}
	
	public static boolean DPAHomePage(WebDriver driver) throws Exception
	{
		boolean flag=true;
		try {			
			Thread.sleep(2000);
			if ((driver.findElements(By.linkText(lnkAdministration)).size()!=0) & (driver.findElements(By.linkText(lnkReports)).size()!=0) & (driver.findElements(By.linkText(lnkSystem)).size()!=0))
			{		
				extent.log(LogStatus.PASS, "DPA Home page : Reports Administration System tabs were dispalyed successfully");			
			}
			else
			{
				extent.log(LogStatus.FAIL, "DPA Home page - Reports Administration System tabs were NOT dispalyed");				
				return flag =false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static void close_DPA(WebDriver driver,String windowHandle) throws Exception
	{
		driver.close();
		extent.log(LogStatus.INFO, "DPA window is closed");
		driver.switchTo().window(windowHandle); // switch back to the original window
		
	}
	
	public static boolean selectMenuItem(WebDriver driver,String linkText,String menuItem,String TriggerType) throws Exception
	{
		boolean flag=true;
		Thread.sleep(1000);	
		WebElement tabName = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.linkText(linkText)));
		Actions action = new Actions(driver);
		action.moveToElement(tabName).build().perform();
		Thread.sleep(1000);	
		if (menuItem.contains("Triggers"))
		{
			//Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Trigger.png");
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Trigger.png");
			//Thread.sleep(1000);
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Impact360_Text.png");
			//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Text.png");			
			//driver.findElement(By.xpath("//div[@id='ctl00_StaticMainMenuControl1_TopLevelMenu']/ul/li[2]/div/ul/li[2]/a")).click();
			extent.log(LogStatus.INFO, menuItem+" menu item is selected from "+linkText+" tab");
			Thread.sleep(2000);
		}
		/*driver.findElement(By.linkText(menuItem)).click(); //
		Thread.sleep(8000);
		driver.findElement(By.linkText("Administration")).click();
		Thread.sleep(2000);*/
		//sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Admin_Trigger.png"); //click on DPA menu item
		
		if (TriggerType.contains("Screen Content Triggers"))
		{
			if (driver.findElements(By.linkText(lnkScreenContentTriggers)).size()!=0)
			{
				//driver.findElement(By.linkText(lnkScreenContentTriggers)).click();	
				if ( driver.findElements(By.linkText(lnkScreenName)).size()!=0)
				{
					extent.log(LogStatus.PASS, "Screen Content Triggers page is displayed");
					flag=true;
				}
				else
				{
					extent.log(LogStatus.FAIL, "Screen Content Triggers page is NOT displayed");
					flag=false;
				}
			}
						
		}
		if (menuItem.contains("Application Analysis Reports"))
		{
			driver.findElement(By.xpath("//div[@id='ctl00_StaticMainMenuControl1_TopLevelMenu']/ul/li[1]/div/ul/li[2]/a")).click();
			extent.log(LogStatus.INFO, menuItem+" menu item is selected from "+linkText+" tab");
			Thread.sleep(6000);
			if (driver.findElements(By.xpath("//input[@id='ctl00_MidPanelContentHolder_btnDisplayReport']")).size()!=0)
			{
				extent.log(LogStatus.PASS, "Application Analysis Reports page is displayed");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL, "Application Analysis Reports page is NOT displayed");
				flag=false;
			}
		}
		return flag;		
	}
	public static boolean verifyDPAHomePage(WebDriver driver) throws Exception
	{
		boolean flag=true;
		try {			
			By home=By.linkText(lnkAdministration);
			Utilities.waitForPageLoad(driver,home);
			Thread.sleep(2000);
			if (driver.findElements(home).size()!=0)
			{		
				extent.log(LogStatus.PASS, "DPA Home page is dispalyed successfully");			
			}
			else
			{
				extent.log(LogStatus.FAIL, "DPA Home page is NOT dispalyed");
				//Utilities.captureScreenShot(driver,screenshotDir+"Login");
				return flag =false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

}
