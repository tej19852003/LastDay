package ScreenObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class ValidationRuleScreen {
	
	public static ExtentReports extent = ExtentReports.get(ValidationRuleScreen.class);
	
	public static String chkboxrule="//input[@id='VALIDATION_VTO_REDUCE_NET_STAFFING_SURPLUS_true_0']";
	public static String txtsurplus="//input[@id='VTO_MIN_SURPLUS_DURATION_VALUE']";
	public static String btnsave="//button[@id='toolbar_SAVE_ACTIONLabel']";
	
	
	
	public static boolean selectrulebox(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By rulechkbox=By.xpath(chkboxrule);
			Utilities.waitForPageLoad(driver,rulechkbox);
			if(driver.findElements(rulechkbox).size()!=0)
			{
				driver.findElement(rulechkbox).click();
				extent.log(LogStatus.PASS,"clicked on rule check box is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"not able to click on rule chk box");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setsurplus(WebDriver driver,String surplus)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By surplustxt=By.xpath(txtsurplus);
			Utilities.waitForPageLoad(driver,surplustxt);
			if(driver.findElements(surplustxt).size()!=0)
			{
				driver.findElement(surplustxt).sendKeys(surplus);
				extent.log(LogStatus.PASS,"value :"+surplus+ "is entered sucessfully for surplus percent");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"not able to enter surplus value");
				flag=false;
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clicksave(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By savebtn=By.xpath(btnsave);
			Utilities.waitForPageLoad(driver,savebtn);
			if(driver.findElements(savebtn).size()!=0)
			{
				driver.findElement(savebtn).click();
				extent.log(LogStatus.PASS,"clicked on save button is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"not able to click on save button");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
}

