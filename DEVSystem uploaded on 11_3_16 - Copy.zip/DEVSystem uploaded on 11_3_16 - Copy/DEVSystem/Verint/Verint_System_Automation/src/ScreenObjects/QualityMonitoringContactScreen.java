package ScreenObjects;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.python.core.exceptions;
import org.sikuli.script.Key;
import org.sikuli.script.KeyModifier;
import org.sikuli.script.Screen;



import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class QualityMonitoringContactScreen {

	public static ExtentReports extent = ExtentReports.get(Impact360Screen.class);
	public static Screen sobj = new Screen ();
	public static String lstEvalForm="formInfo_ddFormName";
	public static String lstMediaComponent="dfd_MS_catAD__ctl2_ddlContent";
	public static String btnSubmitform="//input[@id='toolBar_submit']";
	public static String lnkPreferences="//a[@id='PlaybackHeader_btnCustomize_btnCustomize']";
	public static String dateRangeFrom="//input[@id='dfd_MS_catDRC__ctl2_trsDRC__ctl2_DDatePicker_DDatePicker_DateFrom']";
	public static String dateRangeTo="//input[@id='dfd_MS_catDRC__ctl2_trsDRC__ctl2_DDatePicker_DDatePicker_DateTo']";
	public static String radioBetweenDatesTimes="//input[@id='dfd_MS_catDRC__ctl2_trsDRC__ctl2']";
	public static String btnExecuteSearch="//a[@id='Search_btnExecuteSearch_btnExecuteSearch']";
	public static String btnEditEval="//img[@id='toolBar_edit']";
	public static String radioEvaluations="//input[@id='Search__ctl1'][@type='radio']";
	public static String lnkCustomizeInbox="//a[@id='GridHeader_btnCustomizeInbox_btnCustomizeInbox']";
	public static String txtfromdays="//input[@id='dfd_MS_catDRC__ctl2_trsDRC__ctl1_LastDaysTextBox']";
	public static String linkpreference="//a[@id='GridHeader_btnCustomize_btnCustomize']";
	public static String headertext="//div[@title='Sort by: Number of Holds ']//span";
	public static String linksearch="//a[@id='GridHeader_btnSearch_btnSearch']";
	public static String btnexecsearch="//a[@id='Search_btnExecuteSearch_btnExecuteSearch']";
	
	
	public static boolean clickExecutesearch(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			driver.switchTo().defaultContent();
			driver.switchTo().frame("FR_HEADER");
			By btnsearch=By.xpath(btnexecsearch);
			Utilities.waitForPageLoad(driver,btnsearch);
			if(driver.findElements(btnsearch).size()!=0)
			{
				driver.findElement(btnsearch).click();
				extent.log(LogStatus.PASS,"click on execute serach button is successfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"Not able to click on execute search button");
				flag=false;
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickPreference(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			driver.switchTo().defaultContent();
			driver.switchTo().frame("FR_GRID");
			driver.switchTo().frame("headerframe");
			By linkpref=By.xpath(linkpreference);
			Utilities.waitForPageLoad(driver,linkpref);
			if(driver.findElements(linkpref).size()!=0)
			{
				driver.findElement(linkpref).click();
				extent.log(LogStatus.PASS,"click on preference link is successfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"Not able to click on preference link");
				flag=false;
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clickSearch(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			driver.switchTo().defaultContent();
			driver.switchTo().frame("FR_GRID");
			driver.switchTo().frame("headerframe");
			By linksrch=By.xpath(linksearch);
			Utilities.waitForPageLoad(driver,linksrch);
			if(driver.findElements(linksrch).size()!=0)
			{
				driver.findElement(linksrch).click();
				extent.log(LogStatus.PASS,"click on search link is successfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"Not able to click on search link");
				flag=false;
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean clickCustomizeInbox(WebDriver driver) throws Exception  
	{
		boolean flag=false;
		try{
			/*By customInboxLnk=By.xpath(lnkCustomizeInbox);
			driver.switchTo().defaultContent();
			driver.switchTo().frame(0);	
			Thread.sleep(1000);
			driver.switchTo().frame(0);
			Thread.sleep(1000);
			Utilities.waitForPageLoad(driver,customInboxLnk);
			if (driver.findElements(customInboxLnk).size()!=0)
			{					
				driver.findElement(customInboxLnk).click();				
				extent.log(LogStatus.INFO, "Clicked on Customize Inbox is successful");
				Thread.sleep(10000);
				flag=true;
			}
			else
			{
				 extent.log(LogStatus.FAIL,"Clicked on Customize Inbox is UNsuccessful");
				 flag=false;
			}*/		
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_CustomizeInbox.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_CustomizeInbox.png");
				extent.log(LogStatus.INFO, "Clicked on Customize Inbox is successful");
				Thread.sleep(10000);
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"Clicked on Customize Inbox is UNsuccessful");
				 flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean select_SearchFor_Evaluations(WebDriver driver) throws Exception
	{
		 Boolean flag=true;
		try{
			By evalRadio=By.xpath(radioEvaluations);
			driver.switchTo().defaultContent();
			Thread.sleep(1000);
			driver.switchTo().frame(1);
			Thread.sleep(1000);
			Utilities.waitForPageLoad(driver,evalRadio);
			if (driver.findElements(evalRadio).size()!=0)
			{					
				//extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QM05_07_14_Playback_EvalForm_RemarksBy"));
				driver.findElement(evalRadio).click();
				extent.log(LogStatus.INFO, "Clicked on QM Search For - Evaluations radio button is successful");
				Thread.sleep(4000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on QM Search For - Evaluations radio button is Unsuccessful");
				//extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QM05_07_14_Playback_EvalForm_RemarksBy"));
				return flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean editEvaluationForm(WebDriver driver) throws Exception  // edit Evaluation form - only first radio button - couch
	{
		Boolean flag=true;
		Boolean temp=false;;
		try{
			Thread.sleep(4000);
			driver.switchTo().defaultContent();
			/*driver.switchTo().frame(1);	
			Thread.sleep(1000);
			driver.switchTo().frame("FR_EVALUATION");
			Thread.sleep(1000);*/
			
			Utilities.switchFrame(driver,"FR_PLAYBACK");
		    Thread.sleep(2000);
		    Utilities.switchFrame(driver,"FR_EVALUATION");
		    Thread.sleep(2000);
			
			  List<WebElement> li=driver.findElements(By.xpath("//div[@class='element_div']"));
				System.out.println("list size is:" + li.size());
				List<WebElement> li1=driver.findElements(By.xpath("//div[@class='element_div']//input[@type='radio']"));
				System.out.println("size of input tag is:" + li1.size());
				for(WebElement elt:li1)
				{
					String text=elt.findElement(By.xpath("..//label")).getText();
					//System.out.println("text is:"+ text);
					if(text.equalsIgnoreCase("N/A"))
					{
						elt.click();
						temp=true;
						break;
					}
				}
				
				if (temp==true)
				{
					extent.log(LogStatus.PASS, "Edit Evaluation form is successful");
					extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Eval"));
				}
				else
				{
					extent.log(LogStatus.FAIL, "Not able to Edit Evaluation form");
					extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Eval"));
					flag=false;
				}
			
			/*if (driver.findElements(By.xpath("//table[@id='Section405000927_Category405000934_Element405000965_405000965']/tbody/tr[1]/td[2]/input[@type='radio']")).size()!=0)
			{
				driver.findElement(By.xpath("//table[@id='Section405000927_Category405000934_Element405000965_405000965']/tbody/tr[1]/td[2]/input[@type='radio']")).click();
			}
			else
			{
				extent.log(LogStatus.WARNING, "Not able to Edit Evaluation form");
				flag=false;
			}*/
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
		
	}
	public static boolean clickEditEvaluation(WebDriver driver) throws Exception  
	{
		boolean flag=false;
		try{
			By editBtn=By.xpath(btnEditEval);
			driver.switchTo().defaultContent();
			/*driver.switchTo().frame(1);			
			driver.switchTo().frame("FR_EVALUATION");
			Thread.sleep(4000);*/
			Utilities.switchFrame(driver,"FR_PLAYBACK");
		    Thread.sleep(2000);
		    Utilities.switchFrame(driver,"FR_EVALUATION");
		    Thread.sleep(2000);
			
			Utilities.waitForPageLoad(driver,editBtn);
			if (driver.findElements(editBtn).size()!=0)
			{			
				if (driver.findElement(editBtn).isEnabled())
				{
					driver.findElement(editBtn).click();				
					extent.log(LogStatus.INFO, "Clicked on Edit Evaluation button is successful");
					Thread.sleep(3000);
					flag=true;
				}
				else
				{
					 extent.log(LogStatus.FAIL,"Edit Evaluation button is NOT enabled");
					 return flag=false;
				}
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Edit Evaluation button is unsuccessful");
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickExecute(WebDriver driver) throws Exception
	{
		 Boolean flag=true;
		try{
			By executeSearch=By.xpath(btnExecuteSearch);
			driver.switchTo().defaultContent();
			Thread.sleep(1000);
			Utilities.switchFrame(driver,"FR_HEADER");
			Thread.sleep(1000);
			Utilities.waitForPageLoad(driver,executeSearch);
			if (driver.findElements(executeSearch).size()!=0)
			{					
				//extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QM05_07_14_Playback_EvalForm_RemarksBy"));
				driver.findElement(executeSearch).click();
				extent.log(LogStatus.INFO, "Clicked on QM Search - Execute Search button is successful");
				Thread.sleep(4000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on QM Search - Execute Search button is unsuccessful");
				//extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QM05_07_14_Playback_EvalForm_RemarksBy"));
				return flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setDateRange_Days(WebDriver driver,String Days) throws Exception
	{
		 Boolean flag=true;
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_DateRange.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_DateRange.png");
			sobj.type("a", KeyModifier.CTRL); // select all text			
			sobj.type(Key.BACKSPACE); // delete selection
			sobj.type(Days);
		}
		else
		{
			extent.log(LogStatus.FAIL,"Date Range text field is NOT displayed");
			flag=false;
		}
		return flag;
	}
	
	public static boolean selectQMSearchContact_Betweenthesedatesandtimes(WebDriver driver) throws Exception
	{
		boolean flag=true;
		try{
			Thread.sleep(5000);			
			driver.switchTo().defaultContent();
			Utilities.switchFrame(driver,"FR_SEARCH");
			Thread.sleep(2000);
			By datetimeRad=By.xpath(radioBetweenDatesTimes);
			Utilities.waitForPageLoad(driver,datetimeRad);
			if (driver.findElements(datetimeRad).size()!=0)
			{				
				driver.findElement(datetimeRad).click();
				extent.log(LogStatus.PASS, "Date Range - Between these dates and times radio button selected successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Date Range - Between these dates and times radio button NOT selected");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean setQMSearchContact_DateRangeFrom(WebDriver driver,String DateRangeFrom) throws Exception
	{
		boolean flag=true;
		try{
			Thread.sleep(2000);
			driver.switchTo().defaultContent();
			Utilities.switchFrame(driver,"FR_SEARCH");
			Thread.sleep(2000);
			By fromDate=By.xpath(dateRangeFrom);
			Utilities.waitForPageLoad(driver,fromDate);
			System.out.println(DateRangeFrom);
			if (driver.findElements(fromDate).size()!=0)
			{
				driver.findElement(fromDate).clear();
				driver.findElement(fromDate).sendKeys(DateRangeFrom);
				extent.log(LogStatus.PASS, "Date Range From : "+DateRangeFrom +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Date Range From : "+DateRangeFrom +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean setQMSearchContact_DateRangeTo(WebDriver driver,String DateRangeTo) throws Exception
	{
		boolean flag=true;
		try{
			Thread.sleep(2000);
			driver.switchTo().defaultContent();
			Thread.sleep(1000);
			Utilities.switchFrame(driver,"FR_SEARCH");
			Thread.sleep(2000);
			By toDate=By.xpath(dateRangeTo);
			Utilities.waitForPageLoad(driver,toDate);
			if (driver.findElements(toDate).size()!=0)
			{
				driver.findElement(toDate).clear();
				driver.findElement(toDate).sendKeys(DateRangeTo);
				extent.log(LogStatus.PASS, "Date Range To : "+DateRangeTo +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Date Range To : "+DateRangeTo +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickQMEvalForm_Home(WebDriver driver) throws Exception
	{
		boolean flag=true;
		try{
			driver.switchTo().defaultContent();
			driver.switchTo().frame(1);
			Thread.sleep(2000);
			driver.switchTo().frame(1);
			Thread.sleep(1000);
			if (driver.findElements(By.xpath("//a[@id='PlaybackHeader__ctl5__ctl0']")).size()!=0)
			{					
				
				driver.findElement(By.xpath("//a[@id='PlaybackHeader__ctl5__ctl0']")).click();
				System.out.println("clicked");
			}
			/*if (driver.findElements(By.xpath("//table[@class='NavigationHeaderPosition']/tbody/tr/td/table/tbody/tr/td/a[@id='PlaybackHeader__ctl5__ctl0']")).size()!=0)
			{					
				driver.findElement(By.xpath("//table[@class='NavigationHeaderPosition']/tbody/tr/td/table/tbody/tr/td/a[@id='PlaybackHeader__ctl5__ctl0']")).click();
				//driver.findElement(prefLnk).click();
				extent.log(LogStatus.INFO, "Clicked on Home is successful");
				Thread.sleep(6000);
			}*/
			else
			{
				extent.log(LogStatus.FAIL, "Clicked on Home is unsuccessful");
				flag=false;
			}
			 /*if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_EvalForm_Home.png")!=null)
			 {
				 sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_EvalForm_Home.png");
				 extent.log(LogStatus.PASS,"clicked on QM Eval Form - Home is successfully");
				 Thread.sleep(6000);
			 }
			 else
			 {
				 extent.log(LogStatus.FAIL,"clicked on QM Eval Form - Home is NOT successful");
				 return flag=false;
			 }*/
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickEvalPreferences(WebDriver driver) throws Exception
	{
		boolean flag=true;
		try{
			By prefLnk=By.xpath(lnkPreferences);
			driver.switchTo().defaultContent();
			driver.switchTo().frame(1);
			Thread.sleep(2000);
			driver.switchTo().frame(1);
			Utilities.waitForPageLoad(driver,prefLnk);
			if (driver.findElements(prefLnk).size()!=0)
			{					
				driver.findElement(prefLnk).click();
				extent.log(LogStatus.INFO, "Clicked on Preferences is successful");
				Thread.sleep(6000);
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Preferences is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean getSelectItemFromEvalForm(WebDriver driver,String Option) throws Exception
	{
		boolean flag=false;
		Thread.sleep(3000);
		driver.switchTo().defaultContent();
		/*driver.switchTo().frame(1);	
		Thread.sleep(2000);
		driver.switchTo().frame("FR_EVALUATION");*/
		 Utilities.switchFrame(driver,"FR_PLAYBACK");
	    Thread.sleep(2000);
	    Utilities.switchFrame(driver,"FR_EVALUATION");
	    Thread.sleep(2000);
		
		
		WebElement e =  driver.findElement(By.id(lstEvalForm));
		Select comboBox = new Select(e);
		String value =  comboBox.getFirstSelectedOption().getText();
		System.out.println("lst option:"+value);
		if (value.contains(Option))
		{
			extent.log(LogStatus.PASS,"Evaluation form Option:"+value+" is selected/displayed");
			flag=true;
		}
		else
		{
			extent.log(LogStatus.FAIL,"Evaluation form Option:"+value+" is NOT selected/displayed");
		}
		return flag;
	}
	
	public static boolean clickFlag_ForwardToAgent(WebDriver driver) throws Exception
	{
		boolean flag=false;
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);			
		driver.switchTo().frame("FR_EVALUATION");
		 
		 if (driver.findElements(By.xpath("//span[@id='toolBar_numofflags']")).size()!=0)
		 {
			 driver.findElement(By.xpath("//span[@id='toolBar_numofflags']")).click();
			 Thread.sleep(2000);
			 //Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\ForwardToAgent_checkbox.png");
			 if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\ForwardToAgent_checkbox.png")!=null)
			 {
				 sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\ForwardToAgent_checkbox.png");
				 extent.log(LogStatus.PASS,"'Forward To Agent checkbox' is selected successfully");
			 }
			 else
			 {
				 extent.log(LogStatus.FAIL,"Not able to select 'Forward To Agent checkbox'");
				 return flag=false;
			 }
			
			 Thread.sleep(2000);
			 if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png")!=null)
			 {
				 sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png");
				 extent.log(LogStatus.PASS,"Evaluation Flag - OK button clicked successfully");
			 }
			 else
			 {
				 extent.log(LogStatus.FAIL,"Not able to click on Evaluation Flag - OK button'");	
				 return flag=false;
			 }			 
			 Thread.sleep(2000);
			 Boolean temp=true;
			 if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Evaluation_Comments.png")!=null)
			 {
				 sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\Evaluation_Comments.png","AutomationTesting");
				 extent.log(LogStatus.PASS,"Evaluation comments - AutomationTesting entered");
				 //extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QMEval"));
			 }
			
			 
			 if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Evaluation_Comments1.png")!=null)
			 {
				 sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\Evaluation_Comments1.png","AutomationTesting");
				 extent.log(LogStatus.PASS,"Evaluation comments - AutomationTesting entered");
				 //extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QMEval"));
			 }
			
			 if (temp==false)
			 {
				 return flag=false;
			 }
			 Thread.sleep(3000);
			 if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Feedback_Send.png")!=null)
			 {
				 sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Feedback_Send.png");
				 extent.log(LogStatus.PASS,"Clicked on Feedback - Send button is successful");
				 flag=true;
			 }
			 else
			 {
				 extent.log(LogStatus.FAIL,"Not able to click on Feedback - Send button");
				 return flag=false;
			 }					 
			 //Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Feedback_Send.png");			
		 }
		 else
		 {
			 extent.log(LogStatus.FAIL,"Not able to click on Flags icon");
			 return flag=false;
		 }
		 Thread.sleep(2000);
		
		
		return flag;
	}
	
	public static boolean clickSubmitform(WebDriver driver) throws Exception  // fill Evaluation form - supports only eval form -  Quality Monitoring Form - Scored (New)
	{
		boolean flag=false;
		try{
			driver.switchTo().defaultContent();
			Utilities.switchFrame(driver,"FR_PLAYBACK");
		    Thread.sleep(2000);
		    Utilities.switchFrame(driver,"FR_EVALUATION");
		    Thread.sleep(2000);
			By submitBtn=By.xpath(btnSubmitform);
			Utilities.waitForPageLoad(driver,submitBtn);
			if (driver.findElements(submitBtn).size()!=0)
			{			
				if (driver.findElement(submitBtn).isEnabled())
				{
					driver.findElement(submitBtn).click();				
					extent.log(LogStatus.INFO, "Clicked on Submit form button is successful");
					Thread.sleep(3000);
					flag=true;
				}
				else
				{
					 extent.log(LogStatus.FAIL,"Submit button is NOT enabled");
					 return flag=false;
				}
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Submit form button is unsuccessful");
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean evaluateEvaluationForm(WebDriver driver) throws Exception  // fill Evaluation form - supports only eval form -  Quality Monitoring Form - Scored (New)
	{
		Boolean flag=true;
		Thread.sleep(4000);
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);			
		driver.switchTo().frame("FR_EVALUATION");
		Thread.sleep(4000);
		 List<WebElement> li=driver.findElements(By.xpath("//div[@class='element_div']"));
			System.out.println("list size is:" + li.size());
			List<WebElement> li1=driver.findElements(By.xpath("//div[@class='element_div']//input[@type='radio']"));
			System.out.println("size of input tag is:" + li1.size());
			for(WebElement elt:li1)
			{
				String text=elt.findElement(By.xpath("..//label")).getText();
				//System.out.println("text is:"+ text);
				if(text.equalsIgnoreCase("Achieved"))
				{
					elt.click();
				}
			}			
		Thread.sleep(3000);
		return flag;	
	}
	public static boolean selectQMSearchContact_AdvancedData_last60mins(WebDriver driver) throws Exception
	{
		Boolean flag=true;			
		Thread.sleep(6000); 
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_GroupsAndAgents.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_GroupsAndAgents.png");				
		}
		Thread.sleep(6000); 
		Robot r = new Robot();
		r.keyPress(KeyEvent.VK_PAGE_DOWN);
		Thread.sleep(1000);
		r.keyRelease(KeyEvent.VK_PAGE_DOWN);
		
		Thread.sleep(1000);
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Advanced.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Advanced.png");				
		}
		else
		{
			extent.log(LogStatus.INFO,"Not able to expand Advanced");
			//return flag=false;
		}
		Thread.sleep(1000); 
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png");				
		}
		Thread.sleep(1000);
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Last60mins.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Last60mins.png");				
		}
		else
		{
			extent.log(LogStatus.INFO,"Not able to select Last 60mins checkbox");
			//return flag=false;
		}
		
		
		
		/*if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Groups.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Groups.png");				
		}
		else
		{
			extent.log(LogStatus.INFO,"Not able to collapse Groups");
			//return flag=false;
		}			
		Thread.sleep(1000); 
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png");				
		}
		Thread.sleep(1000);
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Date.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Date.png");				
		}
		else
		{
			extent.log(LogStatus.INFO,"Not able to collapse Date");
			//return flag=false;
		}
		Thread.sleep(1000); 
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png");				
		}
		Thread.sleep(1000);
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Contact.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Contact.png");				
		}
		else
		{
			extent.log(LogStatus.INFO,"Not able to collapse Contacts");
			//return flag=false;
		}
		Thread.sleep(1000); 
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png");				
		}
		Thread.sleep(1000);
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Advanced.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Advanced.png");				
		}
		else
		{
			extent.log(LogStatus.INFO,"Not able to expand Advanced");
			//return flag=false;
		}
		Thread.sleep(1000); 
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png");				
		}
		Thread.sleep(1000);
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Last60mins.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Last60mins.png");				
		}
		else
		{
			extent.log(LogStatus.INFO,"Not able to select Last 60mins checkbox");
			flag=false;
		}*/
		return flag;	
	}
	
	public static boolean setQMSearchContact_SkillGroupNumber(WebDriver driver,String SkillGroupNumber) throws Exception
	{
		 Boolean flag=true;	 
		 Thread.sleep(3000);
		 driver.switchTo().defaultContent();
		 Thread.sleep(2000);
		driver.switchTo().frame(2);
		if (driver.findElements(By.xpath("//span[@id='dfd_MS_catCD__ctl8_ctrlSetCD_CD17']/table/tbody/tr[1]/td[1]/input[@id='dfd_MS_catCD__ctl8_ctrlSetCD_CD17_CD17']")).size()!=0)
		{
			driver.findElement(By.xpath("//span[@id='dfd_MS_catCD__ctl8_ctrlSetCD_CD17']/table/tbody/tr[1]/td[1]/input[@id='dfd_MS_catCD__ctl8_ctrlSetCD_CD17_CD17']")).clear();
			driver.findElement(By.xpath("//span[@id='dfd_MS_catCD__ctl8_ctrlSetCD_CD17']/table/tbody/tr[1]/td[1]/input[@id='dfd_MS_catCD__ctl8_ctrlSetCD_CD17_CD17']")).sendKeys(SkillGroupNumber);
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "SkillGroupNumber"));
		}
		else
		{
			extent.log(LogStatus.FAIL, "Not able to enter SkillGroupNumber");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "SkillGroupNumber"));
			flag=false;
		}		
		 return flag; 
	}
	
	
	public static boolean setQMSearchContact_RouterCallKey(WebDriver driver,String RouterCallKey) throws Exception
	{
		 Boolean flag=true;	 
		 Thread.sleep(3000);
		 driver.switchTo().defaultContent();
		 Thread.sleep(2000);
		driver.switchTo().frame(2);
		if (driver.findElements(By.xpath("//span[@id='dfd_MS_catCD__ctl8_ctrlSetCD_CD18']/table/tbody/tr[1]/td[1]/input[@id='dfd_MS_catCD__ctl8_ctrlSetCD_CD18_CD18']")).size()!=0)
		{
			driver.findElement(By.xpath("//span[@id='dfd_MS_catCD__ctl8_ctrlSetCD_CD18']/table/tbody/tr[1]/td[1]/input[@id='dfd_MS_catCD__ctl8_ctrlSetCD_CD18_CD18']")).clear();
			driver.findElement(By.xpath("//span[@id='dfd_MS_catCD__ctl8_ctrlSetCD_CD18']/table/tbody/tr[1]/td[1]/input[@id='dfd_MS_catCD__ctl8_ctrlSetCD_CD18_CD18']")).sendKeys(RouterCallKey);
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "RouterCallKey"));
		}
		else
		{
			extent.log(LogStatus.FAIL, "Not able to enter RouterCallKey");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "RouterCallKey"));
			flag=false;
		}		
		 return flag; 
	}
	
	public static boolean setQMSearch_AdvancedData_MediaComponents(WebDriver driver,String MediaComponent) throws Exception
	{		
		boolean flag=false;
		Thread.sleep(3000);
		driver.switchTo().defaultContent();
		driver.switchTo().frame(2);			 
		WebElement sel = driver.findElement(By.id(lstMediaComponent));
		List<WebElement> lists = sel.findElements(By.tagName("option"));
		if (lists.size()!=0)
		{			 	
			System.out.println("Media Component items count :"+lists.size());
			for(WebElement element: lists)  
			{
			    String lstValues = element.getText();
			    System.out.println("valueApp:"+lstValues);
			    System.out.println("value:"+MediaComponent);
			    if (lstValues.contains(MediaComponent))
			    {
			    	element.click();
			    	extent.log(LogStatus.PASS,"Media Component value:"+MediaComponent+" selected");
			        Thread.sleep(5000);
			        flag=true;
			        break;
			     }		        
		     }
		 }
		 else
		 {
			 extent.log(LogStatus.FAIL,"No items/Not able to select option from Media Component");
			 return flag=false;
		 }	
		 return flag;		
	}
	
	public static boolean setQMSearch_AdvancedData_ContactID(WebDriver driver,String ContactID) throws Exception
	{
		 Boolean flag=true;	 
		 Thread.sleep(3000);
		 driver.switchTo().defaultContent();
		 Thread.sleep(2000);
		driver.switchTo().frame(2);
		if (driver.findElements(By.xpath("//table[@id='dfd_MS_catAD_CollapsibleContainerElementsTable']/tbody/tr[2]/td[2]/input[@id='dfd_MS_catAD__ctl3_txtCallNumber']")).size()!=0)
		{
			driver.findElement(By.xpath("//table[@id='dfd_MS_catAD_CollapsibleContainerElementsTable']/tbody/tr[2]/td[2]/input[@id='dfd_MS_catAD__ctl3_txtCallNumber']")).clear();
			driver.findElement(By.xpath("//table[@id='dfd_MS_catAD_CollapsibleContainerElementsTable']/tbody/tr[2]/td[2]/input[@id='dfd_MS_catAD__ctl3_txtCallNumber']")).sendKeys(ContactID);
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "ContactID"));
		}
		else
		{
			extent.log(LogStatus.FAIL, "Not able to enter Contact ID");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "ContactID"));
			flag=false;
		}		
		 return flag; 
	}
	public static boolean setQMSearch_AdvancedData_NumberOfConferences(WebDriver driver,String Min,String Max) throws Exception
	{
		 Boolean flag=true;	 
		 Thread.sleep(3000);
		 driver.switchTo().defaultContent();
		 Thread.sleep(2000);
		driver.switchTo().frame(2);
		if (driver.findElements(By.xpath("//span[@id='dfd_MS_catAD__ctl10_FromToNumberOfConferences']/table/tbody/tr[1]/td[2]/input[@id='dfd_MS_catAD__ctl10_FromToNumberOfConferences_from']")).size()!=0)
		{
			driver.findElement(By.xpath("//span[@id='dfd_MS_catAD__ctl10_FromToNumberOfConferences']/table/tbody/tr[1]/td[2]/input[@id='dfd_MS_catAD__ctl10_FromToNumberOfConferences_from']")).clear();
			driver.findElement(By.xpath("//span[@id='dfd_MS_catAD__ctl10_FromToNumberOfConferences']/table/tbody/tr[1]/td[2]/input[@id='dfd_MS_catAD__ctl10_FromToNumberOfConferences_from']")).sendKeys(Min);
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "NumConferences"));
		}
		else
		{
			extent.log(LogStatus.FAIL, "Not able to enter Minimum Number of Conferences");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "NumConferences"));
			flag=false;
		}
		if (driver.findElements(By.xpath("//span[@id='dfd_MS_catAD__ctl10_FromToNumberOfConferences']/table/tbody/tr[1]/td[4]/input[@id='dfd_MS_catAD__ctl10_FromToNumberOfConferences_to']")).size()!=0)
		{
			driver.findElement(By.xpath("//span[@id='dfd_MS_catAD__ctl10_FromToNumberOfConferences']/table/tbody/tr[1]/td[4]/input[@id='dfd_MS_catAD__ctl10_FromToNumberOfConferences_to']")).clear();
			driver.findElement(By.xpath("//span[@id='dfd_MS_catAD__ctl10_FromToNumberOfConferences']/table/tbody/tr[1]/td[4]/input[@id='dfd_MS_catAD__ctl10_FromToNumberOfConferences_to']")).sendKeys(Max);
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "NumConferences"));
		}
		else
		{
			extent.log(LogStatus.FAIL, "Not able to enter Maximum Number of Conferences");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "NumConferences"));
			flag=false;
		}
		 return flag; 
	}
	
	public static boolean setQMSearch_AdvancedData_NumberOfTransfers(WebDriver driver,String Min,String Max) throws Exception
	{
		 Boolean flag=true;	 
		 Thread.sleep(3000);
		 driver.switchTo().defaultContent();
		 Thread.sleep(2000);
		driver.switchTo().frame(2);
		if (driver.findElements(By.xpath("//span[@id='dfd_MS_catAD__ctl9_FromToNumberOfTransfers']/table/tbody/tr[1]/td[2]/input[@id='dfd_MS_catAD__ctl9_FromToNumberOfTransfers_from']")).size()!=0)
		{
			driver.findElement(By.xpath("//span[@id='dfd_MS_catAD__ctl9_FromToNumberOfTransfers']/table/tbody/tr[1]/td[2]/input[@id='dfd_MS_catAD__ctl9_FromToNumberOfTransfers_from']")).clear();
			driver.findElement(By.xpath("//span[@id='dfd_MS_catAD__ctl9_FromToNumberOfTransfers']/table/tbody/tr[1]/td[2]/input[@id='dfd_MS_catAD__ctl9_FromToNumberOfTransfers_from']")).sendKeys(Min);
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "NumTransfers"));
		}
		else
		{
			extent.log(LogStatus.FAIL, "Not able to enter Minimum Number of Transfers");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "NumTransfers"));
			flag=false;
		}
		if (driver.findElements(By.xpath("//span[@id='dfd_MS_catAD__ctl9_FromToNumberOfTransfers']/table/tbody/tr[1]/td[4]/input[@id='dfd_MS_catAD__ctl9_FromToNumberOfTransfers_to']")).size()!=0)
		{
			driver.findElement(By.xpath("//span[@id='dfd_MS_catAD__ctl9_FromToNumberOfTransfers']/table/tbody/tr[1]/td[4]/input[@id='dfd_MS_catAD__ctl9_FromToNumberOfTransfers_to']")).clear();
			driver.findElement(By.xpath("//span[@id='dfd_MS_catAD__ctl9_FromToNumberOfTransfers']/table/tbody/tr[1]/td[4]/input[@id='dfd_MS_catAD__ctl9_FromToNumberOfTransfers_to']")).sendKeys(Max);
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "NumTransfers"));
		}
		else
		{
			extent.log(LogStatus.FAIL, "Not able to enter Maximum Number of Transfers");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "NumTransfers"));
			flag=false;
		}
		 return flag; 
	}
	public static boolean setQMSearch_AdvancedData_TotalHoldTime(WebDriver driver,String Min,String Max) throws Exception
	{
		 Boolean flag=true;	 
		 Thread.sleep(3000);
		 driver.switchTo().defaultContent();
		 Thread.sleep(2000);
		driver.switchTo().frame(2);
		if (driver.findElements(By.xpath("//span[@id='dfd_MS_catAD__ctl11_FromToTotalHoldsTime']/table/tbody/tr[1]/td[2]/input[@id='dfd_MS_catAD__ctl11_FromToTotalHoldsTime_from']")).size()!=0)
		{
			driver.findElement(By.xpath("//span[@id='dfd_MS_catAD__ctl11_FromToTotalHoldsTime']/table/tbody/tr[1]/td[2]/input[@id='dfd_MS_catAD__ctl11_FromToTotalHoldsTime_from']")).clear();
			driver.findElement(By.xpath("//span[@id='dfd_MS_catAD__ctl11_FromToTotalHoldsTime']/table/tbody/tr[1]/td[2]/input[@id='dfd_MS_catAD__ctl11_FromToTotalHoldsTime_from']")).sendKeys(Min);
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Eval"));
		}
		else
		{
			extent.log(LogStatus.FAIL, "Not able to enter Minimum Total Hold Time");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "HoldTime"));
			flag=false;
		}
		if (driver.findElements(By.xpath("//span[@id='dfd_MS_catAD__ctl11_FromToTotalHoldsTime']/table/tbody/tr[1]/td[4]/input[@id='dfd_MS_catAD__ctl11_FromToTotalHoldsTime_to']")).size()!=0)
		{
			driver.findElement(By.xpath("//span[@id='dfd_MS_catAD__ctl11_FromToTotalHoldsTime']/table/tbody/tr[1]/td[4]/input[@id='dfd_MS_catAD__ctl11_FromToTotalHoldsTime_to']")).clear();
			driver.findElement(By.xpath("//span[@id='dfd_MS_catAD__ctl11_FromToTotalHoldsTime']/table/tbody/tr[1]/td[4]/input[@id='dfd_MS_catAD__ctl11_FromToTotalHoldsTime_to']")).sendKeys(Max);
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Eval"));
		}
		else
		{
			extent.log(LogStatus.FAIL, "Not able to enter Maximum Total Hold Time");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "HoldTime"));
			flag=false;
		}
		 return flag; 
	}
	
	public static boolean setQMSearch_AdvancedData_WrapupTime(WebDriver driver,String Min,String Max) throws Exception
	{
		 Boolean flag=true;	 
		 Thread.sleep(3000);
		driver.switchTo().frame(2);
		if (driver.findElements(By.xpath("//span[@id='dfd_MS_catAD__ctl13_FromToWrapUpTime']/table/tbody/tr[1]/td[2]/input[@id='dfd_MS_catAD__ctl13_FromToWrapUpTime_from']")).size()!=0)
		{
			driver.findElement(By.xpath("//span[@id='dfd_MS_catAD__ctl13_FromToWrapUpTime']/table/tbody/tr[1]/td[2]/input[@id='dfd_MS_catAD__ctl13_FromToWrapUpTime_from']")).clear();
			driver.findElement(By.xpath("//span[@id='dfd_MS_catAD__ctl13_FromToWrapUpTime']/table/tbody/tr[1]/td[2]/input[@id='dfd_MS_catAD__ctl13_FromToWrapUpTime_from']")).sendKeys(Min);
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Eval"));
		}
		else
		{
			extent.log(LogStatus.FAIL, "Not able to enter Minimum Wrap-up Time");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "WrapupTime"));
			flag=false;
		}
		if (driver.findElements(By.xpath("//span[@id='dfd_MS_catAD__ctl13_FromToWrapUpTime']/table/tbody/tr[1]/td[4]/input[@id='dfd_MS_catAD__ctl13_FromToWrapUpTime_to']")).size()!=0)
		{
			driver.findElement(By.xpath("//span[@id='dfd_MS_catAD__ctl13_FromToWrapUpTime']/table/tbody/tr[1]/td[4]/input[@id='dfd_MS_catAD__ctl13_FromToWrapUpTime_to']")).clear();
			driver.findElement(By.xpath("//span[@id='dfd_MS_catAD__ctl13_FromToWrapUpTime']/table/tbody/tr[1]/td[4]/input[@id='dfd_MS_catAD__ctl13_FromToWrapUpTime_to']")).sendKeys(Max);
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Eval"));
		}
		else
		{
			extent.log(LogStatus.FAIL, "Not able to enter Maximum Wrap-up Time");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "WrapupTime"));
			flag=false;
		}
		 return flag; 
	}
	
	public static boolean setQMSearchContact_DailedFrom(WebDriver driver,String DailedFrom) throws Exception
	{
		 Boolean flag=true;	 
		 Thread.sleep(3000);
		 driver.switchTo().defaultContent();
		driver.switchTo().frame(2);
		if (driver.findElements(By.xpath("//table[@id='dfd_MS_catCD_CollapsibleContainerElementsTable']/tbody/tr[6]/td[2]/input[@id='dfd_MS_catCD__ctl7_txtANI']")).size()!=0)
		{
			driver.findElement(By.xpath("//table[@id='dfd_MS_catCD_CollapsibleContainerElementsTable']/tbody/tr[6]/td[2]/input[@id='dfd_MS_catCD__ctl7_txtANI']")).clear();
			driver.findElement(By.xpath("//table[@id='dfd_MS_catCD_CollapsibleContainerElementsTable']/tbody/tr[6]/td[2]/input[@id='dfd_MS_catCD__ctl7_txtANI']")).sendKeys(DailedFrom);
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "DailedFrom"));
		}
		else
		{
			extent.log(LogStatus.FAIL, "Not able to enter Dailed To");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "DailedFrom"));
			flag=false;
		}		
		 return flag; 
	}
	
	public static boolean setQMSearchContact_DailedTo(WebDriver driver,String DailedTo) throws Exception
	{
		 Boolean flag=true;	 
		 Thread.sleep(3000);
		driver.switchTo().frame(2);
		if (driver.findElements(By.xpath("//table[@id='dfd_MS_catCD_CollapsibleContainerElementsTable']/tbody/tr[5]/td[2]/input[@id='dfd_MS_catCD__ctl6_txtDNIS']")).size()!=0)
		{
			driver.findElement(By.xpath("//table[@id='dfd_MS_catCD_CollapsibleContainerElementsTable']/tbody/tr[5]/td[2]/input[@id='dfd_MS_catCD__ctl6_txtDNIS']")).clear();
			driver.findElement(By.xpath("//table[@id='dfd_MS_catCD_CollapsibleContainerElementsTable']/tbody/tr[5]/td[2]/input[@id='dfd_MS_catCD__ctl6_txtDNIS']")).sendKeys(DailedTo);
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "DailedTo"));
		}
		else
		{
			extent.log(LogStatus.FAIL, "Not able to enter Dailed To");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "DailedTo"));
			flag=false;
		}		
		 return flag; 
	}
	
	public static boolean setNumberOfEvaluations(WebDriver driver,String Min,String Max) throws Exception
	{
		 Boolean flag=true;	 
		 Thread.sleep(3000);
		 driver.switchTo().defaultContent();
		 Thread.sleep(1000);
		driver.switchTo().frame(2);
		Thread.sleep(1000);
		if (driver.findElements(By.xpath("//span[@id='dfd_MS_catAD__ctl6_FromToNumberOfEvaluations']/table/tbody/tr[1]/td[2]/input[@id='dfd_MS_catAD__ctl6_FromToNumberOfEvaluations_from']")).size()!=0)
		{
			driver.findElement(By.xpath("//span[@id='dfd_MS_catAD__ctl6_FromToNumberOfEvaluations']/table/tbody/tr[1]/td[2]/input[@id='dfd_MS_catAD__ctl6_FromToNumberOfEvaluations_from']")).sendKeys(Min);
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Eval"));
		}
		else
		{
			extent.log(LogStatus.FAIL, "Not able to enter Minimum Number Of Evaluations");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Eval"));
			flag=false;
		}
		if (driver.findElements(By.xpath("//span[@id='dfd_MS_catAD__ctl6_FromToNumberOfEvaluations']/table/tbody/tr[1]/td[4]/input[@id='dfd_MS_catAD__ctl6_FromToNumberOfEvaluations_to']")).size()!=0)
		{
			driver.findElement(By.xpath("//span[@id='dfd_MS_catAD__ctl6_FromToNumberOfEvaluations']/table/tbody/tr[1]/td[4]/input[@id='dfd_MS_catAD__ctl6_FromToNumberOfEvaluations_to']")).sendKeys(Max);
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Eval"));
		}
		else
		{
			extent.log(LogStatus.FAIL, "Not able to enter Maximum Number Of Evaluations");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Eval"));
			flag=false;
		}
		 return flag; 
	}
	
	public static boolean setSegmentNumberOfHolds(WebDriver driver,String Min,String Max) throws Exception
	{
		 Boolean flag=true;	 
		 Thread.sleep(3000);
		 driver.switchTo().defaultContent();
		 Thread.sleep(1000);
		driver.switchTo().frame(2);
		Thread.sleep(1000);
		if (driver.findElements(By.xpath("//span[@id='dfd_MS_catAD__ctl9_FromToSegmentNumberOfHolds']/table/tbody/tr[1]/td[2]/input[@id='dfd_MS_catAD__ctl9_FromToSegmentNumberOfHolds_from']")).size()!=0)
		{
			driver.findElement(By.xpath("//span[@id='dfd_MS_catAD__ctl9_FromToSegmentNumberOfHolds']/table/tbody/tr[1]/td[2]/input[@id='dfd_MS_catAD__ctl9_FromToSegmentNumberOfHolds_from']")).sendKeys(Min);
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "SegmentNoHolds"));
		}
		else
		{
			extent.log(LogStatus.FAIL, "Not able to enter Minimum Segment Number Of Holds");
			flag=false;
		}
		if (driver.findElements(By.xpath("//span[@id='dfd_MS_catAD__ctl9_FromToSegmentNumberOfHolds']/table/tbody/tr[1]/td[4]/input[@id='dfd_MS_catAD__ctl9_FromToSegmentNumberOfHolds_to']")).size()!=0)
		{
			driver.findElement(By.xpath("//span[@id='dfd_MS_catAD__ctl9_FromToSegmentNumberOfHolds']/table/tbody/tr[1]/td[4]/input[@id='dfd_MS_catAD__ctl9_FromToSegmentNumberOfHolds_to']")).sendKeys(Max);
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "SegmentNoHolds"));
		}
		else
		{
			extent.log(LogStatus.FAIL, "Not able to enter Maximum Segment Number Of Holds");
			flag=false;
		}
		 return flag; 
	} 
	
	public static boolean setQMSearchContactDataDuration(WebDriver driver,String Min,String Max) throws Exception
	{
		 Boolean flag=true;	 
		Thread.sleep(8000);
		driver.switchTo().frame(2);
		if (driver.findElements(By.xpath("//span[@id='dfd_MS_catCD__ctl2_FromTominutes']/table/tbody/tr[1]/td[2]/input[@id='dfd_MS_catCD__ctl2_FromTominutes_from']")).size()!=0)
		{
			driver.findElement(By.xpath("//span[@id='dfd_MS_catCD__ctl2_FromTominutes']/table/tbody/tr[1]/td[2]/input[@id='dfd_MS_catCD__ctl2_FromTominutes_from']")).clear();
			driver.findElement(By.xpath("//span[@id='dfd_MS_catCD__ctl2_FromTominutes']/table/tbody/tr[1]/td[2]/input[@id='dfd_MS_catCD__ctl2_FromTominutes_from']")).sendKeys(Min);
			extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QMCallDuration"));
		}
		else
		{
			extent.log(LogStatus.FAIL, "Not able to enter Contact Data Minium duration");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "QMCallDuration"));
		}
		if (driver.findElements(By.xpath("//span[@id='dfd_MS_catCD__ctl2_FromTominutes']/table/tbody/tr[1]/td[4]/input[@id='dfd_MS_catCD__ctl2_FromTominutes_to']")).size()!=0)
		{
			driver.findElement(By.xpath("//span[@id='dfd_MS_catCD__ctl2_FromTominutes']/table/tbody/tr[1]/td[4]/input[@id='dfd_MS_catCD__ctl2_FromTominutes_to']")).clear();
			driver.findElement(By.xpath("//span[@id='dfd_MS_catCD__ctl2_FromTominutes']/table/tbody/tr[1]/td[4]/input[@id='dfd_MS_catCD__ctl2_FromTominutes_to']")).sendKeys(Max);
			extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QMCallDuration"));
		}
		else
		{
			extent.log(LogStatus.FAIL, "Not able to enter Contact Data Maximum duration");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "QMCallDuration"));
		}
		 return flag; 
	}
	
	public static boolean setQMSearchNumberOfHolds(WebDriver driver,String Min,String Max) throws Exception
	{
		 Boolean flag=true;	 
		 Thread.sleep(3000);
		 driver.switchTo().defaultContent();
		 Thread.sleep(3000);
		driver.switchTo().frame(2);
		if (driver.findElements(By.xpath("//span[@id='dfd_MS_catAD__ctl7_FromToNumberOfHolds']/table/tbody/tr[1]/td[2]/input[@id='dfd_MS_catAD__ctl7_FromToNumberOfHolds_from']")).size()!=0)
		{
			driver.findElement(By.xpath("//span[@id='dfd_MS_catAD__ctl7_FromToNumberOfHolds']/table/tbody/tr[1]/td[2]/input[@id='dfd_MS_catAD__ctl7_FromToNumberOfHolds_from']")).sendKeys(Min);
		}
		else
		{
			extent.log(LogStatus.FAIL, "Not able to enter Minimum Number Of Holds");
		}
		if (driver.findElements(By.xpath("//span[@id='dfd_MS_catAD__ctl7_FromToNumberOfHolds']/table/tbody/tr[1]/td[4]/input[@id='dfd_MS_catAD__ctl7_FromToNumberOfHolds_to']")).size()!=0)
		{
			driver.findElement(By.xpath("//span[@id='dfd_MS_catAD__ctl7_FromToNumberOfHolds']/table/tbody/tr[1]/td[4]/input[@id='dfd_MS_catAD__ctl7_FromToNumberOfHolds_to']")).sendKeys(Max);
		}
		else
		{
			extent.log(LogStatus.FAIL, "Not able to enter Maximum Number Of Holds");
		}
		 return flag; 
	}
	
	public static boolean setNumberOfHolds(WebDriver driver,String Min,String Max) throws Exception
	{
		 Boolean flag=true;	 
		 Thread.sleep(3000);
		 driver.switchTo().defaultContent();
		 Thread.sleep(3000);
		driver.switchTo().frame(2);
		Thread.sleep(3000);
		if (driver.findElements(By.xpath("//span[@id='dfd_MS_catAD__ctl8_FromToNumberOfHolds']/table/tbody/tr[1]/td[2]/input[@id='dfd_MS_catAD__ctl8_FromToNumberOfHolds_from']")).size()!=0)
		{
			driver.findElement(By.xpath("//span[@id='dfd_MS_catAD__ctl8_FromToNumberOfHolds']/table/tbody/tr[1]/td[2]/input[@id='dfd_MS_catAD__ctl8_FromToNumberOfHolds_from']")).sendKeys(Min);
		}
		else
		{
			extent.log(LogStatus.FAIL, "Not able to enter Minimum Number Of Holds");
		}
		if (driver.findElements(By.xpath("//span[@id='dfd_MS_catAD__ctl8_FromToNumberOfHolds']/table/tbody/tr[1]/td[4]/input[@id='dfd_MS_catAD__ctl8_FromToNumberOfHolds_to']")).size()!=0)
		{
			driver.findElement(By.xpath("//span[@id='dfd_MS_catAD__ctl8_FromToNumberOfHolds']/table/tbody/tr[1]/td[4]/input[@id='dfd_MS_catAD__ctl8_FromToNumberOfHolds_to']")).sendKeys(Max);
		}
		else
		{
			extent.log(LogStatus.FAIL, "Not able to enter Maximum Number Of Holds");
		}
		 return flag; 
	} 
	
	public static boolean selectQMSearchContactData(WebDriver driver) throws Exception
	{
		 Boolean flag=true;
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Groups.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Groups.png");				
		}
		else
		{
			extent.log(LogStatus.INFO,"Not able to collapse Groups");
			//return flag=false;
		}
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png");				
		}
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Date.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Date.png");				
		}
		else
		{
			extent.log(LogStatus.INFO,"Not able to collapse Date");
			//return flag=false;
		}
		Thread.sleep(1000); 
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png");				
		}
		Thread.sleep(1000);	
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ContactExpand")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ContactExpand");				
		}		
		Thread.sleep(1000); 
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png");				
		}
		 return flag; 
	}
	
	
	public static boolean expandQMSearchAdvancedData(WebDriver driver) throws Exception
	{
		 Boolean flag=true;
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Groups.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Groups.png");				
		}
		else
		{
			extent.log(LogStatus.INFO,"Not able to collapse Groups");
			//return flag=false;
		}
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png");				
		}
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Date.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Date.png");				
		}
		else
		{
			extent.log(LogStatus.INFO,"Not able to collapse Date");
			//return flag=false;
		}
		Thread.sleep(1000); 
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png");				
		}
		Thread.sleep(1000);
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Contact.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Contact.png");				
		}
		else
		{
			extent.log(LogStatus.INFO,"Not able to collapse Contacts");
			//return flag=false;
		}
		Thread.sleep(1000); 
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png");				
		}
		Thread.sleep(1000);
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Advanced.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Advanced.png");				
		}
		else
		{
			extent.log(LogStatus.INFO,"Not able to expand Advanced");
			flag=false;
		}
		Thread.sleep(1000); 
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png");				
		}
		Thread.sleep(3000);
		 
		 return flag; 
	}
	
	
	public static boolean expandContactsAdvancedData(WebDriver driver) throws Exception
	{
		 Boolean flag=true;
		
		/*if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Date.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Date.png");				
		}*/
		
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\date.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\date.png");				
		}
		else
		{
			extent.log(LogStatus.INFO,"Not able to collapse Date");
			//return flag=false;
		}
		Thread.sleep(1000); 
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Impact360_Contacts.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Impact360_Contacts.png");				
		}
		Thread.sleep(1000);
		/*if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Contact.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Contact.png");				
		}*/
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\contact.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\contact.png");				
		}
		
		else
		{
			extent.log(LogStatus.INFO,"Not able to collapse Contacts");
			//return flag=false;
		}
		Thread.sleep(1000); 
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Impact360_Contacts.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Impact360_Contacts.png");				
		}
		Thread.sleep(1000);
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Advanced.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Advanced.png");				
		}
		/*if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\advanced.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\advanced.png");				
		}*/
		else
		{
			extent.log(LogStatus.INFO,"Not able to expand Advanced");
			flag=false;
		}
		Thread.sleep(1000); 
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Impact360_Contacts.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Impact360_Contacts.png");				
		}
		Thread.sleep(3000);
		 
		 return flag; 
	}
	
	
	
	public static boolean verifyContactsStartTime(WebDriver driver) throws Exception
	{
		Thread.sleep(8000);
		
	    Boolean flag=false;
	    if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_NoContacts.png")==null || sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_NoContacts1.png")==null)
		{
			Thread.sleep(5000);
			driver.switchTo().defaultContent();
			/*driver.switchTo().frame(0);
		    driver.switchTo().frame("Grid");*/	
			Utilities.switchFrame(driver,"FR_GRID");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"Grid");
			Thread.sleep(2000);
			int rcCall=driver.findElements(By.xpath("//table[@id='POG1']/tbody/tr")).size();
			System.out.println("callRC:"+rcCall);			
			if (rcCall>1)
			{
				extent.log(LogStatus.PASS, "Contact results are displayed successfully");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QMCall"));
				flag=true;			
			}
			else
			{
				extent.log(LogStatus.WARNING,"Contacts results were not displayed");
				extent.log(LogStatus.WARNING, "", "", Utilities.captureScreenShot(driver, "QMCall"));
				flag =false;
			}				
		}
		else
		{
			extent.log(LogStatus.WARNING, "Message : No contacts were found. is diplayed ");
			extent.log(LogStatus.WARNING, "", "", Utilities.captureScreenShot(driver, "QMCall"));	
			flag=false;
		}
		
		return flag; 
	}
	
	public static boolean setTextInRemarkBy(WebDriver driver,String RemarkByText) throws Exception
	{
		boolean flag=true;
		Thread.sleep(3000);
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);			
		driver.switchTo().frame("FR_REMARK");
		
		if (driver.findElements(By.xpath("//table[@id='remarkMainTable']/tbody/tr[1]/td/a/img[@id='CollapseImage']")).size()!=0)
		{
			driver.findElement(By.xpath("//table[@id='remarkMainTable']/tbody/tr[1]/td/a/img[@id='CollapseImage']")).click();
		}
		else
		{
			extent.log(LogStatus.FAIL,"Not able to click/expand Remark By field");
			return flag=false;
		}
		Thread.sleep(2000);
		if (driver.findElements(By.xpath("//table[@id='remarkMainTable']/tbody/tr[2]/td/textarea[@id='remarkText']")).size()!=0)
		{
			driver.findElement(By.xpath("//table[@id='remarkMainTable']/tbody/tr[2]/td/textarea[@id='remarkText']")).clear();
			driver.findElement(By.xpath("//table[@id='remarkMainTable']/tbody/tr[2]/td/textarea[@id='remarkText']")).sendKeys(RemarkByText);
			extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QM05_07_14_Playback_EvalForm_RemarksBy"));
			Thread.sleep(4000);
		}
		else
		{
			extent.log(LogStatus.FAIL,"Remark By field is not displayed");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "QM05_07_14_Playback_EvalForm_RemarksBy"));
			return flag=false;
		}
		if (driver.findElement(By.xpath("//table[@id='remarkMainTable']/tbody/tr[2]/td/textarea[@id='remarkText']")).getText().contains(RemarkByText))
		{
			extent.log(LogStatus.PASS,"Remark By:"+RemarkByText+" entered successfully");
		}
		else
		{
			extent.log(LogStatus.FAIL,"Remark By:"+RemarkByText+" NOT able to enter");
			return flag=false;
		}
		
		return flag;
	}
	
	public static boolean selectItemFromEvalForm(WebDriver driver,String FormName) throws Exception
	{
		
		boolean flag=false;
		Thread.sleep(3000);
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);			
		driver.switchTo().frame("FR_EVALUATION");
		 
		 WebElement sel = driver.findElement(By.id(lstEvalForm));
		 List<WebElement> lists = sel.findElements(By.tagName("option"));
		 if (lists.size()!=0)
		 {			 	
			 System.out.println("Evaluation Form items count :"+lists.size());
		     for(WebElement element: lists)  
		     {
		         String lstValues = element.getText();
		         System.out.println("valueApp:"+lstValues);
		         System.out.println("value:"+FormName);
		         if (lstValues.contains(FormName))
		         {
		        	element.click();
		        	extent.log(LogStatus.PASS,"Evaluation Form value:"+FormName+" selected");
		        	Thread.sleep(5000);
		        	flag=true;
		        	break;
		         }
		         //extent.log(LogStatus.INFO,"Evaluation Form value:"+lstValues);
		     }
		 }
		 else
		 {
			 extent.log(LogStatus.FAIL,"No items/Not able to select option from Evaluation Form");
			 return flag=false;
		 }	
		 if (flag==false)
		 {
			 extent.log(LogStatus.INFO,"Not able to select option:"+FormName+" from Evaluation Form");			 
		 }
		 return flag;
		
		
	}
	
	public static boolean getItemsFromEvalFormListbox(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		Thread.sleep(3000);
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);			
		driver.switchTo().frame("FR_EVALUATION");
		 
		 WebElement sel = driver.findElement(By.id(lstEvalForm));
		 List<WebElement> lists = sel.findElements(By.tagName("option"));
		 if (lists.size()!=0)
		 {
			 extent.log(LogStatus.PASS,"Evaluation Form items count :"+lists.size());			
		     for(WebElement element: lists)  
		     {
		         String lstValues = element.getText();
		         extent.log(LogStatus.INFO,"Evaluation Form value:"+lstValues);
		     }
		 }
		 else
		 {
			 extent.log(LogStatus.FAIL,"No items were displayed in the Evaluation Form");
			 return flag=false;
		 }	
		 return flag;
		
	}
	
	public static boolean getvaluefromform(WebDriver driver,String form) throws Exception
	{		
		boolean flag=true;
		Thread.sleep(3000);
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);			
		driver.switchTo().frame("FR_EVALUATION");
		 
		 WebElement sel = driver.findElement(By.id(lstEvalForm));
		 List<WebElement> lists = sel.findElements(By.tagName("option"));
		 if (lists.size()!=0)
		 {
			 extent.log(LogStatus.PASS,"Evaluation Form items count :"+lists.size());			
		     for(WebElement element: lists)  
		     {
		         String lstValues = element.getText();
		         System.out.println("form name is:"+lstValues);
		         if(lstValues.equalsIgnoreCase(form))
		         {
		        	 element.click();
		        	 extent.log(LogStatus.INFO,"Form is already evaluated");
		        	 flag=true;
		         }
		        
		        
		     }
		 }
		 else
		 {
			 extent.log(LogStatus.FAIL,"No items were displayed in the Evaluation Form");
			 flag=false;
		 }	
		 return flag;
		
	}
	
	
	public static boolean setDays(WebDriver driver,String days)
	{
		boolean flag=false;
		try
		{
			Thread.sleep(1000);
			driver.switchTo().frame(2);
			Thread.sleep(1000);
			By txtdays=By.xpath(txtfromdays);
			Utilities.waitForPageLoad(driver,txtdays);
			if(driver.findElements(txtdays).size()!=0)
			{
				driver.findElement(txtdays).clear();
				driver.findElement(txtdays).sendKeys(days);
				extent.log(LogStatus.PASS,"no of days:"+days+"is entered in text box successfully");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"not able to enter days in the text box");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean  verifycriteria(WebDriver driver,String  criteria)
	{
		boolean flag=false;
		try
		{
			driver.switchTo().defaultContent();
			Utilities.switchFrame(driver,"FR_GRID");
			Thread.sleep(1000);
			Utilities.switchFrame(driver,"Grid");
			Thread.sleep(1000);
			/*By txtcriteria=By.xpath(headertext);
			Utilities.waitForPageLoad(driver,txtcriteria);
			if(driver.findElements(txtcriteria).size()!=0)
			{
				String criteriatext=driver.findElement(txtcriteria).getText();
				System.out.println("text is:" + criteriatext);
				if(criteriatext.equalsIgnoreCase(criteria))
				{
					extent.log(LogStatus.PASS,"search criteria:" +criteria+ "is present on screen");
					extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "serachscreen"));
					flag=true;
				}
			}*/
			
			List<WebElement> li=driver.findElements(By.xpath("//div[@id='HeaderDiv']//table//tbody//tr//td"));
			System.out.println("size is:" +li.size());
			for(WebElement elt:li)
			{
				String text=elt.getText();
				System.out.println("text is:" +text);
				if(text.equalsIgnoreCase(criteria))
				{
					extent.log(LogStatus.PASS,"search criteria:" +criteria+ "is present on screen");
					extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "serachscreen"));
					flag=true;
					break;
				}
			}
			/*else
			{
				extent.log(LogStatus.FAIL,"search criteria:" +criteria+ "is  not present on screen");
				flag=false;
			}*/
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean verifydataexist(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			driver.switchTo().defaultContent();
			Utilities.switchFrame(driver,"FR_GRID");
			Utilities.switchFrame(driver,"Grid");
			if(driver.findElements(By.xpath("//div[@id='divNormalDir']//table[@id='POG1']//tbody//tr[2]//td")).size()!=0)
			{
				extent.log(LogStatus.PASS, "data exist for the given no of holds");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"no data exist for given no of holds");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
}
