package ScreenObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class AttributesScreen {
	
	public static ExtentReports extent = ExtentReports.get(AttributesScreen.class);
	public static String btncreate="//button[@id='toolbar_ATTRIBUTE_ADD_ACTIONLabel']";
	public static String txtname="//input[@id='attrName_0']";
	public static String txtdesc="//textarea[@id='attrDescription_0']";
	public static String btnsave="//button[@id='toolbar_ATTRIBUTE_CREATE_NEW_ACTIONLabel']";
	public static String btndel="//button[@id='toolbar_DELETE_ATTRIBUTELabel']";
	
	
	public static boolean clickcreate(WebDriver driver)
	{
		
		boolean flag=false;
		try
		{
			//Utilities.selectRightPaneView(driver);
			By createbtn=By.xpath(btncreate);
			Utilities.waitForPageLoad(driver,createbtn);
			if(driver.findElements(createbtn).size()!=0)
			{
				driver.findElement(createbtn).click();
				extent.log(LogStatus.PASS,"click on create button is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"not able to click on create button");
				flag=false;
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setName(WebDriver driver,String name)
	{
		boolean flag=false;
		try
		{
			//Utilities.selectRightPaneView(driver);
			By nametxt=By.xpath(txtname);
			Utilities.waitForPageLoad(driver,nametxt);
			if(driver.findElements(nametxt).size()!=0)
			{
				driver.findElement(nametxt).sendKeys(name);
				extent.log(LogStatus.PASS,"value"+name+"is entered sucessfully");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"value is not enetered");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean setDesc(WebDriver driver,String description)
	{
		boolean flag=false;
		try
		{
			//Utilities.selectRightPaneView(driver);
			By desctxt=By.xpath(txtdesc);
			Utilities.waitForPageLoad(driver,desctxt);
			if(driver.findElements(desctxt).size()!=0)
			{
				driver.findElement(desctxt).sendKeys(description);
				extent.log(LogStatus.PASS,"value"+description+"is entered sucessfully");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"value is not enetered");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clicksave(WebDriver driver)
	{
		
		boolean flag=false;
		try
		{
			//Utilities.selectRightPaneView(driver);
			By savebtn=By.xpath(btnsave);
			Utilities.waitForPageLoad(driver,savebtn);
			if(driver.findElements(savebtn).size()!=0)
			{
				driver.findElement(savebtn).click();
				extent.log(LogStatus.PASS,"click on save button is sucessfull");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "AttributePage"));
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"not able to click on save button");
				flag=false;
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean Attributeexist(WebDriver driver,String aname)
	{
		boolean flag=false;
		
		System.out.println("aname is" + aname);
			List<WebElement> li=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']//tr"));
			System.out.println("size of list is:"+ li.size());
			for(WebElement elt:li)
			{
				//System.out.println(elt.findElement(By.tagName("th")).getAttribute("innerText"));
				String name=elt.findElement(By.tagName("th")).getAttribute("innerText");
				System.out.println("name is::::"+name);
				//System.out.println("aname is" + aname);
				if(name.contains(aname))
				{
					System.out.println("name in if"+name);
					extent.log(LogStatus.PASS,"Attribute:" + aname+ "already exist");
					flag=true;
					break;
					
				}
				else
				{
					//extent.log(LogStatus.PASS,"Attribute:" + aname+ "does not exist");
					flag=false;
				}
			}
			
		return flag;
	}
	
	
	public static boolean selectAttribute(WebDriver driver,String aname) throws Exception
	{
		boolean flag=false;
		
		System.out.println("aname is" + aname);
			List<WebElement> li=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']//tr"));
			System.out.println("size of list is:"+ li.size());
			for(WebElement elt:li)
			{
				//System.out.println(elt.findElement(By.tagName("th")).getAttribute("innerText"));
				String name=elt.findElement(By.tagName("th")).getAttribute("innerText");
				System.out.println("name is::::"+name);
				//System.out.println("aname is" + aname);
				if(name.contains(aname))
				{
					Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
					System.out.println("name in if"+name);
					elt.findElement(By.tagName("th")).click();
					extent.log(LogStatus.PASS,"Attribute:" + aname+ "is selected");
					flag=true;
					break;
					
				}
				else
				{
					//extent.log(LogStatus.FAIL,"Attribute is not selected");
					flag=false;
				}
			}
			
		return flag;
	}
	
	
	public static boolean clickdelete(WebDriver driver)
	{
		
		boolean flag=false;
		try
		{
			//Utilities.selectRightPaneView(driver);
			By delbtn=By.xpath(btndel);
			Utilities.waitForPageLoad(driver,delbtn);
			if(driver.findElements(delbtn).size()!=0)
			{
				driver.findElement(delbtn).click();
				Thread.sleep(3000);
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Delete_OK.png");
				extent.log(LogStatus.PASS,"click on delete button is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"not able to click on delete button");
				flag=false;
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	
}

