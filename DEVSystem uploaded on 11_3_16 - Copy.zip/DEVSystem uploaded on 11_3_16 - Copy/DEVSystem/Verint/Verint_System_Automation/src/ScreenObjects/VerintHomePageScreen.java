package ScreenObjects;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.LogStatus;

import Utilities.Utilities;
import com.relevantcodes.extentreports.ExtentReports;


public class VerintHomePageScreen {
	
	public static ExtentReports extent = ExtentReports.get(VerintHomePageScreen.class);	
	public static Screen sobj = new Screen ();
	public static String homePage="My Home";
	public static String txtPassword="password";
	public static String btnLogin="loginToolbar_LOGINLabel";
	//public static String menuRoleSetup="//table[@class='taskGroup']/tbody/tr[2]/td[2]/p[@id='3_BBM_GEN_ROLES_spn_id']";
	//public static String menuRoleSetup="//div[@id='ds3']/table/tbody/tr[2]/td/div/div/table/tbody/tr/td[1]/table[1]/tbody/tr[2]/td[2]/p[@id='3_BBM_GEN_ROLES_spn_id']";
	public static String menuRoleSetup="//DIV[@id='ds3']/TABLE/TBODY/TR[2]/TD/DIV/DIV";
	public static String menuDPA="//table[@class='taskGroup']/tbody/tr[2]/td[2]/p[@id='FOCUS_spn_id']";
	public static String menuQualityMonitoring="//p[@id='QM_spn_id']";
	public static String dpamenu="//p[@id='FOCUS_spn_id']";
	//public static String menuDataSources="//table[@class='taskGroup']/tbody/tr[2]/td[2]/p[@id='2_BBM_GEN_DATASOURCES_spn_id']";
	//public static String menuDataSources="//div[@id='systemNavigation']/div[3]/table/tbody/tr[2]/td/div/div/table/tbody/tr[1]/td[3]/table[4]/tbody/tr[2]/td[2]/p[@id='2_BBM_GEN_DATASOURCES_spn_id']";
	public static String menuDataSources="//DIV[@id='ds1']/TABLE/TBODY/TR[2]/TD/DIV/DIV/TABLE/TBODY/TR/TD[3]/TABLE[4]/TBODY/TR[2]/TD[2]/P[@ID='2_BBM_GEN_DATASOURCES_spn_id']";
	//public static String menuDataSources="//table/tbody/tr[1]/td[3]/table[4]/tbody/tr[2]/td[2]/p[@id='2_BBM_GEN_DATASOURCES_spn_id']";
	//public static String menuProfiles="//table[@class='taskGroup']/tbody/tr[2]/td[2]/p[@id='3_BBM_PEOPLE_PROFILE_spn_id']";
	public static String menuProfiles="//div[@id='ds3']/table/tbody/tr[2]/td/div/div/table/tbody/tr/td/table[2]/tbody/tr[2]/td[2]/p[@id='3_BBM_PEOPLE_PROFILE_spn_id']";
	//public static String menuAccessRights="//table[@class='taskGroup']/tbody/tr[5]/td[2]/p[@id='3_BBM_PEOPLE_ROLES_spn_id']";
	public static String menuAccessRights="//p[@id='3_BBM_PEOPLE_ROLES_spn_id']";
	//public static String menuAccessRights="//div[@id='ds3']/table/tbody/tr[2]/td/div/div/table/tbody/tr/td/table[2]//tbody/tr[4']/td[2]/p[@id='3_BBM_PEOPLE_ROLES_spn_id']";;
	public static String menuOrgSettings="//p[@id='3_BBM_ORG_GEN_SETTINGS_spn_id']";
	public static String menuRecordingRulesSettings="//p[@id='RULE_SETTING_spn_id']";
	public static String menuCompaignSettings="//p[@id='CAMPAIGNS_SETTINGS_CAMPAIGN_spn_id']";
	public static String menuManageCoaching="//table[@class='taskGroup']/tbody/tr[2]/td[2]/p[@id='3_MANAGE_COACHING_spn_id']";
	public static String verintImpactLogo="//span[@id='utilityPanePC_BPLOGOWrapper']";
	public static String menuWorkQueuesSettings="//table[@class='taskGroup']/tbody/tr[2]/td[2]/p[@id='3_BBM_ORG_WORKLOADS_QUEUES_spn_id']";
	public static String menuWorkQueueGroupMapping="//table[@class='taskGroup']/tbody/tr[4]/td[2]/p[@id='3_BBM_ORG_WORKLOADS_QUEUES_MAPPING_spn_id']";
	public static String menuIntegrationServers="//table[@class='taskGroup']/tbody/tr[2]/td[2]/p[@id='3_ISERVER_LIST_spn_id']";
	public static String menuActiviteis="//table[@class='taskGroup']/tbody/tr[3]/td[2]/p[@id='3_BBM_ORG_ACT_ACTIVITIES_spn_id']";
	//public static String menuInstances="//table[@class='taskGroup']/tbody/tr[2]/td[2]/p[@id='3_CORE_REPORTS_INSTANCES_spn_id']";
	public static String menuInstances="//p[@id='3_CORE_REPORTS_INSTANCES_spn_id']";
	public static String menuTimeOffPool="//table[@class='taskGroup']/tbody/tr[5]/td[2]/p[@id='3_RM_ORG_REQUEST_PROCESSING_AVAILABLETIMEOFF_spn_id']";
	public static String menuTimeOff="//table[@class='taskGroup']/tbody/tr[7]/td[2]/p[@id='PEOPLE_TIMEOFF_spn_id']";
	public static String menuMyRequests="//table[@class='taskGroup']/tbody/tr[2]/td[2]/p[@id='3_RM_MYSCHEDULE_MYREQUESTS_spn_id']";
	public static String menuEmpRequests="//table[@class='taskGroup']/tbody/tr[2]/td[2]/p[@id='2_RM_AGENTS_REQUESTS_spn_id']";
	public static String menuAutoProcessing="//table[@class='taskGroup']/tbody/tr[6]/td[2]/p[@id='3_RM_ORG_REQUEST_PROCESSING_AUTOPROCESSING_spn_id']";
	public static String parentHandle="";
	
	public static boolean selectMenuItem(WebDriver driver,String linkText,String menuItem) throws Exception
	{
		boolean flag=false;
		//String parentHandle="";
		WebElement tabName = (new WebDriverWait(driver,20)).until(ExpectedConditions.elementToBeClickable(By.linkText(linkText)));
		//WebElement tabName = driver.findElement(By.linkText(linkText));
		Actions action = new Actions(driver);
		action.moveToElement(tabName).build().perform();
		Thread.sleep(2000);
		
		if (menuItem.contains("Assignment Manager"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\menu_AssignmentManager.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\menu_AssignmentManager.png");	
				extent.log(LogStatus.INFO, "Assignment Manager menu item is selected from Organization Management tab");
				flag=true;
			}			
			Thread.sleep(1000);
			//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);	
		}
		
		
		if (menuItem.contains("Rotation"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\menu_rotations.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\menu_rotations.png");	
				extent.log(LogStatus.INFO, "Rotations menu item is selected from Organization Management tab");
				flag=true;
			}			
			Thread.sleep(1000);
			//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);	
		}


			if (menuItem.contains("OverTime"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_overtime.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_overtime.png");	
				extent.log(LogStatus.INFO, "Overtime menu item is selected from Organization Management tab");
				flag=true;
			}			
			Thread.sleep(1000);
			//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);	
		}
		if (menuItem.equals("TimeOff_Employee_Requests"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_EmployeeRequest.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_EmployeeRequest.png");	
				extent.log(LogStatus.INFO, "Employee Request menu item is selected from Request management tab");
				System.out.println("******************");
				flag=true;
			}			
			Thread.sleep(1000);
			/*Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);*/
			
			
			/*driver.findElement(By.xpath(menuEmpRequests)).click(); //click on Role Setup menu item
			extent.log(LogStatus.INFO, "My Requests menu item is selected from System Management tab");
			Thread.sleep(5000);*/
		}


		if (menuItem.equals("TimeOff_Pools"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\menu_timeoff_pools.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\menu_timeoff_pools.png");	
				extent.log(LogStatus.INFO, "TimeOff_Pool menu item is selected from Organization management tab");
				System.out.println("******************");
				flag=true;
			}			
			Thread.sleep(1000);
			/*Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);*/
			
			
			/*driver.findElement(By.xpath(menuEmpRequests)).click(); //click on Role Setup menu item
			extent.log(LogStatus.INFO, "My Requests menu item is selected from System Management tab");
			Thread.sleep(5000);*/
		}	
		
		
		if (menuItem.contains("Tracking_schedules"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Tracking_Schedules.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Tracking_Schedules.png");	
				extent.log(LogStatus.INFO, "Schedule menu item is selected from Tracking tab");
				flag=true;
			}			
			Thread.sleep(1000);
			//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);	
		}
		if (menuItem.contains("Tracking_TimeSummary"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Tracking_TimeSummary.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Tracking_TimeSummary.png");	
				extent.log(LogStatus.INFO, "Time Summary menu item is selected from Tracking tab");
				flag=true;
			}			
			Thread.sleep(1000);
			//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);	
		}		
		
		
		if (menuItem.equals("My Requests_Agent"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_MyRequests.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_MyRequests.png");	
				extent.log(LogStatus.INFO, "My Requests menu item is selected from Reports tab");
				flag=true;
			}			
			Thread.sleep(1000);
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);
			
			
			/*driver.findElement(By.xpath(menuMyRequests)).click(); //click on Role Setup menu item
			extent.log(LogStatus.INFO, "My Requests menu item is selected from System Management tab");
			Thread.sleep(5000);*/
		}
		
		
		if (menuItem.contains("Shifts"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Shifts.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Shifts.png");	
				extent.log(LogStatus.INFO, "Shifts menu item is selected from Organization Management tab");
				flag=true;
			}			
			Thread.sleep(1000);
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);			
		}
		
		
		if (menuItem.contains("Work Rules"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_workRules.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_workRules.png");	
				extent.log(LogStatus.INFO, "work Pattern menu item is selected from user management tab");
				flag=true;
			}			
			Thread.sleep(1000);
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);	
		}
		
		
		if (menuItem.contains("Work Pattern"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_WorkPattern.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_WorkPattern.png");	
				extent.log(LogStatus.INFO, "work Pattern menu item is selected from Organization tab");
				flag=true;
			}			
			Thread.sleep(1000);
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);	
		}
		
		
		if (menuItem.contains("Instances"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Instances.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Instances.png");	
				extent.log(LogStatus.INFO, "Instances menu item is selected from Organization Management tab");
				flag=true;
			}			
			Thread.sleep(1000);
			//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);	
		}
		
		
		if (menuItem.contains("Adherence Mapping"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Adherence_Mapping.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Adherence_Mapping.png");	
				extent.log(LogStatus.INFO, "Adherence mapping menu item is selected from Organization Management tab");
				flag=true;
			}			
			Thread.sleep(1000);
			//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);	
		}
		if (menuItem.contains("Pulse"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Pulse.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Pulse.png");	
				extent.log(LogStatus.INFO, "Pulse menu item is selected");
				flag=true;
			}			
			Thread.sleep(1000);
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);	
		}	
		
		
		if (menuItem.contains("Organization_AutoProcessing"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_org_AutoProcessing.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_org_AutoProcessing.png");	
				extent.log(LogStatus.INFO, "Auto Processing menu item is selected from Organization Management tab");
				flag=true;
			}			
			Thread.sleep(1000);
			//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);	
		}
		
		
		if (menuItem.contains("Organization_validation"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_org_validation.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_org_validation.png");	
				extent.log(LogStatus.INFO, "validation menu item is selected from Organization Management tab");
				flag=true;
			}			
			Thread.sleep(1000);
			//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);	
		}
		
		if (menuItem.contains("Adherence"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Adherence.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Adherence.png");	
				extent.log(LogStatus.INFO, "Adherence  menu item is selected from Tracking tab");
				flag=true;
			}			
			Thread.sleep(1000);
			//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);	
		}
		
		if (menuItem.contains("Custom Attributes"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_custom_attributes.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_custom_attributes.png");	
				extent.log(LogStatus.INFO, "custom attribute menu item is selected from system Management tab");
				flag=true;
			}			
			Thread.sleep(1000);
			//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);	
		}
		
		
		
		if (menuItem.contains("Schedule Preference"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_schedulePreference.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_schedulePreference.png");	
				extent.log(LogStatus.INFO, "Schedule Preference menu item is selected from My home tab");
				flag=true;
			}			
			Thread.sleep(1000);
			//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);	
		}
		
		
		if (menuItem.contains("Tracking_Organization"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_tracking_org.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_tracking_org.png");	
				extent.log(LogStatus.INFO, "organization menu item is selected from Tracking tab");
				flag=true;
			}			
			Thread.sleep(1000);
			//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);	
		}
		
		if (menuItem.contains("Interactions Contacts"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\menu_InteractionsContacts.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\menu_InteractionsContacts.png");	
				extent.log(LogStatus.INFO, "Contacts menu item is selected from Interactions tab");
				flag=true;
			}			
			Thread.sleep(1000);
			//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);	
		}
		
		if (menuItem.contains("Calendar"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\calendar.png") != null)
			{
				try
				{
					for(int i=0;1<10;i++)
					{
						sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\calendar.png");
						Thread.sleep(3000);
						System.out.println(" calendar page is getting displayed.");
						if(driver.findElements(By.linkText("Calendar")).size()!=0)
						{
							System.out.println(" calendar page is getting displayed.");
							break;
						}
					}
				}
				catch (Exception e) {
					// TODO: handle exception
				}
				
				extent.log(LogStatus.INFO, "Calendar menu item is selected from Forecasting tab");
				flag=true;
			}			
			Thread.sleep(1000);
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);	
		}
		
		if (menuItem.contains("Forecast"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_forecast.png") != null)
			{
				try
				{
					for(int i=0;i<15;i++)
					{
						sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_forecast.png");
						System.out.println("in service goals");
						if(driver.findElements(By.linkText("Service Goals")).size()!=0)
				    	{
				    		
				    		break;
				    	}
					}
					
					
				}
				catch (Exception e) {
					// TODO: handle exception
				}
				
				extent.log(LogStatus.INFO, "Forecast menu item is selected from Forecasting tab");
				flag=true;
			}			
			Thread.sleep(2000);
			/*Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);	*/
		}
		
		
		if (menuItem.contains("ServiceGoals"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\SGoals.png") != null)
			{
				try
				{
					for(int i=0;i<15;i++)
					{
						sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\SGoals.png");
						System.out.println("in service goals");
						if(driver.findElements(By.linkText("Service Goals")).size()!=0)
				    	{
				    		
				    		break;
				    	}
					}
					
					
				}
				catch (Exception e) {
					// TODO: handle exception
				}
				
				extent.log(LogStatus.INFO, "Service Goals menu item is selected from Forecasting tab");
				flag=true;
			}			
			Thread.sleep(2000);
			/*Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);	*/
		}
		
		if (menuItem.contains("FS_Profiles"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\FS_pro.png") != null)
			{
				try
				{
					for(int i=0;i<15;i++)
					{
						sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FS_pro.png");
						if(driver.findElements(By.linkText("Profiles")).size()!=0)
				    	{
				    		System.out.println("in fs profiles");
				    		break;
				    	}
					}
					
				}
				catch(Exception e)
				{
					
				}
				extent.log(LogStatus.INFO, "Profiles menu item is selected from Forecasting & Scheduling tab");
				flag=true;
			}			
			Thread.sleep(3000);
			//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			//Thread.sleep(5000);			
		}
		
		if (menuItem.contains("user_profiles"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_UserMgmnt_profiles.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_UserMgmnt_profiles.png");	
				extent.log(LogStatus.INFO, "Profiles menu item is selected from User Management tab");
				flag=true;
			}			
			Thread.sleep(1000);
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);			
		}
		
		if (menuItem.contains("Interactions Contacts"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\menu_InteractionsContacts.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\menu_InteractionsContacts.png");	
				extent.log(LogStatus.INFO, "Contacts menu item is selected from Interactions tab");
				flag=true;
			}			
			Thread.sleep(1000);
			//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);	
		}
		
		if (menuItem.contains("Auto Processing"))
		{
			driver.findElement(By.xpath(menuAutoProcessing)).click(); //click on Role Setup menu item
			extent.log(LogStatus.INFO, "Auto Processing menu item is selected from System Management tab");
			Thread.sleep(5000);
		}
		if (menuItem.contains("Employee Requests"))
		{
			driver.findElement(By.xpath(menuEmpRequests)).click(); //click on Role Setup menu item
			extent.log(LogStatus.INFO, "My Requests menu item is selected from System Management tab");
			Thread.sleep(5000);
		}
		
		if (menuItem.contains("My Requests"))
		{
			driver.findElement(By.xpath(menuMyRequests)).click(); //click on Role Setup menu item
			extent.log(LogStatus.INFO, "My Requests menu item is selected from System Management tab");
			Thread.sleep(5000);
		}
		if (menuItem.equals("TimeOff"))
		{
			driver.findElement(By.xpath(menuTimeOffPool)).click(); //click on Role Setup menu item
			extent.log(LogStatus.INFO, "Time Off Pools menu item is selected from System Management tab");
			Thread.sleep(5000);
		}
		if (menuItem.equals("Time Off Pools"))
		{
			driver.findElement(By.xpath(menuTimeOffPool)).click(); //click on Role Setup menu item
			extent.log(LogStatus.INFO, "Time Off Pools menu item is selected from System Management tab");
			Thread.sleep(5000);
		}
		if (menuItem.equals("Instances"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_ReportsInstances.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_ReportsInstances.png");	
				extent.log(LogStatus.INFO, "Instances menu item is selected from Reports tab");
				flag=true;
			}			
			Thread.sleep(1000);
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);	
		}
		
		if (menuItem.contains("Activiteis"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Activities.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Activities.png");	
				extent.log(LogStatus.INFO, "Activiteis menu item is selected");
				flag=true;
			}			
			Thread.sleep(1000);
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);			
		}
		if (menuItem.contains("Integration Servers"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_IntegrationServers.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_IntegrationServers.png");	
				extent.log(LogStatus.INFO, "Integration Servers menu item is selected");
				flag=true;
			}			
			Thread.sleep(1000);
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);				
		}
		if (menuItem.contains("Work Queue Group Mapping"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_WorkQueueGroupMapping.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_WorkQueueGroupMapping.png");	
				extent.log(LogStatus.INFO, "Work Queue Group Mapping menu item is selected from System Management tab");
				flag=true;
			}			
			Thread.sleep(1000);
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);	
			
		}
		if (menuItem.contains("Work Queues Settings"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_WorkQueuesSettings.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_WorkQueuesSettings.png");	
				extent.log(LogStatus.INFO, "Work Queues Settings menu item is selected");
				flag=true;
			}			
			Thread.sleep(1000);
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);		
		}
		if (menuItem.contains("Manage Coaching"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_ManageCoaching.png") != null)
			{			
				for(int i=0;i<15;i++)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_ManageCoaching.png");
					if(driver.findElements(By.linkText("Manage Coaching")).size()!=0)
			    	{
			    		//System.out.println("in fs profiles");
			    		break;
			    	}
				}		
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_ManageCoaching.png");	
				extent.log(LogStatus.INFO, "Manage Coaching menu item is selected from Coaching tab");
				flag=true;
			}			
			Thread.sleep(1000);
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);			
		}
		if (menuItem.contains("Compaign Settings"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_CampaignSettings.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_CampaignSettings.png");	
				extent.log(LogStatus.INFO, "Compaign Settings menu item is selected from User Management tab");
				flag=true;
			}			
			Thread.sleep(1000);
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);		
		}
		
		if (menuItem.contains("RecordingRules Settings"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_RecordingRulesSettings.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_RecordingRulesSettings.png");	
				extent.log(LogStatus.INFO, "RecordingRules Settings menu item is selected from System Management tab");
				flag=true;
			}			
			Thread.sleep(1000);
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);		
			
		}
		
		if (menuItem.contains("Organization Settings"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_OrgSettings.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_OrgSettings.png");	
				extent.log(LogStatus.INFO, "Organization Settings menu item is selected from User Management tab");
				flag=true;
			}			
			Thread.sleep(1000);
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);
		}
		
		if (menuItem.contains("Access Rights"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_AccessRights.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_AccessRights.png");	
				extent.log(LogStatus.INFO, "Access Rights menu item is selected from User Management tab");
				flag=true;
			}			
			Thread.sleep(1000);
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);
		}
		
		if (menuItem.contains("Profiles"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Profiles.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Profiles.png");	
				extent.log(LogStatus.INFO, "Profiles menu item is selected from User Management tab");
				flag=true;
			}			
			Thread.sleep(1000);
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);			
		}
		
		if (menuItem.contains("Data Sources"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_DataSources.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_DataSources.png");	
				extent.log(LogStatus.INFO, "Data Sources menu item is selected from System Management tab");
				flag=true;
			}			
			Thread.sleep(1000);
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);
		}	
		
		if (menuItem.contains("Quality Monitoring"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_QualityMonitoring.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_QualityMonitoring.png");	
				extent.log(LogStatus.INFO, "Quality Monitoring menu item is selected");
				flag=true;
			}			
			Thread.sleep(10000);			
			/*driver.findElement(By.xpath(menuQualityMonitoring)).click(); 
			extent.log(LogStatus.INFO, "Quality Monitoring menu item is selected from Interactions tab");
			parentHandle = driver.getWindowHandle();
			for(String winHandle :driver.getWindowHandles()){
                driver.switchTo().window(winHandle);
			}
			Thread.sleep(10000);*/			
		}		
		if (menuItem.contains("Role Setup"))
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\menu_RolesSetup.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\menu_RolesSetup.png");	
				extent.log(LogStatus.INFO, "Roles Setup menu item is selected");
				flag=true;
			}			
			Thread.sleep(1000);
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\VerintImpact.png");			
			Thread.sleep(5000);	
		}	
		if (menuItem.contains("Desktop And Process Analytics"))
		{
			
			driver.findElement(By.xpath(menuDPA)).click(); //click on DPA menu item
			extent.log(LogStatus.INFO, "Desktop And Process Analytics menu item is selected from Tracking");
			Utilities.waitForPageLoad(driver,By.linkText("Administration"));
			//Thread.sleep(8000);	
			parentHandle = driver.getWindowHandle();
			for(String winHandle :driver.getWindowHandles()){
                driver.switchTo().window(winHandle);
                if(driver.getTitle().contains("Desktop And Process Analytics"))
                {
                	flag=true;
                	System.out.println("You are in DPA window");
                	//driver.manage().window().maximize();
                    break;
                }			
			}
			
		} 
		if (menuItem.contains("DesktopProcessAnalytics_Menu"))
		{
		//with sikuli	
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_DPA.png"); //click on DPA menu item
			extent.log(LogStatus.INFO, "Desktop And Process Analytics menu item is selected from Tracking");
			Thread.sleep(5000);	
			Utilities.windowsSecurityCredentials(driver,Utilities.Globlocators.getProperty("WindowsSecurityUserName"),Utilities.Globlocators.getProperty("WindowsSecurityPassword"));
			//Utilities.waitForPageLoad(driver,By.linkText("Administration"));
			Thread.sleep(15000);	
			/*parentHandle = driver.getWindowHandle();
			for(String winHandle :driver.getWindowHandles()){
                driver.switchTo().window(winHandle);
                if(driver.getTitle().contains("Desktop And Process Analytics"))
                {
                	flag=true;
                	System.out.println("You are in DPA window");
                	//driver.manage().window().maximize();
                	//driver.manage().window().maximize();
                    //break;
                }
                if (!driver.getTitle().contains("Desktop And Process Analytics"))
                {
                	driver.switchTo().window(parentHandle).close();
                }*/
			//}
			
			Set<String> windowIds1 = driver.getWindowHandles();
			System.out.println("windows size:"+windowIds1.size());
			if (windowIds1.size()==2)
			{
			Iterator<String> itererator = windowIds1.iterator(); 			
			String mainWinID1 = itererator.next();//main window 
			System.out.println(mainWinID1);
			//driver.switchTo().window(mainWinID1).close();
			Thread.sleep(1000);	
			String  popWindow1 = itererator.next();//popup window
			Thread.sleep(2000);	
			driver.switchTo().window(popWindow1);
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Text.png");
			flag=true;
			//sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Text.png");
			}
			else
			{
				flag=false;
			}
		}
		if (menuItem.contains("DPA"))
		{
			//DPA09 - testcase - here itwill display only DPA menu item-xpath is different in this case
			driver.findElement(By.xpath(dpamenu)).click(); //click on DPA menu item
			extent.log(LogStatus.INFO, "Desktop And Process Analytics menu item is selected from Tracking");
			Utilities.waitForPageLoad(driver,By.linkText("Administration"));
			//Thread.sleep(8000);	
			parentHandle = driver.getWindowHandle();
			for(String winHandle :driver.getWindowHandles()){
                driver.switchTo().window(winHandle);
                if(driver.getTitle().contains("Desktop And Process Analytics"))
                {
                	flag=true;
                	System.out.println("You are in DPA window");
                	//driver.manage().window().maximize();
                    break;
                }			
			}
			
		} 
		Thread.sleep(3000);
		//return parentHandle;
		return flag;
	}
	public static boolean verifyVerintHomePage(WebDriver driver) throws Exception
	{
		boolean flag=true;
		try {			
				By home=By.linkText(homePage);
				Thread.sleep(5000);
				Utilities.waitForPageLoad(driver,home);
				if (driver.findElements(home).size()!=0)
				{
					extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "HomePage"));
					extent.log(LogStatus.PASS, "Verint Home page is dispalyed successfully");
				}
				else
				{
					extent.log(LogStatus.FAIL, "Verint Home page is NOT dispalyed");
					extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "HomePage"));
						//Utilities.captureScreenShot(driver,screenshotDir+"Login");
					return flag =false;
				}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean verifyVerintImpact360(WebDriver driver) throws Exception
	{
		boolean flag=true;
		try {			
				By home=By.xpath(verintImpactLogo);
				Thread.sleep(5000);
				Utilities.waitForPageLoad(driver,home);
				if (driver.findElements(home).size()!=0)
				{
					extent.log(LogStatus.PASS, "Verint Home page is dispalyed successfully");
				}
				else
				{
					extent.log(LogStatus.FAIL, "Verint Home page is NOT dispalyed");
						//Utilities.captureScreenShot(driver,screenshotDir+"Login");
					return flag =false;
				}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	
	public static boolean clickCalOK()
	{
		boolean flag=false;
		try
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\btnOK_calendar.png") != null)
			{
			
				System.out.println("in calendar if");
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\btnOK_calendar.png");
				Thread.sleep(2000);
				return flag=true;
			}
			else
			{
				System.out.println("in calendar else");
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\okbtn.png");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
		
	}
	
	public static boolean clickyes()
	{
		boolean flag=false;
		try
		{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\view_yes.png") != null)
			{
			
				System.out.println("click on yes");
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\view_yes.png");
				Thread.sleep(2000);
				return flag=true;
			}
			else
			{
				System.out.println("no yes exist");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
}
