package ScreenObjects;

import java.awt.Robot;
import java.awt.event.KeyEvent;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class OrganizationSettings {

	public static ExtentReports extent = ExtentReports.get(OrganizationSettings.class);
	public static String btnCreateOrg="//button[@id='workpaneMediator_toolbar_ADD_ACTIONLabel']";
	public static String txtOrganizationName="organizationName_0";
	public static String txtOrganizationDesc="description_0";
	public static String txtTimeZone="//input[@id='timezoneID_0']";	
	public static String txtWeekStartDay="//input[@id='weekStartDay_0']";
	public static String txtDayBoundary="//input[@id='dayBoundaryOffset_0']";
	public static String txtNumberOfSeats="//input[@id='numSeats_0']";
	public static String txtMinTimeBetShifts="//input[@id='MinTimeBetweenShift__input_id']";
	public static String txtMaxConsecutiveWorkingDay="//input[@id='MaxConsecutiveWorkingDay_0']";
	public static String chkCrossDayBoundary="//input[@id='bChk_canCrossDayBoundary_true_0']";
	
	
	public static String chkis24hours="bChk_is24Hour_true_0";
	public static String btnSave="workpaneMediator_toolbar_SAVE_ACTIONLabel";
	public static String iconlstWeekStartDay="//span[@id='weekStartDay_0Wrapper']/nobr/img[@id='weekStartDay_0Button']";
	
	//public static String btnSaveApplySubOrg="//button[@id='workpaneMediator_toolbar_SAVE_ACTIONLabel'][@actionType='NORMAL_TYPE']";
	public static String btnSaveApplySubOrg="//div[@id='workToolbarWrapper']span/table/tbody/tr[1]/td[2]/table/tbody/tr/td/button[@id='workpaneMediator_toolbar_SAVE_ACTIONLabel']";
	public static String btnDelete="//button[@id='workpaneMediator_toolbar_DELETE_CONFIRM_DIALOG_ACTIONLabel']";
	public static String btnDeleteOrg="//table[@id='workpaneMediator_toolbar_DELETE_ACTIONWrapper']/tbody/tr/td/button[@id='workpaneMediator_toolbar_DELETE_ACTIONLabel']";
	
	public static boolean clickDeleteOrg(WebDriver driver) throws Exception
	{		
		Utilities.selectRightPaneView(driver);
		boolean flag=true;
		try{			
			By delOrgBtn=By.xpath(btnDeleteOrg);
			Utilities.waitForPageLoad(driver,delOrgBtn);
			if (driver.findElements(delOrgBtn).size()!=0)
			{					
				driver.findElement(delOrgBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Confirmation - Delete button is successful");
				Thread.sleep(6000);
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Confirmation - Delete button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean clickDelete(WebDriver driver) throws Exception
	{	
		Utilities.selectRightPaneView(driver);
		boolean flag=true;
		try{			
			By delBtn=By.xpath(btnDelete);
			Utilities.waitForPageLoad(driver,delBtn);
			if (driver.findElements(delBtn).size()!=0)
			{					
				driver.findElement(delBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Delete button is successful");
				Thread.sleep(6000);
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Delete button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean ViewOrganizationStructure(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		boolean opt=false;
		try{
			if (driver.findElements(By.id(txtOrganizationName)).size()!=0)				
			{
				extent.log(LogStatus.PASS, "Organization Name filed is displayed");
			}
			else
			{
				extent.log(LogStatus.FAIL, "Organization Name filed is NOT displayed");
				return flag=false;
			}
			if (driver.findElements(By.id(txtOrganizationDesc)).size()!=0)				
			{
				extent.log(LogStatus.PASS, "Description filed is displayed");
			}
			else
			{
				extent.log(LogStatus.FAIL, "Description filed is NOT displayed");
				return flag=false;
			}
			if (driver.findElements(By.xpath(txtTimeZone)).size()!=0)				
			{
				extent.log(LogStatus.PASS, "Time Zone filed is displayed");
			}
			else
			{
				extent.log(LogStatus.FAIL, "Time Zone filed is NOT displayed");
				return flag=false;
			}
			if (driver.findElements(By.xpath(txtWeekStartDay)).size()!=0)				
			{
				extent.log(LogStatus.PASS, "Week Start Day filed is displayed");
			}
			else
			{
				extent.log(LogStatus.FAIL, "Week Start Day filed is NOT displayed");
				return flag=false;
			}
			if (driver.findElements(By.xpath(txtDayBoundary)).size()!=0)				
			{
				extent.log(LogStatus.PASS, "Day Boundary filed is displayed");
			}
			else
			{
				extent.log(LogStatus.FAIL, "Day Boundary filed is NOT displayed");
				return flag=false;
			}
			if (driver.findElements(By.xpath(txtNumberOfSeats)).size()!=0)				
			{
				extent.log(LogStatus.PASS, "Number Of Seats filed is displayed");
			}
			else
			{
				extent.log(LogStatus.FAIL, "Number Of Seats filed is NOT displayed");
				return flag=false;
			}
			if (driver.findElements(By.xpath(txtMinTimeBetShifts)).size()!=0)				
			{
				extent.log(LogStatus.PASS, "Minimum time between shift assignments filed is displayed");
			}
			else
			{
				extent.log(LogStatus.FAIL, "Minimum time between shift assignments filed is NOT displayed");
				return flag=false;
			}
			if (driver.findElements(By.xpath(txtMaxConsecutiveWorkingDay)).size()!=0)				
			{
				extent.log(LogStatus.PASS, "Maximum consecutive working days to schedule filed is displayed");
			}
			else
			{
				extent.log(LogStatus.FAIL, "Maximum consecutive working days to schedule filed is NOT displayed");
				return flag=false;
			}
			if (driver.findElements(By.xpath(chkCrossDayBoundary)).size()!=0)				
			{
				extent.log(LogStatus.PASS, "Allow shift assignments to cross day boundary filed is displayed");
			}
			else
			{
				extent.log(LogStatus.FAIL, "Allow shift assignments to cross day boundary filed is NOT displayed");
				return flag=false;
			}
			if (driver.findElements(By.id(chkis24hours)).size()!=0)				
			{
				extent.log(LogStatus.PASS, "Is 24 Hour filed is displayed");
			}
			else
			{
				extent.log(LogStatus.FAIL, "Is 24 Hour filed is NOT displayed");
				return flag=false;
			}		
			
			if (driver.findElements(By.xpath("//input[@name='bChk_HooIsActive1']")).size()!=0 &	driver.findElements(By.xpath("//input[@name='bChk_HooIsActive2']")).size()!=0 &	driver.findElements(By.xpath("//input[@name='bChk_HooIsActive3']")).size()!=0 & driver.findElements(By.xpath("//input[@name='bChk_HooIsActive4']")).size()!=0 & driver.findElements(By.xpath("//input[@name='bChk_HooIsActive5']")).size()!=0 & driver.findElements(By.xpath("//input[@name='bChk_HooIsActive6']")).size()!=0 & driver.findElements(By.xpath("//input[@name='bChk_HooIsActive7']")).size()!=0)		
			{
				opt=true;
			}
			
			if (opt==true)
			{
				extent.log(LogStatus.PASS, "Sunday to Saturday fileds are displayed");
			}
			else
			{
				extent.log(LogStatus.FAIL, "Sunday to Saturday fileds are NOT displayed");
			}
			
			
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static void clickSaveApplySubOrg(WebDriver driver) throws Exception
	{		
		try{			
			By saveSubOrgBtn=By.id(btnSaveApplySubOrg);
			Utilities.waitForPageLoad(driver,saveSubOrgBtn);
			if (driver.findElements(saveSubOrgBtn).size()!=0)
			{					
				driver.findElement(saveSubOrgBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Save and Apply to sub organizations button is successful");
				Thread.sleep(6000);
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Save and Apply to sub organizations button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static boolean setWeekStartDay(WebDriver driver,String WeekStartDay) throws Exception
	{
		boolean flag=false;
		try{		
			By weekstartlst=By.xpath(iconlstWeekStartDay);
			Utilities.waitForPageLoad(driver,weekstartlst);
			if (driver.findElements(weekstartlst).size()!=0)
			{			
				driver.findElement(weekstartlst).click();
				Thread.sleep(2000);
				driver.findElement(weekstartlst).sendKeys(WeekStartDay);
				Robot r = new Robot();
				r.keyPress(KeyEvent.VK_ENTER);
				r.keyRelease(KeyEvent.VK_ENTER);
				extent.log(LogStatus.INFO, "Week Start Day:"+WeekStartDay+ " is selected");	
				//extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "OrganizationWeekDay"));
				flag=true;	
				Thread.sleep(4000);				
			}else
			{
				extent.log(LogStatus.FAIL, "Week Start Day : "+WeekStartDay +" is NOT selected");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "OrganizationWeekDay"));
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setDayBoundary(WebDriver driver,String DayBoundary) throws Exception
	{
		boolean flag=false;
		try{		
			By daytxt=By.xpath(txtDayBoundary);
			Utilities.waitForPageLoad(driver,daytxt);
			if (driver.findElements(daytxt).size()!=0)
			{			
				driver.findElement(daytxt).click();
				driver.findElement(daytxt).clear();
				Thread.sleep(2000);
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK1.png");
				driver.findElement(daytxt).sendKeys(DayBoundary);
				
				extent.log(LogStatus.INFO, "Day Boundary:"+DayBoundary+ " is selected");	
				//extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "OrganizationWeekDay"));
				flag=true;	
				Thread.sleep(4000);				
			}else
			{
				extent.log(LogStatus.FAIL, "Day Boundary : "+DayBoundary +" is NOT selected");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "OrganizationWeekDay"));
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickSave(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{			
			By saveBtn=By.id(btnSave);
			Utilities.waitForPageLoad(driver,saveBtn);
			if (driver.findElements(saveBtn).size()!=0)
			{					
				driver.findElement(saveBtn).click();
				//System.out.println("clicked save");
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Save.png");
				extent.log(LogStatus.PASS, "Clicked on Save button is successful");
				Thread.sleep(6000);
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Save button is unsuccessful");
				//System.out.println("not clicked save");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	public static void isSelectedDaysAndHoursOfOperation(WebDriver driver) throws Exception
	{
		try{		
			By ishourschk=By.id(chkis24hours);
			Utilities.waitForPageLoad(driver,ishourschk);
			if (driver.findElements(ishourschk).size()!=0)
			{
				if (driver.findElement(ishourschk).isSelected())
					extent.log(LogStatus.INFO, "Days and Hours of Operation  - is 24hours is checked by default");
				else
					extent.log(LogStatus.INFO, "Days and Hours of Operation  - is 24hours is not checked by default");
			}else
			{
				extent.log(LogStatus.FAIL, "Days and Hours of Operation  - is 24hours checkbox is not displayed");
			}
			//Under Days and Hours of Operation banner- verifying check boxes 		
			if (driver.findElement(By.id("bChk_HooIsActive1_true_0")).isSelected() && driver.findElement(By.id("bChk_HooIsActive1_true_0")).isSelected() && driver.findElement(By.id("bChk_HooIsActive2_true_0")).isSelected() && driver.findElement(By.id("bChk_HooIsActive3_true_0")).isSelected() && driver.findElement(By.id("bChk_HooIsActive4_true_0")).isSelected() && driver.findElement(By.id("bChk_HooIsActive5_true_0")).isSelected() && driver.findElement(By.id("bChk_HooIsActive6_true_0")).isSelected() && driver.findElement(By.id("bChk_HooIsActive7_true_0")).isSelected())
			{
				extent.log(LogStatus.INFO, "Under Days and Hours of Operation banner, Sunday - Saturday checkboxes are selected");
				//captureScreenShot(driver,"DaysHoursOperations");
			}
			else
			{
				extent.log(LogStatus.INFO, "Under Days and Hours of Operation banner, Sunday - Saturday some of the checkboxes are NOT selected");
				//captureScreenShot(driver,screenshotDir+"DaysHoursOperations");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
	public static void setOrganizationDescription(WebDriver driver,String OrgDesc) throws Exception
	{
		try{		
			By orgDesctxt=By.id(txtOrganizationDesc);
			Utilities.waitForPageLoad(driver,orgDesctxt);
			if (driver.findElements(orgDesctxt).size()!=0)
			{
				driver.findElement(orgDesctxt).clear();
				driver.findElement(orgDesctxt).sendKeys(OrgDesc);
				extent.log(LogStatus.PASS, "Organization Description : "+orgDesctxt +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Organization Description : "+orgDesctxt +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void setOrganizationName(WebDriver driver,String OrgName) throws Exception
	{
		try{		
			By orgtxt=By.id(txtOrganizationName);
			Utilities.waitForPageLoad(driver,orgtxt);
			if (driver.findElements(orgtxt).size()!=0)
			{
				driver.findElement(orgtxt).clear();
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK1.png");
				driver.findElement(orgtxt).sendKeys(OrgName);
				extent.log(LogStatus.PASS, "Organization Name : "+OrgName +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Organization Name : "+OrgName +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static boolean clickCreateOrganization(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{			
			By orgBtn=By.xpath(btnCreateOrg);
			Utilities.waitForPageLoad(driver,orgBtn);
			if (driver.findElements(orgBtn).size()!=0)
			{					
				driver.findElement(orgBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Create Organization button is successful");
				Thread.sleep(6000);
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Create Organization button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean verifyOrganizationFromLeftTreeFrame(WebDriver driver,String OrgName) throws Exception
	{
		boolean flag=false;
		Utilities.selectLeftTreeFrame(driver);
		//Boolean Temp1=false;
		//String organizationName=".Automation_Organization";
		int rc1=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
		System.out.println("rc1:"+rc1);
		for (int j=1;j<=rc1;j++)
		{
			if (j<=15)
			{
				String orgName=driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).getText();				
				Thread.sleep(1000);
				if (orgName.contains(OrgName))
				{
					driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).click();
					flag=true;
					break;
				}
			}
		}
		
		if (flag==true)
		{
			extent.log(LogStatus.PASS, "Organization Name: "+OrgName+" Created/Selected/verified successfully");
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "CreateOrganization"));
		}
		else
		{
			extent.log(LogStatus.WARNING, "Not able to select Organization Name: "+OrgName);
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "CreateOrganization"));
			flag=false;
		}
	
		return flag;
	}
	
	public static boolean selectOrganizationFromLeftTreeFrame(WebDriver driver,String OrgName) throws Exception
	{
		boolean flag=false;
		Utilities.selectLeftTreeFrame(driver);
		int rc=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
		//System.out.println("rc:"+rc);
		for (int i=1;i<=rc;i++)
		{
			if (OrgName.contains("state") || OrgName.contains("State"))
			{
				driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr[1]/td/a")).click();
				flag=true;
				break;
			}
			if (i<=15)
			{
			String orgName=driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+i+"]/td/a")).getText();
			//System.out.println("orgname:"+orgName);
			if (orgName.contains(OrgName))
			{
				driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+i+"]/td/a")).click();
				//System.out.println("statefarm node is selected");
				flag=true;
				//captureScreenShot(driver,"StateFarm node");
				break;
			}}
		}
		if (flag==true)
		{
			extent.log(LogStatus.PASS, "Organization Name: "+OrgName+" Created/Selected successfully");
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "CreateOrganization"));
		}
		else
		{
			extent.log(LogStatus.WARNING, "Not able to select Parent Organization Name: "+OrgName);
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "CreateOrganization"));
			return flag=false;
		}
	
		return flag;
	}
	
	
}
