package ScreenObjects;

import java.util.List;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.sikuli.script.Key;
import org.sikuli.script.KeyModifier;
import org.sikuli.script.Screen;


public class Impact360WebPortalPreferencesScreen {
	public static Screen sobj = new Screen ();
	public static ExtentReports extent = ExtentReports.get(Impact360WebPortalPreferencesScreen.class);
	public static String lstContactAppearance="etmCtrl_lstSectionExpandability";
	public static String lstQMDefaultForm="ccqCtrl_lstDDLDefaultEvaluation";
										   
	public static String btnOK="//a[id='UserSettingsPageHeader__ctl1__ctl0']";
	public static String btnAddReport="//a[@title='Add Report']";
	
	public static boolean deleteReport(WebDriver driver,String ReportName) throws Exception
	{
		String repName="";		
		boolean flag=false;	
		int rc1=driver.findElements(By.xpath("//table[@id='rptCtrl_BOScheduleGrid_Grid']/tbody/tr")).size();
		System.out.println("rc1:"+rc1);
		for (int j=1;j<=rc1;j++)
		{			
				repName=driver.findElement(By.xpath("//table[@id='rptCtrl_BOScheduleGrid_Grid']/tbody/tr["+j+"]/td[2]")).getText();
				System.out.println("repApp:"+repName);				
				System.out.println(ReportName);
				Thread.sleep(1000);
				if (repName.contains(ReportName))
				{		
					extent.log(LogStatus.PASS, "Report Name: "+repName+" added successfully");
					driver.findElement(By.xpath("//table[@id='rptCtrl_BOScheduleGrid_Grid']/tbody/tr["+j+"]/td[4]/a/img[@alt='Delete report']")).click();
					Thread.sleep(2000);
					Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Delete_Yes.png");
					extent.log(LogStatus.PASS, "Report Name: "+repName+" deleted successfully");
					flag=true;
					break;
				}		
		}
		
		if (flag==false)
		{	
			extent.log(LogStatus.WARNING, "Not able to add Report Name : "+ReportName);
			//extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "CreateOrganization"));
			flag=false;
		}
	
		return flag;
	}
	
	public static boolean clickAddReport(WebDriver driver) throws Exception
	{	
		boolean flag=true;
		try{
			By addrepBtn=By.xpath(btnAddReport);
			 Thread.sleep(5000);	
				driver.switchTo().defaultContent();
				Utilities.switchFrame(driver,"main");
				Thread.sleep(2000);
			if (driver.findElements(addrepBtn).size()!=0)
			{					
				driver.findElement(addrepBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Add Report button is successful");
				Thread.sleep(6000);
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Add Report button is unsuccessful");
				flag=false;
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean clickOK(WebDriver driver) throws Exception
	{
		/*boolean flag=true;
		try{
			By okBtn=By.xpath(btnOK);
			driver.switchTo().frame(1);
			Utilities.waitForPageLoad(driver,okBtn);
			if (driver.findElements(okBtn).size()!=0)
			{					
				driver.findElement(okBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Preferences OK button is successful");
				Thread.sleep(6000);
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Preferences OK button is unsuccessful");
				flag=false;
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;*/
		Boolean flag=true;
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_WebPortalPref_OK.png")!=null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_WebPortalPref_OK.png");	
			extent.log(LogStatus.PASS,"Clicked on OK button - Preferences page");
			Thread.sleep(6000);
		}
		else
		{
			extent.log(LogStatus.FAIL,"OK button is not displayed/Not able to click on OK button");
			flag=false;
		}
		return flag;
	}
	
	public static boolean selectOption_QMDefaultForm_PlaybackPref(WebDriver driver,String FormName) throws Exception
	{		
		boolean flag=false;
		Thread.sleep(3000);
		driver.switchTo().defaultContent();
		/*driver.switchTo().frame(1);
		Thread.sleep(2000);*/
		//driver.switchTo().frame(1);	
		Utilities.switchFrame(driver,"FR_PLAYBACK");
		Thread.sleep(2000);
		Utilities.switchFrame(driver,"main");
		Thread.sleep(2000);
		WebElement opt = driver.findElement(By.id(lstQMDefaultForm));
		List<WebElement> lists = opt.findElements(By.tagName("option"));
		if (lists.size()!=0)
		{			 	
			 System.out.println("Evaluation Form items count :"+lists.size());
		     for(WebElement element: lists)  
		     {
		         String lstValues = element.getText();
		         System.out.println("valueApp:"+lstValues);
		         System.out.println("value:"+FormName);
		         if (lstValues.contains(FormName))
		         {
		        	element.click();
		        	extent.log(LogStatus.PASS,"Evaluation Form value:"+FormName+" selected");
		        	Thread.sleep(5000);
		        	flag=true;
		        	break;
		         }
		     }
		}
		else
		{
			 extent.log(LogStatus.FAIL,"No items/Not able to select option from QM Default Form");
			 flag=false;
		}	
		return flag;		
	}
	
	public static boolean selectOption_QMDefaultForm(WebDriver driver,String FormName) throws Exception
	{		
		boolean flag=false;
		Thread.sleep(3000);
		driver.switchTo().defaultContent();
		/*driver.switchTo().frame(1);
		Thread.sleep(2000);*/
		//driver.switchTo().frame(1);	
		
		Utilities.switchFrame(driver,"main");
		Thread.sleep(2000);
		WebElement opt = driver.findElement(By.id(lstQMDefaultForm));
		List<WebElement> lists = opt.findElements(By.tagName("option"));
		if (lists.size()!=0)
		{			 	
			 System.out.println("Evaluation Form items count :"+lists.size());
		     for(WebElement element: lists)  
		     {
		         String lstValues = element.getText();
		         System.out.println("valueApp:"+lstValues);
		         System.out.println("value:"+FormName);
		         if (lstValues.contains(FormName))
		         {
		        	element.click();
		        	extent.log(LogStatus.PASS,"Evaluation Form value:"+FormName+" selected");
		        	Thread.sleep(5000);
		        	flag=true;
		        	break;
		         }
		     }
		}
		else
		{
			 extent.log(LogStatus.FAIL,"No items/Not able to select option from QM Default Form");
			 flag=false;
		}	
		return flag;		
	}
	public static boolean selectOptionContactAppearance(WebDriver driver,String Option) throws Exception
	{
		boolean flag=true;
		try{
			driver.switchTo().frame(1);
			By preflst=By.id(lstContactAppearance);
			WebElement elem = driver.findElement(preflst);
			new Select(elem).selectByVisibleText(Option);		
			
			Select listbox=new Select(elem);			
			String value =  listbox.getFirstSelectedOption().getText();
			System.out.println("Value selected is " + value );
			if (value.contains(Option))
			{
				extent.log(LogStatus.PASS, "Option:"+Option+" is selected from Contacts Appearance dropdown");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Preferences"));
				Thread.sleep(5000);
			}else
			{
				extent.log(LogStatus.FAIL, "Option:"+Option+" is NOT selected from Contacts Appearance dropdown");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Preferences"));
				flag=false;
			}
			}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
}
