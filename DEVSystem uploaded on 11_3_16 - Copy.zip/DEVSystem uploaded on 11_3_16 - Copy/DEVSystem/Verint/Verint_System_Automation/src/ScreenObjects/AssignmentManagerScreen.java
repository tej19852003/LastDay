package ScreenObjects;



import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.sikuli.script.Screen;

//import Library.DPA_Library;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class AssignmentManagerScreen {
	
	public static ExtentReports extent = ExtentReports.get(AssignmentManagerScreen.class);
	public static Screen sobj = new Screen ();
	public static String lnkRoles="//a[@id='ext-gen122']";
	public static String lnkGroups="//a[@id='ext-gen120']";
	public static String lnkEntities="//a[@id='ext-gen124']";
	public static String lnkQualityMonitoringForLeaders="//a[@id='ext-gen172']";
	public static String lnkReports="//a[@id='ext-gen176']";
	public static String chkSearchForAnyForm="//input[@id='checkbox1_12_-1'][@type='checkbox']";
	public static String btnSave="//button[@id='ext-gen104']";
	public static String radChangealltoNotAssigned="//input[@id='radBreakType1'][@type='radio']";
	
	public static boolean selectReportsTab(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			/*By Reportslnk=By.xpath(lnkReports);
			Utilities.waitForPageLoad(driver,Reportslnk);
			if (driver.findElements(Reportslnk).size()!=0)
			{					
				driver.findElement(Reportslnk).click();
				extent.log(LogStatus.PASS, "Clicked on Reports Tab is successful");
				Thread.sleep(5000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Reports Tab is unsuccessful");
				flag=false;
			}*/	
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_Reports.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_Reports.png");	
				extent.log(LogStatus.PASS, "Clicked on Reports Tab is successful");
				Thread.sleep(2000);
				flag=true;	
			}
			else
			{
				extent.log(LogStatus.FAIL, "Clicked on Reports Tab is unsuccessful");
				return flag=false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean selectGroupName(WebDriver driver,String GroupName) throws Exception
	{
		boolean flag=false;
		try{
		/*String childGrpName;
		String groupName;
		try{
			groupName=driver.findElement(By.xpath("//ul[@id='ext-gen131']/div/li/div/a/span")).getText();
			System.out.println("Grpname:"+groupName);
			if (GroupName.contains("Statefarm") || GroupName.contains("StateFarm")|| GroupName.contains("State farm") || GroupName.contains("State Farm"))
			{
				if (driver.findElements(By.xpath("//ul[@id='ext-gen131']/div/li/div/a/span")).size()!=0)
				{
					driver.findElement(By.xpath("//ul[@id='ext-gen131']/div/li/div/a/span")).click();
					extent.log(LogStatus.PASS,"GroupName :"+GroupName+" selected successfully");
					flag=true;					
				}
				else
				{
					extent.log(LogStatus.FAIL,"Not able to select GroupName :"+GroupName);
				}
			}
			else
			{
				
				if (driver.findElements(By.xpath("//ul[@id='ext-gen131']/div/li/div/img[1]")).size()!=0)
				{
					driver.findElement(By.xpath("//ul[@id='ext-gen131']/div/li/div/img[1]")).click();	
				}
				else
				{
					extent.log(LogStatus.FAIL,"Not able to expand Groups");
					return flag=false;
				}
				Thread.sleep(3000);
				if (driver.findElements(By.xpath("//ul[@id='ext-gen131']/div/li/ul/li")).size()!=0)
				{				
					int rc=driver.findElements(By.xpath("//ul[@id='ext-gen131']/div/li/ul/li")).size();
					for (int i=1;i<=rc;i++)
					{
						childGrpName=driver.findElement(By.xpath("//ul[@id='ext-gen131']/div/li/ul/li["+i+"]/div/a/span")).getText();
						System.out.println("chilsGrpName:"+childGrpName);
						if (childGrpName.contains(GroupName))
						{
							driver.findElement(By.xpath("//ul[@id='ext-gen131']/div/li/ul/li["+i+"]/div/a/span")).click();
							extent.log(LogStatus.PASS,"GroupName :"+GroupName+" selected successfully");
							Thread.sleep(5000);
							flag=true;
							break;
						}
					}
				}
			}	
			if (flag==false)
			{
				extent.log(LogStatus.FAIL,"Not able to select GroupName :"+GroupName);
			}*/
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_StateFarmGrpName.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_StateFarmGrpName.png");	
				extent.log(LogStatus.PASS,"GroupName :StateFarm selected successfully");
				Thread.sleep(2000);
				flag=true;	
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to select Group Name: StateFarm");
				return flag=false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickOK(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_OK.png")!=null)
			 {
				 sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_OK.png");
				 extent.log(LogStatus.PASS,"Clicked on OK Button is successful");
				 Thread.sleep(4000);
				 flag=true;
			 }
			 else
			 {
				 extent.log(LogStatus.FAIL,"Not able to click on OK button");
				 return flag=false;
			 }			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean clickChangealltoNotAssigned(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			/*By changeallRad=By.xpath(radChangealltoNotAssigned);
			Utilities.waitForPageLoad(driver,changeallRad);
			if (driver.findElements(changeallRad).size()!=0)
			{						
				driver.findElement(changeallRad).click();
				extent.log(LogStatus.PASS, "Clicked on Change all to Not Assigned radio button is successful");
				Thread.sleep(4000);
				flag=true;			
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Change all to Not Assigned radio button is unsuccessful");
				flag=false;
			}*/	
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_ChangealltoNotAssigned.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_ChangealltoNotAssigned.png");	
				extent.log(LogStatus.PASS, "Clicked on Change all to Not Assigned radio button is successful");	
				Thread.sleep(2000);
				flag=true;	
			}
			else
			{
				extent.log(LogStatus.FAIL, "Clicked on Change all to Not Assigned radio button is unsuccessful");
				return flag=false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean clickSave(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			/*By saveBtn=By.xpath(btnSave);
			Utilities.waitForPageLoad(driver,saveBtn);
			if (driver.findElements(saveBtn).size()!=0)
			{		
				if (driver.findElement(saveBtn).isEnabled())
				{
					driver.findElement(saveBtn).click();
					extent.log(LogStatus.PASS, "Clicked on Save button is successful");
					Thread.sleep(4000);
					flag=true;
				}
				else
				{
					extent.log(LogStatus.WARNING, "Save button is disabled");
				}
				
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Save button is unsuccessful");
				flag=false;
			}*/	
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_Save.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_Save.png");	
				extent.log(LogStatus.PASS, "Clicked on Save button is successful");
				flag=true;
				Thread.sleep(6000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Clicked on Save button is Unsuccessful");
				return flag=false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean verifyChkboxSearchForAnyFormSelected(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			By searchformChk=By.xpath(chkSearchForAnyForm);
			Utilities.waitForPageLoad(driver,searchformChk);
			if (driver.findElements(searchformChk).size()!=0)
			{		
				//if (driver.findElement(searchformChk).isSelected())
				String checked=driver.findElement(By.xpath("//input[@id='checkbox1_12_-1']")).getAttribute("checkbox");
				if (checked=="true")
				//if (driver.findElement(searchformChk).getAttribute("checkbox") != null)
				{
					extent.log(LogStatus.PASS,"Search For Any Form checkbox is already selected");
					return flag=true;				
				}else
				{					
					flag=false;
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean verifyChkboxSearchForAnyForm(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_ContFlags.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_ContFlags.png");
				Thread.sleep(2000);
			}			
			Robot r = new Robot();
			r.keyPress(KeyEvent.VK_PAGE_DOWN);
			Thread.sleep(1000);
			r.keyRelease(KeyEvent.VK_PAGE_DOWN);
			
			By searchformChk=By.xpath(chkSearchForAnyForm);
			Utilities.waitForPageLoad(driver,searchformChk);
			if (driver.findElements(searchformChk).size()!=0)
			{					
				extent.log(LogStatus.PASS,"Search For Any Form checkbox is displayed");
				return flag=true;
				
			}else
			{
				extent.log(LogStatus.FAIL, "Search For Any Form checkbox is NOT displayed");
				flag=false;
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean selectChkboxSearchForAnyForm(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			By searchformChk=By.xpath(chkSearchForAnyForm);
			Utilities.waitForPageLoad(driver,searchformChk);
			if (driver.findElements(searchformChk).size()!=0)
			{	
				driver.findElement(searchformChk).click();
				//if (driver.findElement(searchformChk).isSelected())  //need to check once
				//{
					//driver.findElement(searchformChk).click();
					extent.log(LogStatus.PASS, "Search For Any Form checkbox is selected");
					Thread.sleep(4000);
					flag=true;
				/*}
				else
				{
					extent.log(LogStatus.WARNING,"Search For Any Form checkbox is unchecked");
					return flag=false;
				}*/
			}else
			{
				extent.log(LogStatus.FAIL, "Search For Any Form checkbox is NOT displayed");
				flag=false;
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean selectQualityMonitoringForLeadersTab(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			/*By QMForLeaderslnk=By.xpath(lnkQualityMonitoringForLeaders);
			Utilities.waitForPageLoad(driver,QMForLeaderslnk);
			if (driver.findElements(QMForLeaderslnk).size()!=0)
			{					
				driver.findElement(QMForLeaderslnk).click();
				extent.log(LogStatus.PASS, "Clicked on Quality Monitoring For Leaders Tab is successful");
				Thread.sleep(5000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Quality Monitoring For Leaders Tab is unsuccessful");
				flag=false;
			}*/	
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_QMForLeaders.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_QMForLeaders.png");
				extent.log(LogStatus.PASS, "Clicked on Quality Monitoring For Leaders Tab is successful");
				Thread.sleep(5000);
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL, "Clicked on Quality Monitoring For Leaders Tab is unsuccessful");
				return flag=false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectGroupsTab(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			By groupsTab=By.xpath(lnkGroups);
			Utilities.waitForPageLoad(driver,groupsTab);
			if (driver.findElements(groupsTab).size()!=0)
			{					
				driver.findElement(groupsTab).click();
				extent.log(LogStatus.PASS, "Clicked on Groups Tab is successful");
				Thread.sleep(4000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Groups Tab is unsuccessful");
				flag=false;
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectEntitiesTab(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			/*By entitiesTab=By.xpath(lnkEntities);
			Utilities.waitForPageLoad(driver,entitiesTab);
			if (driver.findElements(entitiesTab).size()!=0)
			{					
				driver.findElement(entitiesTab).click();
				extent.log(LogStatus.PASS, "Clicked on Entities Tab is successful");
				Thread.sleep(5000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Entities Tab is unsuccessful");
				flag=false;
			}*/	
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_EntitiesTab.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_EntitiesTab.png");
				extent.log(LogStatus.PASS, "Clicked on Entities Tab is successful");
				Thread.sleep(5000);
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL, "Clicked on Entities Tab is unsuccessful");
				return flag=false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectRolesTab(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			/*By rolesTab=By.xpath(lnkRoles);
			Utilities.waitForPageLoad(driver,rolesTab);
			if (driver.findElements(rolesTab).size()!=0)
			{					
				driver.findElement(rolesTab).click();
				extent.log(LogStatus.PASS, "Clicked on Roles Tab is successful");
				Thread.sleep(5000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Roles Tab is unsuccessful");
				flag=false;
			}*/		
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_RolesTab.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_RolesTab.png");
				extent.log(LogStatus.PASS, "Clicked on Roles Tab is successful");
				Thread.sleep(5000);
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL, "Clicked on Roles Tab is unsuccessful");
				return flag=false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean selectRolesName(WebDriver driver,String RoleName) throws Exception
	{
		boolean flag=false;
		try{
			/*int rolesize=driver.findElements(By.xpath("//div[@id='ext-comp-1003']/div/div/ul/div/li")).size();
			System.out.println("roles size:"+driver.findElements(By.xpath("//div[@id='ext-comp-1003']/div/div/ul/div/li")).size());
			if (rolesize>0)
			{
				driver.findElement(By.xpath("//div[@id='ext-comp-1003']/div/div/ul/div/li[1]/div/a/span")).click();
			}
			for (int i=1;i<=rolesize;i++)
			{
				if (i==rolesize/2)
				{
					Robot r = new Robot();
					r.keyPress(KeyEvent.VK_PAGE_DOWN);
					Thread.sleep(1000);
					r.keyRelease(KeyEvent.VK_PAGE_DOWN);
				}
					if (driver.findElements(By.xpath("//div[@id='ext-comp-1003']/div/div/ul/div/li["+i+"]/div/a/span")).size()!=0)
					{
						System.out.println("role:"+driver.findElement(By.xpath("//div[@id='ext-comp-1003']/div/div/ul/div/li["+i+"]/div/a/span")).getText());
						if (driver.findElement(By.xpath("//div[@id='ext-comp-1003']/div/div/ul/div/li["+i+"]/div/a/span")).getText().contains(RoleName))
						{
							driver.findElement(By.xpath("//div[@id='ext-comp-1003']/div/div/ul/div/li["+i+"]/div/a/span")).click();
							Thread.sleep(5000);
							flag=true;
							break;
						}
					}
				}
				
			if (flag==true)
			{
				extent.log(LogStatus.PASS, "Roles Name:"+RoleName+" selected");
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to select Roles Name:"+RoleName);
			}*/
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_AllRoles.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_AllRoles.png");
				extent.log(LogStatus.PASS, "Roles Name:All Roles selected");
				Thread.sleep(5000);
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to select Roles Name:All Roles");
				return flag=false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

}

