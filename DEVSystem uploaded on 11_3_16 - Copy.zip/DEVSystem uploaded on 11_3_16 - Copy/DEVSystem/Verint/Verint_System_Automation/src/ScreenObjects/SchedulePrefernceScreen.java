package ScreenObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class SchedulePrefernceScreen {
	
	public static ExtentReports extent = ExtentReports.get(SchedulePrefernceScreen.class);
	
	public static String btnSave="//button[@id='toolbar_CREATE_NEW_ACTIONLabel']";
	public static String btnEdit="toolbar_EDIT_ACTIONLabel";
	public static String btnEditSave="//button[@id='toolbar_SAVE_ACTIONLabel']";
	public static String iconarrow="//button[@id='dayOffPrefs_tb_ASSIGN_RIGHTLabel']";
	
	
	public static boolean selectday(WebDriver driver,String data)
	{
		boolean flag=false;
		try
		{
			//Utilities.selectRightPaneView(driver);
			int size=driver.findElements(By.xpath("//div[@id='dayOffPrefs_srcWrapper']//table[@id='dayOffPrefs_srcTable']//tbody//tr//td//a")).size();
			System.out.println("size is;"+size);
			for(int i=1;i<size;i++)
			{
				
				String day=driver.findElement(By.xpath("//table[@id='dayOffPrefs_srcTable']//tbody[@id='dayOffPrefs_srcTBody']//tr["+i+"]//td["+i+"]//a//span")).getText();
				if(day.equals(data))
				{
					driver.findElement(By.xpath("//table[@id='dayOffPrefs_srcTable']//tbody[@id='dayOffPrefs_srcTBody']//tr["+i+"]//td["+i+"]//a//span")).click();
					
					extent.log(LogStatus.PASS,"day:"+data+" is selected suceesfully");
					flag=true;
					break;
				}
				else
				{
					extent.log(LogStatus.FAIL,"day is not selected suceesfully");
					flag=false;
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();	
		}
		
		return flag;
	}
	
	public static boolean verifyday(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			String day=driver.findElement(By.xpath("//table[@id='dayOffPrefs_dstTable']//tbody[@id='dayOffPrefs_dstTBody']//tr[@class='assignmentList']//td[1]//a//span")).getText();
			System.out.println("day is:"+ day);
			if(day.equals("Sunday"))
			{
				flag=true;
			}
			else
			{
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	
	
	
	public static boolean clickSave(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			//Utilities.selectRightPaneView(driver);
			By saveBtn=By.xpath(btnSave);
			Utilities.waitForPageLoad(driver,saveBtn);
			if (driver.findElements(saveBtn).size()!=0)
			{					
				driver.findElement(saveBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Save button is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Save button is unsuccessful");
				flag=false;
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	
	public static boolean clickArrow(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			//Utilities.selectRightPaneView(driver);
			By arrowicon=By.xpath(iconarrow);
			Utilities.waitForPageLoad(driver,arrowicon);
			if (driver.findElements(arrowicon).size()!=0)
			{					
				driver.findElement(arrowicon).click();
				extent.log(LogStatus.PASS, "Clicked on  arrow icon is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on arrow icon is unsuccessful");
				flag=false;
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clickEditSave(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			//Utilities.selectRightPaneView(driver);
			By saveBtn=By.xpath(btnEditSave);
			Utilities.waitForPageLoad(driver,saveBtn);
			if (driver.findElements(saveBtn).size()!=0)
			{					
				driver.findElement(saveBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Save button is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Save button is unsuccessful");
				flag=false;
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
}

