package ScreenObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class OverTimeScreen
{
	public static ExtentReports extent = ExtentReports.get(OverTimeScreen.class);
	public static String btncreate="//button[@id='toolbar_ADD_ACTIONLabel']";
	public static String txtname="//input[@id='otextension_name_0']";
	public static String txtdesc="//input[@id='otextension_description_0']";
	public static String iconactivity="//img[@id='activityID__input_0Button']";
	public static String txtduration="//input[@name='otextensionDurationInMins__input']";
	public static String btnsave="//button[@id='toolbar_CREATE_NEW_ACTIONLabel']";
	
	
	
	public static boolean  clickcreate(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By createbtn=By.xpath(btncreate);
			Utilities.waitForPageLoad(driver,createbtn);
			if(driver.findElements(createbtn).size()!=0)
			{
				driver.findElement(createbtn).click();
				extent.log(LogStatus.PASS,"clicked on create button is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"not able to click on create button");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean  setName(WebDriver driver,String data)
	{
		boolean flag=false;
		try
		{
			//Utilities.selectRightPaneView(driver);
			By name=By.xpath(txtname);
			Utilities.waitForPageLoad(driver,name);
			if(driver.findElements(name).size()!=0)
			{
				driver.findElement(name).sendKeys(data);
				extent.log(LogStatus.PASS,"Name is entered successfully");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"Name is not entered successfully");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean  setDesc(WebDriver driver,String data)
	{
		boolean flag=false;
		try
		{
			//Utilities.selectRightPaneView(driver);
			By desc=By.xpath(txtdesc);
			Utilities.waitForPageLoad(driver,desc);
			if(driver.findElements(desc).size()!=0)
			{
				driver.findElement(desc).sendKeys(data);
				extent.log(LogStatus.PASS,"Description is entered successfully");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"Description is not entered successfully");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean  SetActivity(WebDriver driver,String Activity)
	{
		boolean flag=false;
		try
		{
			//Utilities.selectRightPaneView(driver);
			By activityicon=By.xpath(iconactivity);
			Utilities.waitForPageLoad(driver,activityicon);
			if(driver.findElements(activityicon).size()!=0)
			{
				driver.findElement(activityicon).click();
				Select sbox=new Select(driver.findElement(By.id("activityID__input")));
				sbox.selectByVisibleText(Activity);
				extent.log(LogStatus.PASS,"Activity:" +Activity+"is selected successfully");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"Activity is not selected successfully");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean  setDuration(WebDriver driver,String data)
	{
		boolean flag=false;
		try
		{
			//Utilities.selectRightPaneView(driver);
			By duration=By.xpath(txtduration);
			Utilities.waitForPageLoad(driver,duration);
			if(driver.findElements(duration).size()!=0)
			{
				//driver.findElement(duration).clear();
				driver.findElement(duration).sendKeys(data);
				extent.log(LogStatus.PASS,"Duration is entered successfully");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"Duration is not entered successfully");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean  clickSave(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By savebtn=By.xpath(btnsave);
			Utilities.waitForPageLoad(driver,savebtn);
			if(driver.findElements(savebtn).size()!=0)
			{
				driver.findElement(savebtn).click();
				extent.log(LogStatus.PASS,"clicked on save button is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"not able to click on save button");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean OverTimeExist(WebDriver driver,String overtime)
	{
		
		boolean Temp=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			List<WebElement> li=driver.findElements(By.xpath("//table[@id='otExtensionTableRef']//tr[@class='tblRow']"));
	    	System.out.println("++++"+ li.size());
	    	if(driver.findElements(By.xpath("//table[@id='otExtensionTableRef']//tr[@class='tblRow']//td")).size()!=0)
	    	{
	    		for(WebElement elt:li)
	        	{
	        		//System.out.println("**************");
	        		System.out.println(elt.findElement(By.tagName("td")).getAttribute("innerText"));
	        		String oname=elt.findElement(By.tagName("td")).getAttribute("innerText");
	        		if(oname.contains(overtime))
	        		{
	        			System.out.println("OverTime Name is"+oname);
	        			Temp=true;
	        			break;
	        		}
	        	}
	    	}
	    	else
	    	{
	    		Temp=false;
	    	}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	    	return Temp;
	    	
		
    	
	}
	
}

