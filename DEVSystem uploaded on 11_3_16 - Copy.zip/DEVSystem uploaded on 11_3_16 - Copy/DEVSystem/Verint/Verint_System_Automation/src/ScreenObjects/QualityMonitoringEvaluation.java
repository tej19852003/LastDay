package ScreenObjects;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.sikuli.script.Screen;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class QualityMonitoringEvaluation {

	public static ExtentReports extent = ExtentReports.get(Impact360Screen.class);
	public static Screen sobj = new Screen ();
	public static String lstAvailableEvaluators="dfd_MS_catED__ctl2_ctrlLS_dlstGroupUsers";
	public static String iconEvalDataRightArrow="//a[@id='dfd_MS_catED__ctl2_ctrlLS_add_add']";
	public static String iconremark="//table[@id='remarkMainTable']//tbody//tr//td//a//img[@id='CollapseImage']";
	public static String txtremark="//textarea[@id='remarkText']";
	public static String btnsave="//a[@id='saveBtn_saveBtn']";
	
	public static boolean verifyEvaluationsStartTime(WebDriver driver) throws Exception
	{
		Thread.sleep(4000);		
	    Boolean flag=false;	   
	    String Agent="";
		
	    if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_No.png")==null)
		{
			Thread.sleep(5000);
			driver.switchTo().defaultContent();
			driver.switchTo().frame(0);
			Thread.sleep(2000);	
		    driver.switchTo().frame("Grid");		   
		    Thread.sleep(2000);	
			int rcCall=driver.findElements(By.xpath("//table[@id='POG1']/tbody/tr")).size();
			System.out.println("callRC:"+rcCall);			
			if (rcCall>1)
			{
				extent.log(LogStatus.PASS, "Evaluations results are displayed successfully");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QMCall"));
				flag=true;			
			}
			else
			{
				extent.log(LogStatus.FAIL,"Evaluations results were not displayed");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "QMCall"));
				return flag =false;
			}				
		}
		else
		{
			extent.log(LogStatus.FAIL, "Message : No Evaluations were found. is diplayed ");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "QMCall"));	
			return flag=false;
		}  
	    return flag;   
	}
	
	public static boolean evaluationdata_click_RightArrow(WebDriver driver) throws Exception  
	{
		boolean flag=false;
		try{
			By rtArrowIcon=By.xpath(iconEvalDataRightArrow);
			driver.switchTo().defaultContent();
			driver.switchTo().frame(2);				
			Thread.sleep(2000);
			Utilities.waitForPageLoad(driver,rtArrowIcon);
			if (driver.findElements(rtArrowIcon).size()!=0)
			{			
				if (driver.findElement(rtArrowIcon).isEnabled())
				{
					driver.findElement(rtArrowIcon).click();				
					extent.log(LogStatus.INFO, "Clicked on Evaluation Data Right Arrow is successful");
					Thread.sleep(3000);
					flag=true;
				}
				else
				{
					extent.log(LogStatus.WARNING, "Clicked on Evaluation Data Right Arrow is UNsuccessful");
					 return flag=false;
				}
			}else
			{
				extent.log(LogStatus.WARNING, "Clicked on Evaluation Data Right Arrow is UNsuccessful");
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean evaluationdata_SelectOption_AvailableEvaluators(WebDriver driver,String Evaluator) throws Exception
	{
		
		boolean flag=false;
		Thread.sleep(3000);
		driver.switchTo().defaultContent();
		driver.switchTo().frame(2);			
		Thread.sleep(3000);
		 Evaluator=Evaluator.toUpperCase();
		 WebElement sel = driver.findElement(By.id(lstAvailableEvaluators));
		 List<WebElement> lists = sel.findElements(By.tagName("option"));
		 if (lists.size()!=0)
		 {			 	
			 System.out.println("Evaluators items count :"+lists.size());
		     for(WebElement element: lists)  
		     {
		         String lstValues = element.getText();
		         System.out.println("valueApp:"+lstValues);
		         System.out.println("value:"+Evaluator);
		         if (lstValues.contains(Evaluator))
		         {
		        	element.click();
		        	extent.log(LogStatus.PASS,"Evaluator:"+Evaluator+" selected");
		        	Thread.sleep(5000);
		        	flag=true;
		        	break;
		         }		       
		     }
		 }
		 else
		 {
			 extent.log(LogStatus.FAIL,"No items/Not able to select option from Evaluators");
			 return flag=false;
		 }
		 if (flag==false)
		 {
			 extent.log(LogStatus.FAIL,"No items/Not able to select option from Evaluators");
		 }
		 return flag;
		
		
	}
	
	public static boolean evaluationdata_SelectOption_AvailableGroups(WebDriver driver) throws Exception //selects statefarm as of now
	{
		Boolean flag=false;		
		driver.switchTo().defaultContent();
		Thread.sleep(1000);
		driver.switchTo().frame(2);			
		Thread.sleep(1000);
		
		if (driver.findElements(By.xpath("//div[@id='dfd_MS_catED__ctl2_ctrlLS_Groups_TreeView']/table[@id='Table1']/tbody/tr/td[1]/table[@id='Table2']/tbody/tr/td[3]")).size()!=0)
		{
			driver.findElement(By.xpath("//div[@id='dfd_MS_catED__ctl2_ctrlLS_Groups_TreeView']/table[@id='Table1']/tbody/tr/td[1]/table[@id='Table2']/tbody/tr/td[3]")).click();	
			extent.log(LogStatus.PASS,"Available Groups : Statefarm is selected");
			flag=true;
		}
		else
		{
			extent.log(LogStatus.FAIL,"Available Groups : Statefarm is NOT selected");
		}	
		return flag;
	}
	
	public static boolean selectEvaluationsStartTime(WebDriver driver) throws Exception
	{
		Thread.sleep(4000);		
	    Boolean flag=false;
	    String callName="";
	   		
	    if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_No.png")==null)
		{
			Thread.sleep(5000);
			driver.switchTo().defaultContent();
			/*driver.switchTo().frame(0);
			Thread.sleep(2000);	
		    driver.switchTo().frame(3);		   
		    Thread.sleep(2000);	
		    driver.switchTo().frame(1);*/
		    
		    Utilities.switchFrame(driver,"FR_GRID");
		    Thread.sleep(2000);	
		    Utilities.switchFrame(driver,"Grid");
		    Thread.sleep(2000);	
		    Utilities.switchFrame(driver,"GridPage");
		    Thread.sleep(2000);	   
		    
		   /* if (driver.findElements(By.xpath("//table[@id='POG1']")).size()!=0)
		    {
		    	extent.log(LogStatus.FAIL,"No Evaluations were found displayed");
		    	return flag =false;
		    }*/
			int rcCall=driver.findElements(By.xpath("//table[@id='POG1']/tbody/tr")).size();
			System.out.println("callRC:"+rcCall);			
			if (rcCall>1)
			{
				extent.log(LogStatus.PASS, "Contact results are displayed successfully");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QMCall"));
				flag=true;			
			}
			else
			{
				extent.log(LogStatus.WARNING,"No Evaluations were found displayed");
				extent.log(LogStatus.WARNING, "", "", Utilities.captureScreenShot(driver, "QMCall"));
				return flag =false;
			}				
		}
		else
		{
			extent.log(LogStatus.FAIL, "Message : No drafts/Evaluations were found.");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "QMCall"));	
			return flag=false;
		}  
	    
	    
		int rcCall=driver.findElements(By.xpath("//table[@id='POG1']/tbody/tr")).size();
		System.out.println("callRC:"+rcCall);
		int j;
		if (rcCall>1)
		{
			for (j=2;j<=rcCall;j++)
			{	
				driver.manage().window().maximize();									
				callName=driver.findElement(By.xpath("//table[@id='POG1']/tbody/tr["+j+"]/td[1]/a")).getText().trim();
				System.out.println("callName:"+callName);		
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QMCall"));
				driver.findElement(By.xpath("//table[@id='POG1']/tbody/tr["+j+"]/td[1]/a")).click();
				//extent.log(LogStatus.PASS,"Call Name - "+callName+" selected successfully");
				flag=true;
				break;		
			}
		}		
		if (flag==true)
		{
			System.out.println("pass");
			extent.log(LogStatus.PASS, "Contact Start Link Name: "+callName+" selected successfully");
			extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QMCall"));				
		}	
		else
		{
			extent.log(LogStatus.WARNING, "Not able to select Evaluations Start time link");
			flag=false;
		}
		return flag; 
	}
	public static boolean selectDraftEvaluationStartTime(WebDriver driver) throws Exception
	{
		Thread.sleep(4000);		
	    Boolean flag=false;
	    String callName="";
	   		
	    if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_No.png")==null)
		{
			Thread.sleep(5000);
			driver.switchTo().defaultContent();
			driver.switchTo().frame(0);
			Thread.sleep(2000);	
		    driver.switchTo().frame(3);		   
		    Thread.sleep(2000);	
		    //driver.switchTo().frame(1);
			int rcCall=driver.findElements(By.xpath("//table[@id='POG1']/tbody/tr")).size();
			System.out.println("callRC:"+rcCall);			
			if (rcCall>1)
			{
				extent.log(LogStatus.PASS, "Contact results are displayed successfully");
				//extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QMCall"));
				flag=true;			
			}
			else
			{
				extent.log(LogStatus.FAIL,"No Evaluations were found displayed");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "QMCall"));
				return flag =false;
			}				
		}
		else
		{
			extent.log(LogStatus.FAIL, "Message : No drafts/Evaluations were found.");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "QMCall"));	
			return flag=false;
		}  
	    
	    
		int rcCall=driver.findElements(By.xpath("//table[@id='POG1']/tbody/tr")).size();
		System.out.println("callRC:"+rcCall);
		int j;
		if (rcCall>1)
		{
			for (j=2;j<=rcCall;j++)
			{	
				driver.manage().window().maximize();									
				callName=driver.findElement(By.xpath("//table[@id='POG1']/tbody/tr["+j+"]/td[1]/a")).getText().trim();
				System.out.println("callName:"+callName);		
				//extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QMCall"));
				driver.findElement(By.xpath("//table[@id='POG1']/tbody/tr["+j+"]/td[1]/a")).click();
				//extent.log(LogStatus.PASS,"Call Name - "+callName+" selected successfully");
				flag=true;
				break;		
			}
		}		
		if (flag==true)
		{
			System.out.println("pass");
			extent.log(LogStatus.PASS, "Contact Start Link Name: "+callName+" selected successfully");
			extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QMCall"));				
		}	
		else
		{
			extent.log(LogStatus.WARNING, "Not able to select Evaluations Start time link");
			flag=false;
		}
		return flag; 
	}
	
	
	public static boolean clickremark(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			By iconrmk=By.xpath(iconremark);
			driver.switchTo().defaultContent();
			Utilities.switchFrame(driver, "FR_PLAYBACK");
			Thread.sleep(1000);
			Utilities.switchFrame(driver, "FR_REMARK");
			Utilities.waitForPageLoad(driver,iconrmk);
			if(driver.findElements(iconrmk).size()!=0)
			{
				driver.findElement(iconrmk).click();
				extent.log(LogStatus.INFO,"clicked on arrow is successfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.INFO,"clicked on arrow is not successfull");
				flag=false;
				
			}
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean setremark(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			By txtrmk=By.xpath(txtremark);
			driver.switchTo().defaultContent();
			Utilities.switchFrame(driver, "FR_PLAYBACK");
			Thread.sleep(2000);
			driver.switchTo().frame("FR_REMARK");
			Utilities.waitForPageLoad(driver,txtrmk);
			if(driver.findElements(txtrmk).size()!=0)
			{
				driver.findElement(txtrmk).click();
				Robot r=new Robot();
				r.keyPress(KeyEvent.VK_SHIFT);
				r.keyPress(KeyEvent.VK_T);
				r.keyRelease(KeyEvent.VK_T);
				r.keyRelease(KeyEvent.VK_SHIFT);
				extent.log(LogStatus.PASS," Data is entered sucessfully");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"value is not enetred");
				flag=false;
				
			}
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean verifyRemark(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			By txtrmk=By.xpath(txtremark);
			driver.switchTo().defaultContent();
			Utilities.switchFrame(driver, "FR_PLAYBACK");
			Thread.sleep(2000);
			driver.switchTo().frame("FR_REMARK");
			Utilities.waitForPageLoad(driver,txtrmk);
			
				String text=driver.findElement(txtrmk).getText();
				if(text.equals("T"))
				{
					extent.log(LogStatus.PASS,"T is eneterd sucessfully");
					flag=true;
				}
				
			
			else
			{
				extent.log(LogStatus.FAIL,"value is not enetred");
				flag=false;
				
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickSave(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			By savebtn=By.xpath(btnsave);
			driver.switchTo().defaultContent();
			Utilities.switchFrame(driver, "FR_PLAYBACK");
			Thread.sleep(2000);
			driver.switchTo().frame("FR_REMARK");
			Utilities.waitForPageLoad(driver,savebtn);
			if(driver.findElements(savebtn).size()!=0)
			{
				driver.findElement(savebtn).click();
				extent.log(LogStatus.PASS,"clicked on save button is successfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"not able to click on save button");
				flag=false;
				
			}
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	}
