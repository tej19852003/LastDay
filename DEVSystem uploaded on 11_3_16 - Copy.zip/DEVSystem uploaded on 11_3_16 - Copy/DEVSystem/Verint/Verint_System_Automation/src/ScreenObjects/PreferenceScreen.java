package ScreenObjects;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import com.relevantcodes.extentreports.LogStatus;
import Utilities.Utilities;
import com.relevantcodes.extentreports.ExtentReports;


public class PreferenceScreen {
	
	public static ExtentReports extent = ExtentReports.get(PreferenceScreen.class);	
	public static String setvalues="//select[@name='lstAvailableColumns']";
	public static String unsetvalues="//select[@name='lstCurrentColumns']";
	public static String btnok="//a[@title='OK']";
	
	
	
	public static boolean selectserachcriteria(WebDriver driver,String criteria)
	{
		boolean flag=false;
		try
		{
			driver.switchTo().defaultContent();
			Utilities.switchFrame(driver,"FR_GRID");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"main");
			Thread.sleep(2000);
			By values=By.xpath(setvalues);
			if(driver.findElements(values).size()!=0)
			{
				Select sbox=new Select(driver.findElement(values));
				sbox.selectByVisibleText(criteria);
				driver.findElement(By.xpath("//img[@id='btnRemoveToAvailableColumns']")).click();
				extent.log(LogStatus.PASS,"Search criteria:"+criteria+"is added to current colums list");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"Search criteria:"+criteria+"is not added to current colums list");
				flag=false;
			}
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickok(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			driver.switchTo().defaultContent();
			driver.switchTo().frame("FR_GRID");
			Thread.sleep(2000);
			driver.switchTo().frame("header");
			Thread.sleep(2000);
			By okbtn=By.xpath(btnok);
			Utilities.waitForPageLoad(driver,okbtn);
			if(driver.findElements(okbtn).size()!=0)
			{
				driver.findElement(okbtn).click();
				extent.log(LogStatus.PASS,"click on OK button is sucessffull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"not able to click on OK button");
				flag=false;
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean deselectserachcriteria(WebDriver driver,String criteria)
	{
		boolean flag=false;
		try
		{
			driver.switchTo().defaultContent();
			Utilities.switchFrame(driver,"FR_GRID");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"main");
			Thread.sleep(2000);
			By values=By.xpath(unsetvalues);
			if(driver.findElements(values).size()!=0)
			{
				Select sbox=new Select(driver.findElement(values));
				sbox.selectByVisibleText(criteria);
				driver.findElement(By.xpath("//img[@id='btnAddToCurrentColumns']")).click();
				extent.log(LogStatus.PASS,"Search criteria:"+criteria+"is added to available colums list");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"Search criteria:"+criteria+"is not added to available colums list");
				flag=false;
			}
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
}
