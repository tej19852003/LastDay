package ScreenObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class CalendarScreen 
{
	public static ExtentReports extent = ExtentReports.get(WorkQueuesScreen.class);
	public static String iconCampaign="//span[@id='campaignSPPeopleFilterBox_listbox_0Wrapper']/nobr/img[@id='campaignSPPeopleFilterBox_listbox_0Button']";
	public static String iconPeriod="//span[@id='schedulingPeriodID_0Wrapper']/nobr/img[@id='schedulingPeriodID_0Button']";
	public static String linkagent="//div[@id='psWrapper']//table[@id='psLIST_TBL_NAME']//tbody//tr//td//div[@class='tableRowSelected']//a//span[contains(text(),'test2, test1')]";
	public static String iconphantom="//div[@id='workAreaWrapper']//table[@id='selectionHdr_tbl_id']//tbody//tr//td[3]//span[@class='imageButtonContainer']//img[contains(@alt,'Show Phantoms']";
	public static String selectallbtn="//button[@id='selectionMediator_toolbar_SELECT_ALLLabel']";
	public static String btnview="//button[@id='selectionMediator_toolbar_SUBMITLabel']";
	
	
	/*public static boolean selectCampaign(WebDriver driver,String CampaignName) throws Exception
	{
		boolean flag=true;
		try{
			
			Utilities.selectLeftTreeFrame(driver);
			By iconCamp=By.id(iconCampaign);
			Utilities.waitForPageLoad(driver,iconCamp);
			if (driver.findElements(iconCamp).size()!=0)
			{					
				driver.findElement(iconCamp).click();
				Thread.sleep(1000);
				Select sbox=new Select(driver.findElement(By.id("campaignSPPeopleFilterBox_listbox")));
				sbox.selectByVisibleText(CampaignName);
				Thread.sleep(3000);				
				extent.log(LogStatus.INFO, "Campaign Name:"+CampaignName+" is selected from View Listbox");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Not able to select Campaign Name:"+CampaignName+" from View Listbox");
				return flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}*/
	
	
	public static boolean selectCampaign(WebDriver driver,String CampaignName) throws Exception
	{
		boolean flag=true;
		try{
			
			Utilities.selectLeftTreeFrame(driver);
			By iconCamplst=By.xpath(iconCampaign);
			Utilities.waitForPageLoad(driver,iconCamplst);
			if (driver.findElements(iconCamplst).size()!=0)
			{					
				driver.findElement(iconCamplst).click();
				Thread.sleep(1000);
				driver.findElement(iconCamplst).sendKeys(CampaignName);
				Thread.sleep(3000);				
				extent.log(LogStatus.INFO, "Campaign Name:"+CampaignName+" is selected from View Listbox");				
			}else
			{
				extent.log(LogStatus.FAIL, "Not able to select Campaign Name:"+CampaignName+" from View Listbox");
				return flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean selectPeriod(WebDriver driver,String Period) throws Exception
	{
		boolean flag=true;
		try{			
			Utilities.selectLeftTreeFrame(driver);
			By iconSchPeriod=By.xpath(iconPeriod);
			Utilities.waitForPageLoad(driver,iconSchPeriod);
			if (driver.findElements(iconSchPeriod).size()!=0)
			{					
				driver.findElement(iconSchPeriod).click();
				Thread.sleep(1000);
				Select sbox1=new Select(driver.findElement(By.id("schedulingPeriodID")));
				sbox1.selectByVisibleText(Period);
				//driver.findElement(iconSchPeriod).sendKeys(Period);
				Thread.sleep(3000);				
				extent.log(LogStatus.INFO, "Period:"+Period+" is selected from View Listbox");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Not able to select Period:"+Period+" from View Listbox");
				return flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	/*public static boolean selectPeriod(WebDriver driver,String Period) throws Exception
	{
		boolean flag=true;
		try{			
			Utilities.selectLeftTreeFrame(driver);
			By iconPeriodlst=By.xpath(iconPeriod);
			Utilities.waitForPageLoad(driver,iconPeriodlst);
			if (driver.findElements(iconPeriodlst).size()!=0)
			{					
				driver.findElement(iconPeriodlst).click();
				Thread.sleep(1000);
				driver.findElement(iconPeriodlst).sendKeys(Period);
				Thread.sleep(3000);				
				extent.log(LogStatus.INFO, "Period:"+Period+" is selected from View Listbox");				
			}else
			{
				extent.log(LogStatus.FAIL, "Not able to select Period:"+Period+" from View Listbox");
				return flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}*/
	/*public static boolean selectEmployee(WebDriver driver,String EmployeeName)
	{
		boolean flag=false;
		try
		{
			Utilities.selectLeftTreeFrame(driver);
			By linkemp=By.xpath(linkagent);
			Utilities.waitForPageLoad(driver,linkemp);
			if(driver.findElements(linkemp).size()!=0)
			{
				String empName=driver.findElement(linkemp).getText();
				if(empName.contains(EmployeeName))
				{
					driver.findElement(linkemp).click();
					extent.log(LogStatus.PASS,"employee"+ EmployeeName +" is selected");
				}
				
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"employee"+ EmployeeName +" is  not selected");
				flag= false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		 return flag;
		
		
	}*/
	
	
	public static boolean SelectEmployee(WebDriver driver,String EmployeeName) throws Exception
	{
		boolean flag=false;
		Utilities.selectLeftTreeFrame(driver);
		int no= driver.findElements(By.xpath("//div[@id='psWrapper']//table[@id='psLIST_TBL_NAME']//tbody//tr")).size();
		System.out.println("no of rows are:" + no);
		//String empname=driver.findElement(By.xpath("//table[@id='psLIST_TBL_NAME']//tbody//tr[1]//td[2]//div//nobr//a")).getText();
		for(int i=1;i<=no;i++)
		{
			String empname=driver.findElement(By.xpath("//table[@id='psLIST_TBL_NAME']//tbody//tr["+i+"]//td//div//nobr//a")).getText();
			System.out.println("emp name is:"+ empname );
			if(empname.contains(EmployeeName))
			{
				driver.findElement(By.xpath("//table[@id='psLIST_TBL_NAME']//tbody//tr["+i+"]//td//div//nobr//a")).click();
				Thread.sleep(2000);
				flag=true;
				break;
				
			}
			
		}
		if(flag==true)
		{
			extent.log(LogStatus.PASS,EmployeeName +"is selected sucessfully");
		}
		else
		{
			extent.log(LogStatus.FAIL,EmployeeName + " does not exist");
			return flag=false;
		}
		return flag;
	
	}
	
	public static boolean Selctallemp(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectLeftTreeFrame(driver);
			By selectbtn=By.xpath(selectallbtn);
			Utilities.waitForPageLoad(driver,selectbtn);
			if(driver.findElements(selectbtn).size()!=0)
			{
				driver.findElement(selectbtn).click();
				flag=true;
				extent.log(LogStatus.PASS,"clicked on select all button is sucessfull");
				
			}
			else
			{
				extent.log(LogStatus.FAIL,"clicked on select all button is  unsucessfull");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clickViewbtn(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectLeftTreeFrame(driver);
			By viewbtn=By.xpath(btnview);
			Utilities.waitForPageLoad(driver,viewbtn);
			if(driver.findElements(viewbtn).size()!=0)
			{
				driver.findElement(viewbtn).click();
				flag=true;
				extent.log(LogStatus.PASS,"clicked on view  button is sucessfull");
				
			}
			else
			{
				extent.log(LogStatus.FAIL,"clicked on view button is  unsucessfull");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean clickPhantomIcon(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectLeftTreeFrame(driver);
			By phantomimg=By.xpath(iconphantom);
			Utilities.waitForPageLoad(driver,phantomimg);
			if(driver.findElements(phantomimg).size()!=0)
			{
				driver.findElement(phantomimg).click();
				flag=true;
				extent.log(LogStatus.PASS,"claicked on phantom icon is sucessfull");
			}
			else
			{
				extent.log(LogStatus.FAIL,"Not able to click on phantom icon.");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
}
