package ScreenObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import com.thoughtworks.selenium.webdriven.commands.GetText;

public class RotationScreeen 
{
	public static ExtentReports extent = ExtentReports.get(WorkQueuesScreen.class);
	public static String btncreate="//button[@id='toolbar_ADD_ACTIONLabel']";
	public static String txtname="//input[@name='_rotationName']";
	public static String btnadd="//button[@id='workPatternList_toolbar_POPUP_WorkPatternSelectionLabel']";
	public static String btnsave="//button[@id='toolbar_CREATE_NEW_ACTIONLabel']";
	
	
	public static boolean clickCreate(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By btncreaterot=By.xpath(btncreate);
			Utilities.waitForPageLoad(driver,btncreaterot);
			if(driver.findElements(btncreaterot).size()!=0)
			{
				driver.findElement(btncreaterot).click();
				extent.log(LogStatus.PASS,"clicked on create button is sucessfull");
				Thread.sleep(6000);
				flag = true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"clicked on create button is not sucessfull");
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return flag;
	}
	
	
	public static boolean setRotationName(WebDriver driver,String name)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By namerotation=By.xpath(txtname);
			Utilities.waitForPageLoad(driver,namerotation);
			if(driver.findElements(namerotation).size()!=0)
			{
				driver.findElement(namerotation).sendKeys(name);
				extent.log(LogStatus.PASS,"value :"+ name +"is enterd in text box");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"Not able to enter values in text box");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickAdd(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By btnAddwp=By.xpath(btnadd);
			Utilities.waitForPageLoad(driver,btnAddwp);
			if(driver.findElements(btnAddwp).size()!=0)
			{
				driver.findElement(btnAddwp).click();
				extent.log(LogStatus.PASS,"clicked on Add work pattern is sucessfull");
				Thread.sleep(6000);
				flag = true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"clicked on add work pattren is not sucessfull");
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return flag;
	}
	
	
	
	
public static  boolean clickAddworkPattern(WebDriver driver,String workPatternName)
	
	{
		boolean flag=false;
		try
	{
		
       
		int no=driver.findElements(By.xpath("//div[@id='tableWrapper']//table[@id='tableRef']//tr")).size();
		System.out.println("no of rows are:" + no);
		for(int i=1;i<no;i+=2)
		{
			String wpname=driver.findElement(By.xpath("//div[@id='tableWrapper']//table[@id='tableRef']//tr[contains(@id,'tabler"+i+"')]//td[contains(@id,'tabler"+i+"c1')]")).getText();
			System.out.println("shift name is:" + wpname);
			if(wpname.contains(workPatternName))
			{
				driver.findElement(By.xpath("//div[@id='tableWrapper']//table[@id='tableRef']//tr[contains(@id,'tabler"+i+"')]//td[contains(@id,'tabler"+i+"c1')]")).click();
				break;
			}
		}
		driver.findElement(By.xpath("//button[@id='workpaneMediator_toolbar_ADDLabel']")).click();
		flag=true;								  
	}catch(Exception e)
	{
		e.printStackTrace();
	}
		return flag;
		
		
	}



public static boolean WorkPatternexist(WebDriver driver,String Wname) throws Exception
{
	Utilities.selectRightPaneView(driver);
	boolean Temp=false;
	
	List<WebElement> li=driver.findElements(By.xpath("//table[@id='workPatternList_tableRef']//tr[@class='tblRow']"));
	System.out.println("++++"+ li.size());
	if(driver.findElements(By.xpath("//table[@id='workPatternList_tableRef']//tr[@class='tblRow']//th")).size()!=0)
	{
		for(WebElement elt:li)
    	{
    		//System.out.println("**************");
    		System.out.println(elt.findElement(By.tagName("th")).getAttribute("innerText"));
    		String wname=elt.findElement(By.tagName("th")).getAttribute("innerText");
    		if(wname.contains(Wname))
    		{
    			System.out.println("work pattern name is"+wname);
    			Temp=true;
    			break;
    		}
    	}
	}
	else
	{
		Temp=false;
	}
	return Temp;
	
}




public static boolean clickSave(WebDriver driver)
{
	boolean flag=false;
	try
	{
		Utilities.selectRightPaneView(driver);
		By btnsaverot=By.xpath(btnsave);
		Utilities.waitForPageLoad(driver,btnsaverot);
		if(driver.findElements(btnsaverot).size()!=0)
		{
			driver.findElement(btnsaverot).click();
			extent.log(LogStatus.PASS,"clicked on save button is sucessfull");
			Thread.sleep(6000);
			flag = true;
		}
		else
		{
			extent.log(LogStatus.FAIL,"clicked on save button is not sucessfull");
			
		}
	}catch(Exception e)
	{
		e.printStackTrace();
	}
	
	return flag;
}


public static boolean Rotationexist(WebDriver driver,String RotationName) throws Exception
{
	Utilities.selectRightPaneView(driver);
	boolean Temp=false;
	driver.findElement(By.name("itemToFind")).clear();
	driver.findElement(By.name("itemToFind")).sendKeys(RotationName);
	driver.findElement(By.xpath("//button[@id='toolbar_FIND_ACTIONLabel']")).click();
	Thread.sleep(2000);
	List<WebElement> li=driver.findElements(By.xpath("//table[@id='tableRef']//tr[@class='tblRow']"));
	System.out.println("++++"+ li.size());
	if(driver.findElements(By.xpath("//table[@id='tableRef']//tr[@class='tblRow']//th")).size()!=0)
	{
		for(WebElement elt:li)
    	{
    		//System.out.println("**************");
    		System.out.println(elt.findElement(By.tagName("th")).getAttribute("innerText"));
    		String wname=elt.findElement(By.tagName("th")).getAttribute("innerText");
    		System.out.println("rotation name is:"+wname);
    		if(wname.contains(RotationName))
    		{
    			System.out.println("rotation name is"+wname);
    			Temp=true;
    			break;
    		}
    	}
	}
	else
	{
		Temp=false;
	}
	return Temp;
	
}


}
