package ScreenObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.LogStatus;
import Utilities.Utilities;
import com.relevantcodes.extentreports.ExtentReports;


public class RolesSetupScreen {
	
	public static ExtentReports extent = ExtentReports.get(RolesSetupScreen.class);	
	public static Screen sobj = new Screen ();
	public static String frameTreeViewLeftPane="oLeftPaneContent";
	public static String frameRightPaneView="oRightPaneContent";
	public static String btnCreateNewRole="//button[@id='toolbar_ADD_ACTIONLabel']";
	public static String btnCreateNewRoleFromExisting="//button[@id='toolbar_CREATE_FROM_EXISTING_ACTIONLabel']";
	public static String btnViewEditRole="//button[@id='toolbar_EDIT_ACTIONLabel']";
	public static String btnDeleteRole="//button[@id='toolbar_DELETE_ACTIONLabel']";
	public static String btnContinue="//button[@id='workpaneMediator_toolbar_CONFIRMED_DELETE_ACTIONLabel']";
	public static String btnContinueDeleteRole="//button[@id='workpaneMediator_toolbar_CONFIRMED_DELETE_ACTIONLabel']";
	
	public static boolean clickContinueDeleteRole(WebDriver driver) throws Exception
	{
		boolean flag=true;
		try{
			By btnDelete=By.xpath(btnContinueDeleteRole);
			Utilities.waitForPageLoad(driver,btnDelete);
			if (driver.findElements(btnDelete).size()!=0)
			{					
				driver.findElement(btnDelete).click();
				Thread.sleep(5000);
				extent.log(LogStatus.INFO, "Clicked on Continue - Delete Role button is successful");
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Continue_DeleteRole.png")!=null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Continue_DeleteRole.png");
					Thread.sleep(5000);
				}				
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean verifyRoleNameModules(WebDriver driver,String RoleName,String ModuleName) throws Exception
	{
		Boolean Temp1=false;
		Boolean Temp=false;
		String modName="";
		try {
			int valrcPriv=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr")).size();
			//System.out.println("valrcPriv:"+valrcPriv);
			for (int j=1;j<=valrcPriv;j++)
			{
				if (j<=15)
				{
				String rolenameApp=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/th/a/span")).getText().trim();
				//System.out.println("rolenameApp:"+rolenameApp);
				//System.out.println("rolemeCreated:"+RoleName);
				Thread.sleep(1000);
				if (rolenameApp.contains(RoleName))
				{
					driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/th/a/span")).click();
					Temp=true;
					modName=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/td[4]")).getText().trim();
					if (modName.contains(ModuleName))
					{
						Temp1=true;
						break;
					}
				}}
			}
			if (Temp==true)
			{
				//System.out.println("pass");
				extent.log(LogStatus.PASS, "Role Name: "+RoleName+" Created/Selected successfully");
				//String imgRole=Utilities.captureScreenShot(driver, "Role");				
				//extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Role"));								
			}
			else
			{
				extent.log(LogStatus.FAIL, "Unable to Create/Select Role Name: "+RoleName);
				//String imgRole=Utilities.captureScreenShot(driver, "Role");				
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Role"));
				return Temp1 =false;
			}
			if (Temp1==true)
			{				
				extent.log(LogStatus.PASS, "Module Name: "+ModuleName+" found in "+modName);							
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Role"));								
			}
			else
			{
				extent.log(LogStatus.FAIL, "Module Name: "+ModuleName+" NOT found in "+modName);							
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Role"));
				return Temp1 =false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return Temp1;
		
	}
	public static boolean clickContinue(WebDriver driver) throws Exception
	{
		boolean flag=true;
		try{
			Thread.sleep(6000);
			By continueBtn=By.xpath(btnContinue);
			Utilities.waitForPageLoad(driver,continueBtn);
			if (driver.findElements(continueBtn).size()!=0)
			{					
				driver.findElement(continueBtn).click();
				Thread.sleep(3000);
				extent.log(LogStatus.INFO, "Clicked on Continue button is successful");				
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Continue button is unsuccessful");
				return flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickDeleteRole(WebDriver driver) throws Exception
	{
		boolean flag=true;
		try{
			By btnDelete=By.xpath(btnDeleteRole);
			Utilities.waitForPageLoad(driver,btnDelete);
			if (driver.findElements(btnDelete).size()!=0)
			{					
				driver.findElement(btnDelete).click();
				Thread.sleep(3000);
				extent.log(LogStatus.INFO, "Clicked on Delete Role button is successful");
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Delete_OK.png")!=null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Delete_OK.png");
					flag=true;
					Thread.sleep(10000);
					extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "User"));
				}
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Delete Role button is unsuccessful");
				return flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean verifyRoleName(WebDriver driver,String RoleName) throws Exception
	{
		Boolean flag=false;
		try {
			int valrcPriv=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr")).size();
			//System.out.println("valrcPriv:"+valrcPriv);
			for (int j=1;j<=valrcPriv;j++)
			{
				if (j<=15)
				{
				String rolenameApp=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/th/a/span")).getText().trim();
				//System.out.println("rolenameApp:"+rolenameApp);
				//System.out.println("rolemeCreated:"+RoleName);
				Thread.sleep(1000);
				if (rolenameApp.contains(RoleName))
				{
					driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/th/a/span")).click();
					//driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).click();
					flag=true;
					break;
				}}
			}
			if (flag==true)
			{
				//System.out.println("pass");
				extent.log(LogStatus.PASS, "Role Name: "+RoleName+" already exist");								
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Role"));				
			}
			else
			{
				extent.log(LogStatus.INFO, "Role Name: "+RoleName+ " does not exist");
				//String imgRole=Utilities.captureScreenShot(driver, "Role");				
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Role"));
				flag =false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
		
	}
	
	public static boolean clickViewEditRole(WebDriver driver) throws Exception
	{
		boolean flag=true;
		try{
			By btnViewEdit=By.xpath(btnViewEditRole);
			Utilities.waitForPageLoad(driver,btnViewEdit);
			if (driver.findElements(btnViewEdit).size()!=0)
			{					
				driver.findElement(btnViewEdit).click();
				extent.log(LogStatus.INFO, "Clicked on View Edit Role button is successful");
				Thread.sleep(4000);
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on View Edit Role button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickCreateNewRoleFromExisting(WebDriver driver) throws Exception
	{
		boolean flag=true;
		try{
			By btnCreateExisting=By.xpath(btnCreateNewRoleFromExisting);
			Utilities.waitForPageLoad(driver,btnCreateExisting);
			if (driver.findElements(btnCreateExisting).size()!=0)
			{					
				driver.findElement(btnCreateExisting).click();
				extent.log(LogStatus.INFO, "Clicked on Create New Role From Existing button is successful");
				Thread.sleep(4000);
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Create New Role From Existing button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectRoleName(WebDriver driver,String RoleName) throws Exception
	{
		Boolean Temp1=false;
		try {
			int valrcPriv=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr")).size();
			//System.out.println("valrcPriv:"+valrcPriv);
			for (int j=1;j<=valrcPriv;j++)
			{
				if (j<=15)
				{
				String rolenameApp=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/th/a/span")).getText().trim();
				//System.out.println("rolenameApp:"+rolenameApp);
				//System.out.println("rolemeCreated:"+RoleName);
				Thread.sleep(1000);
				if (rolenameApp.contains(RoleName))
				{
					driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/th/a/span")).click();
					//driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).click();
					Temp1=true;
					break;
				}}
			}
			if (Temp1==true)
			{
				//System.out.println("pass");
				extent.log(LogStatus.PASS, "Role Name: "+RoleName+" Created/Selected successfully");
				//String imgRole=Utilities.captureScreenShot(driver, "Role");				
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Role"));								
			}
			else
			{
				extent.log(LogStatus.FAIL, "Unable to Create/Select Role Name: "+RoleName);
				//String imgRole=Utilities.captureScreenShot(driver, "Role");				
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Role"));
				Temp1 =false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return Temp1;
		
	}
	
	public static boolean clickCreateNewRole(WebDriver driver) throws Exception
	{
		boolean flag=true;
		try{
			By btnCreate=By.xpath(btnCreateNewRole);
			Utilities.waitForPageLoad(driver,btnCreate);
			if (driver.findElements(btnCreate).size()!=0)
			{					
				driver.findElement(btnCreate).click();
				extent.log(LogStatus.INFO, "Clicked on Create New Role button is successful");
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Create New Role button is unsuccessful");
				return flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static void selectRightPaneView(WebDriver driver) throws Exception
	{
		//boolean flag=true;
		try{
			/*if (driver.findElements(By.id(frameRightPaneView)).size()==0)
				return flag=false;*/
			Thread.sleep(1000);
			driver.switchTo().defaultContent();		
			WebElement oRightPaneContentFrame = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.id(frameRightPaneView)));
			driver.switchTo().frame(oRightPaneContentFrame);
			Thread.sleep(1000);
		}catch (Exception e) {
			e.printStackTrace();
		}	
		//return flag;
	}
	public static boolean selectNodeFromLeftTreePane(WebDriver driver,String nodeName) throws Exception
	{		
		boolean flag=true;
		try {	
			/*if (driver.findElements(By.id("frameTreeViewLeftPane")).size()==0)
				return flag=false;
			
			WebElement leftTreeContentFrame = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.id(frameTreeViewLeftPane)));
			driver.switchTo().frame(leftTreeContentFrame);	*/
			Utilities.selectLeftTreeFrame(driver);
			int rc=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
			//System.out.println("rc:"+rc);
			for (int i=1;i<=rc;i++)
			{
				if (nodeName.contains("state") || nodeName.contains("State"))
				{
					driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr[1]/td/a")).click();
					break;
				}
				if (i<=15)
				{
				String node=driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+i+"]/td/a")).getText();
				if (node.contains(nodeName))
				{
					driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+i+"]/td/a")).click();
					//System.out.println("statefarm node is selected");
					
					flag=true;
					//captureScreenShot(driver,"StateFarm node");
					break;
				}}
			}
			if (flag==true)
			{
				extent.log(LogStatus.INFO, nodeName+" node is selected");
			}
			else
			{
				extent.log(LogStatus.FAIL, nodeName+" node is NOT selected");
				return flag=false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
					
	}
	

}
