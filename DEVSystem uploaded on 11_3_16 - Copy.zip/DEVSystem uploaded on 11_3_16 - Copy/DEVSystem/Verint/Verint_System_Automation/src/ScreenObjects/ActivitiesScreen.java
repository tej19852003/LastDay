package ScreenObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class ActivitiesScreen {
	
	public static ExtentReports extent = ExtentReports.get(ActivitiesScreen.class);
	public static String btnCreateActivity="//button[@id='toolbar_ADD_ACTIONLabel']";
	public static String txtActivityName="activityName";
	public static String txtActivityDesc="activityDescription";
	public static String btnSave="//button[@id='toolbar_CREATE_NEW_ACTIONLabel']";
	public static String btnDeleteActivity="//button[@id='toolbar_DELETE_ACTIONLabel']";
	public static String iconacttype="//span[@id='activityType_0Wrapper']//nobr//img[@id='activityType_0Button']";
	public static String txtactivitycode="colorCode";
	public static String btnEdit="toolbar_EDIT_ACTIONLabel";
	public static String btnEditSave="//button[@id='toolbar_SAVE_ACTIONLabel']";
	
	public static boolean deleteActivityName(WebDriver driver,String ActivityName) throws Exception
	{
		boolean flag=false;
		try{
			Utilities.selectRightPaneView(driver);
			By delBtn=By.xpath(btnDeleteActivity);
			Utilities.waitForPageLoad(driver,delBtn);
			if (driver.findElements(delBtn).size()!=0)
			{					
				driver.findElement(delBtn).click();
				Thread.sleep(3000);
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Delete_OK.png");				
				extent.log(LogStatus.PASS, "Clicked on Delete Activity button is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Delete Activity button is unsuccessful");
				flag=false;
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean verifyActivityName(WebDriver driver,String ActivityName) throws Exception
	{
		boolean flag=false;	
		Utilities.selectRightPaneView(driver);
		int rc=driver.findElements(By.xpath("//table[@id='activityTableRef']/tbody/tr")).size();
		System.out.println("rc:"+rc);
		for (int i=1;i<=rc;i++)
		{
			if (i<=15)
			{
			String ActivityNameApp=driver.findElement(By.xpath("//table[@id='activityTableRef']/tbody/tr["+i+"]/th/a/span")).getText();
			//System.out.println("ActivityNameApp:"+ActivityNameApp);
			if (ActivityNameApp.contains(ActivityName))
			{
				driver.findElement(By.xpath("//table[@id='activityTableRef']/tbody/tr["+i+"]/th/a/span")).click();
				System.out.println("ActivityNameApp is selected");
				flag=true;				
				break;
			}}
		}
		if (flag==true)
		{
			extent.log(LogStatus.PASS, "Activity Name: "+ActivityName+" is already exist/Created");
			extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Activity"));
		}
		else
		{
			extent.log(LogStatus.INFO, "Activity Name: "+ActivityName+" does not exist. Please create Activity");
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Activity"));
			return flag=false;
		}	
		return flag;
	}
	
	/*public static boolean selectActivityName(WebDriver driver,String ActivityName) throws Exception
	{
		boolean flag=false;	
		Utilities.selectRightPaneView(driver);
		int rc=driver.findElements(By.xpath("//table[@id='activityTableRef']/tbody/tr")).size();
		System.out.println("rc:"+rc);
		for (int i=1;i<=rc;i++)
		{
			String ActivityNameApp=driver.findElement(By.xpath("//table[@id='activityTableRef']/tbody/tr["+i+"]/th/a/span")).getText();
			if (ActivityNameApp.contains(ActivityName))
			{
				driver.findElement(By.xpath("//table[@id='activityTableRef']/tbody/tr["+i+"]/th/a/span")).click();
				System.out.println("ActivityNameApp is selected");
				flag=true;				
				break;
			}
		}
		if (flag==true)
		{
			extent.log(LogStatus.PASS, "Activity Name: "+ActivityName+" Created/Selected successfully");
		}
		else
		{
			extent.log(LogStatus.WARNING, "Not able to select Activity Name: "+ActivityName);
			return flag=false;
		}	
		return flag;
	}*/
	
	public static boolean clickSave(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			Utilities.selectRightPaneView(driver);
			By saveBtn=By.xpath(btnSave);
			Utilities.waitForPageLoad(driver,saveBtn);
			if (driver.findElements(saveBtn).size()!=0)
			{					
				driver.findElement(saveBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Save button is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Save button is unsuccessful");
				flag=false;
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean setActivityDescription(WebDriver driver,String ActivityDesc) throws Exception
	{
		boolean flag=false;
		try{		
			By actDesctxt=By.id(txtActivityDesc);
			Utilities.waitForPageLoad(driver,actDesctxt);
			if (driver.findElements(actDesctxt).size()!=0)
			{
				driver.findElement(actDesctxt).clear();
				driver.findElement(actDesctxt).sendKeys(ActivityDesc);
				extent.log(LogStatus.PASS, "Activity Description : "+ActivityDesc +" is entered successfully");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Activity Description : "+ActivityDesc +" is NOT entered");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean setActivityName(WebDriver driver,String ActivityName) throws Exception
	{
		boolean flag=false;
		try{		
			By actNametxt=By.id(txtActivityName);
			Utilities.waitForPageLoad(driver,actNametxt);
			if (driver.findElements(actNametxt).size()!=0)
			{
				driver.findElement(actNametxt).clear();
				driver.findElement(actNametxt).sendKeys(ActivityName);
				extent.log(LogStatus.PASS, "Activity Name : "+ActivityName +" is entered successfully");
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Activity Name : "+ActivityName +" is NOT entered");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean clickCreateActivity(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			Utilities.selectRightPaneView(driver);
			By CreateActivityBtn=By.xpath(btnCreateActivity);
			Utilities.waitForPageLoad(driver,CreateActivityBtn);
			if (driver.findElements(CreateActivityBtn).size()!=0)
			{					
				driver.findElement(CreateActivityBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Create Activity button is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Create Activity button is unsuccessful");
				flag=false;
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean activityExist(WebDriver driver,String ActivityName)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			List<WebElement> li1=driver.findElements(By.xpath("//div[@id='activityTableWrapper']//table[@id='activityTableRef']//tbody//tr[@class='tblRow']"));
			System.out.println("*************"+li1.size());
			for(WebElement elt:li1)
			{
				//System.out.println("**************");
				System.out.println(elt.findElement(By.tagName("th")).getAttribute("innerText"));
				String wname=elt.findElement(By.tagName("th")).getAttribute("innerText");
				if(wname.contains(ActivityName))
				{
					//elt.findElement(By.tagName("th")).click();
					flag=true;
					extent.log(LogStatus.INFO,"Activity Name:"+ActivityName+" is already exist");
					break;
				}
			}
			//driver.findElement(By.xpath("//button[@id='workpaneMediator_toolbar_addShiftsLabel']")).click();
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setActivityType(WebDriver driver,String ActivityType)
	{
		boolean flag=false;
		try
		{
			By acttypeicon=By.xpath(iconacttype);
			Utilities.waitForPageLoad(driver,acttypeicon);
			if(driver.findElements(acttypeicon).size()!=0)
			{
				driver.findElement(acttypeicon).click();
				Select sbox=new Select(driver.findElement(By.xpath("//select[@id='activityType']")));
				sbox.selectByVisibleText(ActivityType);
				flag=true;
				extent.log(LogStatus.PASS,"Activity type:"+ActivityType+"is selected from list box");
				
			}
			else
			{
				flag=false;
				extent.log(LogStatus.FAIL,"Activity type:"+ActivityType+"is not selected from list box");
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setActivityCode(WebDriver driver,String ActivityCode) throws Exception
	{
		boolean flag=false;
		try{		
			By actCodext=By.id(txtactivitycode);
			Utilities.waitForPageLoad(driver,actCodext);
			if (driver.findElements(actCodext).size()!=0)
			{
				driver.findElement(actCodext).clear();
				driver.findElement(actCodext).sendKeys(ActivityCode);
				extent.log(LogStatus.PASS, "Activity code : "+ActivityCode +" is entered successfully");
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Activity Code : "+ActivityCode +" is NOT entered");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean selectActivity(WebDriver driver,String ActivityName)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			List<WebElement> li1=driver.findElements(By.xpath("//div[@id='activityTableWrapper']//table[@id='activityTableRef']//tbody//tr[@class='tblRow']"));
			System.out.println("*************"+li1.size());
			for(WebElement elt:li1)
			{
				//System.out.println("**************");
				System.out.println(elt.findElement(By.tagName("th")).getAttribute("innerText"));
				String wname=elt.findElement(By.tagName("th")).getAttribute("innerText");
				if(wname.contains(ActivityName))
				{
					elt.findElement(By.tagName("th")).click();
					flag=true;
					extent.log(LogStatus.INFO,"Activity Name:"+ActivityName+" is already exist");
					break;
				}
			}
			//driver.findElement(By.xpath("//button[@id='workpaneMediator_toolbar_addShiftsLabel']")).click();
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clickEditActivity(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By EditActivitybtn=By.id(btnEdit);
			Utilities.waitForPageLoad(driver,EditActivitybtn);
			if(driver.findElements(EditActivitybtn).size()!=0)
			{
				driver.findElement(EditActivitybtn).click();
				extent.log(LogStatus.PASS,"clicked on Edit button is sucessfull");
				Thread.sleep(3000);
				flag=true;
			}
			else
			{
				extent.log(LogStatus.PASS,"clicked on Edit button is not sucessfull");
				flag=false;
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clickEditSave(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{
			Utilities.selectRightPaneView(driver);
			By saveBtn=By.xpath(btnEditSave);
			Utilities.waitForPageLoad(driver,saveBtn);
			if (driver.findElements(saveBtn).size()!=0)
			{					
				driver.findElement(saveBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Save button is successful");
				Thread.sleep(8000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Save button is unsuccessful");
				flag=false;
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
}

