package ScreenObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class ScheduleScreen {

	public static ExtentReports extent = ExtentReports.get(ScheduleScreen.class);
	public static String recurrence="//select[@id='recurrenceBean']";
	public static String format="//select[@id='theForm:formatCombo']";
	public static String destination="//select[@id='destCombo']";
	public static String startdate="//input[@name='dateRange_START']";
	public static String enddate="//input[@name='dateRange_END']";
	public static String btnrefresh="//button[@id='toolbar_REFRESH_ACTIONLabel']";
	
	
	public static boolean setrecurrence(WebDriver driver,String value)
	{
		boolean  flag=false;
		try
		{
			By sboxrec=By.xpath(recurrence);
			if(driver.findElements(sboxrec).size()!=0)
			{
				Select sbox1=new Select(driver.findElement(sboxrec));
				sbox1.selectByValue(value);
				Thread.sleep(2000);
				System.out.println("clicked on once");
				extent.log(LogStatus.PASS,"Value:"+ value +"is selected from list box.");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.PASS,"Value:"+ value +"is not selected from list box.");
				flag=false;
			}
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean setFormat(WebDriver driver,String value)
	{
		boolean  flag=false;
		try
		{
			By sboxfromat=By.xpath(format);
			if(driver.findElements(sboxfromat).size()!=0)
			{
				Select sbox1=new Select(driver.findElement(sboxfromat));
				sbox1.selectByVisibleText(value);
				Thread.sleep(2000);
				System.out.println("clicked on PDF");
				extent.log(LogStatus.PASS,"Value:"+ value +"is selected from list box.");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.PASS,"Value:"+ value +"is not selected from list box.");
				flag=false;
			}
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean setDestination(WebDriver driver,String value)
	{
		boolean  flag=false;
		try
		{
			By sboxdestination=By.xpath(destination);
			if(driver.findElements(sboxdestination).size()!=0)
			{
				Select sbox1=new Select(driver.findElement(sboxdestination));
				sbox1.selectByVisibleText(value);
				Thread.sleep(2000);
				System.out.println("clicked on send portal");
				extent.log(LogStatus.PASS,"Value:"+ value +"is selected from list box.");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.PASS,"Value:"+ value +"is not selected from list box.");
				flag=false;
			}
			
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setstartdate(WebDriver driver,String sdate)
	{
		boolean flag=false;
		
		try
		{
			Utilities.selectRightPaneView(driver);
			By strtdate=By.xpath(startdate);
			Utilities.waitForPageLoad(driver,strtdate);
			if(driver.findElements(strtdate).size()!=0)
			{
				driver.findElement(strtdate).clear();
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
				driver.findElement(strtdate).sendKeys(sdate);
				extent.log(LogStatus.PASS,"start Date: "+sdate+"is entered sucessfully");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.PASS,"start Date: "+sdate+"is  not entered sucessfully");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean setendDate(WebDriver driver,String edate)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By nddate=By.xpath(enddate);
			Utilities.waitForPageLoad(driver,nddate);
			if(driver.findElements(nddate).size()!=0)
			{
				//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
				driver.findElement(nddate).clear();
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
				Thread.sleep(2000);
				driver.findElement(nddate).sendKeys(edate);
				extent.log(LogStatus.PASS,"start Date: "+edate+"is entered sucessfully");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.PASS,"start Date: "+edate+"is  not entered sucessfully");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
public static  boolean clickrefresh(WebDriver driver)
	
	{
		boolean flag=false;
		try
		{
			By refreshbtn=By.xpath(btnrefresh);
			Utilities.waitForPageLoad(driver,refreshbtn);
			if(driver.findElements(refreshbtn).size()!=0)
			{
				driver.findElement(refreshbtn).click();
				extent.log(LogStatus.PASS,"clicked on refresh button is successfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"Not able to click on refresh button");
				flag=false;
			}
		}
		catch(Exception e)
		
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	
}
