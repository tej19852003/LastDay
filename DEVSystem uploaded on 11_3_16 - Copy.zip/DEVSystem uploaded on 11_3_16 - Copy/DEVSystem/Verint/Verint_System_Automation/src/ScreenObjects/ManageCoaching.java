package ScreenObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class ManageCoaching {

	public static ExtentReports extent = ExtentReports.get(ManageCoaching.class);
	public static String btnCreate="//button[@id='toolbar_COACHING_SESSION_LIST_CREATE_PAGE_ACTIONLabel']";
	public static String txtReason="REASON_0";
	public static String txtDateTime="SCHEDULE_DATE_0";
	public static String txtLocation="LOCATION_0";
	public static String btnSave="toolbar_COACHING_SESSION_FORM_SAVE_PAGE_ACTIONLabel";
	//public static String btnPending="toolbar_COACHING_SESSION_FORM_EDIT_SAVE_PENDING_PAGE_ACTIONLabel";
	public static String btnPending="//table[@id='toolbar_COACHING_SESSION_FORM_CREATE_SAVE_PENDING_PAGE_ACTIONWrapper']/tbody/tr/td/button[@id='toolbar_COACHING_SESSION_FORM_CREATE_SAVE_PENDING_PAGE_ACTIONLabel']";
	public static String btnEdit="//button[@id='toolbar_COACHING_SESSION_LIST_EDIT_PAGE_ACTIONLabel']";
	public static String btnDelete="//button[@id='toolbar_COACHING_SESSION_LIST_DELETE_PAGE_ACTIONLabel']";
	public static String btnEditPending="//table[@id='toolbar_COACHING_SESSION_FORM_EDIT_SAVE_PENDING_PAGE_ACTIONWrapper']/tbody/tr/td/button[@id='toolbar_COACHING_SESSION_FORM_EDIT_SAVE_PENDING_PAGE_ACTIONLabel']";
	
	public static boolean clickEditPending(WebDriver driver) throws Exception
	{		
		boolean flag=false;
		try{			
			By editpendingBtn=By.xpath(btnEditPending);
			Utilities.waitForPageLoad(driver,editpendingBtn);
			if (driver.findElements(editpendingBtn).size()!=0)
			{					
				driver.findElement(editpendingBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Edit - Pending button is successful");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Edit - Pending button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean clickDelete(WebDriver driver) throws Exception
	{		
		boolean flag=false;
		try{			
			By delBtn=By.xpath(btnDelete);
			Utilities.waitForPageLoad(driver,delBtn);
			if (driver.findElements(delBtn).size()!=0)
			{					
				driver.findElement(delBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Delete button is successful");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Delete button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean clickEdit(WebDriver driver) throws Exception
	{		
		boolean flag=false;
		try{			
			By editBtn=By.xpath(btnEdit);
			Utilities.waitForPageLoad(driver,editBtn);
			if (driver.findElements(editBtn).size()!=0)
			{					
				driver.findElement(editBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Edit button is successful");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Edit button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean selectCoaching(WebDriver driver,String DateTime) throws Exception
	{
		boolean flag=false;
		int rc=driver.findElements(By.xpath("//table[@id='coachingListWrapper']/tbody/tr")).size();
		System.out.println("rc:"+rc);
		if (rc>0)
		{
			for (int i=1;i<=rc;i++)
			{
				if (i<=15)
				{
					String datetimeApp=driver.findElement(By.xpath("//table[@id='coachingListWrapper']/tbody/tr["+i+"]/td[3]/nobr")).getText();				
					String[] str=datetimeApp.split(" ");
					String str0=str[0];
					String str1=str[1];
					String str2=str[2];					
					if (DateTime.contains(str0) & DateTime.contains(str1) & DateTime.contains(str2))
					{
						driver.findElement(By.xpath("//table[@id='coachingListWrapper']/tbody/tr["+i+"]/td[3]/nobr")).click();
						
						flag=true;					
						extent.log(LogStatus.PASS, "Expected Coaching row has been selected");										
						break;
					}
				}
			}
		}
		else
		{
			extent.log(LogStatus.FAIL, "No rows are displayed under Manage Coaching");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "CoachingStatus"));
			return flag=false;
		}
		if (flag==false)
		{
			extent.log(LogStatus.WARNING, "Not able to select Manage Coaching row");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "CoachingStatus"));
			return flag=false;
		}	
		return flag;
	}
	public static boolean verifyStatus(WebDriver driver,String DateTime,String Status) throws Exception
	{
		boolean flag=false;		
		int rc=driver.findElements(By.xpath("//table[@id='coachingListWrapper']/tbody/tr")).size();
		System.out.println("rc:"+rc);
		if (rc>0)
		{
			for (int i=1;i<=rc;i++)
			{
				if (i<=15)
				{
				String datetimeApp=driver.findElement(By.xpath("//table[@id='coachingListWrapper']/tbody/tr["+i+"]/td[3]/nobr")).getText();				
				String[] str=datetimeApp.split(" ");
				String str0=str[0];
				String str1=str[1];
				String str2=str[2];				
				/*System.out.println(str0+";"+str1+";"+str2);
				if (DateTime.contains(str0) & DateTime.contains(str1) & DateTime.contains(str2))
				{
					System.out.println("pass");
				}*/				
				//System.out.println("Appdate:"+datetimeApp);
				//System.out.println("DateIime:"+DateTime);
				if (DateTime.contains(str0) & DateTime.contains(str1) & DateTime.contains(str2))
				{
					driver.findElement(By.xpath("//table[@id='coachingListWrapper']/tbody/tr["+i+"]/td[3]/nobr")).click();
					//System.out.println("row is selected");
					flag=true;					
					extent.log(LogStatus.PASS, "Manage Coaching row has been selected");
					String statusApp=driver.findElement(By.xpath("//table[@id='coachingListWrapper']/tbody/tr["+i+"]/td[9]/span")).getText();
					if (statusApp.contains(Status))
					{
						extent.log(LogStatus.PASS, "Status:"+Status+" is displayed as Expected");
						extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "CoachingStatus"));
					}
					else
					{
						extent.log(LogStatus.FAIL, "Status:"+Status+" is NOT displayed as Expected");
						extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "CoachingStatus"));
					}					
					break;
				}}
			}
		}
		else
		{
			extent.log(LogStatus.FAIL, "No rows are displayed under Manage Coaching");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "CoachingStatus"));
			return flag=false;
		}
		if (flag==false)
		{
			extent.log(LogStatus.WARNING, "Not able to select Manage Coaching row");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "CoachingStatus"));
			return flag=false;
		}
	
		return flag;
	}
	
	public static boolean clickPending(WebDriver driver) throws Exception
	{		
		boolean flag=false;
		try{			
			By pendingBtn=By.xpath(btnPending);
			Utilities.waitForPageLoad(driver,pendingBtn);
			if (driver.findElements(pendingBtn).size()!=0)
			{					
				driver.findElement(pendingBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Pending button is successful");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Pending button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickSave(WebDriver driver) throws Exception
	{		
		boolean flag=false;
		try{			
			By saveBtn=By.id(btnSave);
			Utilities.waitForPageLoad(driver,saveBtn);
			if (driver.findElements(saveBtn).size()!=0)
			{					
				driver.findElement(saveBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Save button is successful");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Save button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	
	
	public static void setReason(WebDriver driver,String Reason) throws Exception
	{
		try{		
			By reasontxt=By.id(txtReason);
			Utilities.waitForPageLoad(driver,reasontxt);
			if (driver.findElements(reasontxt).size()!=0)
			{
				driver.findElement(reasontxt).clear();
				driver.findElement(reasontxt).sendKeys(Reason);
				extent.log(LogStatus.PASS, "Reason : "+Reason +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Reason : "+Reason +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void setLocation(WebDriver driver,String Location) throws Exception
	{
		try{		
			By loctxt=By.id(txtLocation);
			Utilities.waitForPageLoad(driver,loctxt);
			if (driver.findElements(loctxt).size()!=0)
			{
				driver.findElement(loctxt).clear();
				driver.findElement(loctxt).sendKeys(Location);
				extent.log(LogStatus.PASS, "Location : "+Location +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Location : "+Location +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void setDateTime(WebDriver driver,String DateTime) throws Exception
	{
		try{		
			By datetime=By.id(txtDateTime);
			Utilities.waitForPageLoad(driver,datetime);
			if (driver.findElements(datetime).size()!=0)
			{
				driver.findElement(datetime).clear();
				driver.findElement(datetime).sendKeys(DateTime);
				extent.log(LogStatus.PASS, "Date and Time : "+DateTime +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Date and Time : "+DateTime +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static boolean clickCreate(WebDriver driver) throws Exception
	{	
		boolean flag=false;
		try{			
			By createBtn=By.xpath(btnCreate);
			Utilities.waitForPageLoad(driver,createBtn);
			if (driver.findElements(createBtn).size()!=0)
			{					
				driver.findElement(createBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Manage Coaching - Create button is successful");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Manage Coaching - Create button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	
	
}
