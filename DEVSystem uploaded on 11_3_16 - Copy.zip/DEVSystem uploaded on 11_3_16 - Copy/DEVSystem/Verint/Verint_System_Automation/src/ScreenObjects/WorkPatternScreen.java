package ScreenObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.python.core.exceptions;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WorkPatternScreen
{
	public static ExtentReports extent = ExtentReports.get(WorkQueuesScreen.class);
	public static String btnCreateworkpattern= "//button[@id='toolbar_ADD_ACTIONLabel']";
	public static String txtworkpatternName= "workPatternName";
	public static String txtworkpatternDesc="workPatternDesc";
	public static String txtemployeetype="employeeType__input_0";
	public static String chkboxsun="shiftPatternWorkDaysTable_1_occurenceCheckBoxPC_MQ__input_id";
	public static String chkboxmon="shiftPatternWorkDaysTable_2_occurenceCheckBoxPC_MQ__input_id";
	public static String chkboxtue="shiftPatternWorkDaysTable_3_occurenceCheckBoxPC_MQ__input_id";
	public static String chkboxwed="shiftPatternWorkDaysTable_4_occurenceCheckBoxPC_MQ__input_id";
	public static String chkboxthurs="shiftPatternWorkDaysTable_5_occurenceCheckBoxPC_MQ__input_id";
	public static String chkboxfri="shiftPatternWorkDaysTable_6_occurenceCheckBoxPC_MQ__input";
	public static String chkboxsat="shiftPatternWorkDaysTable_7_occurenceCheckBoxPC_MQ__input_id";
	public static String btnAddshift="workDaysToolbar_POPUP_SHIFTLabel";
	public static String btnSaveworkPattern="//button[@id='toolbar_CREATE_NEW_ACTIONLabel']";
	public static String iconemptype="//img[@id='employeeType__input_0Button']";
	public static String btnaddovertime="//button[@id='otExtensionToolbar_POPUP_OT_EXTENSIONLabel']";
	
	
	public static boolean clickworkpattern(WebDriver driver) throws Exception
	{		
		boolean flag=false;
		try{	
			Utilities.selectRightPaneView(driver);
			By wpBtn=By.xpath(btnCreateworkpattern);
			Utilities.waitForPageLoad(driver,wpBtn);
			if (driver.findElements(wpBtn).size()!=0)
			{					
				driver.findElement(wpBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Create work pattern button is successful");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Create work pattern button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setWorkpatternName(WebDriver driver,String WorkpatternName) throws Exception
	{
		boolean flag=false;
		try{		
			By wpNametxt=By.name(txtworkpatternName);
			Utilities.waitForPageLoad(driver,wpNametxt);
			if (driver.findElements(wpNametxt).size()!=0)
			{
				driver.findElement(wpNametxt).clear();
				driver.findElement(wpNametxt).sendKeys(WorkpatternName);
				extent.log(LogStatus.PASS, "Work pattern Name"+WorkpatternName +" is entered successfully");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Work pattern Name "+WorkpatternName +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean setWorkpatternDescription(WebDriver driver,String WorkpatternDesc) throws Exception
	{
		boolean flag=false;
		try{		
			By wpDesctxt=By.name(txtworkpatternDesc);
			Utilities.waitForPageLoad(driver,wpDesctxt);
			if (driver.findElements(wpDesctxt).size()!=0)
			{
				driver.findElement(wpDesctxt).clear();
				driver.findElement(wpDesctxt).sendKeys(WorkpatternDesc);
				extent.log(LogStatus.PASS, "Work pattern Description "+WorkpatternDesc +" is entered successfully");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Work pattern Description "+WorkpatternDesc +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setEmployeeType(WebDriver driver,String EmpType) throws Exception
	{
		boolean flag=false;
		try{
			driver.findElement(By.id("employeeType__input_0Button"));
			By emptypetxt=By.id(txtemployeetype);
			Utilities.waitForPageLoad(driver,emptypetxt);
			if (driver.findElements(emptypetxt).size()!=0)
			{
				driver.findElement(emptypetxt).clear();
				driver.findElement(emptypetxt).sendKeys(EmpType);
				extent.log(LogStatus.PASS, "Employee Type  "+EmpType +" is entered successfully");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Employee Type  "+EmpType +" is not entered ");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setpossibledaysOff(WebDriver driver)throws Exception
	{
		boolean temp=false;
		Utilities.selectRightPaneView(driver);
		int rows=driver.findElements(By.xpath("//table[@id='shiftPatternWorkDaysTableRef']//tbody//tr//td")).size();
		System.out.println("no of rows are:" + rows);
		for(int i=3;i<8;i++)
		{
			if(driver.findElement(By.xpath("//table[@id='shiftPatternWorkDaysTableRef']//tbody//tr//td[contains(@id,'shiftPatternWorkDaysTabler1c"+i+"')]//input[@type='checkbox']")).isSelected())
			{
				driver.findElement(By.xpath("//table[@id='shiftPatternWorkDaysTableRef']//tbody//tr//td[contains(@id,'shiftPatternWorkDaysTabler1c"+i+"')]//input[@type='checkbox']")).click();
				extent.log(LogStatus.PASS,"possible days off saturday and sunday is checked");
				
			}
		}
		
		return temp=true;
			
		}
	
	
	public static boolean clickAddshift(WebDriver driver) throws Exception
	{		
		boolean flag=false;
		try{	
			//Utilities.selectRightPaneView(driver);
			By addshiftBtn=By.id(btnAddshift);
			Utilities.waitForPageLoad(driver,addshiftBtn);
			if (driver.findElements(addshiftBtn).size()!=0)
			{					
				driver.findElement(addshiftBtn).click();
				extent.log(LogStatus.PASS, "Clicked on add shift button is successful");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on add shift button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	
	public static boolean clickSave(WebDriver driver) throws Exception
	{		
		boolean flag=false;
		try{	
			Utilities.selectRightPaneView(driver);
			By saveBtn=By.xpath(btnSaveworkPattern);
			Utilities.waitForPageLoad(driver,saveBtn);
			if (driver.findElements(saveBtn).size()!=0)
			{					
				driver.findElement(saveBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Save button is successful");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Save button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean setshift(WebDriver driver,String ShiftName)throws Exception
	{
		boolean flag=false;
		//Utilities.setWindowFocus(driver);
		try
		{
			/*int rows=driver.findElements(By.xpath("//div[@id='shiftTableWrapper']//table[@id='shiftTableRef']//tr")).size();
			System.out.println("no of rows are:" + rows);
			for(int j=1;j<rows;j+=2)
			{
				String sname=driver.findElement(By.xpath("//div[@id='shiftTableWrapper']//table[@id='shiftTableRef']//tr[contains(@id,'shiftTabler"+j+"')]//td[contains(@id,'shiftTabler"+j+"c1')]")).getAttribute("innerText");
				System.out.println("shift name is:" + sname);
				if(sname.contains(ShiftName))
				{
					driver.findElement(By.xpath("//div[@id='shiftTableWrapper']//table[@id='shiftTableRef']//tr[contains(@id,'shiftTabler"+j+"')]//td[contains(@id,'shiftTabler"+j+"c1')]")).click();
					break;
				}
				
			}*/
			
			List<WebElement> li1=driver.findElements(By.xpath("//table[@id='shiftTableRef']//tr[@class='tblRow']"));
			System.out.println(li1.size());
			for(WebElement elt:li1)
			{
				//System.out.println("**************");
				System.out.println(elt.findElement(By.tagName("td")).getAttribute("innerText"));
				String wname=elt.findElement(By.tagName("td")).getAttribute("innerText");
				if(wname.contains(ShiftName))
				{
					Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
					elt.findElement(By.tagName("td")).click();
					flag=true;
					break;
				}
			}
			driver.findElement(By.xpath("//button[@id='workpaneMediator_toolbar_addShiftsLabel']")).click();
			flag=true;
		}
		catch(Exception e){
			e.printStackTrace();
			
		}
		return flag;
	}
	
	public static boolean setemptyep(WebDriver driver,String emptype)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By icon=By.xpath(iconemptype);
			Utilities.waitForPageLoad(driver,icon);
			if(driver.findElements(icon).size()!=0)
			{
				driver.findElement(icon).click();
				Select sbox=new Select(driver.findElement(By.xpath("//select[@id='employeeType__input']")));
				sbox.selectByVisibleText(emptype);
				extent.log(LogStatus.PASS,"value :"+emptype+" is selected from list box");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"Value is not getting selected from list box");
				flag=false;
			}
			
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickAddOverTime(WebDriver driver) throws Exception
	{		
		boolean flag=false;
		try{	
			Utilities.selectRightPaneView(driver);
			By addOTTime=By.xpath(btnaddovertime);
			Utilities.waitForPageLoad(driver,addOTTime);
			if (driver.findElements(addOTTime).size()!=0)
			{					
				driver.findElement(addOTTime).click();
				extent.log(LogStatus.PASS, "Clicked on add overtime button is successful");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on add overtime button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean setovertime(WebDriver driver,String overtime)throws Exception
	{
		boolean flag=false;
		//Utilities.setWindowFocus(driver);
		try
		{
			/*int rows=driver.findElements(By.xpath("//div[@id='shiftTableWrapper']//table[@id='shiftTableRef']//tr")).size();
			System.out.println("no of rows are:" + rows);
			for(int j=1;j<rows;j+=2)
			{
				String sname=driver.findElement(By.xpath("//div[@id='shiftTableWrapper']//table[@id='shiftTableRef']//tr[contains(@id,'shiftTabler"+j+"')]//td[contains(@id,'shiftTabler"+j+"c1')]")).getAttribute("innerText");
				System.out.println("shift name is:" + sname);
				if(sname.contains(ShiftName))
				{
					driver.findElement(By.xpath("//div[@id='shiftTableWrapper']//table[@id='shiftTableRef']//tr[contains(@id,'shiftTabler"+j+"')]//td[contains(@id,'shiftTabler"+j+"c1')]")).click();
					break;
				}
				
			}*/
			
			List<WebElement> li1=driver.findElements(By.xpath("//table[@id='otExtensionTableRef']//tr[@class='tblRow']"));
			System.out.println(li1.size());
			for(WebElement elt:li1)
			{
				//System.out.println("**************");
				System.out.println(elt.findElement(By.tagName("td")).getAttribute("innerText"));
				String wname=elt.findElement(By.tagName("td")).getAttribute("innerText");
				if(wname.contains(overtime))
				{
					//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
					elt.findElement(By.tagName("td")).click();
					flag=true;
					break;
				}
			}
			driver.findElement(By.xpath("//button[@id='workpaneMediator_toolbar_addShiftOTExtensionsLabel']")).click();
			flag=true;
		}
		catch(Exception e){
			e.printStackTrace();
			
		}
		return flag;
	}
	
	
}
