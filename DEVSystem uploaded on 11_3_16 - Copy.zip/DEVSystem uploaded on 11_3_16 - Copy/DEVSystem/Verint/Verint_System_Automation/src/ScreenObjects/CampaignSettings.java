package ScreenObjects;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.python.modules.struct;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class CampaignSettings {

	public static ExtentReports extent = ExtentReports.get(CampaignSettings.class);
	public static String btnCreateCampaign="//button[@id='toolbar_NEW_ACTIONLabel']";
	public static String txtCampaignName="campaignName_0";
	public static String txtCampaignDesc="description_0";
	public static String btnSave="toolbar_CAMPAIGN_SAVE_ACTIONLabel";
	public static String btnCreateSchedulingPeriod="//button[@id='toolbar_ADD_ACTIONLabel']";
	public static String txtSchedulingPeriodStartDate="campaignspstartdate_0";
	public static String btnSPSave="toolbar_SP_CREATE_ACTIONLabel";
	public static String btnOrgSelectoricon="//button[@id='toolbar_spOrgSelectorPC_ID']";
	//public static String btnOrgSelectoricon="//span[@id='toolbar_spOrgSelectorPCWrapper']/button/img[@alt='Organization Selector']";
	//public static String btnOrgSelectoricon="//span[@id='toolbar_spOrgSelectorPCWrapper']";
	public static String btnCampaignSettingsSave="toolbar_SAVE_ACTIONLabel";
	public static String btnSet="//button[@id='workpaneMediator_toolbar_SET_ACTIONLabel']";
	public static String linkqueue="//span[@id='CAMPAIGNS_QUEUES_CAMPAIGN_spn_id']//a";
	public static String btnADDtoSP="//button[@id='toolbar_POPUP_CAMPAIGN_SP_QUEUESLabel']";
	public static String btndelcamp="//button[@id='toolbar_DELETE_ACTIONLabel']";
	public static String rdntncopydata="//input[@id='campaigninitoptions_createfromselected_0']";
	public static String chkboxskill="//input[@name='bChk_skillbased']";
	public static String iconaddskill="//img[starts-with(@id,'selectionSPSkill')]";
	public static String linksetting="//span[@id='CAMPAIGNS_SETTINGS_CAMPAIGN_spn_id']//a";
	
	
	
	
	public static boolean selectOrganizationSelector(WebDriver driver, String OrgName) throws Exception
	{
		boolean flag=true;
		boolean Temp1=false;
		//String mainWind="";
		try{					
				//Utilities.setWindowFocus(driver);
				Thread.sleep(2000);
				System.out.println("rows:"+driver.findElements(By.xpath("//table[@id='orgTree_id']//tbody//tr")).size());
				if (driver.findElements(By.xpath("//table[@id='orgTree_id']/tbody/tr")).size()!=0)
				{
					int rcOrg=driver.findElements(By.xpath("//table[@id='orgTree_id']//tr")).size();
					System.out.println("rcOrg:"+rcOrg);
					for (int p=1;p<=rcOrg;p++)
					{
						String orgApp=driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+p+"]/td[2]/label/span")).getText().trim();
						System.out.println("orgApp:"+orgApp);
						System.out.println("orgname:"+OrgName);
						Thread.sleep(1000);
						if (orgApp.contains(OrgName))
						{					
							if (!driver.findElement(By.xpath("//table[@id='orgTree_id']//tr["+p+"]/td[1]/span/input[@name='checkedOrgID'][@type='checkbox']")).isSelected())
								{
								driver.findElement(By.xpath("//table[@id='orgTree_id']//tr["+p+"]/td[1]/span/input[@name='checkedOrgID'][@type='checkbox']")).click();
								Temp1=true;
								break;	
								}						
						}
					}
					if (Temp1==true)
					{
						System.out.println("pass");
						extent.log(LogStatus.PASS, "Organization Name : "+OrgName+" Selected successfully");
						if (driver.findElements(By.xpath(btnSet)).size()!=0)
						{
							driver.findElement(By.xpath(btnSet)).click();
							Thread.sleep(3000);
							extent.log(LogStatus.INFO, "Clicked on Set button in Condition Value Selection popup window");
						}
						else
						{
							extent.log(LogStatus.WARNING, "Not able to Clicked on Set button in Condition Value Selection popup window");
							return flag=false;
						}
						//captureScreenShot(driver,screenshotDir+"OrganizationNameValidation");				
					}
					else
					{
						extent.log(LogStatus.FAIL, "Unable to Select Organization Name : "+OrgName);
						//captureScreenShot(driver,screenshotDir+"RoleNameValidation");
						return flag =false;
					}
				}
				else
				{
					extent.log(LogStatus.FAIL, "Condition Value Selection popup window is not displayed");
				}			
			
				
		}catch (Exception e) {
			e.printStackTrace();
		}
		//driver.switchTo().window(mainWind);
		return flag;
	}
	
	
	
	public static boolean selectHoursOfOperation(WebDriver driver) throws Exception
	{		
		Boolean Temp=false;
		//Utilities.setWindowFocus(driver);
		Utilities.selectRightPaneView(driver);
		int rc1=driver.findElements(By.xpath("//table[@id='HooTwoColumnPC_wrapper_tbl_id']/tbody/tr")).size();
		System.out.println("rc1:"+rc1);
		if (rc1>=1)
		{
			for (int i=2;i<7;i++)
			{
				if (i==2 | i==7)
				{
					if (driver.findElement(By.xpath("//table[@id='HooTwoColumnPC_wrapper_tbl_id']/tbody/tr["+(i+1)+"]/td[2]/input[@name='HooIsActive2__input'][@type='checkbox']")).isSelected())
					{
						driver.findElement(By.xpath("//table[@id='HooTwoColumnPC_wrapper_tbl_id']/tbody/tr["+(i+1)+"]/td[2]/input[@type='checkbox']")).click();							
					}
				}
				if (i!=2 | i!=7)
				{
					if (!driver.findElement(By.xpath("//table[@id='HooTwoColumnPC_wrapper_tbl_id']/tbody/tr["+(i+1)+"]/td[2]/input[@name='HooIsActive"+i+"__input'][@type='checkbox']")).isSelected())
					{
						driver.findElement(By.xpath("//table[@id='HooTwoColumnPC_wrapper_tbl_id']/tbody/tr["+(i+1)+"]/td[2]/input[@name='HooIsActive"+i+"__input'][@type='checkbox']")).click();	
						Temp=true;
					}
				}
			}
		}
		if (Temp==true)
		{					
			extent.log(LogStatus.PASS, "Hours Of Operations selected successfully");	
			//extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Campaign"));
		}
		else
		{
			extent.log(LogStatus.FAIL, "Not able to select Hours Of Operations ");
			//extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Campaign"));
			Temp=false;
		}
		return Temp=false;
	}
	
	public static boolean clickOrganizationSelector(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{	
			Utilities.selectRightPaneView(driver);
			By orgSelectorBtn=By.xpath(btnOrgSelectoricon);
			Utilities.waitForPageLoad(driver,orgSelectorBtn);
			if (driver.findElements(orgSelectorBtn).size()!=0)
			{					
				driver.findElement(orgSelectorBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Organization Selector icon is successful");
				Thread.sleep(6000);
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Organization Selector icon is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean clickCampaignSettingsSave(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{
			
			Utilities.selectRightPaneView(driver);
			
			By saveCSBtn=By.id(btnCampaignSettingsSave);
			Utilities.waitForPageLoad(driver,saveCSBtn);
			if (driver.findElements(saveCSBtn).size()!=0)
			{					
				driver.findElement(saveCSBtn).click();
				//extent.log(LogStatus.PASS, "Clicked on Campaign Settings Save button is successful");
				Thread.sleep(6000);
			}else
			{
				//extent.log(LogStatus.INFO, "Clicked on Campaign Settings Save button is unsuccessful");
				flag=false;
			}
			if (flag==false)
			{
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Save.png");
				flag=true;
			}
			if (flag==true)
			{
				extent.log(LogStatus.PASS, "Clicked on Campaign Settings Save button is successful");
			}
			else
			{
				extent.log(LogStatus.FAIL, "Clicked on Campaign Settings Save button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickSchedulingPeriodPSave(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{	
			Utilities.selectRightPaneView(driver);
			By saveSPBtn=By.id(btnSPSave);
			Utilities.waitForPageLoad(driver,saveSPBtn);
			if (driver.findElements(saveSPBtn).size()!=0)
			{	
				System.out.println("click save");
				driver.findElement(saveSPBtn).click();
				//extent.log(LogStatus.PASS, "Clicked on Scheduling Period Save button is successful");
				Thread.sleep(6000);
			}else
			{
				System.out.println("not in click save");
				//extent.log(LogStatus.INFO, "Clicked on Scheduling Period Save button is unsuccessful");
				flag=false;
			}
			if (flag==false)
			{
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Save.png");
				flag=true;
			}	
			if (flag==true)
			{
				extent.log(LogStatus.PASS, "Clicked on Scheduling Period Save button is successful");
			}
			else
			{
				extent.log(LogStatus.FAIL, "Clicked on Scheduling Period Save button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setSchedulingPeriodStartDate(WebDriver driver,String StartDate) throws Exception
	{
		boolean flag=true;
		try{		
			By startDatetxt=By.id(txtSchedulingPeriodStartDate);
			Utilities.waitForPageLoad(driver,startDatetxt);
			if (driver.findElements(startDatetxt).size()!=0)
			{
				driver.findElement(startDatetxt).clear();
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
				driver.findElement(startDatetxt).sendKeys(StartDate);
				Thread.sleep(4000);
				Robot r = new Robot();
				r.keyPress(KeyEvent.VK_TAB);
				r.keyRelease(KeyEvent.VK_TAB);
				extent.log(LogStatus.PASS, "Scheduling Period Start Date : "+StartDate +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Scheduling Period Start Date : "+StartDate +" is NOT entered");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickSave(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{			
			By saveBtn=By.id(btnSave);
			Utilities.waitForPageLoad(driver,saveBtn);
			if (driver.findElements(saveBtn).size()!=0)
			{					
				driver.findElement(saveBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Save button is successful");
				Thread.sleep(6000);
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Save button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

	
	
	public static boolean setCampaignDescription(WebDriver driver,String CampaignDesc) throws Exception
	{
		boolean flag=true;
		try{		
			By campDesctxt=By.id(txtCampaignDesc);
			Utilities.waitForPageLoad(driver,campDesctxt);
			if (driver.findElements(campDesctxt).size()!=0)
			{
				driver.findElement(campDesctxt).clear();
				driver.findElement(campDesctxt).sendKeys(CampaignDesc);
				extent.log(LogStatus.PASS, "Campaign Description : "+CampaignDesc +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Campaign Description : "+CampaignDesc +" is NOT entered");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static void setCampaignName(WebDriver driver,String CampaignName) throws Exception
	{
		try{		
			By camptxt=By.id(txtCampaignName);
			Utilities.waitForPageLoad(driver,camptxt);
			if (driver.findElements(camptxt).size()!=0)
			{
				driver.findElement(camptxt).clear();
				driver.findElement(camptxt).sendKeys(CampaignName);
				extent.log(LogStatus.PASS, "Campaign Name : "+CampaignName +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Campaign Name : "+CampaignName +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static boolean clickSchedulingPeriod(WebDriver driver) throws Exception
	{	
		boolean flag=false;
		try{
			Utilities.selectRightPaneView(driver);
			By spBtn=By.xpath(btnCreateSchedulingPeriod);
			Utilities.waitForPageLoad(driver,spBtn);
			if (driver.findElements(spBtn).size()!=0)
			{					
				driver.findElement(spBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Create Scheduling Period button is successful");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Create Scheduling Period button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickCreateCampaign(WebDriver driver) throws Exception
	{	
		boolean flag=false;
		try{			
			By campBtn=By.xpath(btnCreateCampaign);
			Utilities.waitForPageLoad(driver,campBtn);
			if (driver.findElements(campBtn).size()!=0)
			{					
				driver.findElement(campBtn).click();
				extent.log(LogStatus.PASS, "Clicked on Create Campaign button is successful");
				Thread.sleep(6000);
				flag=true;
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Create Campaign button is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectCampaignFromLeftTreeFrame(WebDriver driver,String campName) throws Exception
	{
		Boolean Temp=false;
		Utilities.selectLeftTreeFrame(driver);
		int rc=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
		System.out.println("rc:"+rc);
		if (rc>0)
		{
			driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr[1]/td/a")).click();
		}
		for (int i=1;i<=rc;i++)
		{
			
			
			String campNameApp=driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr["+i+"]/td/a")).getText();
			System.out.println(campNameApp);
			if (campNameApp.contains(campName))
			{
				driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr["+i+"]/td/a")).click();
				Thread.sleep(3000);
				Temp=true;
				break;
			}
		}
		if (Temp==true)
		{					
			extent.log(LogStatus.PASS, "Compaign Name:"+campName+" created/selected successfully");	
			extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Campaign"));
		}
		else
		{
			extent.log(LogStatus.FAIL, "Compaign Name:"+campName+" NOT created/displayed ");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Campaign"));
			return Temp=false;
		}
	
		return Temp;
	}
	
	public static boolean clickQueue(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			System.out.println("inside queue");
			//Utilities.selectRightPaneView(driver);
			By queuelink=By.xpath(linkqueue);
			Utilities.waitForPageLoad(driver,queuelink);
			if(driver.findElements(queuelink).size()!=0)
			{
				driver.findElement(queuelink).click();
				extent.log(LogStatus.PASS,"clicked on queue tab is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"not able to click on queue tab");
				return flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean selectSchedulePeriod(WebDriver driver,String Period)
	{
		Boolean Temp=false;
		try{
			/*String value=driver.findElement(By.xpath("//img[@id='campaignSPTreer0Norg']")).getAttribute("alt");
			System.out.println("value of alt is:" + value);
			if(value.contains("Closed"))
			{ 
				driver.findElement(By.xpath("//img[@id='campaignSPTreer0Norg']")).click();
			}*/
			Utilities.selectLeftTreeFrame(driver);
			int rc=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table//tr[starts-with(@id,'campaignSPTreer0r')]")).size();
			System.out.println("rc:"+rc);
			/*if (rc>0)
			{
				driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr[1]/td/a")).click();
			}*/
			for (int i=0;i<rc;i++)
			{
				
				
				String queuename=driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr[@id='campaignSPTreer0r"+i+"']/td/a")).getText();
				System.out.println(i+":"+queuename);
				if (queuename.contains(Period))
				{
					driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr[@id='campaignSPTreer0r"+i+"']/td/a")).click();
					Thread.sleep(3000);
					Temp=true;
					break;
				}
			}
			
			if (Temp==true)
			{					
				extent.log(LogStatus.PASS, "Schedule Period:"+Period+" is  selected successfully");	
				//extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Campaign"));
			}
			else
			{
				extent.log(LogStatus.FAIL, "schedule period:"+Period+" NOT displayed ");
				//extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Campaign"));
				return Temp=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	
		return Temp;
	}
	
	
	
	public static boolean selectSchedulePeriod2(WebDriver driver,String Period)
	{
		Boolean Temp=false;
		try{
			/*String value=driver.findElement(By.xpath("//img[@id='campaignSPTreer0Norg']")).getAttribute("alt");
			System.out.println("value of alt is:" + value);
			if(value.contains("Closed"))
			{ 
				driver.findElement(By.xpath("//img[@id='campaignSPTreer0Norg']")).click();
			}*/
			Utilities.selectLeftTreeFrame(driver);
			int rc=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table//tr[starts-with(@id,'campaignSPTreer22r')]")).size();
			System.out.println("rc:"+rc);
			/*if (rc>0)
			{
				driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr[1]/td/a")).click();
			}*/
			for (int i=0;i<rc;i++)
			{
				
				
				String queuename=driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr[@id='campaignSPTreer22r"+i+"']/td/a")).getText();
				System.out.println(i+":"+queuename);
				if (queuename.contains(Period))
				{
					driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr[@id='campaignSPTreer22r"+i+"']/td/a")).click();
					Thread.sleep(3000);
					Temp=true;
					break;
				}
			}
			
			if (Temp==true)
			{					
				extent.log(LogStatus.PASS, "Schedule Period:"+Period+" is  selected successfully");	
				//extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "Campaign"));
			}
			else
			{
				extent.log(LogStatus.FAIL, "schedule period:"+Period+" NOT displayed ");
				//extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Campaign"));
				return Temp=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	
		return Temp;
	}
	
	public static boolean clickAddSP(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By btnAdd=By.xpath(btnADDtoSP);
			Utilities.waitForPageLoad(driver,btnAdd);
			if(driver.findElements(btnAdd).size()!=0)
			{
				driver.findElement(btnAdd).click();
				extent.log(LogStatus.PASS,"clicked on add to schedule is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"clicked on add to schedule is not sucessfull");
				return flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static  boolean selectWorkQueue(WebDriver driver,String qname)
	{
		boolean flag=false;
		try
		{
			//Utilities.setWindowFocus(driver);
			int rows=driver.findElements(By.xpath("//div[@id='tableWrapper']//table[@id='tableRef']//tbody//tr")).size();
			System.out.println("no of rows are:"+ rows);
			for(int j=1;j<rows;j++)
			{
				String wqname=driver.findElement(By.xpath("//div[@id='tableWrapper']//table[@id='tableRef']//tbody//tr[contains(@id,'tabler"+j+"')]//th[contains(@id,'tabler"+j+"c0')]//a//span")).getText();
				System.out.println("work queue name is " +wqname);
				if(wqname.contains(qname))
				{
					/*if(driver.findElements(By.xpath("//div[@id='tableWrapper']//table[@id='tableRef']//tbody//tr[contains(@id,'tabler"+j+"')]//th[contains(@id,'tabler"+j+"c0')]//a//span")).size()!=0)
					{
						Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
					}*/
					driver.findElement(By.xpath("//div[@id='tableWrapper']//table[@id='tableRef']//tbody//tr[contains(@id,'tabler"+j+"')]//th[contains(@id,'tabler"+j+"c0')]//a//span")).click();
				}
			}
			driver.findElement(By.id("workpaneMediator_toolbar_ADD_ACTIONLabel")).click();
			flag=true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean CampaignExist(WebDriver driver,String campname) throws InterruptedException
	{
		boolean Temp = false;
		int rc=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
		System.out.println("rc:"+rc);
		for (int i=1;i<=rc;i++)
		{
			
			String campNameApp=driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr["+i+"]/td/a")).getText();
			System.out.println("campaign name is:"+ campNameApp);
			if (campNameApp.equals(campname))
			{
				driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr["+i+"]/td/a")).click();
				Thread.sleep(3000);
				Temp=true;
				break;
			}
		}
		return Temp;
	}
	
	
	public static boolean schedulePeriodExist(WebDriver driver,String period)
	{
		boolean Temp3=false;
		//driver.findElement(By.xpath("//img[@id='campaignSPTreer0Norg']")).click();
		int rc2=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table//tr[starts-with(@id,'campaignSPTree')]")).size();
		System.out.println("rc:"+rc2);
		/*if (rc2>0)
		{
			driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr[1]/td/a")).click();
		}*/
		for (int i=0;i<rc2;i++)
		{
			for(int j=0;j<2;j++){
				
			
			if(driver.findElements(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr[@id='campaignSPTreer"+i+"r"+j+"']/td/a")).size()!=0)
			{
				String queuename=driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr[@id='campaignSPTreer"+i+"r"+j+"']/td/a")).getText();
				System.out.println(queuename);
				if (queuename.contains(period))
				{
					System.out.println("schedule period exist");
					driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr[@id='campaignSPTreer"+i+"r"+j+"']/td/a")).click();
					
					Temp3=true;
					break;
					
				}
			}
			
		}}
		return Temp3;
	}
	
	public static boolean workqueueExist(WebDriver driver,String wqname) throws Exception
	{
		boolean temp2=false;
    	Utilities.selectRightPaneView(driver);
    	
    	int row=driver.findElements(By.xpath("//div[@id='tableWrapper']//table[@id='tableRef']//tbody//tr//th")).size();
    	System.out.println("no of row count  in work pattern iis: "+ row);
    	if(row>0)
    	{
    	String workqname=driver.findElement(By.xpath("//table[@id='tableRef']//tbody//tr[@id='tabler0']//th[@id='tabler0c0']//a")).getAttribute("innerText");
    	System.out.println("work pattern name is: "+ workqname);
    	if(workqname.contains(wqname))
    	{
    		temp2 = true;
    	}
    	
	}
    	return temp2;
}
	
	
	public static boolean WorkQueueExist(WebDriver driver,String workqueueName) throws Exception
	{
		Utilities.selectRightPaneView(driver);
		boolean Temp=false;
		
    	List<WebElement> li=driver.findElements(By.xpath("//table[@id='tableRef']//tr[@class='tblRow']"));
    	System.out.println("++++"+ li.size());
    	if(driver.findElements(By.xpath("//table[@id='tableRef']//tr[@class='tblRow']//th")).size()!=0)
    	{
    		for(WebElement elt:li)
        	{
        		//System.out.println("**************");
        		System.out.println(elt.findElement(By.tagName("th")).getAttribute("innerText"));
        		String wname=elt.findElement(By.tagName("th")).getAttribute("innerText");
        		if(wname.contains(workqueueName))
        		{
        			System.out.println("work queue name is"+wname);
        			Temp=true;
        			break;
        		}
        	}
    	}
    	else
    	{
    		Temp=false;
    	}
    	return Temp;
    	
	}
	
	public static boolean deleteCampaign(WebDriver driver)
	{
		boolean flag=false;
		
		try
		{
			Utilities.selectRightPaneView(driver);
			By delcampbtn=By.xpath(btndelcamp);
			Utilities.waitForPageLoad(driver,delcampbtn);
			if(driver.findElements(delcampbtn).size()!=0)
			{
				driver.findElement(delcampbtn).click();
				extent.log(LogStatus.PASS,"delete buttton is clicked sucessfully");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"delete buttton is not clicked sucessfully");
				flag=false;
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static  boolean selectWorkQueue(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			//Utilities.setWindowFocus(driver);
			int rows=driver.findElements(By.xpath("//div[@id='tableWrapper']//table[@id='tableRef']//tbody//tr")).size();
			System.out.println("no of rows are:"+ rows);
			for(int j=1;j<rows;j++)
			{
				String wqname=driver.findElement(By.xpath("//div[@id='tableWrapper']//table[@id='tableRef']//tbody//tr[contains(@id,'tabler"+j+"')]//th[contains(@id,'tabler"+j+"c0')]//a//span")).getText();
				if(wqname.contains(".AutoWFM_WQ"))
				{
					driver.findElement(By.xpath("//div[@id='tableWrapper']//table[@id='tableRef']//tbody//tr[contains(@id,'tabler"+j+"')]//th[contains(@id,'tabler"+j+"c0')]//a//span")).click();
				}
			}
			driver.findElement(By.id("workpaneMediator_toolbar_ADD_ACTIONLabel")).click();
			flag=true;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clickskill(WebDriver driver)
	{
		boolean flag=false;
		
		try
		{
			Utilities.selectRightPaneView(driver);
			By chkskill=By.xpath(chkboxskill);
			Utilities.waitForPageLoad(driver,chkskill);
			if(driver.findElements(chkskill).size()!=0)
			{
				driver.findElement(chkskill).click();
				extent.log(LogStatus.PASS,"checkbox skill is clicked sucessfully");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"checkbox skill is not clicked sucessfully");
				flag=false;
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean addskill_queue(WebDriver driver,String data)
	{
		boolean flag=false;
		try
		{
			System.out.println("inside add skill function");
			Utilities.selectRightPaneView(driver);
			By skillicon=By.xpath(iconaddskill);
			Utilities.waitForPageLoad(driver,skillicon);
			if(driver.findElements(skillicon).size()!=0)
			{
				driver.findElement(skillicon).click();
				Thread.sleep(2000);
				Select sbox=new Select(driver.findElement(By.xpath("//select[starts-with(@name,'selectionSPSkill')]"))); 
				List<WebElement> li=sbox.getOptions();
				for(WebElement elt:li)
				{
					System.out.println(elt.getText());
				}
				sbox.selectByVisibleText(data);
				extent.log(LogStatus.PASS,"Skill :"+data+"is selected from list box suceessfully");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"Skill is not getting selected from list box");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clickcopydata(WebDriver driver)
	{
		boolean flag=false;
		
		try
		{
			Utilities.selectRightPaneView(driver);
			By btncopydata=By.xpath(rdntncopydata);
			Utilities.waitForPageLoad(driver,btncopydata);
			if(driver.findElements(btncopydata).size()!=0)
			{
				driver.findElement(btncopydata).click();
				extent.log(LogStatus.PASS,"radio  buttton  copy data is clicked sucessfully");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"radio  buttton  copy data is  not clicked sucessfully");
				flag=false;
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clicksave_SP(WebDriver driver)
	{
		boolean flag=true;
		try{	
			Utilities.selectRightPaneView(driver);
			By saveSPBtn=By.id(btnSPSave);
			Utilities.waitForPageLoad(driver,saveSPBtn);
			if (driver.findElements(saveSPBtn).size()!=0)
			{	
				System.out.println("click save");
				driver.findElement(saveSPBtn).click();
				//Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\btnok_campaign.png");
				extent.log(LogStatus.PASS, "Clicked on Scheduling Period Save button is successful");
				Thread.sleep(6000);
			}else
			{
				System.out.println("not in click save");
				extent.log(LogStatus.INFO, "Clicked on Scheduling Period Save button is unsuccessful");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clicksettings(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			System.out.println("inside settings");
			//Utilities.selectRightPaneView(driver);
			By settingslink=By.xpath(linksetting);
			Utilities.waitForPageLoad(driver,settingslink);
			if(driver.findElements(settingslink).size()!=0)
			{
				driver.findElement(settingslink).click();
				extent.log(LogStatus.PASS,"clicked on settings tab is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"not able to click on settings tab");
				return flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
}
