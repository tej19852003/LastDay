
package ScreenObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.sikuli.script.Screen;

import Utilities.Utilities;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class ApplicationAnalysisReportsScreen {
	
	public static Screen sobj = new Screen ();
	public static ExtentReports extent = ExtentReports.get(ApplicationAnalysisReportsScreen.class);
	
	
	public static String lstReportType="ctl00_MidPanelContentHolder_lstViewBy_Input";
	public static String lstDateRange="ctl00_MidPanelContentHolder_ReportDateRange_lstSpecialDate_Input";
									   //ctl00_MidPanelContentHolder_ReportDateRange_lstSpecialDate_Input
	public static String lstFilters="ctl00_MidPanelContentHolder_ReportFilter_lstFilterItems_Input";
	public static String btnAddFilter="//input[@id='ctl00_MidPanelContentHolder_ReportFilter_btnAdd']";
	public static String btnDisplayReport="//input[@id='ctl00_MidPanelContentHolder_btnDisplayReport']";
	public static String labReportName="//span[@id='ctl00_MidPanelContentHolder_lblReportTitle']";
	public static String txtTimeRangeStartTime="//input[@id='ctl00_MidPanelContentHolder_startTimePicker_dateInput']";
	public static String txtTimeRangeEndTime="//input[@id='ctl00_MidPanelContentHolder_endTimePicker_dateInput']";
	public static String chkDataStreamAppDuration="//input[@id='ctl00_MidPanelContentHolder_lstDataStreams_0'][@type='checkbox']";
	public static String chkDataStreamTriggers="//input[@id='ctl00_MidPanelContentHolder_lstDataStreams_1'][@type='checkbox']";
	public static String lstViewBy="ctl00_MidPanelContentHolder_lstViewTimelineBy_Input";
	public static String chkIdleTimeReport="//input[@id='ctl00_MidPanelContentHolder_ReportFilter_chkIncludeIdleTime'][@type='checkbox']";
	
	public static String logReport="//input[@id='ctl00_MidPanelContentHolder_lstReportType_ctl01_btnRunReport']";
	public static String barChartReport="//input[@id='ctl00_MidPanelContentHolder_lstReportType_ctl02_btnRunReport']";
	public static String timeLineReport="//input[@id='ctl00_MidPanelContentHolder_lstReportType_ctl03_btnRunReport']";
	public static String liveInformationReport="//input[@id='ctl00_MidPanelContentHolder_lstReportType_ctl04_btnRunReport']";
	public static String btnEditReport="//input[@id='ctl00_MidPanelContentHolder_btnEditReport']";
	public static String timelineReport="//input[@id='ctl00_MidPanelContentHolder_lstReportType_ctl03_btnRunReport']";
	
	public static boolean clickTimelineReport(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{			
			By addFilterBtn=By.xpath(timelineReport);
			Utilities.waitForPageLoad(driver,addFilterBtn);
			if (driver.findElements(addFilterBtn).size()!=0)
			{					
				driver.findElement(addFilterBtn).click();
				//System.out.println("inside search");
				extent.log(LogStatus.INFO, "Clicked on Timeline Report is successful");
				Thread.sleep(3000);
				flag=true;
			}else
			{
				//System.out.println("not inside search");
				extent.log(LogStatus.FAIL, "Clicked on Timeline Report is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickEditReport(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{			
			By editRepBtn=By.xpath(btnEditReport);
			Utilities.waitForPageLoad(driver,editRepBtn);
			if (driver.findElements(editRepBtn).size()!=0)
			{					
				driver.findElement(editRepBtn).click();
				//System.out.println("inside edit");
				extent.log(LogStatus.INFO, "Clicked on Edit Report is successful");
				Thread.sleep(5000);
				flag=true;
			}else
			{
				//System.out.println("not inside search");
				extent.log(LogStatus.FAIL, "Clicked on Edit Report is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean clicReportCriteria(WebDriver driver,String ReportCriteria) throws Exception
	{
		boolean flag=false;
		try{			
			By RepCriteria=By.xpath(logReport);
			Utilities.waitForPageLoad(driver,RepCriteria);
			if (ReportCriteria.contains("Log Report"))
			{
				if (driver.findElements(By.xpath(logReport)).size()!=0)
				{					
					driver.findElement(By.xpath(logReport)).click();
					flag=true;
				}				
			}
			if (ReportCriteria.contains("Bar Chart Report"))
			{
				if (driver.findElements(By.xpath(barChartReport)).size()!=0)
				{					
					driver.findElement(By.xpath(barChartReport)).click();
					flag=true;
				}				
			}
			if (ReportCriteria.contains("Timeline Report"))
			{
				if (driver.findElements(By.xpath(timeLineReport)).size()!=0)
				{					
					driver.findElement(By.xpath(timeLineReport)).click();
					flag=true;
				}				
			}
			if (ReportCriteria.contains("Live Information Report"))
			{
				if (driver.findElements(By.xpath(liveInformationReport)).size()!=0)
				{					
					driver.findElement(By.xpath(liveInformationReport)).click();
					flag=true;
				}				
			}
			Thread.sleep(5000);
			if (flag==false)
			{
				extent.log(LogStatus.FAIL, "Clicked on Report Criteria:"+ReportCriteria+" is unsuccessful");
			}
			else
			{
				extent.log(LogStatus.PASS, "Clicked on Report Criteria:"+ReportCriteria+" is successful");
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectIncludeIdleTimeInReport_Checkbox(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{			
			By idletimeChk=By.xpath(chkIdleTimeReport);
			Utilities.waitForPageLoad(driver,idletimeChk);
			if (driver.findElements(idletimeChk).size()!=0)
			{				
				if (!driver.findElement(idletimeChk).isSelected())
				{
					driver.findElement(idletimeChk).click();
				}
				Thread.sleep(2000);
				if (driver.findElement(idletimeChk).isSelected())
				{
					flag=true;					
				}				
			}else
			{
				//System.out.println("not datastream app");
				extent.log(LogStatus.FAIL, "Include Idle Time In Report checkbox is not displayed");
			}
			if (flag==true)
			{
				//System.out.println("inside datastream app");
				extent.log(LogStatus.INFO, "Include Idle Time In Report checkbox is selected");	
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "AbilityMaintainIdleTime"));
				Thread.sleep(3000);	
			}
			else
			{
				extent.log(LogStatus.FAIL, "NOT able to select Include Idle Time In Report checkbox");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "AbilityMaintainIdleTime"));
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectViewBy(WebDriver driver,String Option) throws Exception
	{
		boolean flag=false;
		try{
			By viewByLst=By.id(lstViewBy);
			Utilities.waitForPageLoad(driver,viewByLst);
			if (driver.findElements(viewByLst).size()!=0)
			{					
				//System.out.println("inside view by");
				driver.findElement(viewByLst).click();
				Thread.sleep(2000);				
				int rcViewby=driver.findElements(By.xpath("//div[@id='ctl00_MidPanelContentHolder_lstViewTimelineBy_DropDown']/div/ul/li")).size();
				//driver.findElement(By.xpath("//div[@id='ctl00_MidPanelContentHolder_dockTriggerProperties_C_lstCommands_cbCommandList_DropDown']/div/ul/li[5]")).click();
				System.out.println("size:"+rcViewby);
				for (int c=1;c<=rcViewby;c++)
				{
					WebElement list=driver.findElement(By.xpath("//div[@id='ctl00_MidPanelContentHolder_lstViewTimelineBy_DropDown']/div/ul/li["+c+"]"));
					//System.out.println("item:"+list.getText());
					if (list.getText().trim().contains(Option))
					{
						//System.out.println("list item:"+list.getText());
						list.click();
						Thread.sleep(3000);
						flag=true;
						break;
					}
				}
				
			}
			if (flag==false)
			{
				extent.log(LogStatus.FAIL, "Not able to select "+Option+ " from View By dropdown");
			}
			else
			{
				extent.log(LogStatus.PASS, "View By: "+Option+ " is selected");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean selectDataStreamsTriggers_Checkbox(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{			
			By triggerChk=By.xpath(chkDataStreamTriggers);
			Utilities.waitForPageLoad(driver,triggerChk);
			if (driver.findElements(triggerChk).size()!=0)
			{				
				if (!driver.findElement(triggerChk).isSelected())
				{
					driver.findElement(triggerChk).click();
				}
				Thread.sleep(2000);
				if (driver.findElement(triggerChk).isSelected())
				{
					flag=true;					
				}				
			}else
			{
				//System.out.println("not datastream trigger");
				extent.log(LogStatus.FAIL, "Data Streams Triggers checkbox is not displayed");
			}
			if (flag==true)
			{
				//System.out.println("inside datastream app");
				extent.log(LogStatus.INFO, "Data Streams Triggers checkbox is selected");				
				Thread.sleep(3000);	
			}
			else
			{
				extent.log(LogStatus.INFO, "NOT able to select Data Streams Triggers checkbox");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean selectDataStreamsAppDuration_Checkbox(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{			
			By appChk=By.xpath(chkDataStreamAppDuration);
			Utilities.waitForPageLoad(driver,appChk);
			if (driver.findElements(appChk).size()!=0)
			{				
				if (!driver.findElement(appChk).isSelected())
				{
					driver.findElement(appChk).click();
				}
				Thread.sleep(2000);
				if (driver.findElement(appChk).isSelected())
				{
					flag=true;					
				}				
			}else
			{
				//System.out.println("not datastream app");
				extent.log(LogStatus.FAIL, "Data Streams Application Duration checkbox is not displayed");
			}
			if (flag==true)
			{
				//System.out.println("inside datastream app");
				extent.log(LogStatus.INFO, "Data Streams Application Duration checkbox is selected");				
				Thread.sleep(3000);	
			}
			else
			{
				extent.log(LogStatus.INFO, "NOT able to select Data Streams Application Duration checkbox");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean setTimeRange(WebDriver driver,String StartTime,String EndTime)
	{
		boolean flag=false;
		try{		
			By starttimetxt=By.xpath(txtTimeRangeStartTime);
			Utilities.waitForPageLoad(driver,starttimetxt);
			if (driver.findElements(starttimetxt).size()!=0)
			{
				driver.findElement(starttimetxt).clear();
				driver.findElement(starttimetxt).sendKeys(StartTime);
				Thread.sleep(2000);
				extent.log(LogStatus.PASS, "Time Range Start Time: "+StartTime +" is entered successfully");
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Time Range Start Time: "+StartTime +" is NOT entered");
			}
			//end time
			By endtimetxt=By.xpath(txtTimeRangeEndTime);
			Utilities.waitForPageLoad(driver,endtimetxt);
			if (driver.findElements(endtimetxt).size()!=0)
			{
				driver.findElement(endtimetxt).clear();
				driver.findElement(endtimetxt).sendKeys(StartTime);
				Thread.sleep(2000);
				extent.log(LogStatus.PASS, "Time Range End Time: "+EndTime +" is entered successfully");
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Time Range End Time: "+EndTime +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean verifyReportName(WebDriver driver,String ReportName) throws Exception
	{
		boolean flag=false;
		try{			
			By repNamelab=By.xpath(labReportName);
			Utilities.waitForPageLoad(driver,repNamelab);
			if (driver.findElements(repNamelab).size()!=0)
			{					
				if (driver.findElement(repNamelab).getText().trim().contains(ReportName))
				{
					extent.log(LogStatus.PASS, "Report Name:"+ReportName+ " is displayed as Expected");
					extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "ReportName"));
					flag=true;
				}else
				{
					extent.log(LogStatus.FAIL, "Report Name:"+ReportName+ " is NOT displayed");
					extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "ReportName"));
				}
			}else
			{
				extent.log(LogStatus.FAIL, "Report Name:"+ReportName+ " is NOT displayed");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "ReportName"));
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickDisplayReport(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{			
			By dispRepBtn=By.xpath(btnDisplayReport);
			Utilities.waitForPageLoad(driver,dispRepBtn);
			if (driver.findElements(dispRepBtn).size()!=0)
			{					
				driver.findElement(dispRepBtn).click();
				//System.out.println("inside search");
				extent.log(LogStatus.INFO, "Clicked on Display Report is successful");
				Thread.sleep(3000);
				flag=true;
			}else
			{
				//System.out.println("not inside search");
				extent.log(LogStatus.FAIL, "Clicked on Display Report is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickAddFilter(WebDriver driver) throws Exception
	{
		boolean flag=false;
		try{			
			By addFilterBtn=By.xpath(btnAddFilter);
			Utilities.waitForPageLoad(driver,addFilterBtn);
			if (driver.findElements(addFilterBtn).size()!=0)
			{					
				driver.findElement(addFilterBtn).click();
				//System.out.println("inside search");
				extent.log(LogStatus.INFO, "Clicked on Add Filter is successful");
				Thread.sleep(3000);
				flag=true;
			}else
			{
				//System.out.println("not inside search");
				extent.log(LogStatus.FAIL, "Clicked on Add Filter is unsuccessful");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectFilters(WebDriver driver,String FilterOption,String FilterValue) throws Exception
	{
		boolean flag=false;
		try{
			By filtersLst=By.id(lstFilters);
			Utilities.waitForPageLoad(driver,filtersLst);
			if (driver.findElements(filtersLst).size()!=0)
			{					
				//System.out.println("inside filter dropdown");
				driver.findElement(filtersLst).click();
				Thread.sleep(1000);				
				int rcCommand=driver.findElements(By.xpath("//div[@id='ctl00_MidPanelContentHolder_ReportFilter_lstFilterItems_DropDown']/div/ul/li")).size();
				for (int c=1;c<=rcCommand;c++)
				{
					WebElement list=driver.findElement(By.xpath("//div[@id='ctl00_MidPanelContentHolder_ReportFilter_lstFilterItems_DropDown']/div/ul/li["+c+"]"));
					if (list.getText().trim().contains(FilterOption))
					{
						//System.out.println("list item:"+list.getText());
						list.click();
						extent.log(LogStatus.INFO, "Filters:"+FilterOption+ " is selected");
						Thread.sleep(1000);
						if (driver.findElements(By.id("ctl00_MidPanelContentHolder_ReportFilter_cbList_Input")).size()!=0)
						{
							driver.findElement(By.id("ctl00_MidPanelContentHolder_ReportFilter_cbList_Input")).click();
							driver.findElement(By.id("ctl00_MidPanelContentHolder_ReportFilter_cbList_Input")).sendKeys(FilterValue);
						}
						Thread.sleep(2000);
						flag=true;
						/*int rcCommand1=driver.findElements(By.xpath("//div[@id='ctl00_MidPanelContentHolder_ReportFilter_cbList_DropDown']/div/ul/li")).size();
						System.out.println("filtervalueRC:"+rcCommand1);
						if (rcCommand1==1)
						{
							WebElement list1=driver.findElement(By.xpath("//div[@id='ctl00_MidPanelContentHolder_ReportFilter_cbList_DropDown']/div/ul/li[1]"));
							System.out.println("filtervalue:"+list1.getText().trim());
							if (list1.getText().trim().contains(FilterValue))
							{
								System.out.println("list item:"+list1.getText());
								list1.click();
								extent.log(LogStatus.INFO, "Filter Value:"+FilterValue+ " is selected");
								flag=true;
								break;
							}
						}*/						
						break;
					}
				}
				
			}else
			{
				extent.log(LogStatus.FAIL, "Not able to select "+FilterOption+ " from Filters dropdown");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "SelectFilter"));
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectDateRange(WebDriver driver,String Option) throws Exception
	{
		boolean flag=false;
		try{
			
			if (driver.findElement(By.xpath("//a[@id='ctl00_MidPanelContentHolder_ReportDateRange_startDatePicker_popupButton']")).isDisplayed())
			{
				driver.findElement(By.xpath("//input[@id='btnBack'][@type='image']")).click();
				Thread.sleep(5000);
			}
			else
			{
				extent.log(LogStatus.INFO, "Date Range calander icon is NOT displayed");
			}
			/*if (!driver.findElements(By.xpath("//input[@id='btnBack'][@type='image']")).isEmpty())
			{
				driver.findElement(By.xpath("//input[@id='btnBack'][@type='image']")).click();
				Thread.sleep(5000);
			}
			else
			{
				extent.log(LogStatus.INFO, "Date Range back icon is NOT displayed");
			}*/
			By dateRangeLst=By.id(lstDateRange);
			Utilities.waitForPageLoad(driver,dateRangeLst);
			if (driver.findElements(dateRangeLst).size()!=0)
			{					
				//System.out.println("inside command dropdown");
				driver.findElement(dateRangeLst).click();
				Thread.sleep(2000);				
				int rcCommand=driver.findElements(By.xpath("//div[@id='ctl00_MidPanelContentHolder_ReportDateRange_lstSpecialDate_DropDown']/div/ul/li")).size();
				//driver.findElement(By.xpath("//div[@id='ctl00_MidPanelContentHolder_dockTriggerProperties_C_lstCommands_cbCommandList_DropDown']/div/ul/li[5]")).click();
				for (int c=1;c<=rcCommand;c++)
				{
					WebElement list=driver.findElement(By.xpath("//div[@id='ctl00_MidPanelContentHolder_ReportDateRange_lstSpecialDate_DropDown']/div/ul/li["+c+"]"));
					if (list.getText().trim().contains(Option))
					{
						//System.out.println("list item:"+list.getText());
						list.click();
						extent.log(LogStatus.INFO, "Date Range:"+Option+ " is selected");
						
						flag=true;
						break;
					}
				}
				
			}else
			{
				extent.log(LogStatus.FAIL, "Not able to select "+Option+ " from Date Range dropdown");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "AbilityMaintainIdleTime"));
			}			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean selectReportType(WebDriver driver,String Command) throws Exception
	{
		boolean flag=false;
		try{
			//System.out.println("report type dropdown item:"+Command);
			By reportTypeLst=By.id(lstReportType);
			Utilities.waitForPageLoad(driver,reportTypeLst);
			if (driver.findElements(reportTypeLst).size()!=0)
			{					
				//System.out.println("inside report type dropdown");
				driver.findElement(reportTypeLst).click();
				Thread.sleep(2000);				
				int rcCommand=driver.findElements(By.xpath("//div[@id='ctl00_MidPanelContentHolder_lstViewBy_DropDown']/div/ul/li")).size();
				//driver.findElement(By.xpath("//div[@id='ctl00_MidPanelContentHolder_dockTriggerProperties_C_lstCommands_cbCommandList_DropDown']/div/ul/li[5]")).click();
				System.out.println("size:"+rcCommand);
				for (int c=1;c<=rcCommand;c++)
				{
					WebElement list=driver.findElement(By.xpath("//div[@id='ctl00_MidPanelContentHolder_lstViewBy_DropDown']/div/ul/li["+c+"]"));
					//System.out.println("item:"+list.getText());
					if (list.getText().trim().contains(Command))
					{
						//System.out.println("list item:"+list.getText());
						list.click();
						
						flag=true;
						break;
					}
				}
				
			}
			
			if (flag==false)
			{
				extent.log(LogStatus.FAIL, "Not able to select "+Command+ " from Report Type dropdown");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "ReportType"));
			}
			else
			{
				extent.log(LogStatus.PASS, "Report Type: "+Command+ " is selected");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "ReportType"));
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}

}
