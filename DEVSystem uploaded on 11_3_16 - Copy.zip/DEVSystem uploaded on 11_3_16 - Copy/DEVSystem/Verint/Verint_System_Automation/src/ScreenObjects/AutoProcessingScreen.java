package ScreenObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class AutoProcessingScreen {
	
	public static ExtentReports extent = ExtentReports.get(AutoProcessingScreen.class);
	
	public static String btncreate_rule="//button[@id='toolbar_NEW_RULE_DIALOG_NAMELabel']";
	public static String shiftchange="//button[@id='toolbar_NEW_CUSTOM_SHIFTLabel']";
	public static String radiobtnorg="//input[@id='orgScope_thisOrgOnly_0']";
	public static String newshift="//input[@id='requestSubTypeRegNewShift_requestSubTypeRegNewShift_0']";
	public static String chkboxautoapprove="//input[@id='approvedFlag_true_0']";
	public static String radiobtnautoapprove="//input[@id='approveChoice_yes_0']";
	public static String btnsave_rule="//button[@id='workpaneMediator_toolbar_SAVE_ACTIONLabel']";
	public static String btndel_rule="//button[@id='toolbar_DELETE_ACTIONLabel']";
	
	
	public static boolean clickcreate(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By createbtn=By.xpath(btncreate_rule);
			Utilities.waitForPageLoad(driver,createbtn);
			if(driver.findElements(createbtn).size()!=0)
			{
				driver.findElement(createbtn).click();
				extent.log(LogStatus.PASS,"click on create button is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"not able to click on create button");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clickshift(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By chkboxshift=By.xpath(shiftchange);
			Utilities.waitForPageLoad(driver,chkboxshift);
			if(driver.findElements(chkboxshift).size()!=0)
			{
				driver.findElement(chkboxshift).click();
				extent.log(LogStatus.PASS,"click on shift request and change is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"not able to click on shift request and change");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectorg(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By rdbtnorg=By.xpath(radiobtnorg);
			Utilities.waitForPageLoad(driver,rdbtnorg);
			if(driver.findElements(rdbtnorg).size()!=0)
			{
				driver.findElement(rdbtnorg).click();
				extent.log(LogStatus.PASS,"selection of organization is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"not able to select organization");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectshft(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By chkboxshift=By.xpath(newshift);
			Utilities.waitForPageLoad(driver,chkboxshift);
			if(driver.findElements(chkboxshift).size()!=0)
			{
				driver.findElement(chkboxshift).click();
				extent.log(LogStatus.PASS,"selection of new shift is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"not able to select new shift");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectautoapprove(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By chkboxapprove=By.xpath(chkboxautoapprove);
			Utilities.waitForPageLoad(driver,chkboxapprove);
			if(driver.findElements(chkboxapprove).size()!=0)
			{
				driver.findElement(chkboxapprove).click();
				extent.log(LogStatus.PASS,"click on auto approve check box is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"not able to click on auto approve check box");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clickautoapprove(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By rdatnapprove=By.xpath(radiobtnautoapprove);
			Utilities.waitForPageLoad(driver,rdatnapprove);
			if(driver.findElements(rdatnapprove).size()!=0)
			{
				driver.findElement(rdatnapprove).click();
				extent.log(LogStatus.PASS,"click on auto approve radio button is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"not able to click on auto approve radio buttton");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clickSave(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By savebtn=By.xpath(btnsave_rule);
			Utilities.waitForPageLoad(driver,savebtn);
			if(driver.findElements(savebtn).size()!=0)
			{
				driver.findElement(savebtn).click();
				extent.log(LogStatus.PASS,"click on save button is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"not able to click on save button");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectrule(WebDriver driver,String rule)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			List<WebElement> li=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']//tbody//tr[@class='tblRow']"));
			System.out.println("list size is:"+ li.size());
			for(WebElement elt:li)
			{
				System.out.println(elt.findElement(By.tagName("td")).getAttribute("innerText"));
				String rulename=elt.findElement(By.tagName("td")).getAttribute("innerText");
				if(rulename.contains(rule))
				{
					elt.findElement(By.tagName("td")).click();
					System.out.println("clicked on rule");
					flag=true;
					break;
				}
				
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clickdelete(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By delbtn=By.xpath(btndel_rule);
			Utilities.waitForPageLoad(driver,delbtn);
			if(driver.findElements(delbtn).size()!=0)
			{
				driver.findElement(delbtn).click();
				extent.log(LogStatus.PASS,"click on delete button is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"not able to click on delete button");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
}

