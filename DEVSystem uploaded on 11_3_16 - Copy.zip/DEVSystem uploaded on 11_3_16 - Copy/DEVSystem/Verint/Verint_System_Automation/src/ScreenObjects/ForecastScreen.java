package ScreenObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class ForecastScreen 
{
	public static ExtentReports extent = ExtentReports.get(WorkQueuesScreen.class);
	//public static String iconCampaign="//span[@id='campaignSPPeopleFilterBox_listbox_0Wrapper']//nobr//img[@id='campaignSPPeopleFilterBox_listbox_0Button']";
	public static String iconCampaign="//span[@id='spQueueFilterBox_listbox_0Wrapper']//nobr//img[@id='spQueueFilterBox_listbox_0Button']";
	public static String iconPeriod="//span[@id='schedulingPeriodID_0Wrapper']//nobr//img[@id='schedulingPeriodID_0Button']";
	public static String iconwqfilter="//span[@id='applicationMediator_listbox_0Wrapper']//nbor//img[@id='applicationMediator_listbox_0Button']";
	public static String linkqueue="//div[@id='spQueueTreeWrapper']//table[@id='spQueueTree_id']//tbody//tr//th//a//span//span[@id='r0c0Content']";
	
	public static boolean setCampaign(WebDriver driver,String Campname)
	{
		boolean flag=true;
		try{			
			Utilities.selectLeftTreeFrame(driver);
			By iconCamp=By.xpath(iconCampaign);
			Utilities.waitForPageLoad(driver,iconCamp);
			if (driver.findElements(iconCamp).size()!=0)
			{					
				driver.findElement(iconCamp).click();
				Thread.sleep(1000);
				Select sbox1=new Select(driver.findElement(By.id("spQueueFilterBox_listbox")));
				sbox1.selectByVisibleText(Campname);
				//driver.findElement(iconSchPeriod).sendKeys(Period);
				Thread.sleep(3000);				
				extent.log(LogStatus.INFO, "campaign:"+Campname+" is selected from View Listbox for forecast screen");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Not able to select campaign:"+Campname+" from View Listbox");
				return flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean selectCampaign(WebDriver driver,String CampaignName) throws Exception
	{
		boolean flag=true;
		try{
			
			Utilities.selectLeftTreeFrame(driver);
			By iconCamplst=By.xpath(iconCampaign);
			Utilities.waitForPageLoad(driver,iconCamplst);
			if (driver.findElements(iconCamplst).size()!=0)
			{					
				driver.findElement(iconCamplst).click();
				Thread.sleep(1000);
				driver.findElement(iconCamplst).sendKeys(CampaignName);
				Thread.sleep(3000);				
				extent.log(LogStatus.INFO, "Campaign Name:"+CampaignName+" is selected from View Listbox");				
			}else
			{
				extent.log(LogStatus.FAIL, "Not able to select Campaign Name:"+CampaignName+" from View Listbox");
				return flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean selectPeriod(WebDriver driver,String Period) throws Exception
	{
		boolean flag=true;
		try{			
			Utilities.selectLeftTreeFrame(driver);
			By iconPeriodlst=By.xpath(iconPeriod);
			Utilities.waitForPageLoad(driver,iconPeriodlst);
			if (driver.findElements(iconPeriodlst).size()!=0)
			{					
				driver.findElement(iconPeriodlst).click();
				Thread.sleep(1000);
				driver.findElement(iconPeriodlst).sendKeys(Period);
				Thread.sleep(3000);				
				extent.log(LogStatus.INFO, "Period:"+Period+" is selected from View Listbox");				
			}else
			{
				extent.log(LogStatus.FAIL, "Not able to select Period:"+Period+" from View Listbox");
				return flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean setPeriod(WebDriver driver,String Period)
	{
		boolean flag=true;
		try{			
			Utilities.selectLeftTreeFrame(driver);
			By iconSchPeriod=By.xpath(iconPeriod);
			Utilities.waitForPageLoad(driver,iconSchPeriod);
			if (driver.findElements(iconSchPeriod).size()!=0)
			{					
				driver.findElement(iconSchPeriod).click();
				Thread.sleep(1000);
				Select sbox1=new Select(driver.findElement(By.id("schedulingPeriodID")));
				sbox1.selectByVisibleText(Period);
				//driver.findElement(iconSchPeriod).sendKeys(Period);
				Thread.sleep(3000);				
				extent.log(LogStatus.INFO, "Period:"+Period+" is selected from View Listbox for forecast screen");	
				flag=true;
			}else
			{
				extent.log(LogStatus.FAIL, "Not able to select Period:"+Period+" from View Listbox");
				return flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean setFilter(WebDriver driver,String WkQuFilter)
	{
		boolean flag=true;
		try
		{
			Utilities.selectLeftTreeFrame(driver);
			By iconFilter=By.xpath(iconwqfilter);
			Utilities.waitForPageLoad(driver,iconFilter);
			if(driver.findElements(iconFilter).size()!=0)
			{
				driver.findElement(iconFilter).click();
				Thread.sleep(1000);
				driver.findElement(iconFilter).sendKeys(WkQuFilter);
				extent.log(LogStatus.INFO,"Filter: " + WkQuFilter+" is selected from list box");
			}
			else
			{
				extent.log(LogStatus.FAIL,"Not able to  select filter" +WkQuFilter+ "from list box");
				return flag=false;
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectworkQueue(WebDriver driver,String workQueue)
	{
		boolean flag=false;
		try
		{
			Utilities.selectLeftTreeFrame(driver);
			By linkwq=By.xpath(linkqueue);
			Utilities.waitForPageLoad(driver,linkwq);
			if(driver.findElements(linkwq).size()!=0)
			{
				String wqueue=driver.findElement(linkwq).getText();
				System.out.println("work quue name is:"+wqueue);
				if(wqueue.contains(workQueue))
				{
					driver.findElement(linkwq).click();
					extent.log(LogStatus.PASS,"work queue" + workQueue +" is selected sucessfully");
					flag=true;
				}
				
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"work queue is not selected");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
}
