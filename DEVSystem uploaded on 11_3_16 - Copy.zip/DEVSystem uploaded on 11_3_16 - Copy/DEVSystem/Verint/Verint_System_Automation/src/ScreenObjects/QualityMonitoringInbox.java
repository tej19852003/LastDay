package ScreenObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.sikuli.script.Key;
import org.sikuli.script.KeyModifier;
import org.sikuli.script.Screen;



import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class QualityMonitoringInbox {

	public static ExtentReports extent = ExtentReports.get(Impact360Screen.class);
	public static Screen sobj = new Screen ();
	
	public static String lnkAddRule="//a[@id='InboxPreferenceControl1_rulesGrid_m_AddButton_m_AddButton']";
	
	public static boolean deleteInboxRuleName(WebDriver driver,String RuleName) throws Exception
	{
		Boolean Temp=false;
		driver.switchTo().defaultContent();
		driver.switchTo().frame(0);
		Thread.sleep(1000);
		driver.switchTo().frame(1);
		Thread.sleep(1000);
		
		int rc=driver.findElements(By.xpath("//table[@id='InboxPreferenceControl1_rulesGrid_Grid']/tbody/tr")).size();
		System.out.println("rc:"+rc);
		for (int i=1;i<=rc;i++)
		{		
			String ruleNameApp=driver.findElement(By.xpath("//table[@id='InboxPreferenceControl1_rulesGrid_Grid']/tbody/tr["+i+"]/td[2]")).getText();
			System.out.println("rulenameapp:"+ruleNameApp);
			if (ruleNameApp.contains(RuleName))
			{			
				if (driver.findElements(By.xpath("//table[@id='InboxPreferenceControl1_rulesGrid_Grid']/tbody/tr["+i+"]/td[5]/a/img[@alt='Delete rule']")).size()!=0)
				{
					driver.findElement(By.xpath("//table[@id='InboxPreferenceControl1_rulesGrid_Grid']/tbody/tr["+i+"]/td[5]/a/img[@alt='Delete rule']")).click();
				}
				//click yes
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Confirmation_Yes.png") != null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Confirmation_Yes.png");
					extent.log(LogStatus.INFO,"Clicked on Yes button is successful");
					Temp=true;
					break;
				}
				else
				{
					extent.log(LogStatus.FAIL,"Not able to click on Yes button");
					return Temp=false;
				}				
			}
		}
		if (Temp==true)
		{					
			extent.log(LogStatus.PASS, "Rule Name:"+RuleName+" deleted successfully");	
			//extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "RuleName"));
			//delete rule name
		}
		else
		{
			extent.log(LogStatus.FAIL, "Rule Name:"+RuleName+" NOT deleted/displayed ");
			//extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Campaign"));
			return Temp=false;
		}
	
		return Temp;
	}
	
	public static boolean validateRuleName(WebDriver driver,String RuleName) throws Exception
	{
		System.out.println("in rule function");
		Boolean Temp=false;
		Thread.sleep(5000);
		driver.switchTo().defaultContent();
		/*driver.switchTo().frame(0);
		Thread.sleep(1000);
		driver.switchTo().frame(1);
		Thread.sleep(1000);*/
		Utilities.switchFrame(driver,"FR_GRID");
		Thread.sleep(1000);
		Utilities.switchFrame(driver,"main");
		Thread.sleep(1000);
		int rc=driver.findElements(By.xpath("//table[@id='InboxPreferenceControl1_rulesGrid_Grid']/tbody/tr")).size();
		System.out.println("rc:"+rc);
		for (int i=1;i<=rc;i++)
		{		
			String ruleNameApp=driver.findElement(By.xpath("//table[@id='InboxPreferenceControl1_rulesGrid_Grid']/tbody/tr["+i+"]/td[2]")).getText();
			System.out.println("rulenameapp:"+ruleNameApp);
			if (ruleNameApp.contains(RuleName))
			{		
				Temp=true;
				break;
			}
		}
		if (Temp==true)
		{					
			extent.log(LogStatus.PASS, "Rule Name:"+RuleName+" created successfully");	
			extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "RuleName"));
			//delete rule name
		}
		else
		{
			extent.log(LogStatus.FAIL, "Rule Name:"+RuleName+" NOT created/displayed ");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Campaign"));
			return Temp=false;
		}	
		return Temp;
	}
	
	public static boolean clickAddRule(WebDriver driver) throws Exception  
	{
		boolean flag=false;
		try{
			/*By addRuleLnk=By.xpath(lnkAddRule);
			driver.switchTo().defaultContent();
			driver.switchTo().frame(0);	
			Thread.sleep(1000);
			driver.switchTo().frame(1);
			Thread.sleep(1000);
			Utilities.waitForPageLoad(driver,addRuleLnk);
			if (driver.findElements(addRuleLnk).size()!=0)
			{					
				driver.findElement(addRuleLnk).click();				
				extent.log(LogStatus.INFO, "Clicked on Add Rule is successful");
				Thread.sleep(10000);
				flag=true;
			}
			else
			{
				 extent.log(LogStatus.FAIL,"Clicked on Add Rule is UNsuccessful");
				 flag=false;
			}*/
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Inbox_AddRule.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Inbox_AddRule.png");
				extent.log(LogStatus.INFO, "Clicked on Add Rule is successful");
				Thread.sleep(10000);
				flag=true;			
			}
			else
			{
				 extent.log(LogStatus.FAIL,"Clicked on Add Rule is UNsuccessful");
				 flag=false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
}
