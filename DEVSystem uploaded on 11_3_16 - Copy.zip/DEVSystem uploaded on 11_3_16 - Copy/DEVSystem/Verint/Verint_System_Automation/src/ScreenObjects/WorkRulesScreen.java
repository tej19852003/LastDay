package ScreenObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import com.thoughtworks.selenium.webdriven.commands.GetText;

public class WorkRulesScreen 
{
	public static ExtentReports extent = ExtentReports.get(WorkQueuesScreen.class);
	public static String txtfindEmployee="peopleFilter_find";
	public static String btnAdd="workPatternToolbar_POPUP_WORKPATTERNLabel";
	public static String btnSave="toolbar_SAVE_ACTIONLabel";
	public static String btnaddrotation="//button[@id='rotationToolbar_POPUP_ROTATIONLabel']";
	public static String iconemp_pool="//input[@id='poolingRule__canPool__input_id']";
	public static String btnSet="//button[@id='workpaneMediator_toolbar_SET_ACTIONLabel']";
	
	public static boolean findEmployee(WebDriver driver,String EmployeeName)
	{
		boolean flag=false;
		try
		{
			Utilities.selectLeftTreeFrame(driver);
			By txtName=By.name(txtfindEmployee);
			Utilities.waitForPageLoad(driver,txtName);
			if(driver.findElements(txtName).size()!=0)
			{
				driver.findElement(txtName).clear();
				driver.findElement(txtName).sendKeys(EmployeeName,Keys.ENTER);
				flag=true;
				extent.log(LogStatus.PASS,EmployeeName +" is entered sucessfully");
			}
			else
			{
				extent.log(LogStatus.FAIL,EmployeeName + "is not searched");
			}
			
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
		
	}
	
	public static boolean SelectEmployee(WebDriver driver,String EmployeeName) throws Exception
	{
		boolean flag=false;
		Utilities.selectLeftTreeFrame(driver);
		int no= driver.findElements(By.xpath("//div[@id='psWrapper']//table[@id='psLIST_TBL_NAME']//tbody//tr")).size();
		System.out.println("no of rows are:" + no);
		//String empname=driver.findElement(By.xpath("//table[@id='psLIST_TBL_NAME']//tbody//tr[1]//td[2]//div//nobr//a")).getText();
		for(int i=1;i<no;i++)
		{
			String empname=driver.findElement(By.xpath("//table[@id='psLIST_TBL_NAME']//tbody//tr["+i+"]//td//div//nobr//a")).getText();
			System.out.println("emp name is:"+ empname );
			if(empname.contains(EmployeeName))
			{
				driver.findElement(By.xpath("//table[@id='psLIST_TBL_NAME']//tbody//tr["+i+"]//td//div//nobr//a")).click();
				Thread.sleep(2000);
				break;
				
			}
			flag=true;
		}
		if(flag==true)
		{
			extent.log(LogStatus.PASS,EmployeeName +"is selected sucessfully");
		}
		else
		{
			extent.log(LogStatus.FAIL,EmployeeName + " does not exist");
			return flag=false;
		}
		return flag;
	
	}
	
	public static boolean clickAdd(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By btnAddwp=By.id(btnAdd);
			Utilities.waitForPageLoad(driver,btnAddwp);
			if(driver.findElements(btnAddwp).size()!=0)
			{
				driver.findElement(btnAddwp).click();
				extent.log(LogStatus.PASS,"clicked on Add work pattern is sucessfull");
				Thread.sleep(6000);
				flag = true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"clicked on add work pattren is not sucessfull");
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return flag;
	}
	
	
	public static boolean clickSave(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By Savebtn=By.id(btnSave);
			Utilities.waitForPageLoad(driver,Savebtn);
			if(driver.findElements(Savebtn).size()!=0)
			{
				driver.findElement(Savebtn).click();
				extent.log(LogStatus.PASS,"clicked on save button is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"clicked on save button is not sucessfull");
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}
	
	public static  boolean clickAddworkPattern(WebDriver driver,String workPatternName)
	
	{
		boolean flag=false;
		try
	{
		Utilities.setWindowFocus(driver);
		/*driver.switchTo().frame("oRightPaneContent");
        driver.findElement(By.xpath("//button[@id='workPatternToolbar_POPUP_WORKPATTERNLabel']")).click();*/
        Thread.sleep(2000);
        driver.findElement(By.xpath("//button[@id='workpaneMediator_toolbar_NEXT_ACTIONLabel']")).click();
        Thread.sleep(2000);
		int no=driver.findElements(By.xpath("//div[@id='tableWrapper']//table[@id='tableRef']//tr")).size();
		System.out.println("no of rows are:" + no);
		for(int i=1;i<no;i+=2)
		{
			String wpname=driver.findElement(By.xpath("//div[@id='tableWrapper']//table[@id='tableRef']//tr[contains(@id,'tabler"+i+"')]//td[contains(@id,'tabler"+i+"c1')]")).getText();
			System.out.println("shift name is:" + wpname);
			if(wpname.contains(workPatternName))
			{
				driver.findElement(By.xpath("//div[@id='tableWrapper']//table[@id='tableRef']//tr[contains(@id,'tabler"+i+"')]//td[contains(@id,'tabler"+i+"c1')]")).click();
				break;
			}
		}
		driver.findElement(By.xpath("//button[@id='workpaneMediator_toolbar_addWorkPatternsLabel']")).click();
		flag=true;
	}catch(Exception e)
	{
		e.printStackTrace();
	}
		return flag;
		
		
	}
	
	public static boolean sethours(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			//driver.findElement(By.name("hoursPC__minPaid__input")).clear();
			driver.findElement(By.name("hoursPC__minPaid__input")).sendKeys("8");
			//driver.findElement(By.name("hoursPC__maxPaid__input")).clear();
			driver.findElement(By.name("hoursPC__maxPaid__input")).sendKeys("40");
			//driver.findElement(By.name("hoursPC__otPerDay__input")).clear();
			driver.findElement(By.name("hoursPC__otPerDay__input")).sendKeys("4");
			//driver.findElement(By.name("hoursPC__otPerWeek__input")).clear();
			driver.findElement(By.name("hoursPC__otPerWeek__input")).sendKeys("20");
			
			flag=true;
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean WorkPatternexist(WebDriver driver,String Wname) throws Exception
	{
		Utilities.selectRightPaneView(driver);
		boolean Temp=false;
		
    	List<WebElement> li=driver.findElements(By.xpath("//table[@id='workPatternTableRef']//tr[@class='tblRow']"));
    	System.out.println("++++"+ li.size());
    	if(driver.findElements(By.xpath("//table[@id='workPatternTableRef']//tr[@class='tblRow']//th")).size()!=0)
    	{
    		for(WebElement elt:li)
        	{
        		//System.out.println("**************");
        		System.out.println(elt.findElement(By.tagName("th")).getAttribute("innerText"));
        		String wname=elt.findElement(By.tagName("th")).getAttribute("innerText");
        		if(wname.contains(Wname))
        		{
        			System.out.println("work pattern name is"+wname);
        			Temp=true;
        			break;
        		}
        	}
    	}
    	else
    	{
    		Temp=false;
    	}
    	return Temp;
    	
	}
	
	
	public static boolean WorkPatternremove(WebDriver driver) throws Exception
	{
		Utilities.selectRightPaneView(driver);
		boolean flag=false;
		
    	List<WebElement> li=driver.findElements(By.xpath("//table[@id='workPatternTableRef']//tr[@class='tblRow']"));
    	System.out.println("++++"+ li.size());
    	if(driver.findElements(By.xpath("//table[@id='workPatternTableRef']//tr[@class='tblRow']//th")).size()!=0)
    	{
    		for(WebElement elt:li)
        	{
        		//System.out.println("**************");
        		System.out.println(elt.findElement(By.tagName("th")).getAttribute("innerText"));
        		String wname=elt.findElement(By.tagName("th")).getAttribute("innerText");
        		elt.findElement(By.tagName("th")).click();
        		driver.findElement(By.xpath("//button[@id='workPatternToolbar_removeWorkPatternLabel']")).click();
        		extent.log(LogStatus.PASS,"work Pattern is removed successfully");
        		flag=true;
        		break;
        	}
    	}
    	else
    	{
    		flag=false;
    		extent.log(LogStatus.INFO,"no workpattern available");
    	}
    	return flag;
    	
	}
	
	
	public static boolean clickAddrotation(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By btnAddrot=By.xpath(btnaddrotation);
			Utilities.waitForPageLoad(driver,btnAddrot);
			if(driver.findElements(btnAddrot).size()!=0)
			{
				driver.findElement(btnAddrot).click();
				extent.log(LogStatus.PASS,"clicked on Add rotation is sucessfull");
				Thread.sleep(6000);
				flag = true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"clicked on add rotation is not sucessfull");
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return flag;
	}
	
	public static boolean Rotationexist(WebDriver driver,String Rname) throws Exception
	{
		Utilities.selectRightPaneView(driver);
		boolean Temp=false;
		
    	List<WebElement> li=driver.findElements(By.xpath("//table[@id='rotationTableRef']//tr[@class='tblRow']"));
    	System.out.println("++++"+ li.size());
    	if(driver.findElements(By.xpath("//table[@id='rotationTableRef']//tr[@class='tblRow']//th")).size()!=0)
    	{
    		for(WebElement elt:li)
        	{
        		//System.out.println("**************");
        		System.out.println(elt.findElement(By.tagName("th")).getAttribute("innerText"));
        		String wname=elt.findElement(By.tagName("th")).getAttribute("innerText");
        		if(wname.contains(Rname))
        		{
        			System.out.println("rotation name is"+wname);
        			Temp=true;
        			break;
        		}
        	}
    	}
    	else
    	{
    		Temp=false;
    	}
    	return Temp;
    	
	}
	
	
public static  boolean Addrotation(WebDriver driver,String RotationName)
	
	{
		boolean flag=false;
		try
	{
		
       
		int no=driver.findElements(By.xpath("//div[@id='tableWrapper']//table[@id='tableRef']//tr")).size();
		System.out.println("no of rows are:" + no);
		for(int i=0;i<no;i++)
		{
			String wpname=driver.findElement(By.xpath("//div[@id='tableWrapper']//table[@id='tableRef']//tr[contains(@id,'tabler"+i+"')]//th[contains(@id,'tabler"+i+"c0')]")).getText();
			System.out.println("shift name is:" + wpname);
			if(wpname.contains(RotationName))
			{
				driver.findElement(By.xpath("//div[@id='tableWrapper']//table[@id='tableRef']//tr[contains(@id,'tabler"+i+"')]//th[contains(@id,'tabler"+i+"c0')]")).click();
				break;
			}
		}
		driver.findElement(By.xpath("//button[@id='workpaneMediator_toolbar_addRotationsLabel']")).click();
		flag=true;								  
	}catch(Exception e)
	{
		e.printStackTrace();
	}
		return flag;
		
		
	}


public static boolean Rotationremove(WebDriver driver) throws Exception
{
	Utilities.selectRightPaneView(driver);
	boolean flag=false;
	
	List<WebElement> li=driver.findElements(By.xpath("//table[@id='rotationTableRef']//tr[@class='tblRow']"));
	System.out.println("++++"+ li.size());
	if(driver.findElements(By.xpath("//table[@id='rotationTableRef']//tr[@class='tblRow']//th")).size()!=0)
	{
		for(WebElement elt:li)
    	{
    		//System.out.println("**************");
    		System.out.println(elt.findElement(By.tagName("th")).getAttribute("innerText"));
    		String wname=elt.findElement(By.tagName("th")).getAttribute("innerText");
    		elt.findElement(By.tagName("th")).click();
    		driver.findElement(By.xpath("//button[@id='rotationToolbar_removeRotationLabel']")).click();
    		extent.log(LogStatus.PASS,"Rotation is removed successfully");
    		flag=true;
    		break;
    	}
	}
	else
	{
		flag=false;
		extent.log(LogStatus.INFO,"no rotation is available");
	}
	return flag;
	
}

public static boolean clickEmployeePool(WebDriver driver)
{
	boolean flag=false;
	try
	{
		Utilities.selectRightPaneView(driver);
		By emppoolicon=By.xpath(iconemp_pool);
		Utilities.waitForPageLoad(driver,emppoolicon);
		if(driver.findElements(emppoolicon).size()!=0)
		{
			driver.findElement(emppoolicon).click();
			extent.log(LogStatus.PASS,"clicked on employee pool icon is sucessfull");
			Thread.sleep(6000);
			flag = true;
		}
		else
		{
			extent.log(LogStatus.FAIL,"clicked on employee pool icon is not sucessfull");
			
		}
	}catch(Exception e)
	{
		e.printStackTrace();
	}
	
	return flag;
}


public static boolean selectOrganizationSelector(WebDriver driver, String OrgName) throws Exception
{
	boolean flag=true;
	boolean Temp1=false;
	//String mainWind="";
	try{					
			//Utilities.setWindowFocus(driver);
			Thread.sleep(2000);
			System.out.println("rows:"+driver.findElements(By.xpath("//table[@id='orgTree_id']//tbody//tr")).size());
			if (driver.findElements(By.xpath("//table[@id='orgTree_id']/tbody/tr")).size()!=0)
			{
				int rcOrg=driver.findElements(By.xpath("//table[@id='orgTree_id']//tr")).size();
				System.out.println("rcOrg:"+rcOrg);
				for (int p=1;p<=rcOrg;p++)
				{
					String orgApp=driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+p+"]/td[2]/label/span")).getText().trim();
					System.out.println("orgApp:"+orgApp);
					System.out.println("orgname:"+OrgName);
					Thread.sleep(1000);
					if (orgApp.contains(OrgName))
					{					
						if (!driver.findElement(By.xpath("//table[@id='orgTree_id']//tr["+p+"]/td[1]/span/input[@name='checkedOrgID'][@type='checkbox']")).isSelected())
							{
							driver.findElement(By.xpath("//table[@id='orgTree_id']//tr["+p+"]/td[1]/span/input[@name='checkedOrgID'][@type='checkbox']")).click();
							Temp1=true;
							break;	
							}						
					}
				}
				if (Temp1==true)
				{
					System.out.println("pass");
					extent.log(LogStatus.PASS, "Organization Name : "+OrgName+" Selected successfully");
					if (driver.findElements(By.xpath(btnSet)).size()!=0)
					{
						driver.findElement(By.xpath(btnSet)).click();
						Thread.sleep(3000);
						extent.log(LogStatus.INFO, "Clicked on Set button in Condition Value Selection popup window");
					}
					else
					{
						extent.log(LogStatus.WARNING, "Not able to Clicked on Set button in Condition Value Selection popup window");
						return flag=false;
					}
					//captureScreenShot(driver,screenshotDir+"OrganizationNameValidation");				
				}
				else
				{
					extent.log(LogStatus.FAIL, "Unable to Select Organization Name : "+OrgName);
					//captureScreenShot(driver,screenshotDir+"RoleNameValidation");
					return flag =false;
				}
			}
			else
			{
				extent.log(LogStatus.FAIL, "Condition Value Selection popup window is not displayed");
			}			
		
			
	}catch (Exception e) {
		e.printStackTrace();
	}
	//driver.switchTo().window(mainWind);
	return flag;
}

	
}
