package ScreenObjects;



import java.io.File;
import java.io.PrintWriter;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class RuleSettingsScreen {

	public static ExtentReports extent = ExtentReports.get(Impact360Screen.class);
	public static String btnCreate="//button[@id='toolbar_CREATE_RULELabel']";
	public static String txtRulename="ruleName";
	public static String txtRuledesc="ruleDescription";
	public static String btnRuleSave="toolbar_SAVE_RULELabel";
	public static String btnYes="toolbar_CREATE_RULE_YES_DIALOGLabel";
	//public static String lnkSchedule="//span[@id='RULE_SCHEDULE_spn_id']/a";
	public static String lnkSchedule="Schedule";
	//public static String lnkCondition="//span[@id='RULE_CONDITIONS_spn_id']/a";
	public static String lnkCondition="Condition";
	public static String lnkSettings="Settings";
	public static String btnScheduleSave="toolbar_SAVE_RULE_SCHEDULELabel";
	public static String btnAdd="FREE_EXP_DYNAMIC_LIST_toolbar_ADD_ACTIONLabel";
	public static String btnCondDelete="FREE_EXP_DYNAMIC_LIST_toolbar_DELETE_ACTIONLabel";
	public static String imgSelectAttribute="//img[@id='freeExpAttributeID_0_IMGID_img_id']";
	public static String imgConditionValue="//img[@id='freeExpInputValue_0_IMGID'][@alt='Select']";
	public static String btnSet="//button[@id='workpaneMediator_toolbar_POPUP_JSFUNCTIONLabel']";
	public static String btnConditionSave="//button[@id='toolbar_SAVE_RULE_CONDITIONLabel']";
	public static String labelTxtMsg="//div[@id='workPaneWrapper']/table[@id='viewfindPane_tbl_id']/tbody/tr/td[2]/div[1]/div";
	public static String btnDelete="//button[@id='toolbar_DELETE_RULELabel']";
	public static String btnrightArrow="//button[@id='assignBox_tb_ASSIGN_RIGHTLabel']";
	public static String btncreate_rule="//button[@id='toolbar_ADD_ACTIONLabel']";
	public static String iconrule="//span[@id='templateID_0Wrapper']//nobr//img[@id='templateID_0Button']";
	public static String iconrequesttype="//span[@id='ruleParamValue_INPUT_rulerequesttype_0Wrapper']//nobr//img[@id='ruleParamValue_INPUT_rulerequesttype_0Button']";
	public static String iconstatus="//span[@id='ruleParamValue_INPUT_rulerequesttype_SEC_0Wrapper']//nobr//img[@id='ruleParamValue_INPUT_rulerequesttype_SEC_0Button']";
	public static String iconaction_email="//input[@name='bChk_checkbox_email']";
	public static String iconaction_employee="//input[@name='tWEmployee12']";
	public static String iconaction_supervisor="//input[@name='tWSupervisor12']";
	public static String iconaction_text="//input[@name='sLTextCheck12']";
	public static String btnsave="//button[@id='toolbar_CREATE_NEW_ACTIONLabel']";
	public static String btndelete_rule="//button[@id='toolbar_DELETE_ACTIONLabel']";
	public static String iconactivity="//span[@id='ruleParamValue_INPUT_Activity_0Wrapper']//nobr//img[@id='ruleParamValue_INPUT_Activity_0Button']";
	public static String txtrminder="//input[@id='ruleParamValue_INPUT_ReminderTime_0']";
	
	public static boolean selectCTIConditionValue(WebDriver driver, String ConditionValue) throws Exception
	{
		boolean flag=true;
		boolean Temp1=false;
		boolean Temp2=false;
		String mainWind="";
		try{
			By condValimg=By.xpath(imgConditionValue);
			Utilities.waitForPageLoad(driver,condValimg);
			if (driver.findElements(condValimg).size()!=0)
			{					
				driver.findElement(condValimg).click();				
				extent.log(LogStatus.PASS, "Clicked on Condition Value Selection icon is successful");
				Thread.sleep(6000);
				//mainWind=Utilities.setWindowFocus(driver);				
				for(String winHandle :driver.getWindowHandles()){
	                driver.switchTo().window(winHandle);
	                if(driver.getTitle().contains("Condition Value"))
	                {
	                	Temp2=true;
	                	System.out.println("You are in Condition Value Selection window");
	                	driver.manage().window().maximize();
	                    break;
	                }			
				}
			}
			else
			{
				extent.log(LogStatus.FAIL, "Clicked on Condition Value Selection is un successful");
				flag=false;
			}		
			
			if (Temp2==true)
			{
				Thread.sleep(2000);
				System.out.println("rows:"+driver.findElements(By.xpath("//table[@id='assignBox_srcTable']/tbody/tr")).size());
				if (driver.findElements(By.xpath("//table[@id='assignBox_srcTable']/tbody/tr")).size()!=0)
				{
					int rcOrg=driver.findElements(By.xpath("//table[@id='assignBox_srcTable']/tbody/tr")).size();
					System.out.println("rcOrg:"+rcOrg);
					
						for (int p=1;p<=rcOrg;p++)
						{
							String orgApp=driver.findElement(By.xpath("//table[@id='assignBox_srcTable']/tbody/tr["+p+"]/td/a/span")).getText().trim();
							System.out.println("orgApp:"+orgApp);
							System.out.println("orgname:"+ConditionValue);
							Thread.sleep(1000);
							if (orgApp.contains(ConditionValue))
							{					
								driver.findElement(By.xpath("//table[@id='assignBox_srcTable']/tbody/tr["+p+"]/td/a/span")).click();										
								Temp1=true;
								break;
							}
						}
						if (Temp1==true)
						{
							System.out.println("pass");
							extent.log(LogStatus.PASS, "Condition Value : "+ConditionValue+" Selected successfully");
							//click right arrow
							if (driver.findElements(By.xpath(btnrightArrow)).size()!=0)
							{
								driver.findElement(By.xpath(btnrightArrow)).click();
								Thread.sleep(3000);
								extent.log(LogStatus.INFO, "Clicked on right arrow button is successful in Condition Value Selection popup window");
							}
							else
							{
								extent.log(LogStatus.WARNING, "Not able to Click on right arrow button in Condition Value Selection popup window");
								return flag=false;
							}
							//destination table
							int rcOrg1=driver.findElements(By.xpath("//table[@id='assignBox_dstTable']/tbody/tr")).size();
							System.out.println("rcOrg:"+rcOrg1);
							
							for (int p=1;p<=rcOrg1;p++)
							{
								String condDestApp=driver.findElement(By.xpath("//table[@id='assignBox_dstTable']/tbody/tr["+p+"]/td/a/span")).getText().trim();
								System.out.println("condDestApp:"+condDestApp);
								System.out.println("orgnamedest:"+ConditionValue);
								Thread.sleep(1000);
								if (condDestApp.contains(ConditionValue))
								{					
									driver.findElement(By.xpath("//table[@id='assignBox_dstTable']/tbody/tr["+p+"]/td/a/span")).click();										
									flag=true;
									Thread.sleep(3000);
									break;
								}
							}						
							
							if (driver.findElements(By.xpath(btnSet)).size()!=0)
							{
								driver.findElement(By.xpath(btnSet)).click();
								Thread.sleep(5000);
								extent.log(LogStatus.INFO, "Clicked on Set button in Condition Value Selection popup window");
							}
							else
							{
								extent.log(LogStatus.WARNING, "Not able to Clicked on Set button in Condition Value Selection popup window");
								flag=false;
							}
							//captureScreenShot(driver,screenshotDir+"OrganizationNameValidation");				
						}
						else
						{
							extent.log(LogStatus.FAIL, "Unable to Select Condition Value : "+ConditionValue);
							//captureScreenShot(driver,screenshotDir+"RoleNameValidation");
							flag =false;
						}					
				}
				else
				{
					extent.log(LogStatus.FAIL, "Not able to select Condition Value");
					flag =false;
				}			
			}
			
				
		}catch (Exception e) {
			e.printStackTrace();
		}
		//driver.switchTo().window(mainWind);
		for(String winHandle :driver.getWindowHandles()){
            driver.switchTo().window(winHandle);
            if(driver.getTitle().contains("System Management"))
            {
            	Temp2=true;
            	System.out.println("You are in System Management window");
            	//driver.manage().window().maximize();
                break;
            }			
		}
		return flag;
	}
	
	
	public static boolean selectActivity(WebDriver driver,String activity)
	{
		boolean flag=false;
		try
		
		{
			By activityicon=By.xpath(iconactivity);
			Utilities.waitForPageLoad(driver,activityicon);
			if(driver.findElements(activityicon).size()!=0)
			{
				driver.findElement(activityicon).click();
				Select sbox=new Select(driver.findElement(By.xpath("//select[@name='ruleParamValue_INPUT_Activity']")));
				sbox.selectByVisibleText(activity);
				extent.log(LogStatus.PASS,"Activity:"+ activity+"is sleected form dropdown");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"value is not selected form dropdowm");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean getTextFromAudiRecordingPercentage(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{
			Utilities.selectRightPaneView(driver);
			if (driver.findElements(By.xpath("//input[@id='actionPercentage_0']")).size()!=0)
			{
				String percent=driver.findElement(By.xpath("//input[@id='actionPercentage_0']")).getAttribute("value");
				extent.log(LogStatus.INFO, "Audio Recording Percentage :"+percent+" is displayed");
			}
			else
			{
				extent.log(LogStatus.FAIL, "Audio Recording Percentage is NOT displayed");
				flag=false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static void viewRecordingRulesSchedule(WebDriver driver) throws Exception
	{		
		//boolean flag=true;
		try{
			Utilities.selectRightPaneView(driver);
			if (driver.findElement(By.xpath("//input[@id='bChk_sunday_true_0']")).isSelected())
			{
				extent.log(LogStatus.INFO, "Enabled on every Sunday checkbox is selected");
			}
			else
			{
				extent.log(LogStatus.INFO, "Enabled on every Sunday checkbox is NOT selected");
			}
			if (driver.findElement(By.xpath("//input[@id='bChk_monday_true_0']")).isSelected())
			{
				extent.log(LogStatus.INFO, "Enabled on every Monday checkbox is selected");
			}
			else
			{
				extent.log(LogStatus.INFO, "Enabled on every Monday checkbox is NOT selected");
			}
			if (driver.findElement(By.xpath("//input[@id='bChk_tuesday_true_0']")).isSelected())
			{
				extent.log(LogStatus.INFO, "Enabled on every Tuesday checkbox is selected");
			}
			else
			{
				extent.log(LogStatus.INFO, "Enabled on every Tuesday checkbox is NOT selected");
			}
			if (driver.findElement(By.xpath("//input[@id='bChk_wednesday_true_0']")).isSelected())
			{
				extent.log(LogStatus.INFO, "Enabled on every Wednesday checkbox is selected");
			}
			else
			{
				extent.log(LogStatus.INFO, "Enabled on every Wednesday checkbox is NOT selected");
			}
			if (driver.findElement(By.xpath("//input[@id='bChk_thursday_true_0']")).isSelected())
			{
				extent.log(LogStatus.INFO, "Enabled on every Thursday checkbox is selected");
			}
			else
			{
				extent.log(LogStatus.INFO, "Enabled on every Thursday checkbox is NOT selected");
			}
			if (driver.findElement(By.xpath("//input[@id='bChk_friday_true_0']")).isSelected())
			{
				extent.log(LogStatus.INFO, "Enabled on every Friday checkbox is selected");
			}
			else
			{
				extent.log(LogStatus.INFO, "Enabled on every Friday checkbox is NOT selected");
			}
			if (driver.findElement(By.xpath("//input[@id='bChk_saturday_true_0']")).isSelected())
			{
				extent.log(LogStatus.INFO, "Enabled on every Saturday checkbox is selected");
			}
			else
			{
				extent.log(LogStatus.INFO, "Enabled on every Saturday checkbox is NOT selected");
			}
			if (driver.findElement(By.xpath("//input[@id='timeSchedule_AllDay_1']")).isSelected())
			{
				extent.log(LogStatus.INFO, "Time to Schedule : All Day radio button is selected");
			}
			else
			{
				extent.log(LogStatus.INFO, "Time to Schedule : All Day radio button is NOT selected");
			}
			//time zone
			if (driver.findElement(By.xpath("//input[@id='timeZoneType_LocalTime_1']")).isSelected())
			{
				extent.log(LogStatus.INFO, "Time Zone : Local time zone of Integration Service radio button is selected");
			}
			else
			{
				extent.log(LogStatus.INFO, "Time Zone : Local time zone of Integration Service radio button is NOT selected");
			}
			//beginning
			if (driver.findElement(By.xpath("//input[@id='timeZoneType_LocalTime_1']")).isSelected())
			{
				extent.log(LogStatus.INFO, "Beginning : immediately radio button is selected");
			}
			else
			{
				extent.log(LogStatus.INFO, "Beginning : immediately radio button is NOT selected");
			}
			//ending
			if (driver.findElement(By.xpath("//input[@id='endDateType_NoEnd_1']")).isSelected())
			{
				extent.log(LogStatus.INFO, "ending : No end date radio button is selected");
			}
			else
			{
				extent.log(LogStatus.INFO, "ending : No end date radio button is NOT selected");
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static boolean clickSettinglnk(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{
			driver.switchTo().defaultContent();
			By settingslnk=By.linkText(lnkSettings);
			Utilities.waitForPageLoad(driver,settingslnk);
			if (driver.findElements(settingslnk).size()!=0)
			{					
				driver.findElement(settingslnk).click();
				extent.log(LogStatus.PASS, "Clicked on Settings link is successful");
				Thread.sleep(8000);
			}else
			{
				//driver.findElement(schedulelnk).click();
				extent.log(LogStatus.INFO, "Clicked on Settings link is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickDelete(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{
			driver.switchTo().defaultContent();
			Utilities.selectRightPaneView(driver);
			By delbtn=By.xpath(btnDelete);
			Utilities.waitForPageLoad(driver,delbtn);
			if (driver.findElements(delbtn).size()!=0)
			{					
				driver.findElement(delbtn).click();
				extent.log(LogStatus.PASS, "Clicked on Delete button is successful");
				Thread.sleep(6000);
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Delete button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectRule(WebDriver driver,String RuleName) throws Exception
	{
		driver.switchTo().defaultContent();		
		Utilities.selectLeftTreeFrame(driver);
		Boolean Temp1=false;
		try {
			int valrcRule=driver.findElements(By.xpath("//table[@id='ruleSelectionLIST_TBL_NAME']/tbody/tr")).size();
			System.out.println("valrcrule:"+valrcRule);
			for (int p=1;p<=valrcRule;p++)
			{
				if (p<=15)
				{
				String rulenameApp=driver.findElement(By.xpath("//table[@id='ruleSelectionLIST_TBL_NAME']/tbody/tr["+p+"]/td/div/nobr/a/span")).getText().trim();
				System.out.println("rulenameApp:"+rulenameApp);
				System.out.println("rulenameCreated:"+RuleName);
				
				if (rulenameApp.contains(RuleName))
				{
					driver.findElement(By.xpath("//table[@id='ruleSelectionLIST_TBL_NAME']/tbody/tr["+p+"]/td/div/nobr/a/span")).click();					
					Temp1=true;
					break;
				}}
			}
			if (Temp1==true)
			{
				System.out.println("pass");
				extent.log(LogStatus.PASS, "Name: "+RuleName+" Created/Selected successfully");
				//extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "RecordingRule"));				
			}
			else
			{
				extent.log(LogStatus.FAIL, "Unable to Create/Select Ruler Name: "+RuleName);
				//extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "RecordingRule"));
				Temp1 =false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return Temp1;
		
	}
	
	public static boolean verifyRule(WebDriver driver,String RuleName) throws Exception
	{
		driver.switchTo().defaultContent();		
		Utilities.selectLeftTreeFrame(driver);
		Boolean Temp1=false;
		try {
			int valrcRule=driver.findElements(By.xpath("//table[@id='ruleSelectionLIST_TBL_NAME']/tbody/tr")).size();
			System.out.println("valrcrule:"+valrcRule);
			for (int p=1;p<=valrcRule;p++)
			{
				if (p<=15)
				{
				String rulenameApp=driver.findElement(By.xpath("//table[@id='ruleSelectionLIST_TBL_NAME']/tbody/tr["+p+"]/td/div/nobr/a/span")).getText().trim();
				System.out.println("rulenameApp:"+rulenameApp);
				System.out.println("rulenameCreated:"+RuleName);
				
				if (rulenameApp.contains(RuleName))
				{
					driver.findElement(By.xpath("//table[@id='ruleSelectionLIST_TBL_NAME']/tbody/tr["+p+"]/td/div/nobr/a/span")).click();					
					Temp1=true;
					break;
				}}
			}
			if (Temp1==true)
			{
				//System.out.println("pass");
				extent.log(LogStatus.INFO, "Name: "+RuleName+" already exist");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "RecordingRule"));				
			}
			else
			{
				extent.log(LogStatus.INFO, "RuleName:"+RuleName+" does not exist. Please create.");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "RecordingRule"));
				Temp1 =false;
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return Temp1;
		
	}
	
	
	
	public static boolean verifySuccessMessage(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{
			By messageTxt=By.xpath(labelTxtMsg);
			//Utilities.waitForPageLoad(driver,impDomUserBtn);
			Thread.sleep(6000);
			//System.out.println("msg:"+driver.findElement(messageTxt));
			if (driver.findElements(messageTxt).size()!=0)
			{					
				String msg=driver.findElement(By.xpath("//div[@id='workPaneWrapper']/table[@id='viewfindPane_tbl_id']/tbody/tr/td[2]/div[1]/div")).getText();
				if (msg.contains("Successfully"))
				{
					extent.log(LogStatus.PASS, "Message:"+msg+" is displayed");
					Thread.sleep(3000);
					extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "RecordingRule"));
				}
				else
				{
					extent.log(LogStatus.FAIL, "Message:"+msg+" is displayed");
					extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "RecordingRule"));
					return flag=false;
				}
			}else
			{
				extent.log(LogStatus.WARNING, "Success message is not displayed");
				return flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean clickConditionSave(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{
			driver.switchTo().defaultContent();
			Utilities.selectRightPaneView(driver);
			By condSavebtn=By.xpath(btnConditionSave);
			Utilities.waitForPageLoad(driver,condSavebtn);
			if (driver.findElements(condSavebtn).size()!=0)
			{					
				driver.findElement(condSavebtn).click();
				extent.log(LogStatus.PASS, "Clicked on Condition - Save button is successful");
				Thread.sleep(6000);
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Condition - Save button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean selectConditionValue(WebDriver driver, String ConditionValue) throws Exception
	{
		boolean flag=true;
		boolean Temp1=false;
		boolean Temp2=false;
		String mainWind="";
		try{
			By condValimg=By.xpath(imgConditionValue);
			Utilities.waitForPageLoad(driver,condValimg);
			if (driver.findElements(condValimg).size()!=0)
			{					
				driver.findElement(condValimg).click();				
				extent.log(LogStatus.PASS, "Clicked on Condition Value Selection icon is successful");
				Thread.sleep(6000);
				//mainWind=Utilities.setWindowFocus(driver);				
				for(String winHandle :driver.getWindowHandles()){
	                driver.switchTo().window(winHandle);
	                if(driver.getTitle().contains("Condition Value"))
	                {
	                	Temp2=true;
	                	System.out.println("You are in Condition Value Selection window");
	                	driver.manage().window().maximize();
	                    break;
	                }			
				}
			}
			else
			{
				extent.log(LogStatus.FAIL, "Clicked on Condition Value Selection is un successful");
				flag=false;
			}		
			
			if (Temp2==true)
			{
				Thread.sleep(2000);
				System.out.println("rows:"+driver.findElements(By.xpath("//table[@id='employeeOrganizationSelectorPC_id']/tbody/tr")).size());
				if (driver.findElements(By.xpath("//table[@id='employeeOrganizationSelectorPC_id']/tbody/tr")).size()!=0)
				{
					int rcOrg=driver.findElements(By.xpath("//table[@id='employeeOrganizationSelectorPC_id']/tbody/tr")).size();
					System.out.println("rcOrg:"+rcOrg);
					if (rcOrg>=15)
					{
						for (int p=1;p<=rcOrg;p++)
						{
							String orgApp=driver.findElement(By.xpath("//table[@id='employeeOrganizationSelectorPC_id']/tbody/tr["+p+"]/td[2]/label/span")).getText().trim();
							System.out.println("orgApp:"+orgApp);
							System.out.println("orgname:"+ConditionValue);
							Thread.sleep(1000);
							if (orgApp.contains(ConditionValue))
							{					
								driver.findElement(By.xpath("//table[@id='employeeOrganizationSelectorPC_id']/tbody/tr["+p+"]/td[1]/span/input[@name='checkedOrgID'][@type='radio']")).click();										
								Temp1=true;
								break;
							}
						}
						if (Temp1==true)
						{
							System.out.println("pass");
							extent.log(LogStatus.PASS, "Condition Value : "+ConditionValue+" Selected successfully");
							if (driver.findElements(By.xpath(btnSet)).size()!=0)
							{
								driver.findElement(By.xpath(btnSet)).click();
								Thread.sleep(3000);
								extent.log(LogStatus.INFO, "Clicked on Set button in Condition Value Selection popup window");
							}
							else
							{
								extent.log(LogStatus.WARNING, "Not able to Clicked on Set button in Condition Value Selection popup window");
								flag=false;
							}
							//captureScreenShot(driver,screenshotDir+"OrganizationNameValidation");				
						}
						else
						{
							extent.log(LogStatus.FAIL, "Unable to Select Condition Value : "+ConditionValue);
							//captureScreenShot(driver,screenshotDir+"RoleNameValidation");
							flag =false;
						}
					}
				}
				else
				{
					extent.log(LogStatus.FAIL, "Not able to select Condition Value");
					flag =false;
				}			
			}
			
				
		}catch (Exception e) {
			e.printStackTrace();
		}
		//driver.switchTo().window(mainWind);
		for(String winHandle :driver.getWindowHandles()){
            driver.switchTo().window(winHandle);
            if(driver.getTitle().contains("System Management"))
            {
            	Temp2=true;
            	System.out.println("You are in System Management window");
            	//driver.manage().window().maximize();
                break;
            }			
		}
		return flag;
	}
	
	public static boolean selectAttribute(WebDriver driver,String AttributName) throws Exception
	{		
		boolean flag=true;
		boolean Temp=false;
		try{
			By attimg=By.xpath(imgSelectAttribute);
			Utilities.waitForPageLoad(driver,attimg);
			if (driver.findElements(attimg).size()!=0)
			{					
				driver.findElement(attimg).click();				
				extent.log(LogStatus.PASS, "Clicked on Add button is successful");
				Thread.sleep(2000);
				int rulerc=driver.findElements(By.xpath("//table[@id='AttributeTree_id']/tbody/tr")).size();
				System.out.println("rulerowc:"+rulerc);
				for (int p=1;p<=rulerc;p++)
				{
					String attributName=driver.findElement(By.xpath("//table[@id='AttributeTree_id']/tbody/tr["+p+"]/th/a/span")).getText().trim();
					System.out.println("attributNameApp:"+attributName);
					System.out.println("AttributName:"+AttributName);
					Thread.sleep(1000);
					if (attributName.contains(AttributName))
					{
						driver.findElement(By.xpath("//table[@id='AttributeTree_id']/tbody/tr["+p+"]/th/a/span")).click();
						Temp=true;
						break;
						
					}
				}
				if (Temp==false)
				{
					return flag=false;
				}
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Select Attribute is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickConditionDelete(WebDriver driver,String AttributeName) throws Exception
	{		
		boolean flag=false;
		boolean temp=false;
		try{
			driver.switchTo().defaultContent();
			Utilities.selectRightPaneView(driver);
			
			int rc1=driver.findElements(By.xpath("//table[@id='FREE_EXP_DYNAMIC_LIST_tableWrapper']/tbody/tr")).size();
			System.out.println("rc1:"+rc1);
			for (int j=1;j<=rc1;j++)
			{
				if (j<=15)
				{
					String attName=driver.findElement(By.xpath("//table[@id='FREE_EXP_DYNAMIC_LIST_tableWrapper']/tbody/tr["+j+"]/td[1]/input")).getText();				
					//String attName1=driver.findElement(By.xpath("//table[@id='FREE_EXP_DYNAMIC_LIST_tableWrapper']/tbody/tr["+j+"]/td[1]/input[@id='Name_freeExpAttributeID_0']")).getText();
					
					Thread.sleep(1000);
					System.out.println("att name:"+attName);
					String attName2=driver.findElement(By.xpath("//table[@id='FREE_EXP_DYNAMIC_LIST_tableWrapper']/tbody/tr["+j+"]/td[1]")).getText();
					System.out.println("att name:"+attName2);
					if (attName.contains(AttributeName))
					{
						driver.findElement(By.xpath("//table[@id='FREE_EXP_DYNAMIC_LIST_tableWrapper']/tbody/tr["+j+"]/td[1]/input")).click();
						temp=true;
						break;
					}
				}
			}
			if (temp==true)
			{
				By addbtn=By.id(btnCondDelete);
				Utilities.waitForPageLoad(driver,addbtn);
				if (driver.findElements(addbtn).size()!=0)
				{					
					driver.findElement(addbtn).click();
					extent.log(LogStatus.PASS, "Clicked on Condition Delete button is successful");
					Thread.sleep(6000);
					flag=true;
				}else
				{
					extent.log(LogStatus.INFO, "Clicked on Condition Delete button is unsuccessful");
					flag=false;
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickAdd(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{
			driver.switchTo().defaultContent();
			Utilities.selectRightPaneView(driver);
			By addbtn=By.id(btnAdd);
			Utilities.waitForPageLoad(driver,addbtn);
			if (driver.findElements(addbtn).size()!=0)
			{					
				driver.findElement(addbtn).click();
				extent.log(LogStatus.PASS, "Clicked on Add button is successful");
				Thread.sleep(6000);
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Add button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickConditionlnk(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{
			driver.switchTo().defaultContent();
			By conditionlnk=By.linkText(lnkCondition);
			Utilities.waitForPageLoad(driver,conditionlnk);
			if (driver.findElements(conditionlnk).size()!=0)
			{					
				driver.findElement(conditionlnk).click();
				extent.log(LogStatus.PASS, "Clicked on Condition link is successful");
				Thread.sleep(15000);
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Condition link is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickScheduleSave(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{
			driver.switchTo().defaultContent();
			Utilities.selectRightPaneView(driver);
			By scheduleSavebtn=By.id(btnScheduleSave);
			Utilities.waitForPageLoad(driver,scheduleSavebtn);
			if (driver.findElements(scheduleSavebtn).size()!=0)
			{					
				driver.findElement(scheduleSavebtn).click();
				extent.log(LogStatus.PASS, "Clicked on Schedule - Save button is successful");
				Thread.sleep(4000);
			}else
			{
				extent.log(LogStatus.INFO, "Clicked on Schedule Save button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickSchedulelnk(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{
			driver.switchTo().defaultContent();
			By schedulelnk=By.linkText(lnkSchedule);
			Utilities.waitForPageLoad(driver,schedulelnk);
			if (driver.findElements(schedulelnk).size()!=0)
			{					
				driver.findElement(schedulelnk).click();
				extent.log(LogStatus.PASS, "Clicked on Schedule link is successful");
				Thread.sleep(8000);
			}else
			{
				driver.findElement(schedulelnk).click();
				extent.log(LogStatus.INFO, "Clicked on Schedule link is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	public static boolean clickYes(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{
			By yesbtn=By.id(btnYes);
			Utilities.waitForPageLoad(driver,yesbtn);
			if (driver.findElements(yesbtn).size()!=0)
			{					
				driver.findElement(yesbtn).click();
				extent.log(LogStatus.PASS, "Clicked on Yes button is successful");
				Thread.sleep(4000);
			}else
			{
				extent.log(LogStatus.INFO, "Yes button is not displayed");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static void setTextInRuleDescription(WebDriver driver,String RuleDesc) throws Exception
	{
		try{		
			By ruledesctxt=By.name(txtRuledesc);
			Utilities.waitForPageLoad(driver,ruledesctxt);
			if (driver.findElements(ruledesctxt).size()!=0)
			{
				driver.findElement(ruledesctxt).clear();
				driver.findElement(ruledesctxt).sendKeys(RuleDesc);
				extent.log(LogStatus.PASS, "Rule Description: "+RuleDesc +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Rule Description: "+RuleDesc +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void setTextInRulename(WebDriver driver,String RuleName) throws Exception
	{
		try{		
			By ruleNametxt=By.name(txtRulename);
			Utilities.waitForPageLoad(driver,ruleNametxt);
			if (driver.findElements(ruleNametxt).size()!=0)
			{
				driver.findElement(ruleNametxt).clear();
				driver.findElement(ruleNametxt).sendKeys(RuleName);
				extent.log(LogStatus.PASS, "Rule Name: "+RuleName +" is entered successfully");				
			}else
			{
				extent.log(LogStatus.FAIL, "Rule Name: "+RuleName +" is NOT entered");
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public static boolean clickRuleSave(WebDriver driver) throws Exception
	{		
		boolean flag=true;
		try{
			By rsavebtn=By.id(btnRuleSave);
			Utilities.waitForPageLoad(driver,rsavebtn);
			if (driver.findElements(rsavebtn).size()!=0)
			{					
				driver.findElement(rsavebtn).click();
				extent.log(LogStatus.PASS, "Clicked on Rule - Save button is successful");
				Thread.sleep(4000);
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked on Rule - Save button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickCreate(WebDriver driver) throws Exception
	{
		boolean flag=true;
		try{
			By createBtn=By.xpath(btnCreate);
			
			Utilities.waitForPageLoad(driver,createBtn);
			if (driver.findElements(createBtn).size()!=0)
			{					
				driver.findElement(createBtn).click();
				extent.log(LogStatus.INFO, "Clicked on Rule Settings - Create button is successful");
				Thread.sleep(4000);
			}else
			{
				extent.log(LogStatus.FAIL, "Clicked onRule Settings - Create button is unsuccessful");
				flag=false;
			}
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clickCreate_Rule(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By createbtn=By.xpath(btncreate_rule);
			Utilities.waitForPageLoad(driver,createbtn);
			if(driver.findElements(createbtn).size()!=0)
			{
				driver.findElement(createbtn).click();
				extent.log(LogStatus.PASS,"clicked on create button is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on save button");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	
	public static boolean selectruletype(WebDriver driver,String Ruletype)
	{
		boolean flag=false;
		try
		
		{
			By ruleicon=By.xpath(iconrule);
			Utilities.waitForPageLoad(driver,ruleicon);
			if(driver.findElements(ruleicon).size()!=0)
			{
				driver.findElement(ruleicon).click();
				Select sbox=new Select(driver.findElement(By.xpath("//select[@name='templateID']")));
				sbox.selectByVisibleText(Ruletype);
				extent.log(LogStatus.PASS,"rule Type:"+ Ruletype+"is sleected form dropdown");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"value is not selected form dropdowm");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean selectrequesttype(WebDriver driver,String Requesttype)
	{
		boolean flag=false;
		try
		
		{
			By requesticon=By.xpath(iconrequesttype);
			Utilities.waitForPageLoad(driver,requesticon);
			if(driver.findElements(requesticon).size()!=0)
			{
				driver.findElement(requesticon).click();
				Select sbox=new Select(driver.findElement(By.xpath("//select[@name='ruleParamValue_INPUT_rulerequesttype']")));
				sbox.selectByVisibleText(Requesttype);
				extent.log(LogStatus.PASS,"Request Type:"+ Requesttype+"is sleected form dropdown");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"value is not selected form dropdowm");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean selectStatustype(WebDriver driver,String Statustype)
	{
		boolean flag=false;
		try
		
		{
			By statusicon=By.xpath(iconstatus);
			Utilities.waitForPageLoad(driver,statusicon);
			if(driver.findElements(statusicon).size()!=0)
			{
				driver.findElement(statusicon).click();
				Select sbox=new Select(driver.findElement(By.xpath("//select[@name='ruleParamValue_INPUT_rulerequesttype_SEC']")));
				sbox.selectByVisibleText(Statustype);
				extent.log(LogStatus.PASS,"status Type:"+ Statustype+"is sleected form dropdown");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"value is not selected form dropdowm");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickAction_email(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			By email_action=By.xpath(iconaction_email);
			Utilities.waitForPageLoad(driver,email_action);
			if(driver.findElements(email_action).size()!=0)
			{
				driver.findElement(email_action).click();
				extent.log(LogStatus.PASS,"clicked on action email is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on action email");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clickEmployee(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			By emp_icon=By.xpath(iconaction_employee);
			Utilities.waitForPageLoad(driver,emp_icon);
			if(driver.findElements(emp_icon).size()!=0)
			{
				driver.findElement(emp_icon).click();
				extent.log(LogStatus.PASS,"clicked on employee checkbox is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on employee checkbox");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean clickSupervisor(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			By supervisor_icon=By.xpath(iconaction_supervisor);
			Utilities.waitForPageLoad(driver,supervisor_icon);
			if(driver.findElements(supervisor_icon).size()!=0)
			{
				driver.findElement(supervisor_icon).click();
				extent.log(LogStatus.PASS,"clicked on supervisor checkbox is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on supervisor checkbox");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean settext_email(WebDriver driver,String data)
	{
		boolean flag=false;
		try
		{
			By text_icon=By.xpath(iconaction_text);
			Utilities.waitForPageLoad(driver,text_icon);
			if(driver.findElements(text_icon).size()!=0)
			{
				driver.findElement(text_icon).click();
				driver.findElement(By.xpath("//input[@name='sLText12']")).sendKeys(data);
				extent.log(LogStatus.PASS,"data entered for email is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL, "data entered for email is not sucessfull");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickSave_Rule(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By savebtn=By.xpath(btnsave);
			Utilities.waitForPageLoad(driver,savebtn);
			if(driver.findElements(savebtn).size()!=0)
			{
				driver.findElement(savebtn).click();
				extent.log(LogStatus.PASS,"clicked on save button is sucessfull");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "RulePage"));
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on save button");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	public static boolean clickDelete_Rule(WebDriver driver)
	{
		boolean flag=false;
		try
		{
			Utilities.selectRightPaneView(driver);
			By delbtn=By.xpath(btndelete_rule);
			Utilities.waitForPageLoad(driver,delbtn);
			if(driver.findElements(delbtn).size()!=0)
			{
				driver.findElement(delbtn).click();
				extent.log(LogStatus.PASS,"clicked on delete button is sucessfull");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on delete button");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	
	
	public static boolean setreminder(WebDriver driver,String time)
	{
		boolean flag=false;
		try
		{
			By remindertime=By.xpath(txtrminder);
			Utilities.waitForPageLoad(driver,remindertime);
			if(driver.findElements(remindertime).size()!=0)
			{
				driver.findElement(remindertime).sendKeys(time);
				extent.log(LogStatus.PASS,"Time:"+time+"has been entered successfully");
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL,"not able to enter time");
				flag=false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	   return flag;
		
	}
	
}
