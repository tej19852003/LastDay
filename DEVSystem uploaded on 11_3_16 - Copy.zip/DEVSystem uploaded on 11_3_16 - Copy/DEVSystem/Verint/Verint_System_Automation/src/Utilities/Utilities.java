package Utilities;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.lang.reflect.Method;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.Screen;

import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import jxl.Sheet;
import jxl.Workbook;
import jxl.format.Alignment;
import jxl.format.Colour;
import jxl.format.Pattern;
import jxl.format.UnderlineStyle;

import jxl.write.Label;

import jxl.write.WritableCellFormat;
import jxl.write.WritableFont;
import jxl.write.WritableHyperlink;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;



public class Utilities {
	public static String datapath;
	public static String sheetname;
	public static ExtentReports extent = ExtentReports.get(Utilities.class);
	public static Screen sobj = new Screen ();
	public static String frameTreeViewLeftPane="oLeftPaneContent";
	public static String frameRightPaneContent="oRightPaneContent";
	

	//GlobalVriables
	public static Properties Globlocators=new Properties(); 
	public static File GloblocFile =new File("C:\\DEVSystem\\Verint\\Verint_System_Automation\\src\\Properties\\GlobalVariables.properties");

	public static void LoadGlobLoc() throws Exception
	{
		Globlocators.load(new FileInputStream(GloblocFile));
	}
	
	public static boolean selectmenu(WebDriver driver,String UserName,String Password,String TabName,String MenuItem) throws Exception
	{	
		boolean flag=false;
		LoginScreen.setTextInUsername(driver,UserName);
		LoginScreen.setTextInPassword(driver,Password);
		LoginScreen.clickLogin(driver);
		if (VerintHomePageScreen.verifyVerintHomePage(driver))
		{					
			VerintHomePageScreen.selectMenuItem(driver,TabName,MenuItem);
			Thread.sleep(6000);
			if (driver.findElements(By.linkText(TabName)).size()==0)
			{
				Utilities.Logout(driver); //logout							
			}
			else
			{
				return flag=true;
			}
		}
		else
		{
			return flag=false;
		}
		return flag;
	
	}
	
	public static void windowsSecurityCredentials(WebDriver driver,String UserName,String Password) throws Exception
	{
		Thread.sleep(3000);
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_UserName.png") != null)
		{
			sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_UserName.png",UserName);
		
		//Thread.sleep(1000);
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_Password.png") != null)
		{
			sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_Password.png",Password);
		}
		//Thread.sleep(1000);
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png") != null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
		}
		}
	}
	public static boolean SearchItem(WebDriver driver,String SearchText) throws Exception
	{
		boolean flag=false;
		boolean temp=false;
		Robot r = new Robot();
		
		for (int s=1;s<=5;s++)
		{
			r.keyPress(KeyEvent.VK_CONTROL);
			r.keyPress(KeyEvent.VK_F);
			Thread.sleep(1000);
			r.keyRelease(KeyEvent.VK_CONTROL);
			r.keyRelease(KeyEvent.VK_F);
			Thread.sleep(3000);
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\FindText.png") != null)
			{
				sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\FindText.png", SearchText);
				Thread.sleep(5000);
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\NoMatchesFound.png") != null)
				{					
					temp=false;				
				}
				else
				{
					temp=true;					
				}
				System.out.println(temp);
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\FindText_Close.png");
				break;
			}
		}
		if (temp==true)
		{
			extent.log(LogStatus.PASS, "Search Item:"+SearchText+" successful");
			flag=true;
		}
		else
		{
			extent.log(LogStatus.FAIL, "Search Item:"+SearchText+" NOT successful");
			flag=false;
		}	
		return flag;
	}
	public static boolean sikuliClick(WebDriver driver,String ImagePath) throws Exception
	{
		boolean flag=true;
		if (sobj.exists(ImagePath) != null)
		{
			sobj.click(ImagePath);			
			Thread.sleep(3000);
		}
		else
		{
			flag=false;
		}
		return flag;
	}
	public static void sikuliType(WebDriver driver,String ImagePath,String Text) throws Exception
	{
		if (sobj.exists(ImagePath) != null)
		{
			sobj.type(ImagePath,Text);
			Thread.sleep(2000);
		}
	}
	
	public static boolean sikuliExist(WebDriver driver,String ImagePath) throws Exception
	{
		boolean flag=true;
		if (sobj.exists(ImagePath) != null)
		{
			extent.log(LogStatus.PASS,"Call is in Playback state");	
			extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QM05_07_14_Playback_EvalForm_RemarksBy"));
		}
		else
		{
			extent.log(LogStatus.FAIL,"Call is NOT in Playback state");
			extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "QM05_07_14_Playback_EvalForm_RemarksBy"));
			flag=false;
		}
		return flag;
	}
	
	public static void selectRightPaneView(WebDriver driver) throws Exception
	{
		driver.switchTo().defaultContent();	
		Thread.sleep(2000);
		WebElement oRightPaneContentFrame = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.id(frameRightPaneContent)));
		driver.switchTo().frame(oRightPaneContentFrame);
		Thread.sleep(3000);
	}
	public static void selectLeftTreeFrame(WebDriver driver) throws Exception
	{
		driver.switchTo().defaultContent();
		Thread.sleep(1000);
		WebElement leftTreeContentFrame1 = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.id(frameTreeViewLeftPane)));
		driver.switchTo().frame(leftTreeContentFrame1);
		Thread.sleep(1000);
	}
	
	public static void sikuliRightClick(WebDriver driver,String ImagePath) throws Exception
	{
		if (sobj.exists(ImagePath) != null)
		{
			sobj.rightClick(ImagePath);
			System.out.println("clicked on this image");
			//sobj.wait((double) 3.0);
			Thread.sleep(3000);
		}
	}
	
	
	public static void Logout(WebDriver driver) throws Exception
	{
		driver.switchTo().defaultContent();
		if (driver.findElements(By.id("utilityPanePC_LOGOUT_spn_id")).size()!=0)
			driver.findElement(By.id("utilityPanePC_LOGOUT_spn_id")).click();
		Thread.sleep(3000);
		//extent.endTest();		
	}
	public static String setWindowFocus(WebDriver driver) throws Exception
	{
		Set<String> windowIds = driver.getWindowHandles();
		Iterator<String> itererator = windowIds.iterator(); 			
		String mainWinID = itererator.next();//main window 
		Thread.sleep(2000);
		String  popWindow = itererator.next();//popup window
		driver.switchTo().window(popWindow);//Switch the driver to the popup window
		return mainWinID;
	}
	public static boolean setWindow(WebDriver driver,String Title) throws Exception
	{
		boolean flag=false;
		String parentHandle = driver.getWindowHandle();
		for(String winHandle :driver.getWindowHandles()){
            driver.switchTo().window(winHandle);
            if(driver.getTitle().contains(Title))
            {
            	flag=true;
            	System.out.println("You are in "+Title+" window");
            	driver.manage().window().maximize();
                break;
            }			
		}
		if (flag==true)			
	    {
	    	extent.log(LogStatus.PASS, Title+" window opened successfully");	    	
	    }
	    else
	    {
	    	extent.log(LogStatus.FAIL, Title+" window NOT opened");	    	
	    }
		return flag;
	}
	public static boolean setFocus(WebDriver driver,String Title) throws Exception
	{
		boolean flag=false;
		String parentHandle = driver.getWindowHandle();
		for(String winHandle :driver.getWindowHandles()){
            driver.switchTo().window(winHandle);
            if(driver.getTitle().contains(Title))
            {
            	flag=true;
            	System.out.println("You are in "+Title+" window");
            	driver.switchTo().window(winHandle);
                break;
            }			
		}
		if (flag==true)			
	    {
	    	extent.log(LogStatus.PASS, Title+" window focus successful");	    	
	    }
	    else
	    {
	    	extent.log(LogStatus.FAIL, Title+" window NOT focused");	    	
	    }
		return flag;
	}
	public static boolean closeWindow(WebDriver driver,String Title) throws Exception
	{
		boolean flag=false;
		String parentHandle = driver.getWindowHandle();
		for(String winHandle :driver.getWindowHandles()){
            driver.switchTo().window(winHandle);
            if(driver.getTitle().contains(Title))
            {
            	flag=true;
            	System.out.println("You are in "+Title+" window");
            	driver.close();
                break;
            }			
		}
		if (flag==true)			
	    {
	    	extent.log(LogStatus.PASS, Title+" window closed successfully");	    	
	    }
	    else
	    {
	    	extent.log(LogStatus.FAIL, Title+" window NOT closed");	    	
	    }
		return flag;
	}
	public static boolean folderExist(String Path,String Type)
	{
		boolean flag=true;
		File prodDir=new File(Path);
		boolean exists = prodDir.exists();
	    if (exists) 
	    {
	    	extent.log(LogStatus.PASS, Path+" "+Type+" exists");	    	
	    }
	    else
	    {
	    	extent.log(LogStatus.FAIL, Path+" "+Type+" does not exists");
	    	return flag==false;
	    }
	    return flag;
	}
	public static void displayDirectoryContents(File dir) {
	    try {
	        File[] files = dir.listFiles();
	        for (File file : files) {
	            if (file.isDirectory()) {
	            	extent.log(LogStatus.INFO, "Directory Name=>:" + file.getCanonicalPath());
	                //System.out.println("Directory Name=>:" + file.getCanonicalPath());
	                displayDirectoryContents(file);
	            } else {
	            	extent.log(LogStatus.INFO, "file Name=>" + file.getCanonicalPath());
	            }
	        }
	    } catch (IOException e) {
	        e.printStackTrace();
	    }
	}
	
	public static void waitForPageLoad(WebDriver driver ,By str) throws Exception
	{
		for(int i=0; i<15 && driver.findElements(str).size()==0 ; i++)
			{
			   Thread.sleep(1000);
			}		
	}
	
	public static void testcaseSetup(String HTMLReportName,String TestcaseName) throws Exception
	{
		String screenshotDir = Utilities.Globlocators.getProperty("ScreenShotPath");
		new File(screenshotDir).mkdirs();
		//System.out.println(screenshotDir);
		
		String reportsDir=Utilities.Globlocators.getProperty("ReportPath");
		new File(reportsDir).mkdirs();		
        
		ExtentReports extent = ExtentReports.get(Utilities.class);		
		extent.init(Utilities.Globlocators.getProperty("ReportPath")+"\\"+HTMLReportName+".html", true);		
		extent.config().documentTitle("Verint Automation Test Result Report");        
        extent.config().reportHeadline(TestcaseName+" Result Report"); 
        extent.config().displayCallerClass(false);
        extent.config().useExtentFooter(false);
        extent.startTest(TestcaseName);

		//File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		//System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
        
       
		
	}
	//Method Name    : captureScreenShot
		//Purpose		 : To create new Organization
		//Date			 : 8/3/2015
		//Author		 : d9ix
		public static String captureScreenShot(WebDriver driver,String PageName) throws Exception
		{		 
			String screenshotPath="";
			File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		    try {
		        // copy file object to designated location
		    	screenshotPath=Utilities.Globlocators.getProperty("ScreenShotPath")+PageName+"_"+System.currentTimeMillis()+".png";
		        FileUtils.copyFile(scrFile, new File(screenshotPath));
		        //System.out.println("imgpath:"+screenshotPath);
		        Thread.sleep(2000);
		    } catch (IOException e) {
		        System.out.println("Error while generating screenshot:\n" + e.toString());
		    }

			return screenshotPath;

		}
	
		
		//@SuppressWarnings( { "unchecked", "rawtypes" } )
		@SuppressWarnings({ "rawtypes", "unchecked" })
		public static void Verint_Execution(String Name) throws Exception
		 {
			
			 Utilities.LoadGlobLoc();
			if (Name.contains("BO"))
			{
				datapath=Utilities.Globlocators.getProperty("testDataPath_BO");
				sheetname="BO_TestSet";
			}
			if (Name.contains("DPA"))
			{
				datapath=Utilities.Globlocators.getProperty("testDataPath_DPA");
				sheetname="DPA_TestSet";
			}
			if (Name.contains("QM"))
			{
				datapath=Utilities.Globlocators.getProperty("testDataPath_QM");
				sheetname="QM_TestSet";
			}
			else if (Name.contains("WFM"))
			{
				datapath=Utilities.Globlocators.getProperty("testDataPath_WFM");
				sheetname="WFM_RegressionTestSet";
			}		
			String Run="";
		    String strOne="";
				FileInputStream fi = new FileInputStream(datapath);
				Workbook W = Workbook.getWorkbook(fi);			
			    Sheet s = W.getSheet(sheetname);    
		
			    
		    for(int row = 1;row < s.getRows();row++)
		    {
		    	 Run = s.getCell(3,row).getContents();		        
		        if (Run.equals("Y") ||  Run.equals("y"))
		        {
			    	strOne= s.getCell(1,row).getContents();
			    	Class cls= Class.forName(strOne);
			    	String methodName= s.getCell(2,row).getContents();
			    	Method m =cls.getDeclaredMethod(methodName);
			    	m.invoke(cls.getClass());	
			    	System.out.println("End of Test case execution: "+methodName);
			    	System.out.println("####################################################################");
			    	/*strOne= s.getCell(1,row).getContents();
			    	Class<?> cls= Class.forName(strOne);
			    	String methodName= s.getCell(2,row).getContents();
			    	Method m =cls.getDeclaredMethod(methodName,(Class<Object>) (null));
			    	m.invoke(cls.getClass(),(Class<Object>) (null));*/
		        }		       
		    }	
		    W.close();
		    fi.close();		    
		 }
		//@SuppressWarnings("deprecation")
	public static void verintScriptStatus(boolean Status,String Name,String HTMLReportName,int Col,int Row) throws Exception
	 {
		if (Name.contains("BO"))
		{
			datapath=Utilities.Globlocators.getProperty("testDataPath_BO");
			sheetname="BO_TestSet";
		}
		if (Name.contains("DPA"))
		{
			datapath=Utilities.Globlocators.getProperty("testDataPath_DPA");
			sheetname="DPA_TestSet";
		}
		if (Name.contains("QM"))
		{
			datapath=Utilities.Globlocators.getProperty("testDataPath_QM");
			sheetname="QM_TestSet";
		}
		if (Name.contains("WFM_REG"))
		{
			datapath=Utilities.Globlocators.getProperty("testDataPath_WFM");
			sheetname="WFM_RegressionTestSet";
		}
		else if (Name.contains("WFM"))
		{
			datapath=Utilities.Globlocators.getProperty("testDataPath_WFM");
			sheetname="WFM_TestSet";
			
		}
		
		
		Workbook workbook1 = Workbook.getWorkbook(new File(datapath));
	    WritableWorkbook copy = Workbook.createWorkbook(new File(datapath), workbook1);
	    WritableSheet sheet2 = copy.getSheet(sheetname); 
	    
	    File file11 = new File(Utilities.Globlocators.getProperty("ReportPath")+"\\"+HTMLReportName+".html");
	    String scriptStatus=""; 
	    if (Status==true)
	    {
	    	scriptStatus="PASS";
	    }
	    else
	    {
	    	scriptStatus="FAIL";
	    }
	     
	      WritableHyperlink wh = new WritableHyperlink(Col, Row, file11, scriptStatus);
	      sheet2.addHyperlink(wh);
	      
	      
	      if (scriptStatus=="PASS")
	      {
			Label label = new Label(Col, Row, "PASS", getCellFormat(Colour.BRIGHT_GREEN, Pattern.GRAY_50));
		    sheet2.addCell(label);
	      }
	      else
    	  if (scriptStatus=="FAIL")
	      {
			Label label = new Label(Col, Row, "FAIL", getCellFormat(Colour.ROSE, Pattern.GRAY_50));
		    sheet2.addCell(label);
	      }
	    copy.write();
	    copy.close();
		
	 }
		//@SuppressWarnings("deprecation")
	 private static WritableCellFormat getCellFormat(jxl.format.Colour green, jxl.format.Pattern gray25) throws WriteException {
		    WritableFont cellFont = new WritableFont(WritableFont.ARIAL, 9);
		    cellFont.setBoldStyle(WritableFont.BOLD);
		    cellFont.setUnderlineStyle(UnderlineStyle.SINGLE);
		    WritableCellFormat cellFormat = new WritableCellFormat(cellFont);
		    cellFormat.setBackground(green, gray25);
		    cellFormat.setAlignment(Alignment.CENTRE);
		    return cellFormat;
		  }
	 
	 
	 public static void switchFrame(WebDriver driver, String data){
			List<WebElement> iframeList = driver.findElements(By.tagName("iframe"));
			List<WebElement> frameList = driver.findElements(By.tagName("frame"));
			frameList.addAll(iframeList);
			System.out.println("Total frames present - "+frameList.size());
			for(WebElement frame : frameList){
				if((frame.getAttribute("id").equals(data))||(frame.getAttribute("name").equals(data))){
					System.out.println("Switching on frame with ID - "+frame.getAttribute("id"));
					System.out.println("*** Name*** - "+frame.getAttribute("name"));
					/*System.out.println("*** Title*** - "+frame.getAttribute("title"));
					System.out.println("*** src*** - "+frame.getAttribute("src"));*/
					driver.switchTo().frame(frame);
					break;
				}
			}
		}

}
