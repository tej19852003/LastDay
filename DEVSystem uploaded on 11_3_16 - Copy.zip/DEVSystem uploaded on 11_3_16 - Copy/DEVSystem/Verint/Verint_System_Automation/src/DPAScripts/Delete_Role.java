package DPAScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import ScreenObjects.LoginScreen;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.VerintHomePageScreen;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class Delete_Role {
	
	
	public static ExtentReports extent = ExtentReports.get(Delete_Role.class);
	
	public static boolean DeleteRole() throws Exception
	{
		
		boolean flag=true;
		String HTMLReportName="Delete_Role"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Delete Role");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver  = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_DPA"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("DPA_TestSet");
	    String ParentOrganization = Ws.getCell(7,18).getContents();
	    String RoleName = Ws.getCell(8,18).getContents();
	    
	   
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Role Setup"))
			//if (driver.findElements(By.linkText("Roles Setup")).size()==0)
			{
				Utilities.Logout(driver);				
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Role Setup"))			
				//if (driver.findElements(By.linkText("Roles Setup")).size()==0)
				{
					extent.log(LogStatus.WARNING, "Roles Setup section is not displayed. Please try again.");
					return flag=false;
				}
			}
				
			if (!RolesSetupScreen.selectNodeFromLeftTreePane(driver,ParentOrganization))
			{
				return flag=false;
			}
			
			String[] RName=RoleName.split(",");
			System.out.println("rolename:"+RName.length);
			for (int r=0;r<RName.length;r++)
			{
				RolesSetupScreen.selectRightPaneView(driver);
				if (RolesSetupScreen.selectRoleName(driver,RName[r]))
				{					
					if (!RolesSetupScreen.clickDeleteRole(driver))
					{
						return flag=false;
					}
					RolesSetupScreen.clickContinueDeleteRole(driver);
				}
			}
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"DPA",HTMLReportName,4,18);
		}
		return flag;
	}


}
