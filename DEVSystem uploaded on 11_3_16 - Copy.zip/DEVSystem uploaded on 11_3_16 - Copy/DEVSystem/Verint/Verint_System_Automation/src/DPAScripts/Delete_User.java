package DPAScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import ScreenObjects.LoginScreen;

import ScreenObjects.RolesSetupScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.ProfilesScreen;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import org.sikuli.script.Screen;

public class Delete_User {
	
	
	public static ExtentReports extent = ExtentReports.get(Delete_User.class);
	
	public static boolean DeleteUser() throws Exception
	{
		boolean flag=true;
		//String windowName="";
		Screen sobj = new Screen ();
		String HTMLReportName="Delete_User"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Delete User");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_DPA"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("DPA_TestSet");	   
	    String UserLastName = Ws.getCell(12,19).getContents();	   	
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Profiles"))			
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Profiles"))			
				{
					extent.log(LogStatus.WARNING, "Profiles section is not displayed. Please try again");
					return flag=false;
				}				
			} 
			//verify User exist or not
			String[] RName=UserLastName.split(",");
			System.out.println("rolename:"+RName.length);
			for (int r=0;r<RName.length;r++)
			{
				if (ProfilesScreen.FindSelect(driver, RName[r]))
				{								
					if (ProfilesScreen.clickDelete(driver))
					{
						Thread.sleep(2000);
						if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Delete_OK.png")!=null)
						{
							sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Delete_OK.png");
							flag=true;
							Thread.sleep(6000);							
						}
					}				
				}
			}
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			//extent.endTest();
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"DPA",HTMLReportName,4,19);
		}
		return flag;
	}
	

}
