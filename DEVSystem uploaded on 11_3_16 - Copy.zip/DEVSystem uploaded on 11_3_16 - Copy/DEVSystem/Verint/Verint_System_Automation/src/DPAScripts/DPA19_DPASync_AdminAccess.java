package DPAScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;

import ScreenObjects.AccessRightsScreen;
import ScreenObjects.DPAHomePageScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.NewRoleScreen;
import ScreenObjects.RolesSetupScreen;

import ScreenObjects.ProfilesScreen;

import ScreenObjects.VerintHomePageScreen;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class DPA19_DPASync_AdminAccess {
	
	
	public static ExtentReports extent = ExtentReports.get(DPA19_DPASync_AdminAccess.class);
	
	public static boolean DPASynchronization_AdminAccess() throws Exception
	{
		
		boolean flag=true;
		Screen sobj = new Screen ();
		String HTMLReportName="DPA19_DPASynchronization_AdminAccess"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "DPA Synchronization AdminAccess");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_DPA"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("DPA_TestSet");
	  
	    String ParentOrganization = Ws.getCell(7,12).getContents();	      
	    String RoleName = Ws.getCell(8,12).getContents();	 
	    String RoleDesc = Ws.getCell(9,12).getContents();  
	    //String UserAlias = Ws.getCell(11,12).getContents();	
	    //String UserLastName = Ws.getCell(12,12).getContents();	
	    String DPATestidAlias=Utilities.Globlocators.getProperty("DPATestidAlias");
	    String DPAPassword=Utilities.Globlocators.getProperty("DPAPassword");
	    String DPATestIdLastName=Utilities.Globlocators.getProperty("DPATestIdLastName");
		try
		{					   
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Role Setup"))
			//if (driver.findElements(By.linkText("Roles Setup")).size()==0)
			{
				Utilities.Logout(driver);				
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Role Setup"))			
				//if (driver.findElements(By.linkText("Roles Setup")).size()==0)
				{
					extent.log(LogStatus.WARNING, "Roles Setup section is not displayed. Please try again.");
					return flag=false;
				}
			}
						
			RolesSetupScreen.selectNodeFromLeftTreePane(driver,ParentOrganization);
			RolesSetupScreen.selectRightPaneView(driver);
			RolesSetupScreen.clickCreateNewRole(driver);
			
			NewRoleScreen.setTextInRolename(driver,RoleName);
			NewRoleScreen.setTextInRoleDescription(driver,RoleDesc);
			//NewRoleScreen.expandPrivilege(driver);
			NewRoleScreen.selectDPAPrivilege(driver);
			NewRoleScreen.clickSave(driver);			
			
			RolesSetupScreen.selectRightPaneView(driver);
			//validation- role created or not
			if (!RolesSetupScreen.selectRoleName(driver,RoleName))
			{
				return flag=false;
			}
			driver.switchTo().defaultContent();
			VerintHomePageScreen.selectMenuItem(driver,"User Management","Access Rights");
			Thread.sleep(4000);
			if (driver.findElements(By.linkText("Profiles")).size()==0)
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				VerintHomePageScreen.selectMenuItem(driver,"User Management","Access Rights");
				if (driver.findElements(By.linkText("Profiles")).size()==0)
				{
					extent.log(LogStatus.WARNING, "Profiles section is not displayed. Please try again");
					return flag=false;
				}
				
			}
			if (!ProfilesScreen.FindSelect(driver, DPATestIdLastName))
			{
				Utilities.selectRightPaneView(driver);				
				if (!ProfilesScreen.clickImportDomainUsers(driver))
				{
					return flag=false;
				}
				Thread.sleep(2000);				
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_EnterObjNameToSelect.png") != null)
				{
					sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_EnterObjNameToSelect.png", DPATestidAlias);
				}				
				Thread.sleep(1000);
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_OK_Btn.png") != null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_OK_Btn.png");
				}				
				Thread.sleep(5000);
				Utilities.selectRightPaneView(driver);
				//System.out.println("err:"+driver.findElement(By.xpath("//div[@id='workPaneWrapper']/table[@id='viewfindPane_tbl_id']/tbody/tr/td[2]/table[@id='pageMessages_bttn_tbl_id']/tbody/tr/td[1]/div")).getText());
				if (!ProfilesScreen.checkErrorMessage(driver))
				{				
						return flag=false;
				}
				Thread.sleep(2000);				
				if (!ProfilesScreen.FindSelect(driver, DPATestIdLastName))
				{
					return flag=false;
				}
				
			}
			
			if (!AccessRightsScreen.selectEmp_From_AccessRightsFrame(driver,DPATestIdLastName))
			{
				return flag=false;
			}
			Utilities.selectRightPaneView(driver);
			AccessRightsScreen.clickEditAccessRights(driver);
						
			AccessRightsScreen.select_RoleName_checkbox(driver,RoleName);
			AccessRightsScreen.clickSave(driver);
			Thread.sleep(10000);
			Utilities.Logout(driver);
			Thread.sleep(12000);
			//LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("QMSupervisorUserName"));
			//LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("QMSupervisorPassword"));
			LoginScreen.setTextInUsername(driver,DPATestidAlias);
			LoginScreen.setTextInPassword(driver,DPAPassword);
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintImpact360(driver))
			{
				return flag=false;
			}
			VerintHomePageScreen.selectMenuItem(driver,"Tracking","DesktopProcessAnalytics_Menu");	
			
			
			
			Set<String> windowIds = driver.getWindowHandles();
			Iterator<String> itererator = windowIds.iterator(); 			
			String mainWinID = itererator.next();//main window 
			Thread.sleep(2000);
			String  popWindow = itererator.next();//popup window
			driver.switchTo().window(popWindow);//Switch the driver to the popup window
			
			if (!DPAHomePageScreen.verifyDPAHomePage(driver))
			{
				return flag=false;
			}
			if (!DPAHomePageScreen.DPAHomePage(driver))
			{
				return flag=false;
			}
			
			driver.close();
			Thread.sleep(2000);
			driver.switchTo().window(mainWinID);
			
			Utilities.Logout(driver);
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Role Setup"))			
			{
				extent.log(LogStatus.WARNING, "Roles Setup section is not displayed. Please try again.");
				return flag=false;
			}
			RolesSetupScreen.selectNodeFromLeftTreePane(driver,ParentOrganization);
			RolesSetupScreen.selectRightPaneView(driver);
			
			if (!RolesSetupScreen.selectRoleName(driver,RoleName))
			{
				return flag=false;
			}
			if (!RolesSetupScreen.clickDeleteRole(driver))
			{
				return flag=false;
			}
			if (!RolesSetupScreen.clickContinue(driver))
			{
				return flag=false;
			}
			
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"DPA",HTMLReportName,4,12);
		}
		return flag;
	}


}
