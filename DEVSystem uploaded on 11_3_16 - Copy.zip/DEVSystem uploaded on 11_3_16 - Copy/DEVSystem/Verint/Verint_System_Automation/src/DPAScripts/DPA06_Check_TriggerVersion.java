package DPAScripts;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import ScreenObjects.DPAHomePageScreen;
import ScreenObjects.LoginScreen;

import ScreenObjects.ScreenContentTriggers;
import ScreenObjects.VerintHomePageScreen;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.Screen;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class DPA06_Check_TriggerVersion {
	
	public static ExtentReports extent = ExtentReports.get(DPA06_Check_TriggerVersion.class);
	public static Screen sobj = new Screen ();
	public static boolean Check_Trigger_Version() throws Exception
	{		
		boolean flag=true;
		String HTMLReportName="DPA06_Check_Trigger_Version"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		//String parentWinHandle="";
		Utilities.testcaseSetup(HTMLReportName, "Check Trigger Version");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 	
	    
		try
		{		   
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			VerintHomePageScreen.selectMenuItem(driver,"Tracking","DesktopProcessAnalytics_Menu");
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Error.png") != null || sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_AuthorisationError.png") != null)
			{
				extent.log(LogStatus.FAIL, "Application/Authorisation error is displayed");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Trigger"));
				return flag=false;
			}
			/*if (!DPAHomePageScreen.selectMenuItem(driver,"Administration","Triggers","Screen Content Triggers"))//Administration tab - triggers menu item
			{
					WebElement tabName1 = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.linkText("Administration")));
					Actions action1 = new Actions(driver);
					action1.moveToElement(tabName1).build().perform();
					Thread.sleep(2000);		
					//driver.findElement(By.linkText(menuItem)).click(); //
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Trigger.png");
					//Thread.sleep(1000);
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Impact360_Text.png");
					
					//Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Trigger.png");
					//Thread.sleep(2000);
					//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Text.png");
					//driver.findElement(By.xpath("//div[@id='ctl00_StaticMainMenuControl1_TopLevelMenu']/ul/li[2]/div/ul/li[2]/a")).click();
					if (driver.findElements(By.linkText("Screen Content Trigger")).size()!=0)
					{
						//driver.findElement(By.linkText("Screen Content Trigger")).click();	
						if ( driver.findElements(By.linkText("Screen Name")).size()!=0)
						{
							extent.log(LogStatus.PASS, "Screen Content Triggers page is displayed");							
						}
						else
						{
							extent.log(LogStatus.FAIL, "Screen Content Triggers page is NOT displayed.Please try again.");
							return flag=false;
						}
					}
			}*/
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Administration_blue.png")!=null)
			{
				sobj.mouseMove(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Administration_blue.png");
			}
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Administration.png")!=null)
			{
				sobj.mouseMove(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Administration.png");
			}
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Trigger.png");					
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Impact360_Text.png");
			if (driver.findElements(By.linkText("Screen Content Trigger")).size()!=0)
			{							
				if ( driver.findElements(By.linkText("Screen Name")).size()!=0)
				{
					extent.log(LogStatus.PASS, "Screen Content Triggers page is displayed");							
				}
				else
				{
					extent.log(LogStatus.FAIL, "Screen Content Triggers page is NOT displayed.Please try again.");
					return flag=false;
				}
			}
			ScreenContentTriggers.checkTriggerVersion(driver);			
		
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Utilities.verintScriptStatus(flag,"DPA",HTMLReportName,4,8);
		}
		return flag;
	}

}
