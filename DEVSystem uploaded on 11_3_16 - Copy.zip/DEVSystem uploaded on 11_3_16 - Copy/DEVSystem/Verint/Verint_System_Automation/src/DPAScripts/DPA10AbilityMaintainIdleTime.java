package DPAScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import ScreenObjects.ApplicationAnalysisReportsScreen;
import ScreenObjects.DPAHomePageScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class DPA10AbilityMaintainIdleTime {
	
	
	public static ExtentReports extent = ExtentReports.get(DPA10AbilityMaintainIdleTime.class);
	
	public static boolean DPA10_Ability_To_Maintain_IdleTime() throws Exception
	{
		
		boolean flag=true;
		String HTMLReportName="DPA10_Ability_To_Maintain_IdleTime"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "DPA10 Ability To Maintain IdleTime");
				
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_DPA"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("DPA_TestSet");
	  
	    String ReportType = Ws.getCell(20,10).getContents();
	    String DateRange = Ws.getCell(21,10).getContents();	    
	    //String StartTime = Ws.getCell(22,10).getContents();
	    //String EndTime = Ws.getCell(23,10).getContents();	    
	    String ViewBy = Ws.getCell(24,10).getContents();   
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintImpact360(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"Tracking","DesktopProcessAnalytics_Menu"))
			{
				Utilities.Logout(driver);				
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintImpact360(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Tracking","DesktopProcessAnalytics_Menu"))
				{
					extent.log(LogStatus.WARNING, "DPA not launched. Please try again.");
					return flag=false;
				}
			}
			
			//Utilities.windowsSecurityCredentials(driver,Utilities.Globlocators.getProperty("WindowsSecurityUserName"),Utilities.Globlocators.getProperty("WindowsSecurityPassword"));
			if (!DPAHomePageScreen.selectMenuItem(driver,"Reports","Application Analysis Reports",""))//Administration tab - triggers menu item
			{
					WebElement tabName1 = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.linkText("Reports")));
					Actions action1 = new Actions(driver);
					action1.moveToElement(tabName1).build().perform();
					Thread.sleep(2000);							
					driver.findElement(By.xpath("//div[@id='ctl00_StaticMainMenuControl1_TopLevelMenu']/ul/li[1]/div/ul/li[2]/a")).click();
					extent.log(LogStatus.INFO, "Application Analysis Reports menu item is selected from Reports tab");
					Thread.sleep(10000);
					if (driver.findElements(By.xpath("//input[@id='ctl00_MidPanelContentHolder_btnDisplayReport']")).size()!=0)
					{
						extent.log(LogStatus.PASS, "Application Analysis Reports page is displayed");
						extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "AppAnalysisReport"));
						flag=true;
					}
					else
					{
						extent.log(LogStatus.FAIL, "Application Analysis Reports page is NOT displayed");
						extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "AppAnalysisReport"));
						return flag=false;
					}
			}
			//report type
			
			if (!ApplicationAnalysisReportsScreen.clickTimelineReport(driver))
			{
				return flag=false;
			}
			
			/*if (!ApplicationAnalysisReportsScreen.selectReportType(driver,ReportType))
			{
				return flag=false;
			}*/
			//date range
			if (!ApplicationAnalysisReportsScreen.selectDateRange(driver,DateRange))
			{
				return flag=false;
			}
			//time range
			/*if (!ApplicationAnalysisReportsScreen.setTimeRange(driver,StartTime,EndTime))
			{
				return flag=false;
			}*/
			//datastream app duration
			if (!ApplicationAnalysisReportsScreen.selectDataStreamsAppDuration_Checkbox(driver))
			{
				return flag=false;
			}
			//datastream trigger
			if (!ApplicationAnalysisReportsScreen.selectDataStreamsTriggers_Checkbox(driver))
			{
				return flag=false;
			}
			//view by
			if (!ApplicationAnalysisReportsScreen.selectViewBy(driver,ViewBy))
			{
				return flag=false;
			}
			//include idle time
			if (!ApplicationAnalysisReportsScreen.selectIncludeIdleTimeInReport_Checkbox(driver))
			{
				return flag=false;
			}			
			//click on display report
			if (!ApplicationAnalysisReportsScreen.clickDisplayReport(driver))
			{
				return flag=false;
			}
			if (!ApplicationAnalysisReportsScreen.verifyReportName(driver,"Application Duration and Triggers Timeline By User/Computer"))
			{
				return flag=false;
			}
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"DPA",HTMLReportName,4,10);
		}
		return flag;
	}
}
