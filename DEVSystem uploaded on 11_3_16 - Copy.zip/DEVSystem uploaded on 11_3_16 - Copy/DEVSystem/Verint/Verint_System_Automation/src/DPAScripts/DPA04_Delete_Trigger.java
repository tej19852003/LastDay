package DPAScripts;

import java.io.File;
import java.io.FileInputStream;

import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import ScreenObjects.LoginScreen;

import ScreenObjects.ScreenContentTriggers;
import ScreenObjects.VerintHomePageScreen;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class DPA04_Delete_Trigger {
	
	public static ExtentReports extent = ExtentReports.get(DPA04_Delete_Trigger.class);
	public static Screen sobj = new Screen ();
	public static boolean Delete_Trigger() throws Exception
	{		
		boolean flag=true;
		//String parentWinHandle="";
		String HTMLReportName="DPA04_Delete_Trigger"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup("DPA04_Delete_Trigger"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date()), "Delete Trigger");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_DPA"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("DPA_TestSet");
	    String ScreenName = Ws.getCell(13,17).getContents();
	    
		try
		{		   
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			VerintHomePageScreen.selectMenuItem(driver,"Tracking","DesktopProcessAnalytics_Menu");
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Error.png") != null || sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_AuthorisationError.png") != null)
			{
				extent.log(LogStatus.FAIL, "Application/Authorisation error is displayed");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "Trigger"));
				return flag=false;
			}
			/*VerintHomePageScreen.selectMenuItem(driver,"Tracking","Desktop And Process Analytics");
			if (!DPAHomePageScreen.verifyDPAHomePage(driver))
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				VerintHomePageScreen.selectMenuItem(driver,"Tracking","Desktop And Process Analytics");
				
			}*/
			/*if (!DPAHomePageScreen.selectMenuItem(driver,"Administration","Triggers","Screen Content Triggers"))//Administration tab - triggers menu item)//Administration tab - triggers menu item
			{
				return flag=false;
			}*/
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Administration_blue.png")!=null)
			{
				sobj.mouseMove(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Administration_blue.png");
			}
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Administration.png")!=null)
			{
				sobj.mouseMove(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Administration.png");
			}
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Trigger.png");					
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Impact360_Text.png");
			if (driver.findElements(By.linkText("Screen Content Trigger")).size()!=0)
			{							
				if ( driver.findElements(By.linkText("Screen Name")).size()!=0)
				{
					extent.log(LogStatus.PASS, "Screen Content Triggers page is displayed");							
				}
				else
				{
					extent.log(LogStatus.FAIL, "Screen Content Triggers page is NOT displayed.Please try again.");
					return flag=false;
				}
			}
			if (!ScreenContentTriggers.selectFind(driver,"Screen Name"))
			{
				return flag=false;
			}
			if (!ScreenContentTriggers.setSearchByName(driver,ScreenName))
			{
				return flag=false;
			}
			if (!ScreenContentTriggers.clickSearch(driver))
			{
				return flag=false;
			}
			ScreenContentTriggers.deleteTrigger(driver,ScreenName);		
		
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"DPA",HTMLReportName,4,17);
		}
		return flag;
	}

}
