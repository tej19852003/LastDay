package DPAScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import ScreenObjects.ApplicationAnalysisReportsScreen;
import ScreenObjects.DPAHomePageScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class DPA64_67_ViewReports {
	
	
	public static ExtentReports extent = ExtentReports.get(DPA64_67_ViewReports.class);
	
	public static boolean DPA64_67_View_Reports() throws Exception
	{
		
		boolean flag=true;
		String HTMLReportName="DPA64_67_View_Reports"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "DPA64 67 View Reports");
				
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		driver.manage().deleteAllCookies();
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_DPA"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("DPA_TestSet");
	  
	    String ReportType = Ws.getCell(20,11).getContents();	      
	    String DateRange = Ws.getCell(21,11).getContents();	 
	    String ViewBy = Ws.getCell(24,11).getContents();  
	    String FilterOption = Ws.getCell(25,11).getContents();	
	    String FilterValue = Ws.getCell(26,11).getContents();	
	   if (FilterValue=="")
	   {
		   FilterValue=Utilities.Globlocators.getProperty("UserName");
	   }
	  
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintImpact360(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"Tracking","DesktopProcessAnalytics_Menu"))
			{
				Utilities.Logout(driver);				
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintImpact360(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Tracking","DesktopProcessAnalytics_Menu"))
				{
					extent.log(LogStatus.WARNING, "DPA not launched. Please try again.");
					return flag=false;
				}
			}
			
			//Utilities.windowsSecurityCredentials(driver,Utilities.Globlocators.getProperty("WindowsSecurityUserName"),Utilities.Globlocators.getProperty("WindowsSecurityPassword"));
			if (!DPAHomePageScreen.selectMenuItem(driver,"Reports","Application Analysis Reports",""))//Administration tab - triggers menu item
			{
					WebElement tabName1 = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.linkText("Reports")));
					Actions action1 = new Actions(driver);
					action1.moveToElement(tabName1).build().perform();
					Thread.sleep(2000);							
					driver.findElement(By.xpath("//div[@id='ctl00_StaticMainMenuControl1_TopLevelMenu']/ul/li[1]/div/ul/li[2]/a")).click();
					extent.log(LogStatus.INFO, "Application Analysis Reports menu item is selected from Reports tab");
					Thread.sleep(10000);
					if (driver.findElements(By.xpath("//input[@id='ctl00_MidPanelContentHolder_btnDisplayReport']")).size()!=0)
					{
						extent.log(LogStatus.PASS, "Application Analysis Reports page is displayed");
						extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "AppAnalysisReport"));
						flag=true;
					}
					else
					{
						extent.log(LogStatus.FAIL, "Application Analysis Reports page is NOT displayed");
						extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "AppAnalysisReport"));
						return flag=false;
					}
			}
			String rep = ReportType;
			System.out.println("rep ;"+rep);
			String[] parts = rep.split(";");
			System.out.println(parts.length);
			String repTypeLog	 = parts[0]; 
			String repTypeBar = parts[1];
			String repTypeTimeline = parts[2];
			String repTypelive = parts[3];
			System.out.println(repTypeLog+" ;"+repTypeBar+";"+repTypeTimeline+";"+repTypelive);
			System.out.println("rep type;"+repTypelive);
			//log report
			if (!ApplicationAnalysisReportsScreen.clicReportCriteria(driver,"Log Report"))
			{
				return flag=false;
			}			
			if (!ApplicationAnalysisReportsScreen.selectReportType(driver,repTypeLog))
			{
				return flag=false;
			}			
			if (!ApplicationAnalysisReportsScreen.selectDateRange(driver,DateRange))
			{
				return flag=false;
			}			
			
			if (!ApplicationAnalysisReportsScreen.selectFilters(driver,FilterOption,FilterValue)) 
			{
				return flag=false;
			}			
			if (!ApplicationAnalysisReportsScreen.clickDisplayReport(driver))
			{
				return flag=false;
			}
			if (!ApplicationAnalysisReportsScreen.verifyReportName(driver,"Application Duration Log"))
			{
				return flag=false;
			}			
			if (!ApplicationAnalysisReportsScreen.clickEditReport(driver))
			{
				return flag=false;
			}
			//end of log report
			
			//bar chart report
			if (!ApplicationAnalysisReportsScreen.clicReportCriteria(driver,"Bar Chart Report"))
			{
				return flag=false;
			}
			if (!ApplicationAnalysisReportsScreen.selectReportType(driver,repTypeBar))
			{
				return flag=false;
			}
			if (!ApplicationAnalysisReportsScreen.selectDateRange(driver,DateRange))
			{
				return flag=false;
			}
			if (!ApplicationAnalysisReportsScreen.selectFilters(driver,FilterOption,FilterValue)) 
			{
				return flag=false;
			}			
			if (!ApplicationAnalysisReportsScreen.clickDisplayReport(driver))
			{
				return flag=false;
			}
			if (!ApplicationAnalysisReportsScreen.verifyReportName(driver,"Application Duration By Application"))
			{
				return flag=false;
			}			
			if (!ApplicationAnalysisReportsScreen.clickEditReport(driver))
			{
				return flag=false;
			}			
			//end of bar chart report
			//time line report
			if (!ApplicationAnalysisReportsScreen.clicReportCriteria(driver,"Timeline Report"))
			{
				return flag=false;
			}
			if (!ApplicationAnalysisReportsScreen.selectReportType(driver,repTypeTimeline))
			{
				return flag=false;
			}
			if (!ApplicationAnalysisReportsScreen.selectDateRange(driver,DateRange))
			{
				return flag=false;
			}
			if (!ApplicationAnalysisReportsScreen.selectViewBy(driver,ViewBy))
			{
				return flag=false;
			}
			if (!ApplicationAnalysisReportsScreen.selectFilters(driver,FilterOption,FilterValue)) 
			{
				return flag=false;
			}			
			if (!ApplicationAnalysisReportsScreen.clickDisplayReport(driver))
			{
				return flag=false;
			}
			if (!ApplicationAnalysisReportsScreen.verifyReportName(driver,"Application Duration Timeline By User/Computer"))
			{
				return flag=false;
			}			
			if (!ApplicationAnalysisReportsScreen.clickEditReport(driver))
			{
				return flag=false;
			}			
			//end of time line report
			//live info report
			if (!ApplicationAnalysisReportsScreen.clicReportCriteria(driver,"Live Information Report"))
			{
				return flag=false;
			}
			if (!ApplicationAnalysisReportsScreen.selectReportType(driver,repTypelive))
			{
				return flag=false;
			}
			if (!ApplicationAnalysisReportsScreen.selectFilters(driver,FilterOption,FilterValue)) 
			{
				return flag=false;
			}			
			if (!ApplicationAnalysisReportsScreen.clickDisplayReport(driver))
			{
				return flag=false;
			}
			if (!ApplicationAnalysisReportsScreen.verifyReportName(driver,"Live Information Report"))
			{
				return flag=false;
			}			
			//end of live info report			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"DPA",HTMLReportName,4,11);
		}
		return flag;
	}
}
