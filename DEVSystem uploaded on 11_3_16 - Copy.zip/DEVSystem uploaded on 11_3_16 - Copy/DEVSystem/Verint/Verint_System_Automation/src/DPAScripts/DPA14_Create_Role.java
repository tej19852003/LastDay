package DPAScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import ScreenObjects.LoginScreen;
import ScreenObjects.NewRoleScreen;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.VerintHomePageScreen;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class DPA14_Create_Role {
	
	
	public static ExtentReports extent = ExtentReports.get(DPA14_Create_Role.class);
	
	public static boolean Create_Role_DPA_PredefinedRole() throws Exception
	{
		
		boolean flag=true;
		String HTMLReportName="DPA14_Create_Role_DPA_PredefinedRole"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Create Role DPA Predefined Role");
		
		//Utilities.testcaseSetup("DPA14_Create_Role_DPA_PredefinedRole"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date()), "Create Role DPA Predefined Role");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_DPA"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("DPA_TestSet");
	    
	    String ParentOrganization = Ws.getCell(7,11).getContents();	     
	    String RoleName = Ws.getCell(8,11).getContents();	
		
		try
		{			
			/*FileInputStream fis = new FileInputStream(SFUtilities.Globlocators.getProperty("testDataPath"));
		    Workbook Wb = Workbook.getWorkbook(fis);		
		    Sheet Ws = Wb.getSheet("TestSet");
		    String UserId12312 = Ws.getCell(3,8).getContents();
		    String TempPwd12312 = Ws.getCell(7,8).getContents();*/
		    
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Role Setup"))
			//if (driver.findElements(By.linkText("Roles Setup")).size()==0)
			{
				Utilities.Logout(driver);				
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Role Setup"))			
				//if (driver.findElements(By.linkText("Roles Setup")).size()==0)
				{
					extent.log(LogStatus.WARNING, "Roles Setup section is not displayed. Please try again.");
					return flag=false;
				}
			}
				
			RolesSetupScreen.selectNodeFromLeftTreePane(driver,ParentOrganization);
			RolesSetupScreen.selectRightPaneView(driver);
			if (!RolesSetupScreen.clickCreateNewRole(driver))
			{
				return flag=false;
			}
			
			if (!NewRoleScreen.setTextInRolename(driver,RoleName))
			{
				return flag=false;
			}
			NewRoleScreen.setTextInRoleDescription(driver,"AutomationPredefDesc");
			//NewRoleScreen.expandPrivilege(driver);
			NewRoleScreen.selectInteractionsAnalyticsPrivilege(driver,"Interactions and Analytics","Assignment Manager;Caption Editor");
			if (!NewRoleScreen.clickSave(driver))
			{
				return flag=false;
			}
			
			RolesSetupScreen.selectRightPaneView(driver);
			//validation- role created or not
			if (!RolesSetupScreen.selectRoleName(driver,RoleName))
			{
				return flag=false;
			}
			
		
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"DPA",HTMLReportName,4,11);
		}
		return flag;
	}


}
