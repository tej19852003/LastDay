package DPAScripts;

import java.io.File;
import java.io.FileInputStream;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;


import jxl.Sheet;
import jxl.Workbook;

import ScreenObjects.DPAHomePageScreen;
import ScreenObjects.LoginScreen;

import ScreenObjects.ScreenContentTriggers;
import ScreenObjects.VerintHomePageScreen;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;


import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import org.sikuli.script.*;
public class DPA30_31_32_Expand_Collapse {
	
	public static ExtentReports extent = ExtentReports.get(DPA30_31_32_Expand_Collapse.class);
	public static Screen sobj = new Screen ();
	public static boolean DPA30_31_32_Expand_Collapse_Cache_Elements() throws Exception
	{		
		boolean flag=true;
		//String parentWinHandle="";
		String HTMLReportName="DPA30_31_32_Expand_Collapse_Cache_Elements"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Expand Collapse Elements");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_DPA"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("DPA_TestSet");	    
	       
	    String ScreenName = Ws.getCell(13,14).getContents(); 
		
		try
		{		   
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}			
			VerintHomePageScreen.selectMenuItem(driver,"Tracking","DesktopProcessAnalytics_Menu");	
						
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Administration_blue.png")!=null)
			{
				sobj.mouseMove(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Administration_blue.png");
			}
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Administration.png")!=null)
			{
				sobj.mouseMove(Utilities.Globlocators.getProperty("imagesPath")+"\\DPA_Administration.png");
			}
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Trigger.png");					
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Impact360_Text.png");
			Thread.sleep(3000);
			if (driver.findElements(By.linkText("Screen Content Trigger")).size()!=0)
			{							
				if ( driver.findElements(By.linkText("Screen Name")).size()!=0)
				{
					extent.log(LogStatus.PASS, "Screen Content Triggers page is displayed");							
				}
				else
				{
					extent.log(LogStatus.FAIL, "Screen Content Triggers page is NOT displayed.Please try again.");
					return flag=false;
				}
			}
			/*if (!DPAHomePageScreen.selectMenuItem(driver,"Administration","Triggers","Screen Content Triggers"))//Administration tab - triggers menu item
			{
					WebElement tabName1 = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.linkText("Administration")));
					Actions action1 = new Actions(driver);
					action1.moveToElement(tabName1).build().perform();
					Thread.sleep(2000);							
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Menu_Trigger.png");				
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Impact360_Text.png");					
					if (driver.findElements(By.linkText("Screen Content Trigger")).size()!=0)
					{
						if ( driver.findElements(By.linkText("Screen Name")).size()!=0)
						{
							extent.log(LogStatus.PASS, "Screen Content Triggers page is displayed");							
						}
						else
						{
							extent.log(LogStatus.FAIL, "Screen Content Triggers page is NOT displayed.Please try again.");
							return flag=false;
						}
					}
			}*/
			//verify whether Trigger exist or not
			if (!ScreenContentTriggers.selectFind(driver,"Screen Name"))
			{
				return flag=false;
			}
			if (!ScreenContentTriggers.setSearchByName(driver,ScreenName))
			{
				return flag=false;
			}
			if (!ScreenContentTriggers.clickSearch(driver))
			{
				return flag=false;
			}		
			
			if (!ScreenContentTriggers.clickExpandCollapse(driver))
			{
				return flag=false;
			}	
			//DPA32
			Set<String> windowIds1 = driver.getWindowHandles();
			System.out.println("windows size:"+windowIds1.size());
			if (windowIds1.size()==2)
			{
				Iterator<String> itererator = windowIds1.iterator(); 			
				String mainWinID1 = itererator.next();//main window 
				System.out.println(mainWinID1);
				//driver.switchTo().window(mainWinID1).close();
				Thread.sleep(1000);	
				String  popWindow1 = itererator.next();//popup window
				Thread.sleep(2000);	
				driver.switchTo().window(popWindow1);
				driver.close();
				driver.switchTo().window(mainWinID1);
			}
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Homepage"));
			VerintHomePageScreen.selectMenuItem(driver,"Tracking","DesktopProcessAnalytics_Menu");
			if (!ScreenContentTriggers.verifyFindByName(driver))
			{
				return flag=false;
			}
			Set<String> windowIds2 = driver.getWindowHandles();
			System.out.println("windows size:"+windowIds2.size());
			if (windowIds1.size()==2)
			{
				Iterator<String> itererator = windowIds2.iterator(); 			
				String mainWinID2 = itererator.next();//main window 
				System.out.println(mainWinID2);
				//driver.switchTo().window(mainWinID1).close();
				Thread.sleep(1000);	
				String  popWindow2 = itererator.next();//popup window
				Thread.sleep(2000);	
				driver.switchTo().window(popWindow2);
				driver.close();
				driver.switchTo().window(mainWinID2);
			}
		
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"DPA",HTMLReportName,4,14);
		}
		return flag;
	}
}
