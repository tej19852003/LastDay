package DPAScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import jxl.Sheet;
import jxl.Workbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import ScreenObjects.LoginScreen;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.ProfilesScreen;
import Utilities.Utilities;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;


public class DPA23_AdoptOrg_UserMgmt {
	
	public static ExtentReports extent = ExtentReports.get(DPA23_AdoptOrg_UserMgmt.class);
	
	public static boolean DPA23_AdoptOrganization() throws Exception
	{
	
		boolean flag=true;
		String windowName="";
		String HTMLReportName="DPA23_AdoptOrganization"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Adopt Organization Settings From UserManagement");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_DPA"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("DPA_TestSet");
	    String organizationName = Ws.getCell(5,4).getContents();	   
	    String userLastName = Ws.getCell(12,4).getContents();
	    
		
	try
	{
		LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
		 
		if (!LoginScreen.verifyLoginPageLaunched(driver))
		{
			return flag=false;
		}
		LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
		LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
		LoginScreen.clickLogin(driver);
		if (!VerintHomePageScreen.verifyVerintHomePage(driver))
		{
			return flag=false;
		}		
		//AddUser To Organization
		if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Profiles"))
		{
			Utilities.Logout(driver);
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Profiles"))			
			{
				extent.log(LogStatus.WARNING, "Access Rights section is not displayed. Please try again");				
				return flag=false;
			}
			
		}
		Thread.sleep(3000);
		Utilities.selectLeftTreeFrame(driver);
		//verify User exist or not
		if (!ProfilesScreen.FindSelect(driver, userLastName))
		{			
			extent.log(LogStatus.WARNING, "User does not exist. Please execute Import Domain New User script.");
			extent.log(LogStatus.WARNING, "", "", Utilities.captureScreenShot(driver, "AdoptRole"));
			return flag=false;			
		}
		
		//Utilities.selectRightPaneView(driver);
		Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
		
		if (!ProfilesScreen.verifyOrgNameAdminDetails(driver,organizationName)) // click on organization edit icon
		{
			
			if (!ProfilesScreen.clickOrganizationEdit(driver)) // click on organization edit icon
			{
				return flag=false;
			}
			Thread.sleep(6000);			
			windowName=Utilities.setWindowFocus(driver);			
			ProfilesScreen.selectOrganizationFromListbox(driver,organizationName);		
				
			driver.switchTo().window(windowName);
			RolesSetupScreen.selectRightPaneView(driver);
			if (!ProfilesScreen.clickSave(driver))
			{
				return flag=false;
			}
			ProfilesScreen.verifySuccessMessage(driver);	
		}
		
	}catch(Exception e){
		System.out.println(e);
	}finally{
		Utilities.Logout(driver);
		driver.close();
		driver.quit();
		Wb.close();
		fis.close();
		Utilities.verintScriptStatus(flag,"DPA",HTMLReportName,4,4);
	}
	return flag;
	}
	
}
