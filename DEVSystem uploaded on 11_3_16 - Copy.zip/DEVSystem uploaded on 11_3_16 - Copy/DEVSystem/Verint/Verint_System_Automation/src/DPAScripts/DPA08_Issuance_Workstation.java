package DPAScripts;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;

import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;


import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
//DPA08 & DPA09
public class DPA08_Issuance_Workstation {
	
	public static ExtentReports extent = ExtentReports.get(DPA08_Issuance_Workstation.class);
	
	public static boolean Issuance_Workstation() throws Exception
	{		
		String HTMLReportName="DPA08_IssuanceInTheWorkstation"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Issuance In The Workstation");
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_DPA"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("DPA_TestSet");
	    String sysType = Ws.getCell(18,5).getContents();
		
		boolean flag=true;
		try{	
			if (sysType.contains("64"))
			{
			    if (!Utilities.folderExist("C:\\Program Files (x86)","Folder"))
			    {
			    	extent.log(LogStatus.FAIL, "C:\\Program Files (x86) folder is not displayed");
			    	return flag=false;
			    }
			    if (!Utilities.folderExist("C:\\Program Files (x86)\\I360","Folder"))
			    {
			    	extent.log(LogStatus.FAIL, "C:\\Program Files (x86)\\I360 folder is not displayed");
			    	return flag=false;
			    }
			    if (!Utilities.folderExist("C:\\Program Files (x86)\\I360\\DPA","Folder"))
			    {
			    	extent.log(LogStatus.FAIL, "C:\\Program Files (x86)\\I360\\DPA is not displayed");
			    	return flag=false;
			    }
			    File currentDir = new File("C:\\Program Files (x86)\\I360\\DPA"+"\\");
				Utilities.displayDirectoryContents(currentDir);
		    
			}
			else
			{
				if (!Utilities.folderExist("C:\\Program Files","Folder"))
			    {
			    	extent.log(LogStatus.FAIL, "C:\\Program Files folder is not displayed");
			    	return flag=false;
			    }
			    if (!Utilities.folderExist("C:\\Program Files\\I360","Folder"))
			    {
			    	extent.log(LogStatus.FAIL, "C:\\Program Files\\I360 folder is not displayed");
			    	return flag=false;
			    }
			    if (!Utilities.folderExist("C:\\Program Files\\I360\\DPA","Folder"))
			    {
			    	extent.log(LogStatus.FAIL, "C:\\Program Files\\I360\\DPA is not displayed");
			    	return flag=false;
			    }
			    File currentDir = new File("C:\\Program Files\\I360\\DPA"+"\\");
				Utilities.displayDirectoryContents(currentDir);
			}
			
			boolean Temp=false;
			String process;
			Process p=Runtime.getRuntime().exec(System.getenv("windir") +"\\system32\\"+"tasklist.exe");
			BufferedReader input = new BufferedReader(new InputStreamReader(p.getInputStream()));
			while ((process = input.readLine())!=null)
			{
				System.out.println("process name:"+process);
				if (process.contains("DCUApp") || process.contains("dcuapp"))
				{
					Temp=true;
				}
			}
			input.close();
			
			if (Temp==true)
			{
				extent.log(LogStatus.PASS, "DCUApp.exe process is running in the background");
			}
			else
			{
				extent.log(LogStatus.FAIL, "DCUApp.exe process is NOT running in the background");
			}
		} catch (Exception err) {
	        err.printStackTrace();
	    }finally
	    {
	    	Utilities.verintScriptStatus(flag,"DPA",HTMLReportName,4,5);
	    }
		return flag;
	}
}
