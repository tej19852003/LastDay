package WFMScripts;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

//import jxl.Sheet;
import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.ie.InternetExplorerDriver;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;

import ScreenObjects.AccessRightsScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.MyRequestsScreen;
import ScreenObjects.ProfilesScreen;
import ScreenObjects.OrgRequestManagement;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.OrganizationSettings;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM047_UtilizeWaitList {
	
	public static ExtentReports extent = ExtentReports.get(WFM047_UtilizeWaitList.class);
	
	public static boolean Create_TimeOff_WaitList() throws Exception
	{		
		boolean flag=true;
		String HTMLReportName="WFM047_UtilizeWaitList"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Create TimeOff Request To Enable WaitList");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("WFM_RegressionTestSet");
	    //Sheet testID=Wb.getSheet("TestIds");
	    String parentorg = Ws.getCell(7,44).getContents();
	   
	    //String organizationDesc = Ws.getCell(6,1).getContents();
	    //String parentOrganization = Ws.getCell(7,1).getContents();
		
		try
		{	
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("WFMPlannerName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("WFMPlannerPassword"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}	
			
			
			
			VerintHomePageScreen.selectMenuItem(driver,"Organization Management","TimeOff_Pools");
			Thread.sleep(5000);
			
			
			Utilities.selectLeftTreeFrame(driver);
			//if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,".AutomationSubOrg"))
			
			//check whether Time Off Pool is exist, if exist then delete
			if (OrgRequestManagement.verifyTimeOffPoolName(driver, "WaitList"))
			{
				if (!OrgRequestManagement.clickDeleteTimeOffPool(driver))
				{
					return flag=false;
				}
			}
			
			if (!OrgRequestManagement.clickCreateTimeOffPoolName(driver)) //create button
			{
				return flag=false;
			}
			OrgRequestManagement.setTextInTimeOffPoolName(driver,"WaitList");
			OrgRequestManagement.clickEnableWaitList(driver);
			if (!OrgRequestManagement.selectMonth(driver,"November"))
			{
				return flag=false;
			}
			if (!OrgRequestManagement.selectYear(driver,"2017"))
			{
				return flag=false;
			}
			if (!OrgRequestManagement.setAllocatedTimeOffHours(driver,"40"))
			{
				return flag=false;
			}
			if (!OrgRequestManagement.clickSave(driver)) //create button
			{
				return flag=false;
			}
			Utilities.selectLeftTreeFrame(driver);
			//if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,".AutomationSubOrg"))
			if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,"StateFarm"))
			{
				return flag=false;
			}
		
			if (OrgRequestManagement.verifyTimeOffPoolName(driver, "WaitList"))
			{
				if (!OrgRequestManagement.clickDeleteTimeOffPool(driver))
				{
					return flag=false;
				}
			}
			
						
			
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM_REG",HTMLReportName,4,44);
		}
		return flag;
	}


	

}
