package WFMScripts;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;

import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.python.modules.thread.thread;

import ScreenObjects.CalendarScreen;
import ScreenObjects.CampaignSettings;
import ScreenObjects.FSEmployees;
import ScreenObjects.ForecastScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.MyRequestsScreen;
import ScreenObjects.OrganizationSettings;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.ServiceGoals;
import ScreenObjects.ShiftScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.ProfilesScreen;
import ScreenObjects.WorkPatternScreen;
import ScreenObjects.WorkQueuesScreen;
import ScreenObjects.WorkRulesScreen;

import Utilities.Utilities;
import org.sikuli.script.Screen;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM073_Available_Employee_Icon {
	
	public static ExtentReports extent = ExtentReports.get(WFM073_Available_Employee_Icon.class);
	
	public static boolean available_Employee_schedule() throws Exception
	{		
		boolean flag=true;
		Screen sobj = new Screen ();
		String windowName="";
		String HTMLReportName="WFM073_Available_Employee_Icon"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "check for available employees");
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("WFM_RegressionTestSet");
	   
	    String shiftName=Ws.getCell(33,56).getContents();
	    String shiftName2=Ws.getCell(47,56).getContents();
	    String Descrition=Ws.getCell(48,56).getContents();
	    String wpname=Ws.getCell(30,56).getContents();
	    String wpname2=Ws.getCell(51,56).getContents();
	    String campName=Ws.getCell(28,56).getContents();
	    String Period=Ws.getCell(29,56).getContents();
	    String StartDate=Ws.getCell(32,56).getContents();
	    String OrgName=Ws.getCell(5,56).getContents();
	    String wqname=Ws.getCell(31,56).getContents();
	    String WqDesc=Ws.getCell(48,56).getContents();	   
	    String EmpName =Ws.getCell(16,56).getContents();
	    String EmpName2=Ws.getCell(52,56).getContents();
	    String skill=Ws.getCell(54,56).getContents();
	    String workQueue=Ws.getCell(31,56).getContents();
	   
	    //String WqDesc=Ws.getCell(23,9).getContents();	
	    String organizationDesc = Ws.getCell(6,56).getContents();
	    String parentOrganization = Ws.getCell(7,56).getContents();
	    String FirstName=Ws.getCell(13,56).getContents();
	    String LastName=Ws.getCell(12,56).getContents();
	  
	    String FirstName2=Ws.getCell(52,56).getContents();
	    String LastName2=Ws.getCell(53,56).getContents();
	    
	    
		
		try
		{			    
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			String mainwindow=driver.getWindowHandle();
			
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			
	    	
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			//String mainwindow=driver.getWindowHandle();
			VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Organization Settings");
	    	Utilities.selectLeftTreeFrame(driver);
			Boolean Temp1=false;			
			int rc1=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
			//System.out.println("rc1:"+rc1);
			for (int j=1;j<=rc1;j++)
			{
				if (j<=15)
				{
				String orgName1=driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).getText();
				System.out.println("org name is:"+orgName1);
				Thread.sleep(1000);
				if (orgName1.contains(OrgName))
				{
					driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).click();
					Temp1=true;
					break;
				}}
			}
			if (Temp1==true)
			{
				System.out.println("org already exist");
				extent.log(LogStatus.INFO, "Organization Name: "+OrgName+" already exist");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Organization"));								
			}			
			//end of verify organization
			//create organization
			if (Temp1==false)
			{
				Utilities.selectLeftTreeFrame(driver);
				if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,parentOrganization))
				{
					return flag=false;
				}
				Utilities.selectRightPaneView(driver);
				if (!OrganizationSettings.clickCreateOrganization(driver))
				{
					return flag=false;
				}
				OrganizationSettings.setOrganizationName(driver,OrgName);
				OrganizationSettings.setOrganizationDescription(driver,organizationDesc);
				OrganizationSettings.isSelectedDaysAndHoursOfOperation(driver);
				if (!OrganizationSettings.clickSave(driver))
				{
					return flag=false;
				}
			}
			driver.switchTo().defaultContent();
	    	Thread.sleep(2000);
	    	
	    	VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings");
	    	Utilities.selectLeftTreeFrame(driver);
	    	if(CampaignSettings.CampaignExist(driver, campName))
	    	{
	    		CampaignSettings.deleteCampaign(driver);
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\btnok_camp.png");
		    	Thread.sleep(3000);
		    	driver.switchTo().defaultContent();
	    	}
	    	else
	    	{
	    		System.out.println("no campaign exist");
	    	}
	    	driver.switchTo().defaultContent();
			
			VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Work Pattern");
			
			Utilities.selectRightPaneView(driver);
	    	Thread.sleep(5000);
	    	//verify if work pattern already exist or not
	    	boolean Temp7=false;
	    	driver.findElement(By.name("itemToFind")).sendKeys(wpname);
	    	driver.findElement(By.xpath("//button[@id='toolbar_FIND_ACTIONLabel']")).click();
	    	Thread.sleep(2000);
	    	List<WebElement> li1=driver.findElements(By.xpath("//table[@id='tableRef']//tr[@class='tblRow']"));
	    	System.out.println(li1.size());
	    	if(driver.findElements(By.xpath("//table[@id='tableRef']//tr[@class='tblRow']//td")).size()!=0)
	    	{
	    	for(WebElement elt:li1)
	    	{
	    		//System.out.println("**************");
	    		System.out.println(elt.findElement(By.tagName("td")).getAttribute("innerText"));
	    		String wname=elt.findElement(By.tagName("td")).getAttribute("innerText");
	    		if(wname.contains(wpname))
	    		{
	    			Temp7=true;
	    			break;
	    		}
	    	}
	    	}
//	    	
	    	
	    	
	    	
	    	
			if (Temp7==true)
			{					
				extent.log(LogStatus.PASS, "Work pattren Name:"+wpname+" already exist");
				//extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Campaign"));
			}
			//end of verify work pattern
			//create a new work pattern
			if(Temp7==false)
			{
				if(!WorkPatternScreen.clickworkpattern(driver))
		    	{
		    		return flag=false;
		    	}
	    	WorkPatternScreen.setWorkpatternName(driver, wpname);
	    	WorkPatternScreen.setWorkpatternDescription(driver,".AutomationDescWorkPattern");
	    	WorkPatternScreen.setpossibledaysOff(driver);
	    	WorkPatternScreen.clickAddshift(driver);
	    	//String windowName1=Utilities.setWindowFocus(driver);
	    	for(String winHandle :driver.getWindowHandles()){
                driver.switchTo().window(winHandle);
                System.out.println("title:"+driver.getTitle());
                if(driver.getTitle().equals("Shift Details"))
                {                	
                	System.out.println("You are in Shift Details window");
                	driver.manage().window().maximize();
                    break;
                }			
			}
	    	
	    	WorkPatternScreen.setshift(driver,shiftName);
	    	driver.switchTo().window(mainwindow);
	    	
	    	if(!WorkPatternScreen.clickSave(driver))
	    	{
	    		return flag=false;
	    	}
			}
	    	Utilities.selectRightPaneView(driver);
	    	Thread.sleep(5000);
	    	//verify if work pattern alreay exist or not
	    	boolean Temp8=false;
	    	driver.findElement(By.name("itemToFind")).clear();
	    	driver.findElement(By.name("itemToFind")).sendKeys(wpname2);
	    	driver.findElement(By.xpath("//button[@id='toolbar_FIND_ACTIONLabel']")).click();
	    	Thread.sleep(2000);
	    	List<WebElement> li2=driver.findElements(By.xpath("//table[@id='tableRef']//tr[@class='tblRow']"));
	    	System.out.println("Li2="+li2.size());
	    	if(driver.findElements(By.xpath("//table[@id='tableRef']//tr[@class='tblRow']//td")).size()!=0)
	    	{
	    		for(WebElement elt:li2)
		    	{
		    		//System.out.println("**************");
		    		System.out.println(elt.findElement(By.tagName("td")).getAttribute("innerText"));
		    		String wname=elt.findElement(By.tagName("td")).getAttribute("innerText");
		    		if(wname.contains(wpname2))
		    		{
		    			Temp8=true;
		    			break;
		    		}
		    	}
	    		if (Temp8==true)
				{					
					extent.log(LogStatus.PASS, "Work pattren Name:"+wpname+" already exist");
					//extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Campaign"));
				}
	    	}
	    	
			//end of verify work pattern
			//create a new work pattern
			if(Temp8==false)
			{
	    	if(!WorkPatternScreen.clickworkpattern(driver))
	    	{
	    		return flag=false;
	    	}
	    	WorkPatternScreen.setWorkpatternName(driver, wpname2);
	    	WorkPatternScreen.setWorkpatternDescription(driver,".AutomationDescWorkPattern");
	    	WorkPatternScreen.setpossibledaysOff(driver);
	    	WorkPatternScreen.clickAddshift(driver);
	    	//String windowName2=Utilities.setWindowFocus(driver);
	    	for(String winHandle :driver.getWindowHandles()){
                driver.switchTo().window(winHandle);
                System.out.println("title:"+driver.getTitle());
                if(driver.getTitle().equals("Shift Details"))
                {                	
                	System.out.println("You are in Shift Details window");
                	driver.manage().window().maximize();
                    break;
                }			
			}
	    	
	    	WorkPatternScreen.setshift(driver,shiftName2);
	    	driver.switchTo().window(mainwindow);
	    	
	    	if(!WorkPatternScreen.clickSave(driver))
	    	{
	    		return flag=false;
	    	}
			}
	    	driver.switchTo().defaultContent();
	    	
	    	VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Work Queues Settings");
	    	//verify if work queue already exist
	    	Utilities.selectRightPaneView(driver);
	    	boolean flag7=false;
	    	int qrows1=driver.findElements(By.xpath("//div[@id='workAreaWrapper']//table[@id='workpaneListWrapper']//tbody//tr")).size();
	    	System.out.println("no of rows in work queue are:" + qrows1);
	    	for(int j=0;j<qrows1;j++)
	    	{
	    		String qname=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']//tbody//tr[@id='workpaneListr"+j+"']//th//a//span")).getAttribute("innerText");
	    		System.out.println("work queue name is" + qname);
	    		if(qname.contains(workQueue))
	    		{
	    			flag7=true;
	    			break;
	    		}
	    	}
	    	if(flag7==true)
	    	{
	    		extent.log(LogStatus.PASS,"work queue already exist");
	    	}
	    	//creation of new work queue
	    	else
	    	{
	    		WorkQueuesScreen.clickworkqueue(driver);
				WorkQueuesScreen.setWorkqueueName(driver, wqname);
				WorkQueuesScreen.setWorkqueueDescription(driver,WqDesc);
				WorkQueuesScreen.clickSave(driver);
	    	}
			
	    	driver.switchTo().defaultContent();
	    	
	    	if(!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings"))
	    	{
	    		Utilities.Logout(driver);
	    		LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
	    		if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings"))
				{
					extent.log(LogStatus.WARNING, "Not able to select Compaign Settings menu. Please try again");
					return flag=false;
				}
	    	}
				//verify whether Compaign name is already exist or not		
				Utilities.selectLeftTreeFrame(driver);
				boolean Temp5=false;
				int rc=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
				System.out.println("rc:"+rc);
				for (int i=1;i<=rc;i++)
				{
					if (i<=15)
					{
					String campNameApp=driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr["+i+"]/td/a")).getText();
					System.out.println(i+":"+campNameApp);
					if (campNameApp.contains(campName))
					{
						driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr["+i+"]/td/a")).click();
						Thread.sleep(3000);
						Temp5=true;
						break;
					}}
				}
				if (Temp5==true)
				{					
					extent.log(LogStatus.PASS, "Compaign Name:"+campName+" already exist");
					extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Campaign"));
				}
				//end of verify campaign
				//create campaign
				if (Temp5==false)
				{
					Utilities.selectRightPaneView(driver);
					
					if (!CampaignSettings.clickCreateCampaign(driver))
					{
						return flag=false;
					}
					CampaignSettings.setCampaignName(driver,campName);
					CampaignSettings.setCampaignDescription(driver,".skillDescCampaign");				
					if (!CampaignSettings.clickSave(driver))
					{
						return flag=false;
					}
					
	    	}
				
				
				Utilities.selectRightPaneView(driver);
				
				//verify if scheduling period exist
				CampaignSettings.clickSave(driver);
				System.out.println("clicked on save");
				Thread.sleep(2000);
				Utilities.selectLeftTreeFrame(driver);
				
				boolean Temp3=false;
				if(driver.findElements(By.xpath("//img[@id='campaignSPTreer1Norg']")).size()!=0)
				{
					driver.findElement(By.xpath("//img[@id='campaignSPTreer1Norg']")).click();
				}
				
				if(CampaignSettings.schedulePeriodExist(driver, Period))
				{
					extent.log(LogStatus.INFO,"schedule period:" + Period + "already exist");
				}
				if(Temp3==true)
				{
					extent.log(LogStatus.INFO,"schedule period:" + Period + "already exist");
				}
				//creation of scheduling period
				else
				{
					CampaignSettings.clickSchedulingPeriod(driver);
					Utilities.selectRightPaneView(driver);
					CampaignSettings.setSchedulingPeriodStartDate(driver, StartDate);
					
					if(!CampaignSettings.clickSchedulingPeriodPSave(driver))
					{
						return flag=false;
					}
					CampaignSettings.setCampaignDescription(driver,".SkillDescCampaign");
					CampaignSettings.clickOrganizationSelector(driver);
					//windowName=Utilities.setWindowFocus(driver);
					for(String winHandle :driver.getWindowHandles())
					{
		                driver.switchTo().window(winHandle);
		                System.out.println("title:"+driver.getTitle());
		                if(driver.getTitle().equals("Organization Selector"))
		                {                	
		                	System.out.println("You are in organization selector window");
		                	driver.manage().window().maximize();
		                    break;
		                }	
					}
					
					CampaignSettings.selectOrganizationSelector(driver, OrgName);
					driver.switchTo().window(mainwindow);
					CampaignSettings.clickskill(driver);
					CampaignSettings.selectHoursOfOperation(driver);
				}
				
				Thread.sleep(2000);
				if(!CampaignSettings.clickCampaignSettingsSave(driver))
				{
					return flag=false;
				}
				//verify if queue is already linked.
				Thread.sleep(2000);
				driver.switchTo().defaultContent();
				CampaignSettings.clickQueue(driver);
				Thread.sleep(3000);
				
				
				CampaignSettings.selectSchedulePeriod(driver, Period);
				boolean temp2=false;
		    	Utilities.selectRightPaneView(driver);
		    	
		    	int row=driver.findElements(By.xpath("//div[@id='tableWrapper']//table[@id='tableRef']//tbody//tr//th")).size();
		    	System.out.println("no of row count  in work pattern iis: "+ row);
		    	if(row>1)
		    	{
		    	String workqname=driver.findElement(By.xpath("//table[@id='tableRef']//tbody//tr[@id='tabler0']//th[@id='tabler0c0']//a")).getAttribute("innerText");
		    	System.out.println("work pattern name is: "+ workqname);
		    	if(workqname.contains(wqname))
		    	{
		    		temp2 = true;
		    	}
		    	if(temp2==true)
		    	{
		    		extent.log(LogStatus.INFO,"work pattern:" +wqname+ " is already added to the campaign queues");
		    	}
		    	}
		    	//addition of queue in campaign
		    	
		    	CampaignSettings.clickAddSP(driver);
				Thread.sleep(2000);
				//String winhandle=Utilities.setWindowFocus(driver);
				for(String winHandle :driver.getWindowHandles())
				{
	                driver.switchTo().window(winHandle);
	                System.out.println("title:"+driver.getTitle());
	                if(driver.getTitle().equals("Add to SP"))
	                {                	
	                	System.out.println("You are in Add to SP window");
	                	driver.manage().window().maximize();
	                    break;
	                }	
				}
//				String winhandle=Utilities.setWindowFocus(driver);
				CampaignSettings.selectWorkQueue(driver,wqname);
				driver.switchTo().window(mainwindow);
				Thread.sleep(2000);
		    	CampaignSettings.addskill_queue(driver,skill);
				if(!CampaignSettings.clickCampaignSettingsSave(driver))
				{
					return flag=false;
				}
				driver.switchTo().defaultContent();
				if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","user_profiles"))
				{
					extent.log(LogStatus.WARNING, "Not able to select User Profile menu. Please try again");
					return flag=false;
				}	
//		    	VerintHomePageScreen.selectMenuItem(driver,"User Management","user_profiles");
				if(!ProfilesScreen.FindSelect(driver,EmpName))
				{
					Utilities.selectRightPaneView(driver);
					ProfilesScreen.clickCreate(driver);
					ProfilesScreen.setProfilesLastName(driver, LastName);
					ProfilesScreen.setProfilesFirstName(driver, FirstName);
					Utilities.selectRightPaneView(driver);
					Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
					if (!ProfilesScreen.clickOrganizationEdit(driver)) // click on organization edit icon
					{
						return flag=false;
					}
					Thread.sleep(6000);			
					String windowName1=Utilities.setWindowFocus(driver);			
					ProfilesScreen.selectOrganizationFromListbox(driver,OrgName);		
						
					driver.switchTo().window(windowName);
					RolesSetupScreen.selectRightPaneView(driver);
					if (!ProfilesScreen.clickSave(driver))
					{
						return flag=false;
					}
					ProfilesScreen.verifySuccessMessage(driver);
				}
				else
				{
					System.out.println("user already exist");
				}
				Utilities.selectRightPaneView(driver);
		    	Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
		    	String org=driver.findElement(By.xpath("//input[@id='orgId_RO']")).getAttribute("value");
		    	System.out.println("org name is" + org);
		    	if(org.contains(OrgName))
		    	{
		    		extent.log(LogStatus.INFO,"Organization is already selected");
		    	}
		    	//set organization for agent
		    	else
		    	{
		    		Utilities.selectRightPaneView(driver);
		    		//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
					if (!ProfilesScreen.clickOrganizationEdit(driver)) // click on organization edit icon
					{
						return flag=false;
					}
					Thread.sleep(6000);			
					String wind=Utilities.setWindowFocus(driver);			
					ProfilesScreen.selectOrganizationFromListbox(driver,OrgName);		
						
					driver.switchTo().window(wind);
					RolesSetupScreen.selectRightPaneView(driver);
					if (!ProfilesScreen.clickSave(driver))
					{
						return flag=false;
					}
		    	}
		    	driver.switchTo().defaultContent();
		    	//verify if skills are already aded to the agent1 profile
		    	ProfilesScreen.clickskillsTab(driver);
		    	boolean flag3=false;
		    	Utilities.selectRightPaneView(driver);
		    	List<WebElement> li4=driver.findElements(By.xpath("//table[@id='skillTableRef']//tr[@class='tblRow']"));
				System.out.println("Li4:"+li4.size());
				for(WebElement elt:li4)
				{
					//System.out.println("**************");
					System.out.println("************skill1:"+elt.findElement(By.tagName("th")).getAttribute("innerText"));
					String wname=elt.findElement(By.tagName("th")).getAttribute("innerText");
					if(wname.equals(skill))
					{
						
						flag3=true;
						break;
					}
				}
				
				if(flag3==true)
				{
					extent.log(LogStatus.PASS, "skill Name:"+skill+" already exist");
				}
				//set skills for agent
				if(flag3==false)
				{
					ProfilesScreen.clickAddskillbtn(driver);
					//String winhandle3=Utilities.setWindowFocus(driver);
					for(String winHandle :driver.getWindowHandles())
					{
		                driver.switchTo().window(winHandle);
		                System.out.println("title:"+driver.getTitle());
		                if(driver.getTitle().equalsIgnoreCase("Skills"))
		                {                	
		                	System.out.println("You are in Skills window");
		                	driver.manage().window().maximize();
		                    break;
		                }	
					}
			    	
			    	ProfilesScreen.setSkill(driver,skill);
			    	driver.switchTo().window(mainwindow);
			    	ProfilesScreen.clickSave(driver);
				}
		    	
				driver.switchTo().defaultContent();
				if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","user_profiles"))
				{
					extent.log(LogStatus.WARNING, "Not able to select User Profile menu. Please try again");
					return flag=false;
				}	
				//verify if skills are already added to the agent2 profile
				if(!ProfilesScreen.FindSelect(driver,EmpName2))
				{
					Utilities.selectRightPaneView(driver);
					ProfilesScreen.clickCreate(driver);
					ProfilesScreen.setProfilesLastName(driver, LastName2);
					ProfilesScreen.setProfilesFirstName(driver, FirstName2);
					Utilities.selectRightPaneView(driver);
					Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
					if (!ProfilesScreen.clickOrganizationEdit(driver)) // click on organization edit icon
					{
						return flag=false;
					}
					Thread.sleep(6000);			
					String windowNam1e=Utilities.setWindowFocus(driver);			
					ProfilesScreen.selectOrganizationFromListbox(driver,OrgName);		
						
					driver.switchTo().window(windowNam1e);
					RolesSetupScreen.selectRightPaneView(driver);
					if (!ProfilesScreen.clickSave(driver))
					{
						return flag=false;
					}
					ProfilesScreen.verifySuccessMessage(driver);
				}
				else
				{
					System.out.println("user already exist");
				}
				Utilities.selectRightPaneView(driver);
		    	Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
		    	org=driver.findElement(By.xpath("//input[@id='orgId_RO']")).getAttribute("value");
		    	System.out.println("org name is" + org);
		    	if(org.contains(OrgName))
		    	{
		    		extent.log(LogStatus.INFO,"Organization is already selected");
		    	}
		    	//set organization for agent
		    	else
		    	{
		    		Utilities.selectRightPaneView(driver);
		    		//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
					if (!ProfilesScreen.clickOrganizationEdit(driver)) // click on organization edit icon
					{
						return flag=false;
					}
					Thread.sleep(6000);			
					String wind=Utilities.setWindowFocus(driver);			
					ProfilesScreen.selectOrganizationFromListbox(driver,OrgName);		
						
					driver.switchTo().window(windowName);
					RolesSetupScreen.selectRightPaneView(driver);
					if (!ProfilesScreen.clickSave(driver))
					{
						return flag=false;
					}
		    	}
		    	driver.switchTo().defaultContent();
		    	ProfilesScreen.clickskillsTab(driver);
		    	boolean flag4=false;
		    	Utilities.selectRightPaneView(driver);
		    	List<WebElement> li3=driver.findElements(By.xpath("//table[@id='skillTableRef']//tr[@class='tblRow']"));
				System.out.println("Li3:"+li3.size());
				for(WebElement elt:li3)
				{
					//System.out.println("**************");
					System.out.println("***************skill2"+elt.findElement(By.tagName("th")).getAttribute("innerText"));
					String wname=elt.findElement(By.tagName("th")).getAttribute("innerText");
					if(wname.equals(skill))
					{
						
						flag4=true;
						break;
					}
				}
				
				if(flag4==true)
				{
					extent.log(LogStatus.PASS, "skill Name:"+skill+" already exist");
				}
				//set skill for agent2
				if(flag4==false)
				{
					ProfilesScreen.clickAddskillbtn(driver);
					//String winhandle4=Utilities.setWindowFocus(driver);
					for(String winHandle :driver.getWindowHandles())
					{
		                driver.switchTo().window(winHandle);
		                System.out.println("title:"+driver.getTitle());
		                if(driver.getTitle().equals("Skills"))
		                {                	
		                	System.out.println("You are in Skills window");
		                	driver.manage().window().maximize();
		                    break;
		                }	
					}
			    	
			    	ProfilesScreen.setSkill(driver,skill);
			    	driver.switchTo().window(mainwindow);
			    	ProfilesScreen.clickSave(driver);
				}
				driver.switchTo().defaultContent();
		    	
		    	VerintHomePageScreen.selectMenuItem(driver,"User Management", "Work Rules");
		    	WorkRulesScreen.findEmployee(driver,EmpName);
		    	WorkRulesScreen.SelectEmployee(driver, EmpName);
		    	//ProfilesScreen.FindSelect(driver,EmpName);
		    	WorkRulesScreen.sethours(driver);
		    	//verify if work rules are already added to agent1 profile
		    	if(WorkRulesScreen.WorkPatternexist(driver,wpname))
		    	{
		    		extent.log(LogStatus.INFO,"work Pattren:"+wpname+"already exist" );
		    	}
		    	
		    	
		    	
		    	
		    	
		    	//addition of created work pattern to Work rules 
		    	else
		    	{
		    		WorkRulesScreen.clickAdd(driver);
		    		Thread.sleep(3000);
		    		//String winhandle3=Utilities.setWindowFocus(driver);
		    		for(String winHandle :driver.getWindowHandles())
					{
		                driver.switchTo().window(winHandle);
		                System.out.println("title:"+driver.getTitle());
		                if(driver.getTitle().equals("Work Patterns"))
		                {                	
		                	System.out.println("You are in Work Patterns window");
		                	driver.manage().window().maximize();
		                    break;
		                }	
					}
			    	
			    	System.out.println("in work pattern window");
			    	WorkRulesScreen.clickAddworkPattern(driver,wpname);
			    	driver.switchTo().window(mainwindow);
		    	}
		    	Thread.sleep(2000);
		    	WorkRulesScreen.clickSave(driver);
		    	
		    	//ProfilesScreen.FindSelect(driver,EmpName2);
		    	WorkRulesScreen.findEmployee(driver,EmpName2);
		    	WorkRulesScreen.SelectEmployee(driver,EmpName2);
		    	//ProfilesScreen.FindSelect(driver,EmpName2);
		    	WorkRulesScreen.sethours(driver);
		    	if(WorkRulesScreen.WorkPatternexist(driver, wpname2))
		    	{
		    		extent.log(LogStatus.INFO,"work Pattren:"+wpname2+"already exist" );
		    	}
		    	
		    	
		    	//addition of created work pattern to Work rules 
		    	else
		    	{
		    		WorkRulesScreen.clickAdd(driver);
		    		Thread.sleep(2000);
		    		//String winhandle3=Utilities.setWindowFocus(driver);
		    		for(String winHandle :driver.getWindowHandles())
					{
		                driver.switchTo().window(winHandle);
		                System.out.println("title:"+driver.getTitle());
		                if(driver.getTitle().equals("Work Patterns"))
		                {                	
		                	System.out.println("You are in Work Patterns window");
		                	driver.manage().window().maximize();
		                    break;
		                }	
					}
			    	
			    	WorkRulesScreen.clickAddworkPattern(driver,wpname2);
			    	driver.switchTo().window(mainwindow);
		    	}
		    	Thread.sleep(2000);
		    	WorkRulesScreen.clickSave(driver);
		    	driver.switchTo().defaultContent();
		    	if (!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","FS_Profiles"))
				{
					Utilities.Logout(driver);
					LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
					LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
					LoginScreen.clickLogin(driver);
					if (!VerintHomePageScreen.verifyVerintHomePage(driver))
					{
						return flag=false;
					}
					if (!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","FS_Profiles"))
					{
						extent.log(LogStatus.WARNING, "Not able to Profiles Settings menu. Please try again");
						return flag=false;
					}			
				}
				if (! FSEmployees.selectCampaign(driver, campName))
				{
					return flag=false;
				}
				if (! FSEmployees.selectPeriod(driver,Period))
				{
					return flag=false;
				}
				//verification of agent1 already added to the campaign
				if(FSEmployees.Empexist(driver,EmpName))
				{
					extent.log(LogStatus.INFO,"employee Name:" +EmpName+"is allready added");
				}
				//addition of agent1 to campaign
				else
				{
					FSEmployees.clickAddEmployeeToSP(driver);
//					String win=Utilities.setWindowFocus(driver);
					for(String winHandle :driver.getWindowHandles()){
		                driver.switchTo().window(winHandle);
		                System.out.println("title:"+driver.getTitle());
		                if(driver.getTitle().equals("Add to Scheduling Period"))
		                {                	
		                	System.out.println("You are in Add Scheduling period window");
		                	driver.manage().window().maximize();
		                    break;
		                }			
					}
					
					FSEmployees.addEmployeeToSP(driver,EmpName);
					FSEmployees.clickAdd(driver);
					driver.switchTo().window(mainwindow);
					FSEmployees.SelectEmployee(driver,EmpName);
					FSEmployees.ClickSave(driver);
				}
				//verification of agent2 already added to the campaign
				if(FSEmployees.Empexist(driver,EmpName2))
				{
					extent.log(LogStatus.INFO,"employee Name:" +EmpName2+"is allready added");
				}
				//addition of agent2 to campaign
				else
				{
					FSEmployees.clickAddEmployeeToSP(driver);
					for(String winHandle :driver.getWindowHandles()){
		                driver.switchTo().window(winHandle);
		                System.out.println("title:"+driver.getTitle());
		                if(driver.getTitle().equals("Add to Scheduling Period"))
		                {                	
		                	System.out.println("You are in Add Scheduling period window");
		                	driver.manage().window().maximize();
		                    break;
		                }			
					}
					FSEmployees.addEmployeeToSP(driver, EmpName2);
					FSEmployees.clickAdd(driver);
					driver.switchTo().window(mainwindow);
					FSEmployees.SelectEmployee(driver,EmpName2);
					FSEmployees.ClickSave(driver);
				}
					
				
				driver.switchTo().defaultContent();
				//go to forecast menu and set the values for volume.
				if(!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Forecast"))
		    	{
		    		Utilities.Logout(driver);
		    		LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
					LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
					LoginScreen.clickLogin(driver);
		    		if (!VerintHomePageScreen.verifyVerintHomePage(driver))
					{
						return flag=false;
					}
					if (!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Forecast"))
					{
						extent.log(LogStatus.WARNING, "Not able to select Forecast menu. Please try again");
						return flag=false;
					}
		    	}
				
		    	Thread.sleep(2000);
		    	
		    	ForecastScreen.setCampaign(driver,campName);
		    	//ForecastScreen.selectPeriod(driver, Period);
		    	ForecastScreen.setPeriod(driver, Period);
		    	Thread.sleep(2000);
		    	ForecastScreen.selectworkQueue(driver, workQueue);
		    	driver.switchTo().defaultContent();
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\btn_clear.png");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Button_Scale.png");
		    	
		    	Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\value_total.png","15");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\value_sun.png");
		       
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\button_set.png");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Save_scale.png");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Save_popup.png");
		    	Thread.sleep(5000);
		    	ForecastScreen.selectworkQueue(driver, workQueue);
		    	driver.switchTo().defaultContent();
		    	Thread.sleep(2000);
		    
		    	//Go to service goals menu and set the values
		    	
		    	if (!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","ServiceGoals"))
				{			
					Utilities.Logout(driver);
					LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
					LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
					LoginScreen.clickLogin(driver);
					if (!VerintHomePageScreen.verifyVerintHomePage(driver))
					{
						extent.log(LogStatus.FAIL, "Verint Homepage is not displayed");
						return flag=false;
					}
					if (!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","ServiceGoals"))
					{
						extent.log(LogStatus.WARNING, "Not able to select Service Goals menu. Please try again.");
						return flag=false;
					}
							
				}
		    	ServiceGoals.selectCampaign(driver,campName);
		    	
		    	ServiceGoals.setPeriod(driver, Period);
		    	ServiceGoals.selectworkQueue(driver, workQueue);
		    	driver.switchTo().defaultContent();
		    	Thread.sleep(2000);
		    	Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\ans.png","0");
		    	Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\seconds.png","0");
		    	Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\ans.png","80");
		    	//Thread.sleep(1000);
		    	
		    	Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\seconds.png","20");
		    	//Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\seconds.png","10");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Save_scale.png");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Save_popup.png");
		    	Thread.sleep(5000);
		    	ServiceGoals.selectworkQueue(driver, workQueue);
		    	driver.switchTo().defaultContent();
		    	Thread.sleep(3000);
		    	// go to calendar menu and  schedule the shifts for both agents and publish it
		    	if (!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Calendar"))
				{			
					Utilities.Logout(driver);
					LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
					LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
					LoginScreen.clickLogin(driver);
					if (!VerintHomePageScreen.verifyVerintHomePage(driver))
					{
						extent.log(LogStatus.FAIL, "Verint Homepage is not displayed");
						return flag=false;
					}
					if (!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Calendar"))
					{
						extent.log(LogStatus.WARNING, "Not able to select Calendar menu. Please try again.");
						return flag=false;
					}
							
				}
				
		    	CalendarScreen.selectCampaign(driver, campName);
		    	CalendarScreen.selectPeriod(driver, Period);
		    	Thread.sleep(2000);
		    	
		    	CalendarScreen.Selctallemp(driver);
		    	CalendarScreen.clickViewbtn(driver);
		    	
		    	Thread.sleep(3000);
		    	driver.switchTo().defaultContent();
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\availableEmp_icon.png");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\emp.png");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\btnok_emp.png");
		    	Thread.sleep(3000);
		    	driver.switchTo().defaultContent();
			    	
			    	
			    	
			    	
			    	
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM_REG",HTMLReportName,4,56);
		}
		return flag;
	
	}

}
