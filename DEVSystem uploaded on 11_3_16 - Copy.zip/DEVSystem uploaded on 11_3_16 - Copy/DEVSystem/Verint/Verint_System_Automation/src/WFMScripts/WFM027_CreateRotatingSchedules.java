package WFMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import jxl.Sheet;
import jxl.Workbook;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.python.modules.thread.thread;
import org.sikuli.basics.proxies.Mat;

import ScreenObjects.CampaignSettings;
import ScreenObjects.ForecastScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.OrganizationSettings;
import ScreenObjects.ProfilesScreen;
import ScreenObjects.PulseScreen;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.RotationScreeen;
import ScreenObjects.ServiceGoals;
import ScreenObjects.ShiftScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.WorkPatternScreen;
import ScreenObjects.WorkQueuesScreen;
import ScreenObjects.WorkRulesScreen;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM027_CreateRotatingSchedules
{
	public static ExtentReports extent = ExtentReports.get(WFM027_CreateRotatingSchedules.class);
	
	public static boolean Create_Rotating_schedules()throws Exception
	{
		boolean flag=true;
		String windowName="";
		String HTMLReportName="WFM027_CreateRotatingSchedules"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "create Rotating schedules for agent");
				
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 			
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);
	    Sheet Ws = Wb.getSheet("WFM_RegressionTestSet");
	    
	    String OrgName=Ws.getCell(5,36).getContents();
	    String organizationDesc = Ws.getCell(6,36).getContents();
	    String parentOrganization = Ws.getCell(7,36).getContents();
	    String shiftName=Ws.getCell(33,36).getContents();
	    String Description=Ws.getCell(48,36).getContents();
	    String wpname=Ws.getCell(30,36).getContents();
	    String EmpName =Ws.getCell(16,36).getContents();
	    String FirstName=Ws.getCell(13,36).getContents();
	    String LastName=Ws.getCell(12,36).getContents();
	    String shiftName2=Ws.getCell(47,3).getContents();
	    String Rname=Ws.getCell(63,36).getContents();
	    String wpname2=Ws.getCell(51,36).getContents();
	    
	    try
	    {
	    	LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			String mainwindow=driver.getWindowHandle();
			
			/*LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			
	    	
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			//String mainwindow=driver.getWindowHandle();
			VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Organization Settings");
	    	Utilities.selectLeftTreeFrame(driver);
			Boolean Temp1=false;			
			int rc1=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
			//System.out.println("rc1:"+rc1);
			for (int j=1;j<=rc1;j++)
			{
				if (j<=15)
				{
				String orgName1=driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).getText();
				Thread.sleep(1000);
				if (orgName1.contains(OrgName))
				{
					driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).click();
					Temp1=true;
					break;
				}}
			}
			if (Temp1==true)
			{
				System.out.println("org already exist");
				extent.log(LogStatus.INFO, "Organization Name: "+OrgName+" already exist");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Organization"));								
			}			
			//end of verify organization
			//create organization
			if (Temp1==false)
			{
				Utilities.selectLeftTreeFrame(driver);
				if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,parentOrganization))
				{
					return flag=false;
				}
				Utilities.selectRightPaneView(driver);
				if (!OrganizationSettings.clickCreateOrganization(driver))
				{
					return flag=false;
				}
				OrganizationSettings.setOrganizationName(driver,OrgName);
				OrganizationSettings.setOrganizationDescription(driver,organizationDesc);
				OrganizationSettings.isSelectedDaysAndHoursOfOperation(driver);
				if (!OrganizationSettings.clickSave(driver))
				{
					return flag=false;
				}
			}
			driver.switchTo().defaultContent();
	    	Thread.sleep(2000);
	    	if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Shifts"))
			{
			
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Shifts"))
				{
				//if (driver.findElements(By.linkText("Profiles")).size()==0)
				//{
					extent.log(LogStatus.WARNING, "Not able to select Shifts menu. Please try again.");
					return flag=false;
				}
				
			}
			Utilities.selectRightPaneView(driver);
			
//	    	
	    	if(ShiftScreen.Shiftexist(driver, shiftName))
	    	{
	    		extent.log(LogStatus.INFO,"shift"+ shiftName + "already exist");
	    	}
	    	
	    	
	    	
			//creation of new shift for agent1
	    	else
	    	{
			
				ShiftScreen.clickcreateshift(driver);
				Thread.sleep(2000);
				ShiftScreen.setshiftName(driver,shiftName);
				ShiftScreen.setshiftDescription(driver,Description);
				ShiftScreen.setshiftstartTime(driver);
				ShiftScreen.clickSave(driver);
	    	}
			
			if(ShiftScreen.Shiftexist(driver, shiftName2))
			{
				extent.log(LogStatus.INFO,"shift"+ shiftName2 + "already exist");
			}
			
			//creation of new shift for agent2
			else
			{
				ShiftScreen.clickcreateshift(driver);
				Thread.sleep(2000);
				ShiftScreen.setshiftName(driver,shiftName2);
				ShiftScreen.setshiftDescription(driver, Description);
				ShiftScreen.setshiftstartTime2(driver);
				ShiftScreen.clickSave(driver);
			}
				
			
			
			Thread.sleep(2000);
			driver.switchTo().defaultContent();
	    	
VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Work Pattern");
			
			Utilities.selectRightPaneView(driver);
	    	Thread.sleep(5000);
	    	//verify if work pattern already exist or not
	    	boolean Temp7=false;
	    	driver.findElement(By.name("itemToFind")).sendKeys(wpname);
	    	driver.findElement(By.xpath("//button[@id='toolbar_FIND_ACTIONLabel']")).click();
	    	Thread.sleep(2000);
	    	List<WebElement> li1=driver.findElements(By.xpath("//table[@id='tableRef']//tr[@class='tblRow']"));
	    	System.out.println(li1.size());
	    	if(driver.findElements(By.xpath("//table[@id='tableRef']//tr[@class='tblRow']//td")).size()!=0)
	    	{
	    	for(WebElement elt:li1)
	    	{
	    		//System.out.println("**************");
	    		System.out.println(elt.findElement(By.tagName("td")).getAttribute("innerText"));
	    		String wname=elt.findElement(By.tagName("td")).getAttribute("innerText");
	    		if(wname.contains(wpname))
	    		{
	    			Temp7=true;
	    			break;
	    		}
	    	}
	    	}
//	    	
	    	
	    	
	    	
	    	
			if (Temp7==true)
			{					
				extent.log(LogStatus.PASS, "Work pattren Name:"+wpname+" already exist");
				//extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Campaign"));
			}
			//end of verify work pattern
			//create a new work pattern
			if(Temp7==false)
			{
				if(!WorkPatternScreen.clickworkpattern(driver))
		    	{
		    		return flag=false;
		    	}
	    	WorkPatternScreen.setWorkpatternName(driver, wpname);
	    	WorkPatternScreen.setWorkpatternDescription(driver,".AutomationDescWorkPattern");
	    	WorkPatternScreen.setpossibledaysOff(driver);
	    	WorkPatternScreen.clickAddshift(driver);
	    	//String windowName1=Utilities.setWindowFocus(driver);
	    	for(String winHandle :driver.getWindowHandles()){
                driver.switchTo().window(winHandle);
                System.out.println("title:"+driver.getTitle());
                if(driver.getTitle().equals("Shift Details"))
                {                	
                	System.out.println("You are in Shift Details window");
                	driver.manage().window().maximize();
                    break;
                }			
			}
	    	
	    	WorkPatternScreen.setshift(driver,shiftName);
	    	driver.switchTo().window(mainwindow);
	    	
	    	if(!WorkPatternScreen.clickSave(driver))
	    	{
	    		return flag=false;
	    	}
			}
	    	Utilities.selectRightPaneView(driver);
	    	Thread.sleep(5000);
	    	//verify if work pattern alreay exist or not
	    	boolean Temp8=false;
	    	driver.findElement(By.name("itemToFind")).clear();
	    	driver.findElement(By.name("itemToFind")).sendKeys(wpname2);
	    	driver.findElement(By.xpath("//button[@id='toolbar_FIND_ACTIONLabel']")).click();
	    	Thread.sleep(2000);
	    	List<WebElement> li2=driver.findElements(By.xpath("//table[@id='tableRef']//tr[@class='tblRow']"));
	    	System.out.println("Li2="+li2.size());
	    	if(driver.findElements(By.xpath("//table[@id='tableRef']//tr[@class='tblRow']//td")).size()!=0)
	    	{
	    		for(WebElement elt:li2)
		    	{
		    		//System.out.println("**************");
		    		System.out.println(elt.findElement(By.tagName("td")).getAttribute("innerText"));
		    		String wname=elt.findElement(By.tagName("td")).getAttribute("innerText");
		    		if(wname.contains(wpname2))
		    		{
		    			Temp8=true;
		    			break;
		    		}
		    	}
	    		if (Temp8==true)
				{					
					extent.log(LogStatus.PASS, "Work pattren Name:"+wpname+" already exist");
					//extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Campaign"));
				}
	    	}
	    	
			//end of verify work pattern
			//create a new work pattern
			if(Temp8==false)
			{
	    	if(!WorkPatternScreen.clickworkpattern(driver))
	    	{
	    		return flag=false;
	    	}
	    	WorkPatternScreen.setWorkpatternName(driver, wpname2);
	    	WorkPatternScreen.setWorkpatternDescription(driver,".AutomationDescWorkPattern");
	    	WorkPatternScreen.setpossibledaysOff(driver);
	    	WorkPatternScreen.clickAddshift(driver);
	    	//String windowName2=Utilities.setWindowFocus(driver);
	    	for(String winHandle :driver.getWindowHandles()){
                driver.switchTo().window(winHandle);
                System.out.println("title:"+driver.getTitle());
                if(driver.getTitle().equals("Shift Details"))
                {                	
                	System.out.println("You are in Shift Details window");
                	driver.manage().window().maximize();
                    break;
                }			
			}
	    	
	    	WorkPatternScreen.setshift(driver,shiftName2);
	    	driver.switchTo().window(mainwindow);
	    	
	    	if(!WorkPatternScreen.clickSave(driver))
	    	{
	    		return flag=false;
	    	}
			}
			Thread.sleep(2000);
	    	driver.switchTo().defaultContent();
				
	    	
			
			
			if(!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Rotation"))

			{
				extent.log(LogStatus.WARNING, "Not able to select Rotation menu. Please try again");
				return flag=false;
			}
			OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,parentOrganization);
			if(RotationScreeen.Rotationexist(driver,Rname))
			{
				extent.log(LogStatus.INFO,"Rotation alreay exist");
			}
			else
			{
			RotationScreeen.clickCreate(driver);
			RotationScreeen.setRotationName(driver,Rname);
			if(RotationScreeen.WorkPatternexist(driver,wpname))
	    	{
	    		extent.log(LogStatus.INFO,"work Pattren:"+wpname+"already exist" );
	    	}
		
			
			else
	    	{
	    		RotationScreeen.clickAdd(driver);
	    		Thread.sleep(3000);
	    		//String winhandle3=Utilities.setWindowFocus(driver);
	    		for(String winHandle :driver.getWindowHandles())
				{
	                driver.switchTo().window(winHandle);
	                System.out.println("title:"+driver.getTitle());
	                if(driver.getTitle().equals("Work Patterns"))
	                {                	
	                	System.out.println("You are in Work Patterns window");
	                	driver.manage().window().maximize();
	                    break;
	                }	
				}
		    	
		    	System.out.println("in work pattern window");
		    	RotationScreeen.clickAddworkPattern(driver,wpname);
		    	driver.switchTo().window(mainwindow);
	    	}
	    	Thread.sleep(2000);
			Utilities.selectRightPaneView(driver);
			RotationScreeen.clickAdd(driver);
    		Thread.sleep(3000);
    		//String winhandle3=Utilities.setWindowFocus(driver);
    		for(String winHandle :driver.getWindowHandles())
			{
                driver.switchTo().window(winHandle);
                System.out.println("title:"+driver.getTitle());
                if(driver.getTitle().equals("Work Patterns"))
                {                	
                	System.out.println("You are in Work Patterns window");
                	driver.manage().window().maximize();
                    break;
                }	
			}
	    	
	    	System.out.println("in work pattern window");
	    	RotationScreeen.clickAddworkPattern(driver,wpname2);
	    	driver.switchTo().window(mainwindow);
	    	Thread.sleep(2000);
	    	RotationScreeen.clickSave(driver);
	    	
			}
			Thread.sleep(2000);
	    	driver.switchTo().defaultContent();
			
			if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","user_profiles"))
			{
				extent.log(LogStatus.WARNING, "Not able to select User Profile menu. Please try again");
				return flag=false;
			}	
//	    	VerintHomePageScreen.selectMenuItem(driver,"User Management","user_profiles");
			if(!ProfilesScreen.FindSelect(driver,EmpName))
			{
				Utilities.selectRightPaneView(driver);
				ProfilesScreen.clickCreate(driver);
				ProfilesScreen.setProfilesLastName(driver, LastName);
				ProfilesScreen.setProfilesFirstName(driver, FirstName);
				Utilities.selectRightPaneView(driver);
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
				if (!ProfilesScreen.clickOrganizationEdit(driver)) // click on organization edit icon
				{
					return flag=false;
				}
				Thread.sleep(6000);			
				String windowName1=Utilities.setWindowFocus(driver);			
				ProfilesScreen.selectOrganizationFromListbox(driver,OrgName);		
					
				driver.switchTo().window(windowName);
				RolesSetupScreen.selectRightPaneView(driver);
				if (!ProfilesScreen.clickSave(driver))
				{
					return flag=false;
				}
				ProfilesScreen.verifySuccessMessage(driver);
			}
			else
			{
				System.out.println("user already exist");
			}
			Utilities.selectRightPaneView(driver);
	    	Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
	    	String org=driver.findElement(By.xpath("//input[@id='orgId_RO']")).getAttribute("value");
	    	System.out.println("org name is" + org);
	    	if(org.contains(OrgName))
	    	{
	    		extent.log(LogStatus.INFO,"Organization is already selected");
	    	}
	    	//set organization for agent
	    	else
	    	{
	    		Utilities.selectRightPaneView(driver);
	    		//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
				if (!ProfilesScreen.clickOrganizationEdit(driver)) // click on organization edit icon
				{
					return flag=false;
				}
				Thread.sleep(6000);			
				String wind=Utilities.setWindowFocus(driver);			
				ProfilesScreen.selectOrganizationFromListbox(driver,OrgName);		
					
				driver.switchTo().window(wind);
				RolesSetupScreen.selectRightPaneView(driver);
				if (!ProfilesScreen.clickSave(driver))
				{
					return flag=false;
				}
	    	}
	    	driver.switchTo().defaultContent();
	    	driver.findElement(By.id("utilityPanePC_LOGOUT_spn_id")).click();*/
	    	
	    	Thread.sleep(3000);
	    	//login with forecaster
	    	LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("WFMPlannerName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("WFMPlannerPassword"));
			LoginScreen.clickLogin(driver);
			extent.log(LogStatus.INFO,"logged in as a Planner");
			driver.switchTo().defaultContent();
			
	    	
	    	
	    	VerintHomePageScreen.selectMenuItem(driver,"User Management", "Work Rules");
	    	WorkRulesScreen.findEmployee(driver,EmpName);
	    	WorkRulesScreen.SelectEmployee(driver, EmpName);
	    	//ProfilesScreen.FindSelect(driver,EmpName);
	    	WorkRulesScreen.sethours(driver);
	    	Utilities.selectRightPaneView(driver);
	    	Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\scrollbar_workrules.png");
	    	//verify if rotatiion is already added to agent1 profile
	    	if(WorkRulesScreen.Rotationexist(driver, Rname))
	    	{
	    		extent.log(LogStatus.INFO,"rotation :"+Rname+"already exist" );
	    	}
	    	
	    	
	    	
	    	
	    	
	    	//addition of created rotation to Work rules 
	    	else
	    	{
	    		WorkRulesScreen.clickAddrotation(driver);
	    		Thread.sleep(3000);
	    		//String winhandle3=Utilities.setWindowFocus(driver);
	    		for(String winHandle :driver.getWindowHandles())
				{
	                driver.switchTo().window(winHandle);
	                System.out.println("title:"+driver.getTitle());
	                if(driver.getTitle().equals("Rotations"))
	                {                	
	                	System.out.println("You are in Rotation window");
	                	driver.manage().window().maximize();
	                    break;
	                }	
				}
		    	
		    	System.out.println("in Rotation window");
		    	WorkRulesScreen.Addrotation(driver,Rname);
		    	driver.switchTo().window(mainwindow);
	    	}
	    	Thread.sleep(2000);
	    	WorkRulesScreen.clickSave(driver);
	    	extent.log(LogStatus.INFO,"Rotation is added sucessfully for agent");
	    	extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Work Pattern_planner"));
	    	driver.switchTo().defaultContent();
	    	
	    	
	    	driver.findElement(By.id("utilityPanePC_LOGOUT_spn_id")).click();
	    	
	    	Thread.sleep(3000);
	    	//login with Admin
	    	LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			
			VerintHomePageScreen.selectMenuItem(driver,"User Management", "Work Rules");
	    	WorkRulesScreen.findEmployee(driver,EmpName);
	    	WorkRulesScreen.SelectEmployee(driver, EmpName);
	    	WorkRulesScreen.Rotationremove(driver);
	    	WorkRulesScreen.clickSave(driver);
	    	extent.log(LogStatus.INFO,"Roatation is removed successfully");
	    	extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Work Pattern_admin"));
	    	driver.switchTo().defaultContent();
				
	    }
	    catch(Exception e)
	    {
	    	e.printStackTrace();
	    }
	    finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM_REG",HTMLReportName,4,36);
		}
		return flag;
	
}
}
