package WFMScripts;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;

import ScreenObjects.ActivitiesScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.ProfilesScreen;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.RuleSettingsScreen;
import ScreenObjects.VerintHomePageScreen;

import ScreenObjects.OrganizationSettings;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM030_ScheduleChangeNotification{
	
	public static ExtentReports extent = ExtentReports.get(WFM030_ScheduleChangeNotification.class);
	
	public static boolean Rule_scheduleChangeNotification() throws Exception
	{		
		boolean flag=true;
		String HTMLReportName="Schedule Change Notification"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Schedule Change Notification");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("WFM_RegressionTestSet");
	    String RuleName=Ws.getCell(37,4).getContents();
	    String Ruletype=Ws.getCell(38,4).getContents();
	   /* String Requesttype=Ws.getCell(38,14).getContents();
	    String Statustype=Ws.getCell(39,14).getContents();*/
	    
	    
	    
		
		try
		{		   
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			
			if (!VerintHomePageScreen.selectMenuItem(driver,"Tracking","Tracking_Organization"))
			{
				extent.log(LogStatus.WARNING, "Not able to select Organization menu from tracking tab. Please try again");
				return flag=false;
			}	
			
			//Utilities.selectRightPaneView(driver);
			RuleSettingsScreen.clickCreate_Rule(driver);
			RuleSettingsScreen.setTextInRulename(driver, RuleName);
			RuleSettingsScreen.selectruletype(driver, Ruletype);
			Thread.sleep(2000);
			/*RuleSettingsScreen.selectrequesttype(driver, Requesttype);
			RuleSettingsScreen.selectStatustype(driver, Statustype);*/
			RuleSettingsScreen.clickAction_email(driver);
			RuleSettingsScreen.clickEmployee(driver);
			RuleSettingsScreen.clickSupervisor(driver);
			RuleSettingsScreen.settext_email(driver,"Notification for schedule change");
			RuleSettingsScreen.clickSave_Rule(driver);
			extent.log(LogStatus.INFO,"rule is created successfully");
			
			RuleSettingsScreen.clickDelete_Rule(driver);
			Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\btnok_delrule.png");
	    	Thread.sleep(3000);
	    	extent.log(LogStatus.INFO,"Rule is deleted sucessfully");
	    	extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "RulePage"));
	    	driver.switchTo().defaultContent();
			
			
			
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM_REG",HTMLReportName,4,4);
		}
		return flag;
	}

}
