package WFMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import ScreenObjects.LoginScreen;
import ScreenObjects.NewRoleScreen;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.VerintHomePageScreen;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM017_RestrictViewOfActivities {
	
	
	public static ExtentReports extent = ExtentReports.get(WFM017_RestrictViewOfActivities.class);
	
	public static boolean Restrict_ViewOfActivities() throws Exception
	{
		
		boolean flag=true;
		String HTMLReportName="WFM017_RestrictViewOfActivities"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Restrict View Of Activities");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("WFM_TestSet");
	    String ParentOrganization = Ws.getCell(7,11).getContents();
	    String RoleName = Ws.getCell(9,11).getContents();
	    String RoleDesc = Ws.getCell(10,11).getContents();	    	   
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Role Setup"))
			//if (driver.findElements(By.linkText("Roles Setup")).size()==0)
			{
				Utilities.Logout(driver);				
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Role Setup"))			
				//if (driver.findElements(By.linkText("Roles Setup")).size()==0)
				{
					extent.log(LogStatus.WARNING, "Roles Setup section is not displayed. Please try again.");
					return flag=false;
				}
			}
				
			RolesSetupScreen.selectNodeFromLeftTreePane(driver,ParentOrganization);
			RolesSetupScreen.selectRightPaneView(driver);
			
			//verify role name already exist or not
			if (!RolesSetupScreen.verifyRoleName(driver,RoleName))
			{			
				if (!RolesSetupScreen.clickCreateNewRole(driver))
				{
					return flag=false;
				}
				
				if (!NewRoleScreen.setTextInRolename(driver,RoleName))
				{
					return flag=false;
				}
				NewRoleScreen.setTextInRoleDescription(driver,RoleDesc);
				//NewRoleScreen.expandPrivilege(driver);
				//NewRoleScreen.selectPrivilege(driver,"Authorize Adherence Exceptions;Load and Playback Agent Interactions");
				if (!NewRoleScreen.clickSave(driver))			
				{
					return flag=false;
				}
				RolesSetupScreen.selectRightPaneView(driver);
				//validation- role created or not
				/*if (!RolesSetupScreen.selectRoleName(driver,RoleName))
				{
					return flag=false;
				}*/
			}
			if (!RolesSetupScreen.selectRoleName(driver,RoleName))
			{
				return flag=false;
			}
			NewRoleScreen.expandPrivilege(driver);
			NewRoleScreen.selectPrivilege(driver,"Authorize Adherence Exceptions;Load and Playback Agent Interactions");
			//delete role
			RolesSetupScreen.selectRightPaneView(driver);
			if (RolesSetupScreen.verifyRoleName(driver,RoleName))
			{
				if (!RolesSetupScreen.clickDeleteRole(driver))
				{
					return flag=false;
				}
			}
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM",HTMLReportName,4,11);
		}
		return flag;
	}


}
