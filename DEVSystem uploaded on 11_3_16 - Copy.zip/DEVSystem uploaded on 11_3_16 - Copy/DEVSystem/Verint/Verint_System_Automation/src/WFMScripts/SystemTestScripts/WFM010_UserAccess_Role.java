package WFMScripts.SystemTestScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import ScreenObjects.LoginScreen;

import ScreenObjects.AccessRightsScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.ProfilesScreen;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import org.sikuli.script.Screen;

public class WFM010_UserAccess_Role {
	
	
	public static ExtentReports extent = ExtentReports.get(WFM010_UserAccess_Role.class);
	
	public static boolean WFM010_UserAccess_With_Role() throws Exception
	{
		boolean flag=true;
		//String windowName="";
		Screen sobj = new Screen ();
		String HTMLReportName="UserAccessWithRole"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Associate User Access with User Role");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("WFM_TestSet");
	    String organizationName = Ws.getCell(5,4).getContents();
	    String UserAlias = Ws.getCell(12,4).getContents();
	    String UserLastName = Ws.getCell(13,4).getContents();	   	
	    String roleName = Ws.getCell(9,4).getContents();
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Profiles"))			
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Profiles"))
				//if (driver.findElements(By.linkText("Profiles")).size()==0)
				{
					extent.log(LogStatus.WARNING, "Profiles section is not displayed. Please try again");
					return flag=false;
				}				
			}
			//verify User exist or not
			if (!ProfilesScreen.FindSelect(driver, UserLastName))
			{			
				Utilities.selectRightPaneView(driver);				
				if (!ProfilesScreen.clickImportDomainUsers(driver))
				{
					return flag=false;
				}
				Thread.sleep(2000);				
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_EnterObjNameToSelect.png") != null)
				{
					sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_EnterObjNameToSelect.png", UserAlias);
				}				
				Thread.sleep(1000);
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_OK_Btn.png") != null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_OK_Btn.png");
				}				
				Thread.sleep(5000);
				Utilities.selectRightPaneView(driver);
				//System.out.println("err:"+driver.findElement(By.xpath("//div[@id='workPaneWrapper']/table[@id='viewfindPane_tbl_id']/tbody/tr/td[2]/table[@id='pageMessages_bttn_tbl_id']/tbody/tr/td[1]/div")).getText());
				if (!ProfilesScreen.checkErrorMessage(driver))
				{				
						return flag=false;
				}
				Thread.sleep(2000);				
				if (!ProfilesScreen.FindSelect(driver, UserLastName))
				{
					return flag=false;
				}
				
				/*if (!ProfilesScreen.selectProfile(driver,UserLastName))
				{
					return flag=false;
				}*/
			}
			//assign role - QM057
			//select Access Rights tab
			driver.switchTo().defaultContent();
			if (driver.findElements(By.linkText("Access Rights")).size()!=0)
			{
				driver.findElement(By.linkText("Access Rights")).click();
				extent.log(LogStatus.INFO, "Access Rights tab is selected");
			}		
			else
			{
				extent.log(LogStatus.FAIL, "Not able to select Access Rights tab");
				return flag=false;
			}
			if (!AccessRightsScreen.selectEmp_From_AccessRightsFrame(driver,UserLastName))
			{
				return flag=false;
			}
			Utilities.selectRightPaneView(driver);
			if (!AccessRightsScreen.clickEditAccessRights(driver))
			{
				return flag=false;
			}
			if (!AccessRightsScreen.select_RoleName_checkbox(driver,roleName))
			{
				return flag=false;
			}
			if (!AccessRightsScreen.select_OrganizationScope_checkbox(driver,organizationName))
			{
				return flag=false;
			}			
			
			if (!AccessRightsScreen.clickSave(driver))
			{
				return flag=false;
			}		
			
			//select Profiles tab
			driver.switchTo().defaultContent();
			if (driver.findElements(By.linkText("Profiles")).size()!=0)
			{
				driver.findElement(By.linkText("Profiles")).click();
				extent.log(LogStatus.INFO, "Profiles tab is selected");
			}		
			else
			{
				extent.log(LogStatus.FAIL, "Not able to select Profiles tab");
				return flag=false;
			}
			Utilities.selectRightPaneView(driver);
			if (!ProfilesScreen.clickDelete(driver))
			{
				return flag=false;
			}					
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Delete_OK.png");
			Thread.sleep(12000);
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "User"));
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			//extent.endTest();
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM",HTMLReportName,4,4);
		}
		return flag;
	}
	

}
