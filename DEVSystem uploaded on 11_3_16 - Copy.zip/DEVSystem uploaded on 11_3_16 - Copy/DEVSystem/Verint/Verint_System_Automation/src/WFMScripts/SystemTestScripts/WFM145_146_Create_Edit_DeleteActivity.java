package WFMScripts.SystemTestScripts;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;

import ScreenObjects.ActivitiesScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.ProfilesScreen;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.VerintHomePageScreen;

import ScreenObjects.OrganizationSettings;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM145_146_Create_Edit_DeleteActivity{
	
	public static ExtentReports extent = ExtentReports.get(WFM145_146_Create_Edit_DeleteActivity.class);
	
	public static boolean Create_Edit_DeleteActivity() throws Exception
	{		
		boolean flag=true;
		String HTMLReportName="Create_Edit_DeleteActivity"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Create_Edit_DeleteActivity");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("WFM_TestSet");
	    String ActivityName=Ws.getCell(22,9).getContents();
	    String ActivityDesc=Ws.getCell(23,9).getContents();
	    String ActivityType=Ws.getCell(24,9).getContents();
	    String ActivityCode=Ws.getCell(25,9).getContents();
	    
	    
	    
		
		try
		{		   
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			
			if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Activiteis"))
			{
				extent.log(LogStatus.WARNING, "Not able to select Activities menu. Please try again");
				return flag=false;
			}	
			//verify if activity exist or not
			if(ActivitiesScreen.activityExist(driver,ActivityName))
			{
				extent.log(LogStatus.INFO,"Activity Name:"+ActivityName+" is already exist");
			}
			//create a new activity
			else
			{
				
				Utilities.selectRightPaneView(driver);
				ActivitiesScreen.clickCreateActivity(driver);
				ActivitiesScreen.setActivityName(driver, ActivityName);
				ActivitiesScreen.setActivityDescription(driver, ActivityDesc);
				ActivitiesScreen.setActivityType(driver, ActivityType);
				Thread.sleep(3000);
				ActivitiesScreen.setActivityCode(driver, ActivityCode);
				driver.findElement(By.id("usedInShift_true_0")).click();
				ActivitiesScreen.clickSave(driver);
			}	
			
			//Edit Activity
			Utilities.selectRightPaneView(driver);
			ActivitiesScreen.selectActivity(driver,ActivityName);
			ActivitiesScreen.clickEditActivity(driver);
			ActivitiesScreen.setActivityDescription(driver,"desc");
			ActivitiesScreen.clickEditSave(driver);
			
			//Delete Activity
			/*Utilities.selectRightPaneView(driver);
			ActivitiesScreen.selectActivity(driver,ActivityName);
			ActivitiesScreen.deleteActivityName(driver,ActivityName);*/
			
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM",HTMLReportName,4,9);
		}
		return flag;
	}

}
