package WFMScripts.SystemTestScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import ScreenObjects.LoginScreen;

import ScreenObjects.RolesSetupScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.ProfilesScreen;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import org.sikuli.script.Screen;

public class WFM008_Import {
	
	
	public static ExtentReports extent = ExtentReports.get(WFM008_Import.class);
	
	public static boolean Import_Agent() throws Exception
	{
		boolean flag=true;
		String windowName="";
		//Screen sobj = new Screen ();
		String HTMLReportName="ImportAgent"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Import Agent");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("WFM_TestSet");
	    String UserName = Ws.getCell(17,3).getContents();
	    String UserLastName = Ws.getCell(13,3).getContents();	   	
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Profiles"))
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Profiles"))				
				{
					extent.log(LogStatus.WARNING, "Profiles section is not displayed. Please try again");
					return flag=false;
				}				
			}
			RolesSetupScreen.selectRightPaneView(driver);
			if (!ProfilesScreen.clickImport(driver))
				return flag=false;
			//windowName=Utilities.setWindowFocus(driver);
			
			for(String winHandle :driver.getWindowHandles()){
                driver.switchTo().window(winHandle);
                System.out.println("title:"+driver.getTitle());
                if(driver.getTitle().contains("Import"))
                {
                	//flag=true;
                	System.out.println("You are in Import - SF window");
                	driver.manage().window().maximize();
                    break;
                }			
			}
			
			Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Browse.png");			
			Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\FileName_To_Upload.png","C:\\DEV\\Verint\\Verint_System_Automation\\src\\TestData\\Import.txt");
			
			Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Open_To_Upload.png");			
			Thread.sleep(5000);
			ProfilesScreen.setNumberOfLinesStartOfFile(driver,"1");			
			ProfilesScreen.clickSelectAll(driver);
			Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Save.png");			
			Thread.sleep(3000);			
			if (!ProfilesScreen.verifyImportSuccessMessage(driver))
			{
				return flag=false;
			}
			driver.close();
			
			for(String winHandle : driver.getWindowHandles()){
			    driver.switchTo().window(winHandle);
			}	
			Utilities.selectLeftTreeFrame(driver);
			
			if (!ProfilesScreen.FindSelect(driver, UserLastName))
			{	
				extent.log(LogStatus.FAIL, "User Last Name:"+UserLastName+" not found. Please try again");
				return flag=false;
			}
			driver.switchTo().defaultContent();
			if (driver.findElements(By.linkText("Users")).size()!=0)
			{
				driver.findElement(By.linkText("Users")).click();
				extent.log(LogStatus.INFO, "Users tab is selected");
			}		
			else
			{
				extent.log(LogStatus.FAIL, "Not able to select Users tab");
				return flag=false;
			}
			Utilities.selectRightPaneView(driver);
			if (!ProfilesScreen.setUserName(driver, UserName))
			{	
				//extent.log(LogStatus.FAIL, "User Name:"+UserName+" not found. Please try again");
				return flag=false;
			}
			if (!ProfilesScreen.clickSave(driver))
			{	
				return flag=false;
			}
			if (!ProfilesScreen.verifyPageMessage(driver))
			{
				return flag=false;
			}
			driver.switchTo().defaultContent();
			if (driver.findElements(By.linkText("Profiles")).size()!=0)
			{
				driver.findElement(By.linkText("Profiles")).click();
				extent.log(LogStatus.INFO, "Profiles tab is selected");
			}		
			else
			{
				extent.log(LogStatus.FAIL, "Not able to select Profiles tab");
				return flag=false;
			}
			Utilities.selectRightPaneView(driver);
			if (!ProfilesScreen.clickDelete(driver))
			{	
				return flag=false;
			}
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			//extent.endTest();
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM",HTMLReportName,4,3);
		}
		return flag;
	}
	

}
