package WFMScripts.SystemTestScripts;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;

import ScreenObjects.ActivitiesScreen;
import ScreenObjects.AdherenceMappingScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.ProfilesScreen;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.VerintHomePageScreen;

import ScreenObjects.OrganizationSettings;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM172_Map_Activities_For_Adherence{
	
	public static ExtentReports extent = ExtentReports.get(WFM172_Map_Activities_For_Adherence.class);
	
	public static boolean Edit_Adherence_Mapping() throws Exception
	{		
		boolean flag=true;
		String HTMLReportName="Edit_Adherence_Mapping"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Edit_Adherence_Mapping");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("WFM_TestSet");
	    String ActivityName=Ws.getCell(22,10).getContents();
	    String ActivityDesc=Ws.getCell(23,10).getContents();
	    String ActivityType=Ws.getCell(24,10).getContents();
	    String ActivityCode=Ws.getCell(25,10).getContents();
	    String MappingName=Ws.getCell(26,10).getContents();
	   
	    
	    
	    
		
		try
		{		   
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			
			if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Activiteis"))
			{
				extent.log(LogStatus.WARNING, "Not able to select Activities menu. Please try again");
				return flag=false;
			}	
			
			
			//verify if activity exist or not
			if(ActivitiesScreen.activityExist(driver,ActivityName))
			{
				extent.log(LogStatus.INFO,"Activity Name:"+ActivityName+" is already exist");
			}
			//create a new activity
			else
			{
				
				Utilities.selectRightPaneView(driver);
				ActivitiesScreen.clickCreateActivity(driver);
				ActivitiesScreen.setActivityName(driver, ActivityName);
				ActivitiesScreen.setActivityDescription(driver, ActivityDesc);
				ActivitiesScreen.setActivityType(driver, ActivityType);
				Thread.sleep(3000);
				ActivitiesScreen.setActivityCode(driver, ActivityCode);
				driver.findElement(By.id("usedInShift_true_0")).click();
				ActivitiesScreen.clickSave(driver);
			}	
			
			driver.switchTo().defaultContent();
			//ActivitiesScreen.clickadherenceTab(driver);
			Thread.sleep(2000);
			//driver.findElement(By.xpath("//div[@name='TLDIV']//span[@id='3_BBM_ORG_ACT_ADHERENCE_spn_id']//a")).click();
			if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Adherence Mapping"))
			{
				extent.log(LogStatus.WARNING, "Not able to select Adherence Mapping menu. Please try again");
				return flag=false;
			}	
		    
			Utilities.selectRightPaneView(driver);
			AdherenceMappingScreen.selectActivity(driver,ActivityName);
			if(AdherenceMappingScreen.VerifyAdherenceMapping(driver,MappingName))
			{
				extent.log(LogStatus.INFO,"Activity mapping :"+ MappingName+" already exist");
			}
			else
			{
			AdherenceMappingScreen.clickEditActivity(driver);
			Utilities.selectRightPaneView(driver);
//			driver.findElement(By.xpath("//table[@id='workpaneMediator_assignmentbox_srcTable']//tbody//tr[@id='workpaneMediator_assignmentbox_srcr3']//td//a//span[contains(text(),'Active')]")).click();
			driver.findElement(By.xpath("//table[@id='workpaneMediator_assignmentbox_srcTable']//tbody//tr[@class='assignmentList']//td//a//span[contains(text(),'Active')]")).click();
			AdherenceMappingScreen.clickArrow(driver);
			AdherenceMappingScreen.clickEditSave(driver);
			
			AdherenceMappingScreen.selectActivity(driver, ActivityName);
			AdherenceMappingScreen.VerifyAdherenceMapping(driver,MappingName);
			}
			
			
			
			
			
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM",HTMLReportName,4,10);
		}
		return flag;
	}

}
