package WFMScripts.SystemTestScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.DataSourceScreen;
import ScreenObjects.LoginScreen;

import ScreenObjects.VerintHomePageScreen;
import Utilities.Utilities;

public class WFM053_54_55_DataSource {
	
	public static ExtentReports extent = ExtentReports.get(WFM053_54_55_DataSource.class);
	
	public static boolean Create_Edit_Delete_DataSource() throws Exception
	{
		boolean flag=true;
		String HTMLReportName="WFM053_54_55_DataSource"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Create Edit Delete DataSource");
				
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("WFM_TestSet");
	  
	    String DataSourceType = Ws.getCell(18,7).getContents();
	    String DataSourceName = Ws.getCell(19,7).getContents();
	    String DSNDescription = Ws.getCell(20,7).getContents();
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"System Management","Data Sources"))
			
			//if (driver.findElements(By.linkText("Settings")).size()==0)
			{
				Utilities.Logout(driver);				
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"System Management","Data Sources"))		
				//if (driver.findElements(By.linkText("Settings")).size()==0)
				{
					extent.log(LogStatus.WARNING, "Not able to select Data Sources. Please try again.");
					return flag=false;
				}
			}			
			//check whether data source exist or not
			Utilities.selectLeftTreeFrame(driver);
			
			int valrcdsn=driver.findElements(By.xpath("//table[@id='dataSourceTree_id']/tbody/tr")).size();
			if (valrcdsn>0)
			{
				driver.findElement(By.xpath("//table[@id='dataSourceTree_id']/tbody/tr[1]/td/a/span/span")).click();
			}
			if (!DataSourceScreen.verifyDataSourceName(driver, DataSourceName))
			{
				Utilities.selectRightPaneView(driver);
				if (!DataSourceScreen.clickCreateDataSource(driver))
				{
					return flag=false;
				}
				if (!DataSourceScreen.selectDataSourceType(driver, DataSourceType)) //select operations from dropdown
				{
					return flag=false;
				}
				if (!DataSourceScreen.clickSelect(driver)) //click on Select button
				{
					return flag=false;
				}
				if (!DataSourceScreen.setDataSourcename(driver, DataSourceName))//dsn name
				{
					return flag=false;
				}
				if (!DataSourceScreen.setDataSourcedescription(driver, DSNDescription))//data source description
				{
					return flag=false;
				}
				if (!DataSourceScreen.clickSave(driver))//click on Save button
				{
					return flag=false;
				}
				if (!DataSourceScreen.selectDataSourceName(driver, DataSourceName))
				{
					return flag=false;
				}
			}
			//edit data source
			if (DataSourceScreen.selectDataSourceName(driver, DataSourceName))
			{
				Utilities.selectRightPaneView(driver);
				if (!DataSourceScreen.setDataSourcename(driver, DataSourceName+"Mod"))//dsn name
				{
					return flag=false;
				}
				if (!DataSourceScreen.clickSave(driver))//click on Save button
				{
					return flag=false;
				}
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to select Updated Data Source Name: "+DataSourceName+"Mod");
			}
			//delete DSN
			if (!DataSourceScreen.selectDataSourceName(driver, DataSourceName+"Mod"))
			{
				return flag=false;
			}
			if (!DataSourceScreen.clickDeleteDataSource(driver))
			{
				return flag=false;
			}
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM",HTMLReportName,4,7);
		}
		return flag;
	}
}
