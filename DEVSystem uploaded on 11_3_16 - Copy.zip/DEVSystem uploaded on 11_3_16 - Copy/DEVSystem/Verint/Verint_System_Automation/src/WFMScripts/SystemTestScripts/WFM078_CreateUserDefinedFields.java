package WFMScripts.SystemTestScripts;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;

import ScreenObjects.ActivitiesScreen;
import ScreenObjects.AttributesScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.ProfilesScreen;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.VerintHomePageScreen;

import ScreenObjects.OrganizationSettings;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM078_CreateUserDefinedFields{
	
	public static ExtentReports extent = ExtentReports.get(WFM078_CreateUserDefinedFields.class);
	
	public static boolean CreateUserDefinedFields() throws Exception
	{		
		boolean flag=true;
		String HTMLReportName="CreateUserDefinedFields"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "CreateUserDefinedFields");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("WFM_TestSet");
	    String name=Ws.getCell(40,15).getContents();
	    String description=Ws.getCell(41,15).getContents();
	   
	    
	    
	    
		
		try
		{		   
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			
			if (!VerintHomePageScreen.selectMenuItem(driver,"System Management","Custom Attributes"))
			{
				extent.log(LogStatus.WARNING, "Not able to select Attributes menu. Please try again");
				return flag=false;
			}	
			
			
			if(AttributesScreen.Attributeexist(driver,name))
			{
				extent.log(LogStatus.PASS,"Attribute:" + name+ "already exist");
			}
			else
			{
				AttributesScreen.clickcreate(driver);
				Thread.sleep(2000);
				AttributesScreen.setName(driver,name);
				AttributesScreen.setDesc(driver,description);
				AttributesScreen.clicksave(driver);
				
			}
			
			if(AttributesScreen.Attributeexist(driver,name))
			{
				AttributesScreen.selectAttribute(driver,name);
				AttributesScreen.clickdelete(driver);
			}
			
			
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM",HTMLReportName,4,15);
		}
		return flag;
	}

}
