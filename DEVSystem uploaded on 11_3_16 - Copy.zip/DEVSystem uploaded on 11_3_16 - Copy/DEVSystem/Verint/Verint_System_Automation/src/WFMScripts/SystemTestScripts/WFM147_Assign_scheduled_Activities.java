package WFMScripts.SystemTestScripts;

import java.io.File;
import java.io.PrintWriter;

import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import ScreenObjects.CalendarScreen;
import ScreenObjects.CampaignSettings;
import ScreenObjects.FSEmployees;
import ScreenObjects.ForecastScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.OrganizationSettings;
import ScreenObjects.ProfilesScreen;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.ServiceGoals;
import ScreenObjects.WorkQueuesScreen;

import ScreenObjects.VerintHomePageScreen;


import Utilities.Utilities;
import org.sikuli.script.Screen;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM147_Assign_scheduled_Activities 
{
	
	public static ExtentReports extent = ExtentReports.get(WFM147_Assign_scheduled_Activities.class);
	
	public static boolean Assign_scheduled_Activities() throws Exception
	{		
		boolean flag=true;
		String windowName="";
		String HTMLReportName="WFM147_Assign_scheduled_Activities "+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Edit_schedule_activity");
				
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 			
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);
	    Sheet Ws = Wb.getSheet("WFM_TestSet");
	    String campName=Ws.getCell(27,12).getContents();
	    String StartDate=Ws.getCell(31,12).getContents();
	    String OrgName=Ws.getCell(5,12).getContents();
	    String Period=Ws.getCell(28,12).getContents();
	    String wqname=Ws.getCell(30,12).getContents();
	    String EmpName = Ws.getCell(17,12).getContents();
	    String workQueue=Ws.getCell(30,12).getContents();
	    String FirstName=Ws.getCell(14,12).getContents();
	    String LastName=Ws.getCell(13,12).getContents();
	    String agentname=Ws.getCell(35,12).getContents();
	    String WqDesc=Ws.getCell(34,12).getContents();	
	    String organizationDesc = Ws.getCell(6,12).getContents();
	    String parentOrganization = Ws.getCell(7,12).getContents();
	    
	    
	    try
	    {
	    	LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
	    	if(!LoginScreen.verifyLoginPageLaunched(driver))
	    	{
	    		return flag=false;
	    	}
	    	LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
	    	LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
	    	LoginScreen.clickLogin(driver);
	    	if(!VerintHomePageScreen.verifyVerintHomePage(driver))
	    	{
	    		return flag=false;
	    	}
	    	String mainwindow=driver.getWindowHandle();
	    	VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings");
	    	Utilities.selectLeftTreeFrame(driver);
	    	if(CampaignSettings.CampaignExist(driver, campName))
	    	{
	    		CampaignSettings.deleteCampaign(driver);
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\btnok_camp.png");
		    	Thread.sleep(3000);
		    	driver.switchTo().defaultContent();
	    	}
	    	else
	    	{
	    		System.out.println("no campaign exist");
	    	}
	    	driver.switchTo().defaultContent();
	    	VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Organization Settings");
	    	Utilities.selectLeftTreeFrame(driver);
			Boolean Temp1=false;			
			int rc1=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
			//System.out.println("rc1:"+rc1);
			for (int j=1;j<=rc1;j++)
			{
				if (j<=15)
				{
				String orgName1=driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).getText();
				Thread.sleep(1000);
				if (orgName1.contains(OrgName))
				{
					driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).click();
					Temp1=true;
					break;
				}}
			}
			if (Temp1==true)
			{
				System.out.println("org already exist");
				extent.log(LogStatus.INFO, "Organization Name: "+OrgName+" already exist");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Organization"));								
			}			
			//end of verify organization
			//create organization
			if (Temp1==false)
			{
				Utilities.selectLeftTreeFrame(driver);
				/*if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,parentOrganization))
				{
					return flag=false;
				}*/
				Utilities.selectRightPaneView(driver);
				if (!OrganizationSettings.clickCreateOrganization(driver))
				{
					return flag=false;
				}
				OrganizationSettings.setOrganizationName(driver,OrgName);
				OrganizationSettings.setOrganizationDescription(driver,organizationDesc);
				OrganizationSettings.isSelectedDaysAndHoursOfOperation(driver);
				if (!OrganizationSettings.clickSave(driver))
				{
					return flag=false;
				}
			}
			driver.switchTo().defaultContent();
	    	if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","user_profiles"))
			{
				extent.log(LogStatus.WARNING, "Not able to select User Profile menu. Please try again");
				return flag=false;
			}	
	    	//verify if organization is already set
	    	if(!ProfilesScreen.FindSelect(driver,EmpName))
			{
				Utilities.selectRightPaneView(driver);
				ProfilesScreen.clickCreate(driver);
				ProfilesScreen.setProfilesLastName(driver, LastName);
				ProfilesScreen.setProfilesFirstName(driver, FirstName);
				Utilities.selectRightPaneView(driver);
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
				if (!ProfilesScreen.clickOrganizationEdit(driver)) // click on organization edit icon
				{
					return flag=false;
				}
				Thread.sleep(6000);			
				String wind=Utilities.setWindowFocus(driver);			
				ProfilesScreen.selectOrganizationFromListbox(driver,OrgName);		
					
				driver.switchTo().window(windowName);
				RolesSetupScreen.selectRightPaneView(driver);
				if (!ProfilesScreen.clickSave(driver))
				{
					return flag=false;
				}
				ProfilesScreen.verifySuccessMessage(driver);
			}
			else
			{
				System.out.println("user already exist");
			}
			
	    	Utilities.selectRightPaneView(driver);
	    	Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
	    	String org=driver.findElement(By.xpath("//input[@id='orgId_RO']")).getAttribute("value");
	    	System.out.println("org name is" + org);
	    	if(org.contains(OrgName))
	    	{
	    		extent.log(LogStatus.INFO,"Organization is already selected");
	    	}
	    	//set organization for agent
	    	else
	    	{
	    		Utilities.selectRightPaneView(driver);
	    		//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
				if (!ProfilesScreen.clickOrganizationEdit(driver)) // click on organization edit icon
				{
					return flag=false;
				}
				Thread.sleep(6000);			
				//String wind=Utilities.setWindowFocus(driver);
				for(String winHandle :driver.getWindowHandles())
				{
	                driver.switchTo().window(winHandle);
	                System.out.println("title:"+driver.getTitle());
	                if(driver.getTitle().contains("Effective Dates"))
	                {                	
	                	System.out.println("You are in organization selector window");
	                	driver.manage().window().maximize();
	                    break;
	                }	
				}
				ProfilesScreen.selectOrganizationFromListbox(driver,OrgName);		
					
				driver.switchTo().window(mainwindow);
				RolesSetupScreen.selectRightPaneView(driver);
				if (!ProfilesScreen.clickSave(driver))
				{
					return flag=false;
				}
	    	}
	    	driver.switchTo().defaultContent();
	    	Thread.sleep(2000);
	    	VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Work Queues Settings");
	    	//verify if work queue already exist
	    	Utilities.selectRightPaneView(driver);
	    	boolean flag1=false;
	    	int qrows=driver.findElements(By.xpath("//div[@id='workAreaWrapper']//table[@id='workpaneListWrapper']//tbody//tr")).size();
	    	System.out.println("no of rows in work queue are:" + qrows);
	    	for(int j=0;j<qrows;j++)
	    	{
	    		String qname=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']//tbody//tr[@id='workpaneListr"+j+"']//th//a//span")).getAttribute("innerText");
	    		System.out.println("work queue name is" + qname);
	    		if(qname.contains(workQueue))
	    		{
	    			flag1=true;
	    			break;
	    		}
	    	}
	    	if(flag1==true)
	    	{
	    		extent.log(LogStatus.PASS,"work queue already exist");
	    	}
	    	//creation of new work queue
	    	else
	    	{
	    		WorkQueuesScreen.clickworkqueue(driver);
				WorkQueuesScreen.setWorkqueueName(driver, wqname);
				WorkQueuesScreen.setWorkqueueDescription(driver,WqDesc);
				WorkQueuesScreen.clickSave(driver);
	    	}
	    	driver.switchTo().defaultContent();
	    	if(!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings"))
	    	{
	    		Utilities.Logout(driver);
	    		LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
	    		LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
	    		LoginScreen.clickLogin(driver);
	    		if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings"))
				{
					extent.log(LogStatus.WARNING, "Not able to select Compaign Settings menu. Please try again");
					return flag=false;
				}
	    	}
	    	//VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings");
				//verify whether Compaign name is already exist or not		
				Utilities.selectLeftTreeFrame(driver);
				/*boolean Temp=false;
				int rc=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
				System.out.println("rc:"+rc);
				for (int i=1;i<=rc;i++)
				{
					if (i<=15)
					{
					String campNameApp=driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr["+i+"]/td/a")).getText();
					System.out.println(i+":"+campNameApp);
					if (campNameApp.contains(campName))
					{
						driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr["+i+"]/td/a")).click();
						//driver.findElement(By.xpath("//img[@id='campaignSPTreer0Norg']")).click();
						Thread.sleep(3000);
						Temp=true;
						break;
					}}
				}*/
				if (CampaignSettings.CampaignExist(driver, campName))
				{					
					extent.log(LogStatus.PASS, "Compaign Name:"+campName+" already exist");
					extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Campaign"));
				}
				//end of verify campaign
				//create campaign
				else
				{
					Utilities.selectRightPaneView(driver);
					
					if (!CampaignSettings.clickCreateCampaign(driver))
					{
						return flag=false;
					}
					CampaignSettings.setCampaignName(driver,campName);
					CampaignSettings.setCampaignDescription(driver,".AutomationDescCampaign");				
					if (!CampaignSettings.clickSave(driver))
					{
						return flag=false;
					}
				}
					/*//validation
					Utilities.selectLeftTreeFrame(driver);
					if (!CampaignSettings.selectCampaignFromLeftTreeFrame(driver,campName))
					{
						return flag=false;
					}
	    	}*/
				
				/*Utilities.selectLeftTreeFrame(driver);
				boolean Temp1=false;
				int rc1=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
				System.out.println("rc1:"+rc1);
				for (int i=1;i<=rc1;i++)
				{
					if (i<=15)
					{
					String campNameApp=driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr["+i+"]/td/a")).getText();
					System.out.println(i+":"+campNameApp);
					if (campNameApp.contains(campName))
					{
						driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr["+i+"]/td/a")).click();
						Thread.sleep(3000);
						Temp1=true;
						break;
					}}
				}
				if (Temp1==true)
				{					
					extent.log(LogStatus.PASS, " clciked on the Compaign Name:"+campName);
					//extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Campaign"));
				}
				if(Temp1==false)
				{
					extent.log(LogStatus.FAIL,"campaign name: "+campName+" does not exist");
				}
				*/
				Utilities.selectRightPaneView(driver);
				
				
				CampaignSettings.clickSave(driver);
				System.out.println("clicked on save");
				Thread.sleep(2000);
				Utilities.selectLeftTreeFrame(driver);
				Thread.sleep(2000);
				if(driver.findElements(By.xpath("//img[@id='campaignSPTreer0Norg']")).size()!=0)
				{
					driver.findElement(By.xpath("//img[@id='campaignSPTreer0Norg']")).click();
				}
				
				//verify if schedule period exist
				/*boolean Temp3=false;
				int rc2=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table//tr[starts-with(@id,'campaignSPTreer0r')]")).size();
				System.out.println("rc2:"+rc2);
				if (rc2>0)
				{
					driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr[1]/td/a")).click();
				}
				for (int i=0;i<rc2;i++)
				{
					
					
					
					String queuename=driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr[@id='campaignSPTreer0r"+i+"']/td/a")).getText();
					System.out.println(i+":"+queuename);
					if (queuename.contains(Period))
					{
						System.out.println("schedule period exist");
						driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr[@id='campaignSPTreer0r"+i+"']/td/a")).click();
						Temp3=true;
						break;
						
					}
				}*/
				if(CampaignSettings.schedulePeriodExist(driver, Period))
				{
					extent.log(LogStatus.INFO,"schedule period:" + Period + "already exist");
				}
				//create a new scheduling period
				else
				{
					
					CampaignSettings.clickSchedulingPeriod(driver);
					Utilities.selectRightPaneView(driver);
					CampaignSettings.setSchedulingPeriodStartDate(driver, StartDate);
					
					if(!CampaignSettings.clickSchedulingPeriodPSave(driver))
					{
						return flag=false;
					}
					CampaignSettings.setCampaignDescription(driver,".AutomationDescCampaign");
					CampaignSettings.clickOrganizationSelector(driver);
					for(String winHandle :driver.getWindowHandles())
					{
		                driver.switchTo().window(winHandle);
		                System.out.println("title:"+driver.getTitle());
		                if(driver.getTitle().contains("Organization Selector"))
		                {                	
		                	System.out.println("You are in organization selector window");
		                	driver.manage().window().maximize();
		                    break;
		                }	
					}
					//windowName=Utilities.setWindowFocus(driver);
					CampaignSettings.selectOrganizationSelector(driver, OrgName);
					driver.switchTo().window(mainwindow);
					CampaignSettings.selectHoursOfOperation(driver);
					CampaignSettings.clickCampaignSettingsSave(driver);
				}
				
				Thread.sleep(2000);
				if(!CampaignSettings.clickCampaignSettingsSave(driver))
				{
					return flag=false;
				}
				Thread.sleep(2000);
				driver.switchTo().defaultContent();
				//verify if queue is laready linked to campaign
				CampaignSettings.clickQueue(driver);
				Thread.sleep(3000);
				
				/*boolean temp2=false;
		    	Utilities.selectRightPaneView(driver);
		    	
		    	int row=driver.findElements(By.xpath("//div[@id='tableWrapper']//table[@id='tableRef']//tbody//tr//th")).size();
		    	System.out.println("no of row count  in work pattern iis: "+ row);
		    	if(row>0)
		    	{
		    	String workqname=driver.findElement(By.xpath("//table[@id='tableRef']//tbody//tr[@id='tabler0']//th[@id='tabler0c0']//a")).getAttribute("innerText");
		    	System.out.println("work pattern name is: "+ workqname);
		    	if(workqname.contains(wqname))
		    	{
		    		temp2 = true;
		    	}*/
		    	/*if(CampaignSettings.workqueueExist(driver, wqname))
		    	{
		    		extent.log(LogStatus.INFO,"work Queue:" +wqname+ " is already added to the campaign queues");
		    	}*/
		    	
		    	//link created queue to campaign
		    	
				CampaignSettings.clickAddSP(driver);
				Thread.sleep(2000);
				for(String winHandle :driver.getWindowHandles())
				{
	                driver.switchTo().window(winHandle);
	                System.out.println("title:"+driver.getTitle());
	                if(driver.getTitle().contains("Add to SP"))
	                {                	
	                	System.out.println("You are in Add to SP window");
	                	driver.manage().window().maximize();
	                    break;
	                }	
				}
//				String winhandle=Utilities.setWindowFocus(driver);
				//String winhandle=Utilities.getWinID(driver);
				CampaignSettings.selectWorkQueue(driver, workQueue);
				driver.switchTo().window(mainwindow);
		    	
				if(!CampaignSettings.clickCampaignSettingsSave(driver))
				{
					return flag=false;
				}
				driver.switchTo().defaultContent();
				Thread.sleep(3000);
				//go to forecast menu and set the values
				
				VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Forecast");
		    	Thread.sleep(3000);
		    	ForecastScreen.selectCampaign(driver, campName);
		    	//ForecastScreen.selectCampaign(driver,campName);
		    	//ForecastScreen.selectPeriod(driver, Period);
		    	ForecastScreen.setPeriod(driver, Period);
		    	Thread.sleep(2000);
		    	ForecastScreen.selectworkQueue(driver, workQueue);
		    	Thread.sleep(3000);
		    	driver.switchTo().defaultContent();
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\btn_clear.png");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Button_Scale.png");
		    	
		    	Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\value_total.png","15");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\value_sun.png");
		       
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\button_set.png");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Save_scale.png");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Save_popup.png");
		    	
		    	//Utilities.selectLeftTreeFrame(driver);
		    	Thread.sleep(5000);
		    	ForecastScreen.selectworkQueue(driver, workQueue);
		    	Thread.sleep(3000);
		    	driver.switchTo().defaultContent();
		    	Thread.sleep(2000);
		    	VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","ServiceGoals");
		    	
//		    	
		    	//ServiceGoals.selectCampaign(driver,campName);
		    	
		    	ServiceGoals.setPeriod(driver, Period);
		    	ServiceGoals.selectworkQueue(driver, workQueue);
		    	Thread.sleep(2000);
		    	driver.switchTo().defaultContent();
		    	Thread.sleep(3000);
		    	Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\ans.png","0");
		    	Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\seconds.png","0");
		    	Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\ans.png","60");
		    	//Thread.sleep(1000);
		    	
		    	Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\seconds.png","40");
		    	//Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\seconds.png","10");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Save_scale.png");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Save_popup.png");
		    	Thread.sleep(2000);
		    	ServiceGoals.selectworkQueue(driver, workQueue);
		    	Thread.sleep(2000);
		    	driver.switchTo().defaultContent();
		    	Thread.sleep(2000);
		    	VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","FS_Profiles");
		    	
		    
		    	Thread.sleep(5000);
		    	//step 7
		    	// go to campaign profiles menu
				/*if (!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","FS_Profiles"))
				{
					Utilities.Logout(driver);
					LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
					LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
					LoginScreen.clickLogin(driver);
					if (!VerintHomePageScreen.verifyVerintHomePage(driver))
					{
						return flag=false;
					}
					if (!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","FS_Profiles"))
					{
						extent.log(LogStatus.WARNING, "Not able to Profiles Settings menu. Please try again");
						return flag=false;
					}			
				}*/
				if (! FSEmployees.selectCampaign(driver,campName))
				{ 
					return flag=false;
				}
				if (! FSEmployees.selectPeriod(driver,Period))
				{
					return flag=false;
				}
				if(FSEmployees.Empexist(driver,agentname))
				{
					extent.log(LogStatus.INFO,"employee Name:" +agentname+"is allready added");
				}
				//addition of agent1 to campaign
				else
				{
					FSEmployees.clickAddEmployeeToSP(driver);
					for(String winHandle :driver.getWindowHandles()){
		                driver.switchTo().window(winHandle);
		                System.out.println("title:"+driver.getTitle());
		                if(driver.getTitle().contains("Add to Scheduling Period"))
		                {                	
		                	System.out.println("You are in Add Scheduling period window");
		                	driver.manage().window().maximize();
		                    break;
		                }			
					}
//					String win=Utilities.setWindowFocus(driver);
					FSEmployees.addEmployeeToSP(driver,agentname);
					FSEmployees.clickAdd(driver);
					driver.switchTo().window(mainwindow);
					FSEmployees.SelectEmployee(driver,agentname);
					FSEmployees.ClickSave(driver);
				}
				/*//verify if agent is already added to the campaign
				int rows1=driver.findElements(By.xpath("//div[@id='psWrapper']//table[@id='psLIST_TBL_NAME']//tbody//tr")).size();
				System.out.println("row size is"+ rows1);
				if(rows1>0)
				{
					System.out.println("in if condition");
					Utilities.selectLeftTreeFrame(driver);
//					String ename=driver.findElement(By.xpath("//div[@id='psWrapper']//table[@id='psLIST_TBL_NAME']//tbody//tr//td[2]//div//nobr//a")).getAttribute("innerText");
					String ename=driver.findElement(By.xpath("//div[@id='psWrapper']//table[@id='psLIST_TBL_NAME']//tbody//tr//td//div//nobr//a")).getAttribute("innerText");
					System.out.println("emp name is" + ename);
					if(ename.contains(EmpName))
					{
						extent.log(LogStatus.INFO,"Employee:" +EmpName+ "is already added to the schedule period");
					}
				}
				//add agent to the campaign
				else
				{
					Thread.sleep(2000);
					FSEmployees.clickAddEmployeeToSP(driver);
					for(String winHandle :driver.getWindowHandles()){
		                driver.switchTo().window(winHandle);
		                System.out.println("title:"+driver.getTitle());
		                if(driver.getTitle().contains("Add to Scheduling Period"))
		                {                	
		                	System.out.println("You are in Add Scheduling period window");
		                	driver.manage().window().maximize();
		                    break;
		                }			
					}
					if (! FSEmployees.addEmployeeToSP(driver,EmpName))
					{
						return flag=false;
					}
					if (! FSEmployees.clickAdd(driver))
					{
						return flag=false;
					}
					for(String winHandle : driver.getWindowHandles()){
					    driver.switchTo().window(winHandle);
					}
				}
				
				Thread.sleep(3000);*/
				FSEmployees.SelectEmployee(driver,agentname);
				driver.switchTo().defaultContent();
				Thread.sleep(2000);
				//go to calendar menu and schedule the shifts and publish it
				if (!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Calendar"))
				{			
					Utilities.Logout(driver);
					LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
					LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
					LoginScreen.clickLogin(driver);
					if (!VerintHomePageScreen.verifyVerintHomePage(driver))
					{
						extent.log(LogStatus.FAIL, "Verint Homepage is not displayed");
						return flag=false;
					}
					if (!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Calendar"))
					{
						extent.log(LogStatus.WARNING, "Not able to select Calendar menu. Please try again.");
						return flag=false;
					}
							
				}
				
		    	
		    	CalendarScreen.selectCampaign(driver, campName);
		    	CalendarScreen.selectPeriod(driver, Period);
		    	Thread.sleep(2000);
		    	CalendarScreen.SelectEmployee(driver,agentname);
		    	Thread.sleep(3000);
		    	driver.switchTo().defaultContent();
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\button_runengine.png");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\button_chkbox1.png");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\button_chkbox2.png");
//		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\okbtn.png");
		    	VerintHomePageScreen.clickCalOK();
		    	Thread.sleep(40000);
		    	extent.log(LogStatus.INFO,"shift is scheduled sucessfully");
		    	Thread.sleep(3000);
		    	//extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "shiftSchedule"));
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\buuton_publishschedule.png");
		    	
		    	VerintHomePageScreen.clickyes();
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\btnok_schedule.png");
		    	VerintHomePageScreen.clickyes();
		    	extent.log(LogStatus.INFO,"shift is published sucessfully");
		    	Thread.sleep(3000);
		    	//extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "shiftpublished"));
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\OK.png");
		    	Thread.sleep(3000);
		    	Utilities.sikuliRightClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\agent2_shift.png");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Edit_shift.png");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\activity_change.png");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\immediate_activity.png");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\shift_ok.png");
		    	Thread.sleep(2000);
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\buuton_publishschedule.png");
		    	
		    	VerintHomePageScreen.clickyes();
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\btnok_schedule.png");
		    	VerintHomePageScreen.clickyes();
		    	extent.log(LogStatus.INFO,"shift is published sucessfully");
		    	Thread.sleep(3000);
		    	
		    	
				}   	
				
		
	    catch(Exception e){
			e.printStackTrace();
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			  
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM",HTMLReportName,4,12);
		}
		return flag;
	
	}

}

