package WFMScripts;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import ScreenObjects.LoginScreen;
import ScreenObjects.ProfilesScreen;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.VerintHomePageScreen;

import ScreenObjects.OrganizationSettings;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM031_AddMultipleSkills {
	
	public static ExtentReports extent = ExtentReports.get(WFM031_AddMultipleSkills.class);
	
	public static boolean Add_Skills() throws Exception
	{		
		boolean flag=true;
		String HTMLReportName="Add Skills"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Add Skills");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("WFM_RegressionTestSet");
	    String organizationName = Ws.getCell(5,3).getContents();
	    String parentOrganization=Ws.getCell(7,3).getContents();
	    String organizationDesc=Ws.getCell(6,3).getContents();
	    String EmpName=Ws.getCell(16,3).getContents();
	    String FirstName=Ws.getCell(13,3).getContents();
	    String LastName=Ws.getCell(12,3).getContents();
	    
		
		try
		{		   
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			String mainwindow=driver.getWindowHandle();
			VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Organization Settings");
	    	Utilities.selectLeftTreeFrame(driver);
			Boolean Temp1=false;			
			int rc1=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
			//System.out.println("rc1:"+rc1);
			for (int j=1;j<=rc1;j++)
			{
				if (j<=15)
				{
				String orgName1=driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).getText();
				Thread.sleep(1000);
				if (orgName1.contains(organizationName))
				{
					driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).click();
					Temp1=true;
					break;
				}}
			}
			if (Temp1==true)
			{
				System.out.println("org already exist");
				extent.log(LogStatus.INFO, "Organization Name: "+organizationName+" already exist");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Organization"));								
			}			
			//end of verify organization
			//create organization
			if (Temp1==false)
			{
				Utilities.selectLeftTreeFrame(driver);
				if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,parentOrganization))
				{
					return flag=false;
				}
				Utilities.selectRightPaneView(driver);
				if (!OrganizationSettings.clickCreateOrganization(driver))
				{
					return flag=false;
				}
				OrganizationSettings.setOrganizationName(driver,organizationName);
				OrganizationSettings.setOrganizationDescription(driver,organizationDesc);
				OrganizationSettings.isSelectedDaysAndHoursOfOperation(driver);
				if (!OrganizationSettings.clickSave(driver))
				{
					return flag=false;
				}
			}
			driver.switchTo().defaultContent();
			if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","user_profiles"))
			{
				extent.log(LogStatus.WARNING, "Not able to select User Profile menu. Please try again");
				return flag=false;
			}	
//	    	VerintHomePageScreen.selectMenuItem(driver,"User Management","user_profiles");
			if(!ProfilesScreen.FindSelect(driver,EmpName))
			{
				Utilities.selectRightPaneView(driver);
				ProfilesScreen.clickCreate(driver);
				ProfilesScreen.setProfilesLastName(driver, LastName);
				ProfilesScreen.setProfilesFirstName(driver, FirstName);
				Utilities.selectRightPaneView(driver);
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
				if (!ProfilesScreen.clickOrganizationEdit(driver)) // click on organization edit icon
				{
					return flag=false;
				}
				Thread.sleep(6000);			
				String windowName1=Utilities.setWindowFocus(driver);			
				ProfilesScreen.selectOrganizationFromListbox(driver,organizationName);		
					
				driver.switchTo().window(windowName1);
				RolesSetupScreen.selectRightPaneView(driver);
				if (!ProfilesScreen.clickSave(driver))
				{
					return flag=false;
				}
				ProfilesScreen.verifySuccessMessage(driver);
			}
			else
			{
				System.out.println("user already exist");
			}
			Utilities.selectRightPaneView(driver);
	    	Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
	    	String org=driver.findElement(By.xpath("//input[@id='orgId_RO']")).getAttribute("value");
	    	System.out.println("org name is" + org);
	    	if(org.contains(organizationName))
	    	{
	    		extent.log(LogStatus.INFO,"Organization is already selected");
	    	}
	    	//set organization for agent
	    	else
	    	{
	    		Utilities.selectRightPaneView(driver);
	    		//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
				if (!ProfilesScreen.clickOrganizationEdit(driver)) // click on organization edit icon
				{
					return flag=false;
				}
				Thread.sleep(6000);			
				String wind=Utilities.setWindowFocus(driver);			
				ProfilesScreen.selectOrganizationFromListbox(driver,organizationName);		
					
				driver.switchTo().window(wind);
				RolesSetupScreen.selectRightPaneView(driver);
				if (!ProfilesScreen.clickSave(driver))
				{
					return flag=false;
				}
	    	}
	    	driver.switchTo().defaultContent();
	    	ProfilesScreen.clickskillsTab(driver);
	    	boolean flag3=false;
	    	Utilities.selectRightPaneView(driver);
	    	List<WebElement> li4=driver.findElements(By.xpath("//table[@id='skillTableRef']//tr[@class='tblRow']"));
			System.out.println("Li4:"+li4.size());
			if(driver.findElements(By.xpath("//table[@id='skillTableRef']//tr[@class='tblRow']//th[@class='tblItem']//a")).size()!=0)
			{
			for(WebElement elt:li4)
			{
				//System.out.println("**************");
				System.out.println("************skill1:"+elt.findElement(By.tagName("th")).getAttribute("innerText"));
				String wname=elt.findElement(By.tagName("th")).getAttribute("innerText");
				System.out.println("skill name is:" + wname);
				/*if(wname.equals(skill))
				{
					
					flag3=true;
					//break;
				}*/
				extent.log(LogStatus.PASS,"Skill name:"+ wname +"already exist for agent");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "skillsPage"));
				
			}
			
			}
			else
			{
				ProfilesScreen.clickAddskillbtn(driver);
				Thread.sleep(2000);
				for(String winHandle :driver.getWindowHandles())
				{
	                driver.switchTo().window(winHandle);
	                Thread.sleep(1000);
	                System.out.println("title:"+driver.getTitle());
	                if(driver.getTitle().equals("Skills"))
	                {   
	                	driver.manage().window().maximize();
	                	System.out.println("You are in Skills window");
	                    break;
	                }	
				}
				List<WebElement> tabledata=driver.findElements(By.xpath("//div[@id='availableSkillsTableWrapper']//table[@id='availableSkillsTableRef']//tr[contains(@id,'availableSkillsTabler')]//th[contains(@id,'availableSkillsTabler')]"));
				/*for(WebElement elt:tabledata)
				{
					System.out.println("element name is:" + elt.getText());
					
					
				}*/
				System.out.println("table data size is:"+tabledata.size());
				tabledata.get(0).click();
				Robot r=new Robot();
				r.keyPress(KeyEvent.VK_CONTROL);
				tabledata.get(1).click();
				r.keyRelease(KeyEvent.VK_CONTROL);
				/*Actions builder=new Actions(driver);
				builder.click(tabledata.get(0)).keyDown(Keys.CONTROL).click(tabledata.get(1)).click(tabledata.get(2)).keyUp(Keys.CONTROL).build().perform();*/
				driver.findElement(By.xpath("//button[@id='workpaneMediator_toolbar_addSkillsLabel']")).click();
				Thread.sleep(2000);
				driver.switchTo().window(mainwindow);
				
				ProfilesScreen.clickSave(driver);
				List<WebElement> li5=driver.findElements(By.xpath("//table[@id='skillTableRef']//tr[@class='tblRow']"));
				System.out.println("Li5:"+li5.size());
				if(driver.findElements(By.xpath("//table[@id='skillTableRef']//tr[@class='tblRow']//th[@class='tblItem']//a")).size()!=0)
				{
				for(WebElement elt:li5)
				{
					//System.out.println("**************");
					System.out.println("************skill1:"+elt.findElement(By.tagName("th")).getAttribute("innerText"));
					String wname=elt.findElement(By.tagName("th")).getAttribute("innerText");
					System.out.println("skill name is:" + wname);
					/*if(wname.equals(skill))
					{
						
						flag3=true;
						//break;
					}*/
					extent.log(LogStatus.PASS,"Skill name:"+ wname +"is added for an agent");
					extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "skillsPage"));
					
				}
				
				
				}
				
			}
			
			
			
	    	
	    	Thread.sleep(2000);
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM_REG",HTMLReportName,4,3);
		}
		return flag;
	}

}
