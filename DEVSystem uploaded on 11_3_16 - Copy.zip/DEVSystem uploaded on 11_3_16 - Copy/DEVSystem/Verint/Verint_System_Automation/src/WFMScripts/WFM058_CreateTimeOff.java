package WFMScripts;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

//import jxl.Sheet;
import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.ie.InternetExplorerDriver;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;

import ScreenObjects.AccessRightsScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.MyRequestsScreen;
import ScreenObjects.ProfilesScreen;
import ScreenObjects.OrgRequestManagement;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.OrganizationSettings;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM058_CreateTimeOff {
	
	public static ExtentReports extent = ExtentReports.get(WFM058_CreateTimeOff.class);
	
	public static boolean Create_TimeOff_Request() throws Exception
	{		
		boolean flag=true;
		String HTMLReportName="WFM058_CreateTimeOff"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Create TimeOff Request");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("WFM_RegressionTestSet");
	    //Sheet testID=Wb.getSheet("TestIds");
	    String organizationName = Ws.getCell(5,24).getContents();
	    String EmpName = Ws.getCell(16,24).getContents();
	    String FirstName=Ws.getCell(13,24).getContents();
	    String LastName=Ws.getCell(12,24).getContents();
	    //String organizationDesc = Ws.getCell(6,1).getContents();
	    //String parentOrganization = Ws.getCell(7,1).getContents();
		
		try
		{	
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}	
			
			/*if (!VerintHomePageScreen.selectMenuItem(driver,"Request Management","TimeOff_Employee Requests"))
			{			
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					extent.log(LogStatus.FAIL, "Verint Homepage is not displayed");
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Request Management","TimeOff_Employee Requests"))
				{
					extent.log(LogStatus.WARNING, "Not able to select Employee Requests menu. Please try again.");
					return flag=false;
				}						
			}		*/
			
			//delete if any time off
			//VerintHomePageScreen.selectMenuItem(driver,"Request Management","Employee Requests");
			VerintHomePageScreen.selectMenuItem(driver,"Request Management","TimeOff_Employee_Requests");
			Thread.sleep(6000);
			/*if (driver.findElements(By.linkText("Employee Requests")).size()==0)
			{
				Utilities.Logout(driver); //logout
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				VerintHomePageScreen.selectMenuItem(driver,"Request Management","TimeOff_Employee Requests");
				if (driver.findElements(By.linkText("Employee Requests")).size()==0)
				{
					
					extent.log(LogStatus.WARNING, "My Requests section is not displayed. Please try again");
					return flag=false;
				}				
			}			*/
			//
			System.out.println("in table");
			int rc=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']//tbody//tr")).size();
			System.out.println("timeoffdelete:"+rc);
			for (int i=1;i<=rc;i++)
			{
				System.out.println("name:"+driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+i+"]/th")).getText());
				if (driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+i+"]/th")).getText().contains("Automation WFM"))
				{
					if (driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+i+"]/td[10]/nobr/span[7]/span/span/a/img[@alt='Withdraw']")).size()!=0)
					{
						driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+i+"]/td[10]/nobr/span[7]/span/span/a/img[@alt='Withdraw']")).click();
						Set<String> withdrawwindowIds = driver.getWindowHandles();
						Iterator<String> itererator = withdrawwindowIds.iterator(); 			
						String mainWin = itererator.next();//main window 
						String  withdrawWin = itererator.next();//popup window						
						driver.switchTo().window(withdrawWin);
						
						if (driver.findElements(By.xpath("//table[@id='workpaneMediator_toolbar_WITHDRAW_ACTIONWrapper']/tbody/tr[1]/td[1]/button[@id='workpaneMediator_toolbar_WITHDRAW_ACTIONLabel']")).size()!=0)
						{
						driver.findElement(By.xpath("//table[@id='workpaneMediator_toolbar_WITHDRAW_ACTIONWrapper']/tbody/tr[1]/td[1]/button[@id='workpaneMediator_toolbar_WITHDRAW_ACTIONLabel']")).click();
						}						
						driver.switchTo().window(mainWin);
						System.out.println("timeoffdeleted");
					}
				}			
			}	
			
			//end of delete time off
			driver.switchTo().defaultContent();
			
			VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Auto Processing");
			Thread.sleep(5000);
			if (driver.findElements(By.linkText("Auto Processing")).size()==0)
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Auto Processing");
				if (driver.findElements(By.linkText("Auto Processing")).size()==0)
				{
					extent.log(LogStatus.WARNING, "Time Off Pools section is not displayed. Please try again");
					return flag=false;
				}			
			}
			
			Utilities.selectLeftTreeFrame(driver);
			//if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,".AutomationSubOrg"))
			if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,"StateFarm"))
			{
				return flag=false;
			}
			//auto processing is ON
			if (!OrgRequestManagement.verifyAutoProcessingRequestON(driver,"Time Off ( Vacation )"))
			{
				OrgRequestManagement.clickCreateNewRule(driver);
				OrgRequestManagement.clickCreateNewAutoProcessingRuleTimeOff(driver);
				OrgRequestManagement.selectAutoProcessing_TimeOffType(driver, "Vacation");
				OrgRequestManagement.selectAutoProcessCriteria_Approval(driver);
				OrgRequestManagement.clickSave(driver);
			}
			
			//end of auto procession
			//go to time off pools
			driver.switchTo().defaultContent();
			if (driver.findElements(By.linkText("Time Off Pools")).size()!=0)
			{
				driver.findElement(By.linkText("Time Off Pools")).click();
			}
			else
			{
				extent.log(LogStatus.WARNING, "Time Off Pools section is not displayed. Please try again");
				return flag=false;
			}
			//check whether Time Off Pool is exist, if exist then delete
			if (OrgRequestManagement.verifyTimeOffPoolName(driver, ".Automation_TimeOffPool"))
			{
				if (!OrgRequestManagement.clickDeleteTimeOffPool(driver))
				{
					return flag=false;
				}
			}
			
			if (!OrgRequestManagement.clickCreateTimeOffPoolName(driver)) //create button
			{
				return flag=false;
			}
			OrgRequestManagement.setTextInTimeOffPoolName(driver,".Automation_TimeOffPool");
			if (!OrgRequestManagement.selectMonth(driver,"November"))
			{
				return flag=false;
			}
			if (!OrgRequestManagement.selectYear(driver,"2017"))
			{
				return flag=false;
			}
			if (!OrgRequestManagement.setAllocatedTimeOffHours(driver,"40"))
			{
				return flag=false;
			}
			if (!OrgRequestManagement.clickSave(driver)) //create button
			{
				return flag=false;
			}
			//profiles
			driver.switchTo().defaultContent();
			VerintHomePageScreen.selectMenuItem(driver,"User Management","user_profiles");
			if (driver.findElements(By.linkText("Profiles")).size()==0)
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				VerintHomePageScreen.selectMenuItem(driver,"User Management","user_profiles");
				if (driver.findElements(By.linkText("Profiles")).size()==0)
				{
					extent.log(LogStatus.WARNING, "Time Off section is not displayed. Please try again");
					return flag=false;
				}			
			}
			if(!ProfilesScreen.FindSelect(driver,EmpName))
			{
				Utilities.selectRightPaneView(driver);
				ProfilesScreen.clickCreate(driver);
				ProfilesScreen.setProfilesLastName(driver, LastName);
				ProfilesScreen.setProfilesFirstName(driver, FirstName);
				Utilities.selectRightPaneView(driver);
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
				if (!ProfilesScreen.clickOrganizationEdit(driver)) // click on organization edit icon
				{
					return flag=false;
				}
				Thread.sleep(6000);			
				String windowName1=Utilities.setWindowFocus(driver);			
				ProfilesScreen.selectOrganizationFromListbox(driver,organizationName);		
					
				driver.switchTo().window(windowName1);
				RolesSetupScreen.selectRightPaneView(driver);
				if (!ProfilesScreen.clickSave(driver))
				{
					return flag=false;
				}
				ProfilesScreen.verifySuccessMessage(driver);
			}
			else
			{
				System.out.println("user already exist");
			}
			//select emp
			//verify User exist or not
			/*if (!ProfilesScreen.FindSelect(driver, "OH0708"))
			{			
				Utilities.selectRightPaneView(driver);				
				if (!ProfilesScreen.clickImportDomainUsers(driver))
				{
					return flag=false;
				}
				Thread.sleep(2000);
				Utilities.sikuliType(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_EnterObjNameToSelect.png", "d9ix");
				Thread.sleep(1000);
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_OK_Btn.png");				
				Thread.sleep(5000);
				Utilities.selectRightPaneView(driver);
				System.out.println("err:"+driver.findElement(By.xpath("//div[@id='workPaneWrapper']/table[@id='viewfindPane_tbl_id']/tbody/tr/td[2]/table[@id='pageMessages_bttn_tbl_id']/tbody/tr/td[1]/div")).getText());
				if (!ProfilesScreen.checkErrorMessage(driver))
				{				
						return flag=false;
				}
				Thread.sleep(2000);				
				if (!ProfilesScreen.FindSelect(driver, "OH0708"))
				{
					return flag=false;
				}				
			}*/
			driver.switchTo().defaultContent();				
			//access rights -select WFM contact center agent - ctrl F
			if (driver.findElements(By.linkText("Access Rights")).size()!=0)
			{
				driver.findElement(By.linkText("Access Rights")).click();
				extent.log(LogStatus.INFO, "Access Rights tab is selected");
			}		
			else
			{
				extent.log(LogStatus.FAIL, "Not able to select Access Rights tab");
				return flag=false;
			}
			if (!AccessRightsScreen.selectEmp_From_AccessRightsFrame(driver,FirstName))
			{
				return flag=false;
			}
			Utilities.selectRightPaneView(driver);
			if (!AccessRightsScreen.clickEditAccessRights(driver))
			{
				return flag=false;
			}
			
			Robot r = new Robot();
			r.keyPress(KeyEvent.VK_CONTROL);
			r.keyPress(KeyEvent.VK_F);
			r.keyRelease(KeyEvent.VK_CONTROL);
			r.keyRelease(KeyEvent.VK_F);
			Utilities.sikuliType(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\FindText.png", "WFM Contact Center Agent");
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\FindText_Close.png");
			Utilities.selectRightPaneView(driver);
			
			int rcRole=driver.findElements(By.xpath("//table[@id='roleTableRef']/tbody/tr")).size();
			System.out.println("rolerc:"+rcRole);
			for (int p=1;p<=rcRole;p++)
			{
				System.out.println("p value:+p");
				if (p<31 & p<=rcRole)
				{
					String rName=driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[1]/tr["+p+"]/td[1]/a/span")).getText().trim();
					System.out.println("prevNameApp:"+rName);
					System.out.println("privVal:WFM Contact Center Agent");
					//Thread.sleep(1000);
					if (rName.contains("WFM Contact Center Agent"))
					{
						if (!driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[1]/tr["+p+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).isSelected())
						{
							driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[1]/tr["+p+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).click();
							extent.log(LogStatus.INFO, "Role Name:"+rName+" checkbox is selected");
							System.out.println("checked");				
							flag=true;
							break;
						}
						
					}
				}
				if (p>30 & p<61 & p<=rcRole)
				{   
					int q;
					q=p-30;
					String rName=driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[2]/tr["+q+"]/td[1]/a/span")).getText().trim();
					System.out.println("prevNameApp:"+rName);
					System.out.println("privVal:WFM Contact Center Agent");
					//Thread.sleep(1000);
					if (rName.contains("WFM Contact Center Agent"))
					{
						if (!driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[2]/tr["+q+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).isSelected())
						{
							driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[2]/tr["+q+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).click();
							extent.log(LogStatus.INFO, "Role Name:"+rName+" checkbox is selected");
							System.out.println("checked");				
							flag=true;
							break;
						}
						
					}
				}
				if (p>60 & p<91 & p<=rcRole)
				{
					int s;
					s=p-60;
					String rName=driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[3]/tr["+s+"]/td[1]/a/span")).getText().trim();
					System.out.println("prevNameApp:"+rName);
					System.out.println("privVal:WFM Contact Center Agent");
					//Thread.sleep(1000);
					if (rName.contains("WFM Contact Center Agent"))
					{
						if (!driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[3]/tr["+s+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).isSelected())
						{
							driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[3]/tr["+s+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).click();
							extent.log(LogStatus.INFO, "Role Name:"+rName+" checkbox is selected");
							System.out.println("checked");				
							flag=true;
							break;
						}
						
					}
				}
				if (p>90 & p<=rcRole)
				{
					int t;
					t=p-90;
					String rName=driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[4]/tr["+t+"]/td[1]/a/span")).getText().trim();
					System.out.println("prevNameApp:"+rName);
					System.out.println("privVal:WFM Contact Center Agent");
					//Thread.sleep(1000);
					if (rName.contains("WFM Contact Center Agent"))
					{
						if (!driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[4]/tr["+t+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).isSelected())
						{
							driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[4]/tr["+t+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).click();
							extent.log(LogStatus.INFO, "Role Name:"+rName+" checkbox is selected");
							System.out.println("checked");				
							flag=true;
							break;
						}
						
					}
				}
				
				
			}
			if (flag==true)
			{
				extent.log(LogStatus.INFO, "Role Name:WFM Contact Center Agent checkbox is selected");
			}
			else
			{
				extent.log(LogStatus.FAIL, "Role Name:WFM Contact Center Agent checkbox is NOT selected");
				return flag=false;
			}
			if (!AccessRightsScreen.select_OrganizationScope_checkbox(driver,"StateFarm"))
			{
				return flag=false;
			}
			if (!AccessRightsScreen.clickSave(driver))
			{
				return flag=false;
			}
			
			//end of access rights
			driver.switchTo().defaultContent();
			if (driver.findElements(By.linkText("Time Off")).size()!=0)
			{
				driver.findElement(By.linkText("Time Off")).click();
				extent.log(LogStatus.INFO, "Time Off tab is selected");
			}		
			else
			{
				extent.log(LogStatus.FAIL, "Not able to select Time Off tab");
				return flag=false;
			}
			if (!OrgRequestManagement.clickEditIcon(driver)) 
			{
				return flag=false;
			}
			
			Thread.sleep(3000);			
			String windowName=Utilities.setWindowFocus(driver);
			
			if (!OrgRequestManagement.selectTimeOffPool(driver,".Automation_TimeOffPool")) 
			{
				return flag=false;
			}
			if (!OrgRequestManagement.clickSet(driver))
			{
				return flag=false;
			}	
			driver.switchTo().window(windowName);
			Utilities.selectRightPaneView(driver);
			OrgRequestManagement.setTextInVacationDefPerDay(driver,"8");
			OrgRequestManagement.setTextInVacationDefPerWeek(driver,"40");
			OrgRequestManagement.setTextInVacationBalance(driver,"100");
			OrgRequestManagement.setTextInVacationDateLastUpdated(driver,"11/14/2017");
			if (!OrgRequestManagement.clickTimeOffSave(driver))
			{
				return flag=false;
			}
			Utilities.Logout(driver); //logout 
	
		
			//login with Agent
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("Agen1tUserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Agent1Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			Thread.sleep(3000);
			if (!VerintHomePageScreen.selectMenuItem(driver,"My Home","My Requests_Agent"))
			{			
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("Agen1tUserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Agent1Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					extent.log(LogStatus.FAIL, "Verint Homepage is not displayed");
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"My Home","My Requests_Agent"))
				{
					extent.log(LogStatus.WARNING, "Not able to select My Requests menu. Please try again.");
					return flag=false;
				}						
			}
			
			
		
			
			if (driver.findElements(By.linkText("My Requests")).size()==0)
			{
				Utilities.Logout(driver); //logout
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("Agen1tUserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Agent1Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (driver.findElements(By.linkText("My Requests")).size()==0)
				{
					
					extent.log(LogStatus.WARNING, "My Requests section is not displayed. Please try again");
					return flag=false;
				}				
			}
			if (!MyRequestsScreen.clickCreateNewRequest(driver))
			{
				return flag=false;
			}
			if (!MyRequestsScreen.clickCreateNewRequest_TimeOff(driver))
			{
				return flag=false;
			}
			Thread.sleep(3000);			
			//String windowName1=Utilities.setWindowFocus(driver);
			/*Set<String> windowIds = driver.getWindowHandles();
			Iterator<String> itererator = windowIds.iterator(); 			
			String mainWinID = itererator.next();//main window 
			Thread.sleep(2000);
			String  popWindow = itererator.next();//popup window
			driver.switchTo().window(popWindow);//Switch the driver to the popup window
*/
			for(String winHandle :driver.getWindowHandles()){
                driver.switchTo().window(winHandle);
                System.out.println("title:"+driver.getTitle());
                if(driver.getTitle().contains("Time Off Request Form"))
                {
                	//flag=true;
                	System.out.println("You are in time off req form window");
                	driver.manage().window().maximize();
                    break;
                }			
			}
			
			driver.switchTo().defaultContent();
			Thread.sleep(2000);
			if (!MyRequestsScreen.selectTimeOffType(driver, "Vacation"))
			{
				return flag=false;
			}
			
			//driver.findElement(By.xpath("//span[@BP_OBJ_TYPE='DATE_PICKER']/input[@id='dateChoice_START_1']")).sendKeys("11/14/2016 12:00 AM");
			//driver.findElement(By.xpath("//span[@BP_OBJ_TYPE='DATE_PICKER']/input[@id='dateChoice_END_1']")).sendKeys("11/15/2016 11:59 PM");
			MyRequestsScreen.setTimeOffChoicesStartDate(driver, "11/14/2017 12:00 AM");			
			MyRequestsScreen.setTimeOffChoicesEndDate(driver, "11/15/2017 11:59 PM");			
			
			if (!MyRequestsScreen.selectMonth(driver, "November"))
			{
				return flag=false;
			}
			if (!MyRequestsScreen.selectYear(driver, "2017"))
			{
				return flag=false;
			}
			//String windowName2=Utilities.setWindowFocus(driver);
			if (!MyRequestsScreen.clickCalculateEstimate(driver))
			{
				return flag=false;
			}
			Thread.sleep(5000);
			//3rd window
			/*Set<String> windowIds = driver.getWindowHandles();
			Iterator<String> itererator = windowIds.iterator(); 
			String mainWinID3 = itererator.next();//main window
			Thread.sleep(1000);
			String  reqpopWindow = itererator.next();//popup window
			Thread.sleep(1000);
			String  calcpopWindow = itererator.next();//popup window
			Thread.sleep(1000);
			driver.switchTo().window(calcpopWindow);//Switch the driver to the calculator window -3rd window			
			//enter date
			Thread.sleep(2000);
			driver.switchTo().window(calcpopWindow);
			Thread.sleep(1000);*/
			for(String winHandle :driver.getWindowHandles()){
                driver.switchTo().window(winHandle);
                System.out.println("title:"+driver.getTitle());
                if(driver.getTitle().contains("Time Off Accrual Calculator"))
                {
                	//flag=true;
                	System.out.println("You are in time off accural calc window");
                	driver.manage().window().maximize();
                    break;
                }			
			}
			
			
			Thread.sleep(2000);	
			//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Title_TimeOffAccuralCalculator.png");
			driver.switchTo().defaultContent();
			//if (driver.findElements(By.xpath("//table[@id='formTwoColumn_wrapper_tbl_id']/tbody/tr[2]/td[2]/span[@BP_OBJ_TYPE='DATE_PICKER']/input[@name='asOfDate']")).size()!=0)
			if (driver.findElements(By.xpath("//span[@BP_OBJ_TYPE='DATE_PICKER']/input[@name='asOfDate']")).size()!=0)
			{  
				driver.findElement(By.xpath("//span[@BP_OBJ_TYPE='DATE_PICKER']/input[@name='asOfDate']")).click();
				driver.findElement(By.xpath("//span[@BP_OBJ_TYPE='DATE_PICKER']/input[@name='asOfDate']")).clear();
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK1.png");
				driver.findElement(By.xpath("//span[@BP_OBJ_TYPE='DATE_PICKER']/input[@name='asOfDate']")).sendKeys("11/14/2017");
				Thread.sleep(2000);
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
			}
			//dropdown
			driver.findElement(By.xpath("//span[@id='activityID_0Wrapper']/nobr/img[@id='activityID_0Button']")).click();
			Thread.sleep(2000);				
			driver.findElement(By.xpath("//span[@id='activityID_0Wrapper']/nobr/img[@id='activityID_0Button']")).sendKeys("Vacation");
			Thread.sleep(3000);
			Robot r1 = new Robot();
			r1.keyPress(KeyEvent.VK_ENTER);
			r1.keyRelease(KeyEvent.VK_ENTER);
			//click on calculate button
			Thread.sleep(2000);
			driver.findElement(By.xpath("//table[@id='workpaneMediator_toolbar_VIEW_ACTIONWrapper']/tbody/tr[1]/td[1]/button[@id='workpaneMediator_toolbar_VIEW_ACTIONLabel']")).click();//calculate
			Thread.sleep(2000);
			//click on done button
			driver.findElement(By.xpath("//table[@id='workpaneMediator_toolbar_DONE_ACTIONWrapper']/tbody/tr[1]/td[1]/button[@id='workpaneMediator_toolbar_DONE_ACTIONLabel']")).click();//done button		
			System.out.println("clicked on Done-3rd window");
//			driver.switchTo().window(reqpopWindow);
			for(String winHandle : driver.getWindowHandles()){
			    driver.switchTo().window(winHandle);
			}
			System.out.println("gng to click on save-2nd window");
			if (!MyRequestsScreen.clickCreateNewRequestSave(driver))
			{
				return flag=false;
			}
			System.out.println("no.ofdays:"+driver.findElement(By.xpath("//table[@id='dynList_tableRef']/tbody/tr[2]/td[2]")).getText());
			System.out.println("no.ofhours:"+driver.findElement(By.xpath("//table[@id='dynList_tableRef']/tbody/tr[2]/td[3]")).getText());
			
			Screen sobj = new Screen ();
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Error_CreateNewReqSave.png") != null)
			{				
				Thread.sleep(2000);
				extent.log(LogStatus.FAIL, "Error Message:Unable to save Request. Validation for time off request for Employee is displayed");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "TimeOffReqErrMsg"));
				System.out.println("error msg");
				return flag=false;
			}
			else
			{
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "TimeOffRequestApproved"));
			}
			
			if (!MyRequestsScreen.clickCreateNewRequestDone(driver))
			{
				return flag=false;
			}
		
						
//			driver.switchTo().window(mainWinID3);
			for(String winHandle : driver.getWindowHandles()){
			    driver.switchTo().window(winHandle);
			}
			
			//verify status approved or not
			int arc=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr")).size();
			System.out.println("rows:"+arc);
			if (driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+arc+"]/th/center/img[@alt='Approved']")).size()!=0)
			{
				System.out.println("approved");
				extent.log(LogStatus.PASS, "Time Off Request approved");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "TimeOffRequestApproved"));
				if (driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+arc+"]/td[7]/nobr/span[7]/span/span/a/img[@alt='Withdraw']")).size()!=0)
				{
					driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+arc+"]/td[7]/nobr/span[7]/span/span/a/img[@alt='Withdraw']")).click();
					for(String winHandle : driver.getWindowHandles()){
						System.out.println("title:"+driver.getTitle());
					    driver.switchTo().window(winHandle);
					}
					Thread.sleep(5000);
					if (driver.findElements(By.xpath("//table[@id='workpaneMediator_toolbar_WITHDRAW_ACTIONWrapper']/tbody/tr[1]/td[1]/button[@id='workpaneMediator_toolbar_WITHDRAW_ACTIONLabel']")).size()!=0)
					{
						driver.findElement(By.xpath("//table[@id='workpaneMediator_toolbar_WITHDRAW_ACTIONWrapper']/tbody/tr[1]/td[1]/button[@id='workpaneMediator_toolbar_WITHDRAW_ACTIONLabel']")).click();
						System.out.println("clicked continue button");
					
					}
					
					
				}
			}	
			else
			{
				System.out.println("not approved");
				extent.log(LogStatus.FAIL, "Time Off Request NOT approved");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "TimeOffRequestNOTApproved"));
			}
			for(String winHandle : driver.getWindowHandles()){
			    driver.switchTo().window(winHandle);
			}
			//Utilities.Logout(driver);
			
			
			/*//login with admin@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@ auto time off is off
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			VerintHomePageScreen.selectMenuItem(driver,"Request Management","Employee Requests");
			if (driver.findElements(By.linkText("Employee Requests")).size()==0)
			{
				Utilities.Logout(driver); //logout
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				VerintHomePageScreen.selectMenuItem(driver,"Request Management","Employee Requests");
				if (driver.findElements(By.linkText("Employee Requests")).size()==0)
				{
					
					extent.log(LogStatus.WARNING, "My Requests section is not displayed. Please try again");
					return flag=false;
				}				
			}
			driver.findElement(By.xpath("//span[@BP_OBJ_TYPE='DATE_PICKER']/input[@id='dateChoice_START_0']")).clear();
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
			
			driver.findElement(By.xpath("//span[@BP_OBJ_TYPE='DATE_PICKER']/input[@id='dateChoice_START_0']")).sendKeys("11/14/2016");
			driver.findElement(By.xpath("//span[@BP_OBJ_TYPE='DATE_PICKER']/input[@id='dateChoice_END_0']")).click();
			driver.findElement(By.xpath("//span[@BP_OBJ_TYPE='DATE_PICKER']/input[@id='dateChoice_END_0']")).clear();
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK1.png");
			driver.findElement(By.xpath("//span[@BP_OBJ_TYPE='DATE_PICKER']/input[@id='dateChoice_END_0']")).sendKeys("11/15/2016");
			Thread.sleep(1000);
			//driver.findElement(By.xpath("//span[@BP_OBJ_TYPE='DATE_PICKER']/input[@id='dateChoice_END_0']")).sendKeys("Keys.TAB");
			Robot r = new Robot();
			r.keyPress(KeyEvent.VK_TAB);
			r.keyRelease(KeyEvent.VK_TAB);
			int rc=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr")).size();
			for (int i=1;i<=rc;i++)
			{
				if (driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+i+"]/td[10]/nobr/span[10]/span/span/a/img[@alt='Approve']")).size()!=0)
				{
					System.out.println("approve");
					driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+i+"]/td[10]/nobr/span[10]/span/span/a/img[@alt='Approve']")).click();
				}
			
			}
			System.out.println("approve");
			Thread.sleep(3000);			
			String windowName2=Utilities.setWindowFocus(driver);
			
			
			driver.switchTo().window(windowName2);
			Utilities.Logout(driver);
			//login with Agent
			LoginScreen.setTextInUsername(driver,"d9ix");
			LoginScreen.setTextInPassword(driver,"Aug@12345");
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			VerintHomePageScreen.selectMenuItem(driver,"My Home","My Requests");
			if (driver.findElements(By.linkText("My Requests")).size()==0)
			{
				Utilities.Logout(driver); //logout
				LoginScreen.setTextInUsername(driver,"d9ix");
				LoginScreen.setTextInPassword(driver,"Aug@12345");
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				VerintHomePageScreen.selectMenuItem(driver,"My Home","My Requests");
				if (driver.findElements(By.linkText("My Requests")).size()==0)
				{
					
					extent.log(LogStatus.WARNING, "My Requests section is not displayed. Please try again");
					return flag=false;
				}				
			}
			//validation
			int rc1=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr")).size();
			
				if (driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+rc1+"]/th/center/img[@alt='Approved']")).size()!=0)
				{
					System.out.println("approved");
					
				}*/
			
			
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM_REG",HTMLReportName,4,24);
		}
		return flag;
	}


	

}
