package WFMScripts;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

//import jxl.Sheet;
import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.ie.InternetExplorerDriver;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;

import ScreenObjects.AccessRightsScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.MyRequestsScreen;
import ScreenObjects.ProfilesScreen;
import ScreenObjects.OrgRequestManagement;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.OrganizationSettings;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM094_deleteActivityPermission {
	
	public static ExtentReports extent = ExtentReports.get(WFM094_deleteActivityPermission.class);
	
	public static boolean Delete_Activity_Admin() throws Exception
	{		
		boolean flag=true;
		String HTMLReportName="WFM094_deleteActivityPermission"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Delete activity for admin");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("WFM_RegressionTestSet");
	    //Sheet testID=Wb.getSheet("TestIds");
	    String organizationName = Ws.getCell(5,53).getContents();
	    String EmpName = Ws.getCell(16,53).getContents();
	    String FirstName=Ws.getCell(13,53).getContents();
	    String LastName=Ws.getCell(12,53).getContents();
	    //String organizationDesc = Ws.getCell(6,1).getContents();
	    //String parentOrganization = Ws.getCell(7,1).getContents();
		
		try
		{	
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}	
			
			
			driver.switchTo().defaultContent();
			VerintHomePageScreen.selectMenuItem(driver,"User Management","user_profiles");
			if (driver.findElements(By.linkText("Profiles")).size()==0)
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				VerintHomePageScreen.selectMenuItem(driver,"User Management","user_profiles");
				if (driver.findElements(By.linkText("Profiles")).size()==0)
				{
					extent.log(LogStatus.WARNING, "Time Off section is not displayed. Please try again");
					return flag=false;
				}			
			}
			if(!ProfilesScreen.FindSelect(driver,EmpName))
			{
				Utilities.selectRightPaneView(driver);
				ProfilesScreen.clickCreate(driver);
				ProfilesScreen.setProfilesLastName(driver, LastName);
				ProfilesScreen.setProfilesFirstName(driver, FirstName);
				Utilities.selectRightPaneView(driver);
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
				if (!ProfilesScreen.clickOrganizationEdit(driver)) // click on organization edit icon
				{
					return flag=false;
				}
				Thread.sleep(6000);			
				String windowName1=Utilities.setWindowFocus(driver);			
				ProfilesScreen.selectOrganizationFromListbox(driver,organizationName);		
					
				driver.switchTo().window(windowName1);
				RolesSetupScreen.selectRightPaneView(driver);
				if (!ProfilesScreen.clickSave(driver))
				{
					return flag=false;
				}
				ProfilesScreen.verifySuccessMessage(driver);
			}
			else
			{
				System.out.println("user already exist");
			}
			
			driver.switchTo().defaultContent();				
			//access rights -select WFM contact center agent - ctrl F
			if (driver.findElements(By.linkText("Access Rights")).size()!=0)
			{
				driver.findElement(By.linkText("Access Rights")).click();
				extent.log(LogStatus.INFO, "Access Rights tab is selected");
			}		
			else
			{
				extent.log(LogStatus.FAIL, "Not able to select Access Rights tab");
				return flag=false;
			}
			if (!AccessRightsScreen.selectEmp_From_AccessRightsFrame(driver,FirstName))
			{
				return flag=false;
			}
			Utilities.selectRightPaneView(driver);
			if (!AccessRightsScreen.clickEditAccessRights(driver))
			{
				return flag=false;
			}
			
			Robot r = new Robot();
			r.keyPress(KeyEvent.VK_CONTROL);
			r.keyPress(KeyEvent.VK_F);
			r.keyRelease(KeyEvent.VK_CONTROL);
			r.keyRelease(KeyEvent.VK_F);
			Utilities.sikuliType(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\FindText.png", "Administrator");
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\FindText_Close.png");
			Utilities.selectRightPaneView(driver);
			
			int rcRole=driver.findElements(By.xpath("//table[@id='roleTableRef']/tbody/tr")).size();
			System.out.println("rolerc:"+rcRole);
			for (int p=1;p<=rcRole;p++)
			{
				System.out.println("p value:" + p);
				if (p<31 & p<=rcRole)
				{
					String rName=driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[1]/tr["+p+"]/td[1]/a/span")).getText().trim();
					System.out.println("prevNameApp:"+rName);
//					System.out.println("privVal:WFM Contact Center Agent");
					//Thread.sleep(1000);
					if (rName.equals("Administrator"))
					{
						if (!driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[1]/tr["+p+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).isSelected())
						{
							driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[1]/tr["+p+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).click();
							extent.log(LogStatus.INFO, "Role Name:"+rName+" checkbox is selected");
							System.out.println("checked");				
							flag=true;
							break;
						}
						
					}
				}
				if (p>30 & p<61 & p<=rcRole)
				{   
					int q;
					q=p-30;
					String rName=driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[2]/tr["+q+"]/td[1]/a/span")).getText().trim();
					System.out.println("prevNameApp:"+rName);
//					System.out.println("privVal:WFM Contact Center Agent");
					//Thread.sleep(1000);
					if (rName.contains("Administrator"))
					{
						if (!driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[2]/tr["+q+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).isSelected())
						{
							driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[2]/tr["+q+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).click();
							extent.log(LogStatus.INFO, "Role Name:"+rName+" checkbox is selected");
							System.out.println("checked");				
							flag=true;
							break;
						}
						
					}
				}
				if (p>60 & p<91 & p<=rcRole)
				{
					int s;
					s=p-60;
					String rName=driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[3]/tr["+s+"]/td[1]/a/span")).getText().trim();
					System.out.println("prevNameApp:"+rName);
					System.out.println("privVal:WFM Contact Center Agent");
					//Thread.sleep(1000);
					if (rName.contains("Administrator"))
					{
						if (!driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[3]/tr["+s+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).isSelected())
						{
							driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[3]/tr["+s+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).click();
							extent.log(LogStatus.INFO, "Role Name:"+rName+" checkbox is selected");
							System.out.println("checked");				
							flag=true;
							break;
						}
						
					}
				}
				if (p>90 & p<=rcRole)
				{
					int t;
					t=p-90;
					String rName=driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[4]/tr["+t+"]/td[1]/a/span")).getText().trim();
					System.out.println("prevNameApp:"+rName);
					System.out.println("privVal:WFM Contact Center Agent");
					//Thread.sleep(1000);
					if (rName.contains("Administrator"))
					{
						if (!driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[4]/tr["+t+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).isSelected())
						{
							driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[4]/tr["+t+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).click();
							extent.log(LogStatus.INFO, "Role Name:"+rName+" checkbox is selected");
							System.out.println("checked");				
							flag=true;
							break;
						}
						
					}
				}
				
				
			}
			if (flag==true)
			{
				extent.log(LogStatus.INFO, "Role Name:Administrator checkbox is selected");
			}
			else
			{
				extent.log(LogStatus.FAIL, "Role Name:Administrator checkbox is NOT selected");
				return flag=false;
			}
			if (!AccessRightsScreen.select_ActivityScope_checkbox(driver,"Break"))
			{
				return flag=false;
			}
			if (!AccessRightsScreen.clickSave(driver))
			{
				return flag=false;
			}
			
			
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM_REG",HTMLReportName,4,53);
		}
		return flag;
	}


	

}
