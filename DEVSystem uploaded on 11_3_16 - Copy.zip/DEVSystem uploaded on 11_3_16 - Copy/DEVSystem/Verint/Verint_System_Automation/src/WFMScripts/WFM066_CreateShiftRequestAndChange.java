package WFMScripts;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

//import jxl.Sheet;
import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.security.Credentials;
import org.sikuli.script.Screen;

import ScreenObjects.AccessRightsScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.MyRequestsScreen;
import ScreenObjects.ProfilesScreen;
import ScreenObjects.OrgRequestManagement;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.OrganizationSettings;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM066_CreateShiftRequestAndChange {
	
	public static ExtentReports extent = ExtentReports.get(WFM066_CreateShiftRequestAndChange.class);
	
	public static boolean Create_ShiftRequestAndChange_Request() throws Exception
	{		
		boolean flag=true;
		String HTMLReportName="WFM066_CreateShiftRequestAndChange"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Create Shift Request and change");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("WFM_RegressionTestSet");
	    //Sheet testID=Wb.getSheet("TestIds");
	  
	    String data=Ws.getCell(60,24).getContents();
	    //String organizationDesc = Ws.getCell(6,1).getContents();
	    //String parentOrganization = Ws.getCell(7,1).getContents();
		
		try
		{	
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			
			String mainwindow=driver.getWindowHandle();
			
			//login with Agent
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			Thread.sleep(3000);
			if (!VerintHomePageScreen.selectMenuItem(driver,"My Home","My Requests_Agent"))
			{			
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					extent.log(LogStatus.FAIL, "Verint Homepage is not displayed");
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"My Home","My Requests_Agent"))
				{
					extent.log(LogStatus.WARNING, "Not able to select My Requests menu. Please try again.");
					return flag=false;
				}						
			}
			
			
		
			
			if (driver.findElements(By.linkText("My Requests")).size()==0)
			{
				Utilities.Logout(driver); //logout
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (driver.findElements(By.linkText("My Requests")).size()==0)
				{
					
					extent.log(LogStatus.WARNING, "My Requests section is not displayed. Please try again");
					return flag=false;
				}				
			}
			
			MyRequestsScreen.clickCreateNewRequest(driver);
	    	MyRequestsScreen.clickCreateNewRequest_shiftChange(driver);
	    	for(String winHandle :driver.getWindowHandles()){
                driver.switchTo().window(winHandle);
                System.out.println("title:"+driver.getTitle());
                if(driver.getTitle().equals("Shift Request & Change Form"))
                {                	
                	System.out.println("You are in Shift  Request and Change Form window");
                	driver.manage().window().maximize();
                    break;
                }			
			}
	    	
	    	Thread.sleep(2000);
			 MyRequestsScreen.setShiftrequestStartDate(driver,"11/20/2016");
			 
			 Robot r=new Robot();
			 r.keyPress(KeyEvent.VK_TAB);
			 r.keyRelease(KeyEvent.VK_TAB);
			 Thread.sleep(2000);
			 //driver.switchTo().alert().accept();
			 
			 
			
			//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK1.png");
			 driver.findElement(By.xpath("//img[@id='CSR_EXTENSION_BEFORE_SHIFTr0Norg']")).click();
			 Thread.sleep(2000);
			 MyRequestsScreen.setextensionType(driver, data);
			 
			MyRequestsScreen.clickCreateNewRequestSave(driver);
			MyRequestsScreen.clickCreateNewRequestDone(driver);
			Thread.sleep(3000);
			driver.switchTo().window(mainwindow);
	    	Thread.sleep(3000);
			VerintHomePageScreen.selectMenuItem(driver,"Request Management","TimeOff_Employee_Requests");
			if (driver.findElements(By.linkText("Employee Requests")).size()==0)
			{
				Utilities.Logout(driver); //logout
				driver.findElement(By.id("username")).clear();
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				VerintHomePageScreen.selectMenuItem(driver,"Request Management","TimeOff_Employee_Requests");
				if (driver.findElements(By.linkText("Employee Requests")).size()==0)
				{
			
					extent.log(LogStatus.WARNING, "My Requests section is not displayed. Please try again");
					return flag=false;
				}				
			}
			
			Thread.sleep(5000);
			
			new Actions(driver).moveToElement(driver.findElement(By.xpath("//a[@title='Approve']"))).build().perform();
			WebElement element2 = driver.findElement(By.xpath("//a[@title='Approve']"));
	
			JavascriptExecutor executor2 = (JavascriptExecutor)driver;
			executor2.executeScript("arguments[0].click();", element2);
	
			System.out.println("approve");
			Thread.sleep(3000);	
			
			for(String winHandle :driver.getWindowHandles()){
                driver.switchTo().window(winHandle);
                System.out.println("title:"+driver.getTitle());
                if(driver.getTitle().contains("Request Status Change"))
                {                	
                	System.out.println("You are in Request Status Change window");
                	driver.manage().window().maximize();
                    break;
                }			
			}
			
			MyRequestsScreen.clickContinue(driver);
			Thread.sleep(3000);
			driver.switchTo().window(mainwindow);
			Thread.sleep(2000);
			int rc9=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr")).size();
			
			if (driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+rc9+"]/th/center/img[@alt='Approved']")).size()!=0)
			{
			System.out.println("approved");
			extent.log(LogStatus.PASS,"shift  request is approved.");
				
			}

			driver.switchTo().defaultContent();
			Thread.sleep(3000);
			
			
//			
			
			
			
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM_REG",HTMLReportName,4,24);
		}
		return flag;
	}


	

}
