package WFMScripts;

import java.io.File;
import java.io.PrintWriter;

import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import ScreenObjects.CalendarScreen;
import ScreenObjects.CampaignSettings;
import ScreenObjects.FSEmployees;
import ScreenObjects.ForecastScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.OrganizationSettings;
import ScreenObjects.ProfilesScreen;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.ScheduleScreen;
import ScreenObjects.ServiceGoals;
import ScreenObjects.WorkQueuesScreen;
import ScreenObjects.WorkRulesScreen;

import ScreenObjects.VerintHomePageScreen;


import Utilities.Utilities;
import org.sikuli.script.Screen;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM091_ViewStatistics 
{
	
	public static ExtentReports extent = ExtentReports.get(WFM091_ViewStatistics.class);
	
	public static boolean View_Statistics() throws Exception
	{		
		boolean flag=true;
		String windowName="";
		String HTMLReportName="WFM091_ViewStatistics"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "View Statistics for Agent");
				
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 			
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);
	    Sheet Ws = Wb.getSheet("WFM_RegressionTestSet");
	   // Sheet testID=Wb.getSheet("TestIds");
	    String campName=Ws.getCell(28,48).getContents();
	    String StartDate=Ws.getCell(32,48).getContents();
	    String OrgName=Ws.getCell(5,48).getContents();
	    String Period=Ws.getCell(29,48).getContents();
	    String wqname=Ws.getCell(31,48).getContents();
	    String EmpName =Ws.getCell(16,48).getContents();
	    String workQueue=Ws.getCell(31,48).getContents();
	    String FirstName=Ws.getCell(13,48).getContents();
	    String LastName=Ws.getCell(12,48).getContents();
	    String agentname=Ws.getCell(16,48).getContents();
	    String WqDesc=Ws.getCell(35,48).getContents();	
	    String organizationDesc = Ws.getCell(6,48).getContents();
	    String parentOrganization = Ws.getCell(7,48).getContents();
	    String enddate=Ws.getCell(59,48).getContents();
	    
	    
	    try
	    {
	    	LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
	    	if(!LoginScreen.verifyLoginPageLaunched(driver))
	    	{
	    		return flag=false;
	    	}
	    	LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
	    	if(!VerintHomePageScreen.verifyVerintHomePage(driver))
	    	{
	    		return flag=false;
	    	}
	    	String mainwindow=driver.getWindowHandle();
	    	VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings");
	    	Utilities.selectLeftTreeFrame(driver);
	    	if(CampaignSettings.CampaignExist(driver, campName))
	    	{
	    		CampaignSettings.deleteCampaign(driver);
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\btnok_camp.png");
		    	Thread.sleep(3000);
		    	driver.switchTo().defaultContent();
	    	}
	    	else
	    	{
	    		System.out.println("no campaign exist");
	    	}
	    	driver.switchTo().defaultContent();
	    	VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Organization Settings");
	    	Utilities.selectLeftTreeFrame(driver);
			Boolean Temp1=false;			
			int rc1=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
			System.out.println("rc1:"+rc1);
			for (int j=1;j<=rc1;j++)
			{
				/*if (j<=15)
				{*/
				String orgName1=driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).getText();
				Thread.sleep(1000);
				System.out.println("org name:"+orgName1);
				if (orgName1.contains(OrgName))
				{
					driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).click();
					Temp1=true;
					break;
				}
			}
			if (Temp1==true)
			{
				System.out.println("org already exist");
				extent.log(LogStatus.INFO, "Organization Name: "+OrgName+" already exist");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Organization"));								
			}			
			//end of verify organization
			//create organization
			if (Temp1==false)
			{
				Utilities.selectLeftTreeFrame(driver);
				if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,parentOrganization))
				{
					return flag=false;
				}
				Utilities.selectRightPaneView(driver);
				if (!OrganizationSettings.clickCreateOrganization(driver))
				{
					return flag=false;
				}
				OrganizationSettings.setOrganizationName(driver,OrgName);
				OrganizationSettings.setOrganizationDescription(driver,organizationDesc);
				OrganizationSettings.isSelectedDaysAndHoursOfOperation(driver);
				if (!OrganizationSettings.clickSave(driver))
				{
					return flag=false;
				}
			}
			driver.switchTo().defaultContent();
	    	if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","user_profiles"))
			{
				extent.log(LogStatus.WARNING, "Not able to select User Profile menu. Please try again");
				return flag=false;
			}	
	    	//verify if organization is already set
	    	if(!ProfilesScreen.FindSelect(driver,EmpName))
			{
				Utilities.selectRightPaneView(driver);
				ProfilesScreen.clickCreate(driver);
				ProfilesScreen.setProfilesLastName(driver, LastName);
				ProfilesScreen.setProfilesFirstName(driver, FirstName);
				Utilities.selectRightPaneView(driver);
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
				if (!ProfilesScreen.clickOrganizationEdit(driver)) // click on organization edit icon
				{
					return flag=false;
				}
				Thread.sleep(6000);			
				//String wind=Utilities.setWindowFocus(driver);	
				for(String winHandle :driver.getWindowHandles())
				{
	                driver.switchTo().window(winHandle);
	                System.out.println("title:"+driver.getTitle());
	                if(driver.getTitle().equals("Effective Dates"))
	                {                	
	                	System.out.println("You are in organization selector window");
	                	driver.manage().window().maximize();
	                    break;
	                }	
				}
				ProfilesScreen.selectOrganizationFromListbox(driver,OrgName);		
					
				driver.switchTo().window(mainwindow);
				
				if (!ProfilesScreen.clickSave(driver))
				{
					return flag=false;
				}
				ProfilesScreen.verifySuccessMessage(driver);
			}
			else
			{
				System.out.println("user already exist");
			}
			
	    	Utilities.selectRightPaneView(driver);
	    	Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
	    	String org=driver.findElement(By.xpath("//input[@id='orgId_RO']")).getAttribute("value");
	    	System.out.println("org name is" + org);
	    	if(org.contains(OrgName))
	    	{
	    		extent.log(LogStatus.INFO,"Organization is already selected");
	    	}
	    	//set organization for agent
	    	else
	    	{
	    		Utilities.selectRightPaneView(driver);
	    		Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
				if (!ProfilesScreen.clickOrganizationEdit(driver)) // click on organization edit icon
				{
					return flag=false;
				}
				Thread.sleep(6000);			
				String wind=Utilities.setWindowFocus(driver);	
				for(String winHandle :driver.getWindowHandles())
				{
	                driver.switchTo().window(winHandle);
	                System.out.println("title:"+driver.getTitle());
	                if(driver.getTitle().equals("Effective Dates"))
	                {                	
	                	System.out.println("You are in organization selector window");
	                	driver.manage().window().maximize();
	                    break;
	                }	
				}
				ProfilesScreen.selectOrganizationFromListbox(driver,OrgName);		
					
				driver.switchTo().window(mainwindow);
				RolesSetupScreen.selectRightPaneView(driver);
				if (!ProfilesScreen.clickSave(driver))
				{
					return flag=false;
				}
	    	}
	    	driver.switchTo().defaultContent();
	    	
	    	if(!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings"))
	    	{
	    		Utilities.Logout(driver);
	    		LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
	    		if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings"))
				{
					extent.log(LogStatus.WARNING, "Not able to select Compaign Settings menu. Please try again");
					return flag=false;
				}
	    	}
	    	//VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings");
				//verify whether Compaign name is already exist or not		
				Utilities.selectLeftTreeFrame(driver);
				boolean Temp=false;
				int rc=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
				System.out.println("rc:"+rc);
				for (int i=1;i<=rc;i++)
				{
					if (i<=15)
					{
					String campNameApp=driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr["+i+"]/td/a")).getText();
					System.out.println(i+":"+campNameApp);
					if (campNameApp.contains(campName))
					{
						driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr["+i+"]/td/a")).click();
						//driver.findElement(By.xpath("//img[@id='campaignSPTreer0Norg']")).click();
						Thread.sleep(3000);
						Temp=true;
						break;
					}}
				}
				if (CampaignSettings.CampaignExist(driver, campName))
				{					
					extent.log(LogStatus.PASS, "Compaign Name:"+campName+" already exist");
					extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Campaign"));
				}
				//end of verify campaign
				//create campaign
				else
				{
					Utilities.selectRightPaneView(driver);
					
					if (!CampaignSettings.clickCreateCampaign(driver))
					{
						return flag=false;
					}
					CampaignSettings.setCampaignName(driver,campName);
					CampaignSettings.setCampaignDescription(driver,".AutomationDescCampaign");				
					if (!CampaignSettings.clickSave(driver))
					{
						return flag=false;
					}
				}
					
				Utilities.selectLeftTreeFrame(driver);
				Thread.sleep(2000);
				if(driver.findElements(By.xpath("//img[@id='campaignSPTreer0Norg']")).size()!=0)
				{
					driver.findElement(By.xpath("//img[@id='campaignSPTreer0Norg']")).click();
				}
				
				//verify if schedule period exist
				
				if(CampaignSettings.schedulePeriodExist(driver, Period))
				{
					extent.log(LogStatus.INFO,"schedule period:" + Period + "already exist");
				}
				//create a new scheduling period
				else
				{
					
					CampaignSettings.clickSchedulingPeriod(driver);
					Utilities.selectRightPaneView(driver);
					CampaignSettings.setSchedulingPeriodStartDate(driver, StartDate);
					
					if(!CampaignSettings.clickSchedulingPeriodPSave(driver))
					{
						return flag=false;
					}
					CampaignSettings.setCampaignDescription(driver,".AutomationDescCampaign");
					CampaignSettings.clickOrganizationSelector(driver);
					for(String winHandle :driver.getWindowHandles())
					{
		                driver.switchTo().window(winHandle);
		                System.out.println("title:"+driver.getTitle());
		                if(driver.getTitle().equals("Organization Selector"))
		                {                	
		                	System.out.println("You are in organization selector window");
		                	driver.manage().window().maximize();
		                    break;
		                }	
					}
					//windowName=Utilities.setWindowFocus(driver);
					CampaignSettings.selectOrganizationSelector(driver, OrgName);
					driver.switchTo().window(mainwindow);
					CampaignSettings.selectHoursOfOperation(driver);
					CampaignSettings.clickCampaignSettingsSave(driver);
				}
				
				Thread.sleep(2000);
				if(!CampaignSettings.clickCampaignSettingsSave(driver))
				{
					return flag=false;
				}
				Thread.sleep(2000);
				driver.switchTo().defaultContent();
				//verify if queue is laready linked to campaign
				CampaignSettings.clickQueue(driver);
				Thread.sleep(3000);
				
				
		    	//link created queue to campaign
		    	
				CampaignSettings.clickAddSP(driver);
				Thread.sleep(2000);
				for(String winHandle :driver.getWindowHandles())
				{
	                driver.switchTo().window(winHandle);
	                System.out.println("title:"+driver.getTitle());
	                if(driver.getTitle().equals("Add to SP"))
	                {                	
	                	System.out.println("You are in Add to SP window");
	                	driver.manage().window().maximize();
	                    break;
	                }	
				}
//			
				CampaignSettings.selectWorkQueue(driver);
				driver.switchTo().window(mainwindow);
		    	
				if(!CampaignSettings.clickCampaignSettingsSave(driver))
				{
					return flag=false;
				}
				driver.switchTo().defaultContent();
				Thread.sleep(3000);
				
		    	VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","FS_Profiles");
		    	
			    
		    	Thread.sleep(5000);
		    	if (! FSEmployees.selectCampaign(driver,campName))
				{ 
					return flag=false;
				}
				if (! FSEmployees.selectPeriod(driver,Period))
				{
					return flag=false;
				}
				if(FSEmployees.Empexist(driver,agentname))
				{
					extent.log(LogStatus.INFO,"employee Name:" +agentname+"is allready added");
				}
				//addition of agent1 to campaign
				else
				{
					FSEmployees.clickAddEmployeeToSP(driver);
					for(String winHandle :driver.getWindowHandles()){
		                driver.switchTo().window(winHandle);
		                System.out.println("title:"+driver.getTitle());
		                if(driver.getTitle().contains("Add to Scheduling Period"))
		                {                	
		                	System.out.println("You are in Add Scheduling period window");
		                	driver.manage().window().maximize();
		                    break;
		                }			
					}
//					String win=Utilities.setWindowFocus(driver);
					FSEmployees.addEmployeeToSP(driver,agentname);
					FSEmployees.clickAdd(driver);
					driver.switchTo().window(mainwindow);
					FSEmployees.SelectEmployee(driver,agentname);
					FSEmployees.ClickSave(driver);
				}
				driver.switchTo().defaultContent();
				Thread.sleep(2000);
				
		    	if (!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Calendar"))
				{			
					Utilities.Logout(driver);
					LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
					LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
					LoginScreen.clickLogin(driver);
					if (!VerintHomePageScreen.verifyVerintHomePage(driver))
					{
						extent.log(LogStatus.FAIL, "Verint Homepage is not displayed");
						return flag=false;
					}
					if (!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Calendar"))
					{
						extent.log(LogStatus.WARNING, "Not able to select Calendar menu. Please try again.");
						return flag=false;
					}
							
				}
				
		    	
		    	CalendarScreen.selectCampaign(driver, campName);
		    	CalendarScreen.selectPeriod(driver, Period);
		    	Thread.sleep(2000);
		    	CalendarScreen.SelectEmployee(driver,agentname);
		    	Thread.sleep(3000);
		    	driver.switchTo().defaultContent();
		    	
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\button_runengine.png");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\button_chkbox1.png");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\button_chkbox2.png");
//		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\okbtn.png");
		    	VerintHomePageScreen.clickCalOK();
		    	Thread.sleep(40000);
		    	extent.log(LogStatus.INFO,"shift is scheduled sucessfully");
		    	Thread.sleep(3000);
		    	//extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "shiftSchedule"));
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\buuton_publishschedule.png");
		    	
		    	VerintHomePageScreen.clickyes();
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\btnok_schedule.png");
		    	VerintHomePageScreen.clickyes();
		    	extent.log(LogStatus.INFO,"shift is published sucessfully");
		    	Thread.sleep(3000);
		    	//extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "shiftpublished"));
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\OK.png");
		    	/*Utilities.Logout(driver);
				Thread.sleep(3000);
				driver.findElement(By.id("username")).clear();
				LoginScreen.setTextInUsername(driver,Utilities.getPassword(driver, 0, 1));			
				LoginScreen.setTextInPassword(driver,Utilities.getPassword(driver, 1, 1));
		    	LoginScreen.clickLogin(driver);
		    	VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings");
		    	Utilities.selectLeftTreeFrame(driver);
		    	CampaignSettings.CampaignExist(driver, campName);
		    	CampaignSettings.deleteCampaign(driver);
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\btnok_camp.png");*/
		    	Thread.sleep(3000);
		    	driver.switchTo().defaultContent();
		    	
				}   	
				
		
	    catch(Exception e){
			e.printStackTrace();
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			  
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM_REG",HTMLReportName,4,48);
		}
		return flag;
	
	}

}

