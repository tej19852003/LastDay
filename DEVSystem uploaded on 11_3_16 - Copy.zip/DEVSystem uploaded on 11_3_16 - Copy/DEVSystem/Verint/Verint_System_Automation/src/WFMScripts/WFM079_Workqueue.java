package WFMScripts;


import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.LoginScreen;
import ScreenObjects.OrganizationSettings;

import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.WorkQueuesScreen;
import Utilities.Utilities;

public class WFM079_Workqueue {
	
	public static ExtentReports extent = ExtentReports.get(WFM079_Workqueue.class);
	public static Screen sobj = new Screen ();
	public static boolean Workqueue() throws Exception
	{
		boolean flag=true;
		boolean temp=false;
		String HTMLReportName="Workqueue_"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Create Map Workqueue");
				
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("WFM_RegressionTestSet");
	  
	    String OrganizatioName = Ws.getCell(7,2).getContents();
	    String WorkqueueName = Ws.getCell(21,2).getContents();
	    String WorkqueueDesc = Ws.getCell(22,2).getContents();
	    String WorkqueueMedia = Ws.getCell(23,2).getContents();
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Work Queues Settings"))
			//if (driver.findElements(By.linkText("Settings")).size()==0)
			{
				Utilities.Logout(driver);				
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Work Queues Settings"))
				//if (driver.findElements(By.linkText("Settings")).size()==0)
				{
					extent.log(LogStatus.WARNING, "Work Queues Settings menu is not selected. Please try again.");
					return flag=false;
				}
			}			
			Utilities.selectLeftTreeFrame(driver);
			if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,OrganizatioName))
			{
				return flag=false;
			}
			//checking whether exist or not
			Utilities.selectRightPaneView(driver);
			int valrcWq=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr")).size();
			System.out.println("valrcPriv:"+valrcWq);
			for (int j=1;j<=valrcWq;j++)
			{
				if (j<=15)
				{
				String WqnameApp=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/th/a/span")).getText().trim();
				//System.out.println("WqnameAppApp:"+WqnameApp);
				//System.out.println("WqnameAppCreated:"+WorkqueueName);
				Thread.sleep(1000);
				if (WqnameApp.contains(WorkqueueName))
				{
					driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/th/a/span")).click();					
					extent.log(LogStatus.INFO, "Work Queue Name:"+WorkqueueName+" already exist");
					extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Workqueue"));
					temp=true;
					break;
				}}
			}
			/*if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\NoMatchesFound.png") != null)
			{
				extent.log(LogStatus.INFO, WorkqueueName+" does not exist. Please create.");
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\FindText_Close.png");
				temp=true;
			}
			else
			{
				extent.log(LogStatus.INFO, "Work Queue Name:"+WorkqueueName+" already exist");
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\FindText_Close.png");
				return flag=false;
			}*/
			
			//end of checking
			Utilities.selectRightPaneView(driver);
			if (temp==false)
			{			
				if (!WorkQueuesScreen.clickworkqueue(driver))
				{
					return flag=false;
				}
				if (!WorkQueuesScreen.setWorkqueueName(driver,WorkqueueName))
				{
					return flag=false;
				}
				WorkQueuesScreen.setWorkqueueDescription(driver,WorkqueueDesc);			
				if (!WorkQueuesScreen.selectWorkqueueMedia(driver,WorkqueueMedia))
				{
					return flag=false;
				}
				if (!WorkQueuesScreen.clickSave(driver))
				{
					return flag=false;
				}
				if (driver.findElements(By.xpath("//div[@id='workPaneWrapper']/table[@id='viewfindPane_tbl_id']/tbody/tr/td[2]/div[@id='pageMessages']/div[@Class='stdError']")).size()!=0)
				{
					String message=driver.findElement(By.xpath("//div[@id='workPaneWrapper']/table[@id='viewfindPane_tbl_id']/tbody/tr/td[2]/div[@id='pageMessages']/div[@Class='stdError']")).getText();
					if (message.contains("Failed") && (message.contains("already exists")))
					{
						extent.log(LogStatus.WARNING, "Workqueue"+WorkqueueName+" already exist");
						extent.log(LogStatus.WARNING, "", "", Utilities.captureScreenShot(driver, "Workqueue"));
					}
					else
					{
						extent.log(LogStatus.INFO, message+" is displayed");
						extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Workqueue"));
					}
					
				}
				//validation
				if (!WorkQueuesScreen.selectWorkqueue(driver,WorkqueueName))
				{
					return flag=false;
				}	
			}
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM",HTMLReportName,4,2);
		}
		return flag;
	}
}
