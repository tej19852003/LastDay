package WFMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import jxl.Sheet;
import jxl.Workbook;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.python.modules.thread.thread;
import org.sikuli.basics.proxies.Mat;

import ScreenObjects.CampaignSettings;
import ScreenObjects.ForecastScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.OrganizationSettings;
import ScreenObjects.PulseScreen;
import ScreenObjects.ServiceGoals;
import ScreenObjects.ShiftScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.WorkPatternScreen;
import ScreenObjects.WorkQueuesScreen;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM049_CreateWork_pattern
{
	public static ExtentReports extent = ExtentReports.get(WFM049_CreateWork_pattern.class);
	
	public static boolean Create_WorkPattern()throws Exception
	{
		boolean flag=true;
		String windowName="";
		String HTMLReportName="WFM049_CreateWork_pattern"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Create work Pattern For scheduling");
				
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 			
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);
	    Sheet Ws = Wb.getSheet("WFM_RegressionTestSet");
	    String campName=Ws.getCell(28,19).getContents();
	    String StartDate=Ws.getCell(32,19).getContents();
	    String OrgName=Ws.getCell(5,19).getContents();
	    String Period=Ws.getCell(29,19).getContents();
	    String wqname=Ws.getCell(31,19).getContents();
	    String WqDesc=Ws.getCell(35,19).getContents();	
	    String organizationDesc = Ws.getCell(6,19).getContents();
	    String parentOrganization = Ws.getCell(7,19).getContents();
	    String shiftName=Ws.getCell(47,19).getContents();
	    String Description=Ws.getCell(48,19).getContents();
	    String shiftEvent=Ws.getCell(49,19).getContents();
	    String Activity=Ws.getCell(50,19).getContents();
	    String wpname=Ws.getCell(30,19).getContents();
	    
	    try
	    {
	    	LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			String mainwindow=driver.getWindowHandle();
			
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			
	    	
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			//String mainwindow=driver.getWindowHandle();
			VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Organization Settings");
	    	Utilities.selectLeftTreeFrame(driver);
			Boolean Temp1=false;			
			int rc1=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
			//System.out.println("rc1:"+rc1);
			for (int j=1;j<=rc1;j++)
			{
				if (j<=15)
				{
				String orgName1=driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).getText();
				Thread.sleep(1000);
				if (orgName1.contains(OrgName))
				{
					driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).click();
					Temp1=true;
					break;
				}}
			}
			if (Temp1==true)
			{
				System.out.println("org already exist");
				extent.log(LogStatus.INFO, "Organization Name: "+OrgName+" already exist");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Organization"));								
			}			
			//end of verify organization
			//create organization
			if (Temp1==false)
			{
				Utilities.selectLeftTreeFrame(driver);
				if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,parentOrganization))
				{
					return flag=false;
				}
				Utilities.selectRightPaneView(driver);
				if (!OrganizationSettings.clickCreateOrganization(driver))
				{
					return flag=false;
				}
				OrganizationSettings.setOrganizationName(driver,OrgName);
				OrganizationSettings.setOrganizationDescription(driver,organizationDesc);
				OrganizationSettings.isSelectedDaysAndHoursOfOperation(driver);
				if (!OrganizationSettings.clickSave(driver))
				{
					return flag=false;
				}
			}
			driver.switchTo().defaultContent();
	    	Thread.sleep(2000);
	    	
	    	/*VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings");
	    	Utilities.selectLeftTreeFrame(driver);
	    	if(CampaignSettings.CampaignExist(driver, campName))
	    	{
	    		CampaignSettings.deleteCampaign(driver);
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\btnok_camp.png");
		    	Thread.sleep(3000);
		    	driver.switchTo().defaultContent();
	    	}
	    	else
	    	{
	    		System.out.println("no campaign exist");
	    	}
	    	driver.switchTo().defaultContent();*/
				
	    	if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Shifts"))
			{
			
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Shifts"))
				{
				//if (driver.findElements(By.linkText("Profiles")).size()==0)
				//{
					extent.log(LogStatus.WARNING, "Not able to select Shifts menu. Please try again.");
					return flag=false;
				}
				
			}
			Utilities.selectRightPaneView(driver);
			
//	    	
	    	if(ShiftScreen.Shiftexist(driver, shiftName))
	    	{
	    		extent.log(LogStatus.INFO,"shift"+ shiftName + "already exist");
	    	}
	    	
	    	else
	    	{
			
				ShiftScreen.clickcreateshift(driver);
				Thread.sleep(2000);
				ShiftScreen.setshiftName(driver,shiftName);
				ShiftScreen.setshiftDescription(driver,Description);
				ShiftScreen.setActivity(driver, Activity);
				driver.findElement(By.xpath("//input[@id='shiftDurationInMins__input_id']")).sendKeys("09:00");
				ShiftScreen.setshiftstartTime(driver);
				ShiftScreen.clickaddbreak(driver);
				for(String winHandle :driver.getWindowHandles()){
	                driver.switchTo().window(winHandle);
	                System.out.println("title:"+driver.getTitle());
	                if(driver.getTitle().equals("Shift Event Selection"))
	                {                	
	                	System.out.println("You are in Shift events window");
	                	driver.manage().window().maximize();
	                    break;
	                }			
				}
				ShiftScreen.setshiftbreak(driver, shiftEvent);
				driver.switchTo().window(mainwindow);
				ShiftScreen.clickSave(driver);
	    	}
		    	
	    	driver.switchTo().defaultContent();
			VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Work Pattern");
			
			Utilities.selectRightPaneView(driver);
	    	Thread.sleep(5000);
	    	//verify if work pattern already exist or not
	    	boolean Temp7=false;
	    	driver.findElement(By.name("itemToFind")).sendKeys(wpname);
	    	driver.findElement(By.xpath("//button[@id='toolbar_FIND_ACTIONLabel']")).click();
	    	Thread.sleep(2000);
	    	List<WebElement> li1=driver.findElements(By.xpath("//table[@id='tableRef']//tr[@class='tblRow']"));
	    	System.out.println(li1.size());
	    	if(driver.findElements(By.xpath("//table[@id='tableRef']//tr[@class='tblRow']//td")).size()!=0)
	    	{
	    	for(WebElement elt:li1)
	    	{
	    		//System.out.println("**************");
	    		System.out.println(elt.findElement(By.tagName("td")).getAttribute("innerText"));
	    		String wname=elt.findElement(By.tagName("td")).getAttribute("innerText");
	    		if(wname.contains(wpname))
	    		{
	    			Temp7=true;
	    			break;
	    		}
	    	}
	    	}
//	    	
	    	
	    	
	    	
	    	
			if (Temp7==true)
			{					
				extent.log(LogStatus.PASS, "Work pattren Name:"+wpname+" already exist");
				//extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Campaign"));
			}
			//end of verify work pattern
			//create a new work pattern
			if(Temp7==false)
			{
				if(!WorkPatternScreen.clickworkpattern(driver))
		    	{
		    		return flag=false;
		    	}
	    	WorkPatternScreen.setWorkpatternName(driver, wpname);
	    	WorkPatternScreen.setWorkpatternDescription(driver,".AutomationDescWorkPattern");
	    	WorkPatternScreen.setpossibledaysOff(driver);
	    	WorkPatternScreen.clickAddshift(driver);
	    	//String windowName1=Utilities.setWindowFocus(driver);
	    	for(String winHandle :driver.getWindowHandles()){
                driver.switchTo().window(winHandle);
                System.out.println("title:"+driver.getTitle());
                if(driver.getTitle().equals("Shift Details"))
                {                	
                	System.out.println("You are in Shift Details window");
                	driver.manage().window().maximize();
                    break;
                }			
			}
	    	
	    	WorkPatternScreen.setshift(driver,shiftName);
	    	driver.switchTo().window(mainwindow);
	    	
	    	if(!WorkPatternScreen.clickSave(driver))
	    	{
	    		return flag=false;
	    	}
			}
	    	Utilities.selectRightPaneView(driver);
	    	Thread.sleep(5000);	
				
				
	    }
	    catch(Exception e)
	    {
	    	e.printStackTrace();
	    }
	    finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM_REG",HTMLReportName,4,19);
		}
		return flag;
	
}
}
