package WFMScripts;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

//import jxl.Sheet;
import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.ie.InternetExplorerDriver;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;

import ScreenObjects.AccessRightsScreen;
import ScreenObjects.CampaignSettings;
import ScreenObjects.FSEmployees;
import ScreenObjects.LoginScreen;
import ScreenObjects.MyRequestsScreen;
import ScreenObjects.ProfilesScreen;
import ScreenObjects.OrgRequestManagement;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.OrganizationSettings;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM054_CreateEmployeeFilter {
	
	public static ExtentReports extent = ExtentReports.get(WFM054_CreateEmployeeFilter.class);
	
	public static boolean Create_Employee_Filter() throws Exception
	{		
		boolean flag=true;
		String HTMLReportName="WFM054_CreateEmployeeFilter"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Create Employee Filter");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("WFM_RegressionTestSet");
	    //Sheet testID=Wb.getSheet("TestIds");
	    String parentorg = Ws.getCell(7,46).getContents();
	    String OrgName=Ws.getCell(5,46).getContents();
	    String campName=Ws.getCell(28,46).getContents();
	    String Period=Ws.getCell(29,46).getContents();
	    String filter=Ws.getCell(6,46).getContents();
	    String editfiletr=Ws.getCell(8,46).getContents();
	    //String organizationDesc = Ws.getCell(6,1).getContents();
	    //String parentOrganization = Ws.getCell(7,1).getContents();
		
		try
		{	
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}	
			
			String mainwindow=driver.getWindowHandle();
			
			if (!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","FS_Profiles"))
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","FS_Profiles"))
				{
					extent.log(LogStatus.WARNING, "Not able to Profiles Settings menu. Please try again");
					return flag=false;
				}			
			}
			
			/*if (! FSEmployees.selectCampaign(driver, campName))
			{
				return flag=false;
			}
			if (! FSEmployees.selectPeriod(driver,Period))
			{
				return flag=false;
			}*/
			
			Utilities.selectLeftTreeFrame(driver);
			FSEmployees.createfilter(driver,filter);
			Thread.sleep(2000);
			for(String winHandle :driver.getWindowHandles())
			{
                driver.switchTo().window(winHandle);
                System.out.println("title:"+driver.getTitle());
                if(driver.getTitle().equals("Employees Filter Configuration"))
                {                	
                	System.out.println("You are in Employee filter Configuration");
                	driver.manage().window().maximize();
                    break;
                }			
			}
			FSEmployees.selectOrganizationSelector(driver, OrgName);
			FSEmployees.ClickSaveAs(driver);
			driver.findElement(By.xpath("//div[@id='SaveAsDlgWrapper']//table//tr[2]//input")).sendKeys(".AutoOrg");
			driver.findElement(By.xpath("//button[@id='DlgToolbar_DIALOG_OKLabel']")).click();
			driver.switchTo().window(mainwindow);
			Thread.sleep(2000);
			
			FSEmployees.clickEditfilter(driver,editfiletr);
			Thread.sleep(2000);
			for(String winHandle :driver.getWindowHandles())
			{
                driver.switchTo().window(winHandle);
                System.out.println("title:"+driver.getTitle());
                if(driver.getTitle().equals("Employees Filter Configuration"))
                {                	
                	System.out.println("You are in Employee filter Configuration");
                	driver.manage().window().maximize();
                    break;
                }			
			}
			Thread.sleep(2000);
			FSEmployees.ClickDelete(driver);
			Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\btnok_camp.png");
	    	Thread.sleep(2000);
			driver.switchTo().window(mainwindow);
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM_REG",HTMLReportName,4,46);
		}
		return flag;
	}


	

}
