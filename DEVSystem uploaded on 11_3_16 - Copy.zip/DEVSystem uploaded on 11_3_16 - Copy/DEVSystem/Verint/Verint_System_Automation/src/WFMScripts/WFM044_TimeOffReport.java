package WFMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import jxl.Sheet;
import jxl.Workbook;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.python.modules.thread.thread;
import org.sikuli.basics.proxies.Mat;

import ScreenObjects.CampaignSettings;
import ScreenObjects.ForecastScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.OrganizationSettings;
import ScreenObjects.PulseScreen;
import ScreenObjects.ServiceGoals;
import ScreenObjects.ShiftScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.WorkQueuesScreen;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM044_TimeOffReport
{
	public static ExtentReports extent = ExtentReports.get(WFM044_TimeOffReport.class);
	
	public static boolean View_TimeOffReport()throws Exception
	{
		boolean flag=true;
		String windowName="";
		String HTMLReportName="WFM040_Shift_breakevents"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "view Time Off Report");
				
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 			
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);
	    Sheet Ws = Wb.getSheet("WFM_RegressionTestSet");
	  
	    
	    try
	    {
	    	LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			String mainwindow=driver.getWindowHandle();
			
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("Agen1tUserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Agent1Password"));
			LoginScreen.clickLogin(driver);
			
	    	
			Thread.sleep(3000);
			if (!VerintHomePageScreen.selectMenuItem(driver,"My Home","My Requests_Agent"))
			{			
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("Agen1tUserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Agent1Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					extent.log(LogStatus.FAIL, "Verint Homepage is not displayed");
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"My Home","My Requests_Agent"))
				{
					extent.log(LogStatus.WARNING, "Not able to select My Requests menu. Please try again.");
					return flag=false;
				}						
			}
			
			driver.findElement(By.xpath("//div[@name='TLDIV']//span[@id='3_RM_MYSCHEDULE_TIMEOFFREPORT_spn_id']//a[@class='navLinkThirdLevel']")).click();
			Thread.sleep(3000);
			List<WebElement> li=driver.findElements(By.xpath("//div[@id='toSchedr0Nodes']//div[@id='tableWrapper']//table[@id='tableRef']//tr[@class='tblRow']//td"));
			System.out.println("++++"+ li.size());
			for(WebElement elt:li)
			{
				System.out.println(elt.getAttribute("innerText"));
				//System.out.println("vacation details are:"+elt.findElement(By.tagName("td")).getAttribute("innerText"));
			}
			extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "TimeOffReport"));
				
				
				
	    }
	    catch(Exception e)
	    {
	    	e.printStackTrace();
	    }
	    finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM_REG",HTMLReportName,4,23);
		}
		return flag;
	
}
}
