package WFMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import jxl.Sheet;
import jxl.Workbook;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.python.modules.thread.thread;
import org.sikuli.basics.proxies.Mat;

import ScreenObjects.CalendarScreen;
import ScreenObjects.CampaignSettings;
import ScreenObjects.FSEmployees;
import ScreenObjects.ForecastScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.OrganizationSettings;
import ScreenObjects.OverTimeScreen;
import ScreenObjects.ProfilesScreen;
import ScreenObjects.PulseScreen;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.ServiceGoals;
import ScreenObjects.ShiftScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.WorkPatternScreen;
import ScreenObjects.WorkQueuesScreen;
import ScreenObjects.WorkRulesScreen;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM029_ScheduleOverTime
{
	public static ExtentReports extent = ExtentReports.get(WFM029_ScheduleOverTime.class);
	
	public static boolean create_schedule_Overtime()throws Exception
	{
		boolean flag=true;
		String windowName="";
		String HTMLReportName="WFM029_ScheduleOverTime"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Schedule OverTime for agent");
				
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 			
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);
	    Sheet Ws = Wb.getSheet("WFM_RegressionTestSet");
	    
	    String OrgName=Ws.getCell(5,49).getContents();
	    String organizationDesc = Ws.getCell(6,49).getContents();
	    String parentOrganization = Ws.getCell(7,49).getContents();
	    String shiftName=Ws.getCell(33,49).getContents();
	    String Description=Ws.getCell(48,49).getContents();
	    String wpname=Ws.getCell(30,49).getContents();
	    String EmpName =Ws.getCell(16,49).getContents();
	    String FirstName=Ws.getCell(13,49).getContents();
	    String LastName=Ws.getCell(12,49).getContents();
	    String Oname=Ws.getCell(64,49).getContents();
	    String Activity=Ws.getCell(65,49).getContents();
	    String campName=Ws.getCell(28,49).getContents();
	    String Period=Ws.getCell(29,49).getContents();
	    String StartDate=Ws.getCell(32,49).getContents();
	    String wqname=Ws.getCell(31,49).getContents();
	    String agentname=Ws.getCell(36,49).getContents();
	    
	    try
	    {
	    	LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			String mainwindow=driver.getWindowHandle();
			
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			
	    	
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			
			VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings");
	    	Utilities.selectLeftTreeFrame(driver);
	    	if(CampaignSettings.CampaignExist(driver, campName))
	    	{
	    		CampaignSettings.deleteCampaign(driver);
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\btnok_camp.png");
		    	Thread.sleep(3000);
		    	driver.switchTo().defaultContent();
	    	}
	    	else
	    	{
	    		System.out.println("no campaign exist");
	    	}
	    	driver.switchTo().defaultContent();
	    	Thread.sleep(2000);
			//String mainwindow=driver.getWindowHandle();
			VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Organization Settings");
	    	Utilities.selectLeftTreeFrame(driver);
			Boolean Temp1=false;			
			int rc1=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
			//System.out.println("rc1:"+rc1);
			for (int j=1;j<=rc1;j++)
			{
				if (j<=15)
				{
				String orgName1=driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).getText();
				Thread.sleep(1000);
				if (orgName1.contains(OrgName))
				{
					driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).click();
					Temp1=true;
					break;
				}}
			}
			if (Temp1==true)
			{
				System.out.println("org already exist");
				extent.log(LogStatus.INFO, "Organization Name: "+OrgName+" already exist");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Organization"));								
			}			
			//end of verify organization
			//create organization
			if (Temp1==false)
			{
				Utilities.selectLeftTreeFrame(driver);
				if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,parentOrganization))
				{
					return flag=false;
				}
				Utilities.selectRightPaneView(driver);
				if (!OrganizationSettings.clickCreateOrganization(driver))
				{
					return flag=false;
				}
				OrganizationSettings.setOrganizationName(driver,OrgName);
				OrganizationSettings.setOrganizationDescription(driver,organizationDesc);
				OrganizationSettings.isSelectedDaysAndHoursOfOperation(driver);
				if (!OrganizationSettings.clickSave(driver))
				{
					return flag=false;
				}
			}
			driver.switchTo().defaultContent();
	    	Thread.sleep(2000);
	    	if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","OverTime"))
			{
			
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","OverTime"))
				{
				//if (driver.findElements(By.linkText("Profiles")).size()==0)
				//{
					extent.log(LogStatus.WARNING, "Not able to select Overtime menu. Please try again.");
					return flag=false;
				}
				
			}
	    	OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,parentOrganization);
			
			
//	    	
	    	if(OverTimeScreen.OverTimeExist(driver, Oname))
	    	{
	    		extent.log(LogStatus.INFO,"OverTime with Name"+ Oname + "already exist");
	    	}
	    	
	    	
	    	
			//creation of new shift for agent1
	    	else
	    	{
	    		OverTimeScreen.clickcreate(driver);
				Thread.sleep(2000);
				OverTimeScreen.setName(driver,Oname);
				OverTimeScreen.setDesc(driver,Description);
				OverTimeScreen.SetActivity(driver, Activity);
				OverTimeScreen.setDuration(driver,"4");
				OverTimeScreen.clickSave(driver);
	    	}
				
				
	    	
			
			
			Thread.sleep(2000);
			driver.switchTo().defaultContent();
	    	
				
	    	
			VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Work Pattern");
			OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,parentOrganization);
			Utilities.selectRightPaneView(driver);
	    	Thread.sleep(5000);
	    	//verify if work pattern already exist or not
	    	boolean Temp7=false;
	    	driver.findElement(By.name("itemToFind")).sendKeys(wpname);
	    	driver.findElement(By.xpath("//button[@id='toolbar_FIND_ACTIONLabel']")).click();
	    	Thread.sleep(2000);
	    	List<WebElement> li1=driver.findElements(By.xpath("//table[@id='tableRef']//tr[@class='tblRow']"));
	    	System.out.println(li1.size());
	    	if(driver.findElements(By.xpath("//table[@id='tableRef']//tr[@class='tblRow']//td")).size()!=0)
	    	{
	    	for(WebElement elt:li1)
	    	{
	    		//System.out.println("**************");
	    		System.out.println(elt.findElement(By.tagName("td")).getAttribute("innerText"));
	    		String wname=elt.findElement(By.tagName("td")).getAttribute("innerText");
	    		if(wname.contains(wpname))
	    		{
	    			Temp7=true;
	    			break;
	    		}
	    	}
	    	}
//	    	
	    	
	    	
	    	
	    	
			if (Temp7==true)
			{					
				extent.log(LogStatus.PASS, "Work pattren Name:"+wpname+" already exist");
				//extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Campaign"));
			}
			//end of verify work pattern
			//create a new work pattern
			if(Temp7==false)
			{
				if(!WorkPatternScreen.clickworkpattern(driver))
		    	{
		    		return flag=false;
		    	}
				
	    	WorkPatternScreen.setWorkpatternName(driver, wpname);
	    	WorkPatternScreen.setWorkpatternDescription(driver,"DescWorkPattern");
	    	
	    	
	    	
	    	WorkPatternScreen.clickAddOverTime(driver);
	    	//String windowName1=Utilities.setWindowFocus(driver);
	    	for(String winHandle :driver.getWindowHandles()){
                driver.switchTo().window(winHandle);
                System.out.println("title:"+driver.getTitle());
                if(driver.getTitle().equals("OT Extension Details"))
                {                	
                	System.out.println("You are in OT Extension Details window");
                	driver.manage().window().maximize();
                    break;
                }			
			}
	    	
	    	WorkPatternScreen.setovertime(driver,Oname);
	    	driver.switchTo().window(mainwindow);
	    	Thread.sleep(2000);
	    	WorkPatternScreen.setpossibledaysOff(driver);
	    	WorkPatternScreen.clickAddshift(driver);
	    	//String windowName1=Utilities.setWindowFocus(driver);
	    	for(String winHandle :driver.getWindowHandles()){
                driver.switchTo().window(winHandle);
                System.out.println("title:"+driver.getTitle());
                if(driver.getTitle().equals("Shift Details"))
                {                	
                	System.out.println("You are in Shift Details window");
                	driver.manage().window().maximize();
                    break;
                }			
			}
	    	
	    	WorkPatternScreen.setshift(driver,shiftName);
	    	driver.switchTo().window(mainwindow);
	    	Thread.sleep(2000);
	    	if(!WorkPatternScreen.clickSave(driver))
	    	{
	    		return flag=false;
	    	}
			}
	    	extent.log(LogStatus.INFO,"work pattern with shift and overtime is created successfully");
	    	extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Work Pattern"));
			driver.switchTo().defaultContent();
			
			
			Thread.sleep(2000);
			
			
			if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","user_profiles"))
			{
				extent.log(LogStatus.WARNING, "Not able to select User Profile menu. Please try again");
				return flag=false;
			}	
//	    	VerintHomePageScreen.selectMenuItem(driver,"User Management","user_profiles");
			if(!ProfilesScreen.FindSelect(driver,EmpName))
			{
				Utilities.selectRightPaneView(driver);
				ProfilesScreen.clickCreate(driver);
				ProfilesScreen.setProfilesLastName(driver, LastName);
				ProfilesScreen.setProfilesFirstName(driver, FirstName);
				Utilities.selectRightPaneView(driver);
				Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
				if (!ProfilesScreen.clickOrganizationEdit(driver)) // click on organization edit icon
				{
					return flag=false;
				}
				Thread.sleep(6000);			
				String windowName1=Utilities.setWindowFocus(driver);			
				ProfilesScreen.selectOrganizationFromListbox(driver,OrgName);		
					
				driver.switchTo().window(windowName);
				RolesSetupScreen.selectRightPaneView(driver);
				if (!ProfilesScreen.clickSave(driver))
				{
					return flag=false;
				}
				ProfilesScreen.verifySuccessMessage(driver);
			}
			else
			{
				System.out.println("user already exist");
			}
			Utilities.selectRightPaneView(driver);
	    	Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
	    	String org=driver.findElement(By.xpath("//input[@id='orgId_RO']")).getAttribute("value");
	    	System.out.println("org name is" + org);
	    	if(org.contains(OrgName))
	    	{
	    		extent.log(LogStatus.INFO,"Organization is already selected");
	    	}
	    	//set organization for agent
	    	else
	    	{
	    		Utilities.selectRightPaneView(driver);
	    		//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");
				if (!ProfilesScreen.clickOrganizationEdit(driver)) // click on organization edit icon
				{
					return flag=false;
				}
				Thread.sleep(6000);			
				String wind=Utilities.setWindowFocus(driver);			
				ProfilesScreen.selectOrganizationFromListbox(driver,OrgName);		
					
				driver.switchTo().window(wind);
				RolesSetupScreen.selectRightPaneView(driver);
				if (!ProfilesScreen.clickSave(driver))
				{
					return flag=false;
				}
	    	}
	    	driver.switchTo().defaultContent();
	    	
	    	VerintHomePageScreen.selectMenuItem(driver,"User Management", "Work Rules");
	    	WorkRulesScreen.findEmployee(driver,EmpName);
	    	WorkRulesScreen.SelectEmployee(driver, EmpName);
	    	//ProfilesScreen.FindSelect(driver,EmpName);
	    	WorkRulesScreen.sethours(driver);
	    	//verify if work rules are already added to agent1 profile
	    	if(WorkRulesScreen.WorkPatternexist(driver,wpname))
	    	{
	    		extent.log(LogStatus.INFO,"work Pattren:"+wpname+"already exist" );
	    	}
	    	
	    	
	    	
	    	
	    	
	    	//addition of created work pattern to Work rules 
	    	else
	    	{
	    		WorkRulesScreen.clickAdd(driver);
	    		Thread.sleep(3000);
	    		//String winhandle3=Utilities.setWindowFocus(driver);
	    		for(String winHandle :driver.getWindowHandles())
				{
	                driver.switchTo().window(winHandle);
	                System.out.println("title:"+driver.getTitle());
	                if(driver.getTitle().equals("Work Patterns"))
	                {                	
	                	System.out.println("You are in Work Patterns window");
	                	driver.manage().window().maximize();
	                    break;
	                }	
				}
		    	
		    	System.out.println("in work pattern window");
		    	WorkRulesScreen.clickAddworkPattern(driver,wpname);
		    	driver.switchTo().window(mainwindow);
	    	}
	    	Thread.sleep(2000);
	    	WorkRulesScreen.clickSave(driver);
	    	extent.log(LogStatus.INFO,"work pattern with  shiffts and overtime  is created successfully");
	    	extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Work Pattern"));
	    	driver.switchTo().defaultContent();
	    	
	    	
	    	
	    	Thread.sleep(3000);
	    	
	    	
	    	
			
	    	
	    	if(!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings"))
	    	{
	    		Utilities.Logout(driver);
	    		LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
	    		if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings"))
				{
					extent.log(LogStatus.WARNING, "Not able to select Compaign Settings menu. Please try again");
					return flag=false;
				}
	    	}
	    	Utilities.selectLeftTreeFrame(driver);
	    	if (CampaignSettings.CampaignExist(driver, campName))
			{					
				extent.log(LogStatus.PASS, "Compaign Name:"+campName+" already exist");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Campaign"));
			}
			//end of verify campaign
			//create campaign
			else
			{
				Utilities.selectRightPaneView(driver);
				
				if (!CampaignSettings.clickCreateCampaign(driver))
				{
					return flag=false;
				}
				CampaignSettings.setCampaignName(driver,campName);
				CampaignSettings.setCampaignDescription(driver,".AutomationDescCampaign");				
				if (!CampaignSettings.clickSave(driver))
				{
					return flag=false;
				}
			}
	    	Utilities.selectLeftTreeFrame(driver);
			Thread.sleep(2000);
			if(driver.findElements(By.xpath("//img[@id='campaignSPTreer0Norg']")).size()!=0)
			{
				driver.findElement(By.xpath("//img[@id='campaignSPTreer0Norg']")).click();
			}
			
			if(CampaignSettings.schedulePeriodExist(driver, Period))
			{
				extent.log(LogStatus.INFO,"schedule period:" + Period + "already exist");
			}
			//create a new scheduling period
			else
			{
				
				CampaignSettings.clickSchedulingPeriod(driver);
				Utilities.selectRightPaneView(driver);
				CampaignSettings.setSchedulingPeriodStartDate(driver, StartDate);
				
				if(!CampaignSettings.clickSchedulingPeriodPSave(driver))
				{
					return flag=false;
				}
				CampaignSettings.setCampaignDescription(driver,".AutomationDescCampaign");
				CampaignSettings.clickOrganizationSelector(driver);
				for(String winHandle :driver.getWindowHandles())
				{
	                driver.switchTo().window(winHandle);
	                System.out.println("title:"+driver.getTitle());
	                if(driver.getTitle().contains("Organization Selector"))
	                {                	
	                	System.out.println("You are in organization selector window");
	                	driver.manage().window().maximize();
	                    break;
	                }	
				}
				//windowName=Utilities.setWindowFocus(driver);
				CampaignSettings.selectOrganizationSelector(driver, OrgName);
				driver.switchTo().window(mainwindow);
				CampaignSettings.selectHoursOfOperation(driver);
				CampaignSettings.clickCampaignSettingsSave(driver);
			}
			
			Thread.sleep(2000);
			if(!CampaignSettings.clickCampaignSettingsSave(driver))
			{
				return flag=false;
			}
			Thread.sleep(2000);
			driver.switchTo().defaultContent();
			//verify if queue is laready linked to campaign
			CampaignSettings.clickQueue(driver);
			Thread.sleep(3000);
			
			CampaignSettings.clickAddSP(driver);
			Thread.sleep(2000);
			for(String winHandle :driver.getWindowHandles())
			{
                driver.switchTo().window(winHandle);
                System.out.println("title:"+driver.getTitle());
                if(driver.getTitle().contains("Add to SP"))
                {                	
                	System.out.println("You are in Add to SP window");
                	driver.manage().window().maximize();
                    break;
                }	
			}
			CampaignSettings.selectWorkQueue(driver);
			driver.switchTo().window(mainwindow);
	    	
			if(!CampaignSettings.clickCampaignSettingsSave(driver))
			{
				return flag=false;
			}
			driver.switchTo().defaultContent();
			Thread.sleep(3000);
			
			//go to forecast menu and set the values
			
			VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Forecast");
	    	Thread.sleep(2000);
	    	ForecastScreen.selectCampaign(driver, campName);
	    	//ForecastScreen.selectCampaign(driver,campName);
	    	//ForecastScreen.selectPeriod(driver, Period);
	    	ForecastScreen.setPeriod(driver, Period);
	    	Thread.sleep(2000);
	    	ForecastScreen.selectworkQueue(driver, wqname);
	    	Thread.sleep(3000);
	    	driver.switchTo().defaultContent();
	    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\btn_clear.png");
	    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Button_Scale.png");
	    	
	    	Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\value_total.png","15");
	    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\value_sun.png");
	       
	    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\button_set.png");
	    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Save_scale.png");
	    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Save_popup.png");
	    	
	    	//Utilities.selectLeftTreeFrame(driver);
	    	Thread.sleep(5000);
	    	ForecastScreen.selectworkQueue(driver, wqname);
	    	Thread.sleep(3000);
	    	driver.switchTo().defaultContent();
	    	Thread.sleep(2000);
	    	VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","ServiceGoals");
	    	
//	    	
	    	//ServiceGoals.selectCampaign(driver,campName);
	    	
	    	ServiceGoals.setPeriod(driver, Period);
	    	ServiceGoals.selectworkQueue(driver, wqname);
	    	Thread.sleep(2000);
	    	driver.switchTo().defaultContent();
	    	Thread.sleep(3000);
	    	Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\ans.png","0");
	    	Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\seconds.png","0");
	    	Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\ans.png","60");
	    	//Thread.sleep(1000);
	    	
	    	Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\seconds.png","40");
	    	//Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\seconds.png","10");
	    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Save_scale.png");
	    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Save_popup.png");
	    	Thread.sleep(2000);
	    	ServiceGoals.selectworkQueue(driver, wqname);
	    	Thread.sleep(2000);
	    	driver.switchTo().defaultContent();
	    	Thread.sleep(2000);
	    	
	    	VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","FS_Profiles");
	    	
		    
	    	Thread.sleep(5000);
	    	if (! FSEmployees.selectCampaign(driver,campName))
			{ 
				return flag=false;
			}
			if (! FSEmployees.selectPeriod(driver,Period))
			{
				return flag=false;
			}
			if(FSEmployees.Empexist(driver,agentname))
			{
				extent.log(LogStatus.INFO,"employee Name:" +agentname+"is allready added");
			}
			//addition of agent1 to campaign
			else
			{
				FSEmployees.clickAddEmployeeToSP(driver);
				for(String winHandle :driver.getWindowHandles()){
	                driver.switchTo().window(winHandle);
	                System.out.println("title:"+driver.getTitle());
	                if(driver.getTitle().contains("Add to Scheduling Period"))
	                {                	
	                	System.out.println("You are in Add Scheduling period window");
	                	driver.manage().window().maximize();
	                    break;
	                }			
				}
//				String win=Utilities.setWindowFocus(driver);
				FSEmployees.addEmployeeToSP(driver,agentname);
				FSEmployees.clickAdd(driver);
				driver.switchTo().window(mainwindow);
				FSEmployees.SelectEmployee(driver,agentname);
				FSEmployees.ClickSave(driver);
			}
			FSEmployees.SelectEmployee(driver,agentname);
			driver.switchTo().defaultContent();
			Thread.sleep(2000);
			//go to calendar menu and schedule the shifts and publish it
			if (!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Calendar"))
			{			
				Utilities.Logout(driver);

				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					extent.log(LogStatus.FAIL, "Verint Homepage is not displayed");
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Calendar"))
				{
					extent.log(LogStatus.WARNING, "Not able to select Calendar menu. Please try again.");
					return flag=false;
				}
						
			}
			
	    	
	    	CalendarScreen.selectCampaign(driver, campName);
	    	CalendarScreen.selectPeriod(driver, Period);
	    	Thread.sleep(2000);
	    	CalendarScreen.SelectEmployee(driver,agentname);
	    	Thread.sleep(3000);
	    	driver.switchTo().defaultContent();
	    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\button_runengine.png");
	    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\selectOT.png");
	    	Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\setOThours.png","4");
	    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\button_chkbox1.png");
	    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\button_chkbox2.png");
//	    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\okbtn.png");
	    	VerintHomePageScreen.clickCalOK();
	    	Thread.sleep(40000);
	    	extent.log(LogStatus.INFO,"shift is scheduled sucessfully");
	    	Thread.sleep(3000);
	    	//extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "shiftSchedule"));
	    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\buuton_publishschedule.png");
	    	
	    	VerintHomePageScreen.clickyes();
	    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\btnok_schedule.png");
	    	VerintHomePageScreen.clickyes();
	    	extent.log(LogStatus.INFO,"shift is published sucessfully");
	    	Thread.sleep(3000);
	    	//extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "shiftpublished"));
	    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\OK.png");
	    	driver.switchTo().defaultContent();
	    	Thread.sleep(2000);
	    	VerintHomePageScreen.selectMenuItem(driver,"User Management", "Work Rules");
	    	WorkRulesScreen.findEmployee(driver,EmpName);
	    	WorkRulesScreen.SelectEmployee(driver, EmpName);
	    	WorkRulesScreen.WorkPatternremove(driver);
	    	WorkRulesScreen.clickSave(driver);
	    	extent.log(LogStatus.INFO,"work pattern with  shifft and overtime is removed successfully");
	    	extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Work Pattern_admin"));
	    	driver.switchTo().defaultContent();
	    }
	    catch(Exception e)
	    {
	    	e.printStackTrace();
	    }
	    finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM_REG",HTMLReportName,4,49);
		}
		return flag;
	
}
}
