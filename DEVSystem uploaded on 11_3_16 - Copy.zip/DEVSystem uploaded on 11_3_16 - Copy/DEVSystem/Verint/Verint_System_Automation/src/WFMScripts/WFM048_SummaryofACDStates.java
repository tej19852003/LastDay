package WFMScripts;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

//import jxl.Sheet;
import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.ie.InternetExplorerDriver;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;

import ScreenObjects.AccessRightsScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.MyRequestsScreen;
import ScreenObjects.ProfilesScreen;
import ScreenObjects.OrgRequestManagement;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.OrganizationSettings;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM048_SummaryofACDStates {
	
	public static ExtentReports extent = ExtentReports.get(WFM048_SummaryofACDStates.class);
	
	public static boolean Create_Summary() throws Exception
	{		
		boolean flag=true;
		String HTMLReportName="WFM048_SummaryofACDStates"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "View summary of ACD States");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("WFM_RegressionTestSet");
	    //Sheet testID=Wb.getSheet("TestIds");
	    String parentorg = Ws.getCell(7,45).getContents();
	    String EmpName =Ws.getCell(16,45).getContents();
	    //String organizationDesc = Ws.getCell(6,1).getContents();
	    //String parentOrganization = Ws.getCell(7,1).getContents();
		
		try
		{	
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("WFMPlannerName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("WFMPlannerPassword"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}	
			
			
			
			VerintHomePageScreen.selectMenuItem(driver,"Tracking","Menu_Adherence");
			Thread.sleep(5000);
			
			
			Utilities.selectLeftTreeFrame(driver);
			ProfilesScreen.FindSelect(driver,EmpName);
			Thread.sleep(2000);
			driver.switchTo().defaultContent();
			Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\enter_date.png","0");
			Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\btnok_adherence.png");
			Thread.sleep(2000);
			Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\click_agent.png");
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Adherence Screen"));
			driver.switchTo().defaultContent();
						
			
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM_REG",HTMLReportName,4,45);
		}
		return flag;
	}


	

}
