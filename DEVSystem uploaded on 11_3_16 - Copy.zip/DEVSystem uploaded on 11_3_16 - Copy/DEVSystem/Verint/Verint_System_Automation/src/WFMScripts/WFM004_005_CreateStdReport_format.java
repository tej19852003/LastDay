package WFMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import ScreenObjects.LoginScreen;
import ScreenObjects.RequestsResultsScreen;
import ScreenObjects.VerintHomePageScreen;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM004_005_CreateStdReport_format {
	
	public static ExtentReports extent = ExtentReports.get(WFM004_005_CreateStdReport_format.class);
	
	public static boolean Create_Standard_report_format() throws Exception
	{		
		boolean flag=true;
		String mainWinID1="";
		String HTMLReportName="Create_Standard_report"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Create Standard Report");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("WFM_RegressionTestSet");
	    String ReportSelection = Ws.getCell(60,28).getContents();
	    String ReportName = Ws.getCell(61,28).getContents();
	    String ReportNote = Ws.getCell(62,28).getContents();
		
		try
		{				    
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","user_profiles"))
			//if (driver.findElements(By.linkText("Profiles")).size()==0)
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","user_profiles"))
				//if (driver.findElements(By.linkText("Profiles")).size()==0)
				{
					extent.log(LogStatus.WARNING, "Not able to select Profiles menu. Please try again");
					return flag=false;
				}			
			}
			//fetch emp count
			Utilities.selectLeftTreeFrame(driver);
			String 	allEmpCount=driver.findElement(By.xpath("//table[@id='selectionHdr_tbl_id']/tbody/tr/td[1]")).getText();
			System.out.println("profiles emp count:"+allEmpCount);
			int valrcProf=driver.findElements(By.xpath("//table[@id='psLIST_TBL_NAME']/tbody/tr")).size();
			if (valrcProf>1)
			{
				driver.findElement(By.xpath("//table[@id='psLIST_TBL_NAME']/tbody/tr[1]/td/div/nobr/a/span")).click();
				Thread.sleep(2000);
			}
			
			driver.switchTo().defaultContent();
			if (!VerintHomePageScreen.selectMenuItem(driver,"Reports","Instances"))
			//if (driver.findElements(By.linkText("Instances")).size()==0)
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Reports","Instances"))
				//if (driver.findElements(By.linkText("Instances")).size()==0)
				{
					extent.log(LogStatus.WARNING, "Not able to select Instances menu. Please try again");
					return flag=false;
				}			
			}
			if (!RequestsResultsScreen.selectReportSelection(driver, ReportSelection))
			{
				return flag=false;
			}
			driver.switchTo().defaultContent();
			if (driver.findElements(By.linkText("Parameters")).size()!=0)
			{
				driver.findElement(By.linkText("Parameters")).click();
			}
			else
			{
				extent.log(LogStatus.WARNING, "Parameters section is not displayed. Please try again");
				return flag=false;
			}
			Utilities.selectRightPaneView(driver);
			if (!RequestsResultsScreen.setReportName(driver, ReportName))
			{
				return flag=false;
			}
			if (!RequestsResultsScreen.setReportNote(driver, ReportNote))
			{
				return flag=false;
			}
			if(!RequestsResultsScreen.selectformat(driver,"PDF"))
			{
				return flag=false;
			}
			Thread.sleep(3000);
			if (!RequestsResultsScreen.clickRunNow(driver))
			{
				return flag=false;
			}
			//new window 
			Thread.sleep(15000);
			Set<String> windowIds1 = driver.getWindowHandles();
			Iterator<String> itererator = windowIds1.iterator(); 			
			mainWinID1 = itererator.next();//main window 
			String  popWindow1 = itererator.next();//report window
			driver.switchTo().window(popWindow1);
			Thread.sleep(2000);
			driver.manage().window().maximize();
			System.out.println(mainWinID1);
			System.out.println(popWindow1);
			if (popWindow1==null)
			{
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "WFMReport"));
				return flag=false;
			}
			driver.switchTo().defaultContent();
			
			Thread.sleep(2000);
			//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\close.png");
			//driver.switchTo().defaultContent();
			driver.close();
			driver.switchTo().window(mainWinID1);
			Thread.sleep(3000);
			//driver.switchTo().defaultContent();
			if (driver.findElements(By.linkText("Instances")).size()!=0)
			{
				driver.findElement(By.linkText("Instances")).click();
			}
			else
			{
				extent.log(LogStatus.WARNING, "Instances section is not displayed. Please try again");
				return flag=false;
			}
			RequestsResultsScreen.reportExist(driver, ReportName);
			RequestsResultsScreen.clickdelete(driver);
			Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\btnok_camp.png");
			Thread.sleep(2000);
			//driver.switchTo().defaultContent();
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM_REG",HTMLReportName,4,28);
		}
		return flag;
	}


	

}
