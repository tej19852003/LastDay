package WFMScripts;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;

import ScreenObjects.ActivitiesScreen;
import ScreenObjects.AutoProcessingScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.ProfilesScreen;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.RuleSettingsScreen;
import ScreenObjects.VerintHomePageScreen;

import ScreenObjects.OrganizationSettings;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM068_AutoApprovalCustomShiftRequestRule{
	
	public static ExtentReports extent = ExtentReports.get(WFM068_AutoApprovalCustomShiftRequestRule.class);
	
	public static boolean Rule_autoapprovecustomshift() throws Exception
	{		
		boolean flag=true;
		String HTMLReportName="Auto approve custom Shift"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Auto approve custom Shift");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("WFM_RegressionTestSet");
	    String rule=Ws.getCell(37,7).getContents();
	    
	    
		
		try
		{		   
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			
			if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Organization_AutoProcessing"))
			{
				extent.log(LogStatus.WARNING, "Not able to select auto processing from organization tab. Please try again");
				return flag=false;
			}	
			
			
			
			AutoProcessingScreen.clickcreate(driver);
			AutoProcessingScreen.clickshift(driver);
			AutoProcessingScreen.selectorg(driver);
			AutoProcessingScreen.selectshft(driver);
			AutoProcessingScreen.selectautoapprove(driver);
			AutoProcessingScreen.clickautoapprove(driver);
			AutoProcessingScreen.clickSave(driver);
			extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "AutoProcessingPage"));
			
			AutoProcessingScreen.selectrule(driver,rule);
			AutoProcessingScreen.clickdelete(driver);
			Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\btnok_delrule.png");
	    	Thread.sleep(3000);
	    	extent.log(LogStatus.INFO,"Rule is deleted sucessfully");
	    	extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "RulePage"));
	    	driver.switchTo().defaultContent();
			
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM_REG",HTMLReportName,4,7);
		}
		return flag;
	}

}
