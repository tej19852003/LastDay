package WFMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.python.modules.thread.thread;
import org.sikuli.basics.proxies.Mat;

import ScreenObjects.CampaignSettings;
import ScreenObjects.ForecastScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.OrganizationSettings;
import ScreenObjects.PulseScreen;
import ScreenObjects.ServiceGoals;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.WorkQueuesScreen;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM015_016_CreateViews
{
	public static ExtentReports extent = ExtentReports.get(WFM015_016_CreateViews.class);
	
	public static boolean Create_CheckView()throws Exception
	{
		boolean flag=true;
		String windowName="";
		String HTMLReportName="WFM015_016_CreateViews"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Create Views and check views");
				
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 			
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);
	    Sheet Ws = Wb.getSheet("WFM_RegressionTestSet");
	    String campName=Ws.getCell(28,16).getContents();
	    String StartDate=Ws.getCell(32,16).getContents();
	    String OrgName=Ws.getCell(5,16).getContents();
	    String Period=Ws.getCell(29,16).getContents();
	    String wqname=Ws.getCell(31,16).getContents();
	    String wqname2=Ws.getCell(43,16).getContents();
	    String WqDesc=Ws.getCell(35,16).getContents();	
	    String organizationDesc = Ws.getCell(6,16).getContents();
	    String parentOrganization = Ws.getCell(7,16).getContents();
	    
	    
	    try
	    {
	    	LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
	    	if(!LoginScreen.verifyLoginPageLaunched(driver))
	    	{
	    		return flag=false;
	    	}
	    	LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
	    	if(!VerintHomePageScreen.verifyVerintHomePage(driver))
	    	{
	    		return flag=false;
	    	}
	    	String mainwindow=driver.getWindowHandle();
	    	VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings");
	    	Utilities.selectLeftTreeFrame(driver);
	    	if(CampaignSettings.CampaignExist(driver, campName))
	    	{
	    		CampaignSettings.deleteCampaign(driver);
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\btnok_camp.png");
		    	Thread.sleep(3000);
		    	driver.switchTo().defaultContent();
	    	}
	    	else
	    	{
	    		System.out.println("no campaign exist");
	    	}
	    	driver.switchTo().defaultContent();
	    	VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Organization Settings");
	    	Utilities.selectLeftTreeFrame(driver);
			Boolean Temp1=false;			
			int rc1=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
			//System.out.println("rc1:"+rc1);
			for (int j=1;j<=rc1;j++)
			{
				if (j<=15)
				{
				String orgName1=driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).getText();
				Thread.sleep(1000);
				if (orgName1.contains(OrgName))
				{
					driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a")).click();
					Temp1=true;
					break;
				}}
			}
			if (Temp1==true)
			{
				System.out.println("org already exist");
				extent.log(LogStatus.INFO, "Organization Name: "+OrgName+" already exist");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Organization"));								
			}			
			//end of verify organization
			//create organization
			if (Temp1==false)
			{
				Utilities.selectLeftTreeFrame(driver);
				if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,parentOrganization))
				{
					return flag=false;
				}
				Utilities.selectRightPaneView(driver);
				if (!OrganizationSettings.clickCreateOrganization(driver))
				{
					return flag=false;
				}
				OrganizationSettings.setOrganizationName(driver,OrgName);
				OrganizationSettings.setOrganizationDescription(driver,organizationDesc);
				OrganizationSettings.isSelectedDaysAndHoursOfOperation(driver);
				if (!OrganizationSettings.clickSave(driver))
				{
					return flag=false;
				}
			}
			driver.switchTo().defaultContent();
	    	Thread.sleep(2000);
	    	VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Work Queues Settings");
	    	//verify if work queue already exist
	    	Utilities.selectRightPaneView(driver);
	    	boolean flag1=false;
	    	int qrows=driver.findElements(By.xpath("//div[@id='workAreaWrapper']//table[@id='workpaneListWrapper']//tbody//tr")).size();
	    	System.out.println("no of rows in work queue are:" + qrows);
	    	for(int j=0;j<qrows;j++)
	    	{
	    		String qname=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']//tbody//tr[@id='workpaneListr"+j+"']//th//a//span")).getAttribute("innerText");
	    		System.out.println("work queue name is" + qname);
	    		if(qname.contains(wqname))
	    		{
	    			flag1=true;
	    			break;
	    		}
	    	}
	    	if(flag1==true)
	    	{
	    		extent.log(LogStatus.PASS,"work queue already exist");
	    	}
	    	//creation of new work queue
	    	else
	    	{
	    		WorkQueuesScreen.clickworkqueue(driver);
				WorkQueuesScreen.setWorkqueueName(driver, wqname);
				WorkQueuesScreen.setWorkqueueDescription(driver,WqDesc);
				WorkQueuesScreen.clickSave(driver);
	    	}
	    	driver.switchTo().defaultContent();
	    	if(!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings"))
	    	{
	    		Utilities.Logout(driver);
	    		LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
	    		if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
	    		driver.switchTo().defaultContent();
	    		
				if (!VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Compaign Settings"))
				{
					extent.log(LogStatus.WARNING, "Not able to select Compaign Settings menu. Please try again");
					return flag=false;
				}
	    	}
				//verify whether Compaign name is already exist or not		
				Utilities.selectLeftTreeFrame(driver);
				/*boolean Temp=false;
				int rc=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
				System.out.println("rc:"+rc);
				for (int i=1;i<=rc;i++)
				{
					if (i<=15)
					{
					String campNameApp=driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr["+i+"]/td/a")).getText();
					System.out.println(i+":"+campNameApp);
					if (campNameApp.contains(campName))
					{
						driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr["+i+"]/td/a")).click();
						Thread.sleep(3000);
						Temp=true;
						break;
					}}
				}*/
				if(CampaignSettings.CampaignExist(driver, campName))
				{
					extent.log(LogStatus.PASS, "Compaign Name:"+campName+" already exist");
					extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Campaign"));
				}
				
				//end of verify campaign
				//create campaign
				else
				{
					Utilities.selectRightPaneView(driver);
					
					if (!CampaignSettings.clickCreateCampaign(driver))
					{
						return flag=false;
					}
					CampaignSettings.setCampaignName(driver,campName);
					CampaignSettings.setCampaignDescription(driver,".AutomationDescCampaign");				
					if (!CampaignSettings.clickSave(driver))
					{
						return flag=false;
					}
					Utilities.selectLeftTreeFrame(driver);
					if (!CampaignSettings.selectCampaignFromLeftTreeFrame(driver,campName))
					{
						return flag=false;
					}
	    	}
				Utilities.selectRightPaneView(driver);
				
				
				CampaignSettings.clickSave(driver);
				System.out.println("clicked on save");
				Thread.sleep(2000);
				Utilities.selectLeftTreeFrame(driver);
				Thread.sleep(2000);
				if(driver.findElements(By.xpath("//img[@id='campaignSPTreer0Norg']")).size()!=0)
				{
					driver.findElement(By.xpath("//img[@id='campaignSPTreer0Norg']")).click();
				}
				//driver.findElement(By.xpath("//img[@id='campaignSPTreer0Norg']")).click();
				
				/*boolean Temp3=false;
				driver.findElement(By.xpath("//img[@id='campaignSPTreer0Norg']")).click();
				int rc2=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table//tr[starts-with(@id,'campaignSPTreer0r')]")).size();
				System.out.println("rc:"+rc2);
				if (rc2>0)
				{
					driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr[1]/td/a")).click();
				}
				for (int i=0;i<rc2;i++)
				{
					
					
					String queuename=driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr[@id='campaignSPTreer0r"+i+"']/td/a")).getText();
					System.out.println(queuename);
					if (queuename.contains(Period))
					{
						System.out.println("schedule period exist");
						driver.findElement(By.xpath("//table[@id='campaignSPTree_id']/tbody/tr[@id='campaignSPTreer0r"+i+"']/td/a")).click();
						
						Temp3=true;
						break;
						
					}
				}*/
				if(CampaignSettings.schedulePeriodExist(driver, Period))
				{
					extent.log(LogStatus.INFO,"schedule period:" + Period + "already exist");
				}
				else
				{
					CampaignSettings.clickSchedulingPeriod(driver);
					Utilities.selectRightPaneView(driver);
					CampaignSettings.setSchedulingPeriodStartDate(driver, StartDate);
					
					if(!CampaignSettings.clickSchedulingPeriodPSave(driver))
					{
						return flag=false;
					}
					CampaignSettings.setCampaignDescription(driver,".AutomationDescCampaign");
					CampaignSettings.clickOrganizationSelector(driver);
					for(String winHandle :driver.getWindowHandles())
					{
		                driver.switchTo().window(winHandle);
		                System.out.println("title:"+driver.getTitle());
		                if(driver.getTitle().contains("Organization Selector"))
		                {                	
		                	System.out.println("You are in organization selector window");
		                	driver.manage().window().maximize();
		                    break;
		                }	
					}
//					windowName=Utilities.setWindowFocus(driver);
					CampaignSettings.selectOrganizationSelector(driver, OrgName);
					driver.switchTo().window(mainwindow);
					CampaignSettings.selectHoursOfOperation(driver);
				}
				
				Thread.sleep(2000);
				if(!CampaignSettings.clickCampaignSettingsSave(driver))
				{
					return flag=false;
				}
				Thread.sleep(2000);
				driver.switchTo().defaultContent();
				CampaignSettings.clickQueue(driver);
				Thread.sleep(3000);
				
				CampaignSettings.selectSchedulePeriod(driver, Period);
				/*boolean temp2=false;
		    	Utilities.selectRightPaneView(driver);
		    	
		    	int row=driver.findElements(By.xpath("//div[@id='tableWrapper']//table[@id='tableRef']//tbody//tr//th")).size();
		    	System.out.println("no of row count  in work pattern iis: "+ row);
		    	if(row>0)
		    	{
		    	String workqname=driver.findElement(By.xpath("//table[@id='tableRef']//tbody//tr[@id='tabler0']//th[@id='tabler0c0']//a")).getAttribute("innerText");
		    	System.out.println("work pattern name is: "+ workqname);
		    	if(workqname.contains(wqname))
		    	{
		    		temp2 = true;
		    	}*/
		    	/*if(CampaignSettings.workqueueExist(driver, wqname))
		    	{
		    		extent.log(LogStatus.INFO,"work pattern:" +wqname+ " is already added to the campaign queues");
		    	}*/
		    
				CampaignSettings.clickAddSP(driver);
				Thread.sleep(2000);
				for(String winHandle :driver.getWindowHandles())
				{
	                driver.switchTo().window(winHandle);
	                System.out.println("title:"+driver.getTitle());
	                if(driver.getTitle().contains("Add to SP"))
	                {                	
	                	System.out.println("You are in Add to SP window");
	                	driver.manage().window().maximize();
	                    break;
	                }	
				}
//				 String winhandle=Utilities.setWindowFocus(driver);
				CampaignSettings.selectWorkQueue(driver);
				driver.switchTo().window(mainwindow);
		    	
				if(!CampaignSettings.clickCampaignSettingsSave(driver))
				{
					return flag=false;
				}
				driver.switchTo().defaultContent();
				Thread.sleep(3000);
				//go to forecast menu and set the values
				
				VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","Forecast");
		    	Thread.sleep(3000);
		    	ForecastScreen.selectCampaign(driver, campName);
		    	//ForecastScreen.selectCampaign(driver,campName);
		    	//ForecastScreen.selectPeriod(driver, Period);
		    	ForecastScreen.setPeriod(driver, Period);
		    	Thread.sleep(2000);
		    	ForecastScreen.selectworkQueue(driver, wqname);
		    	Thread.sleep(3000);
		    	driver.switchTo().defaultContent();
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\btn_clear.png");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Button_Scale.png");
		    	
		    	Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\value_total.png","15");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\value_sun.png");
		       
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\button_set.png");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Save_scale.png");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Save_popup.png");
		    	
		    	//Utilities.selectLeftTreeFrame(driver);
		    	Thread.sleep(5000);
		    	ForecastScreen.selectworkQueue(driver, wqname);
		    	Thread.sleep(3000);
		    	driver.switchTo().defaultContent();
		    	Thread.sleep(2000);
		    	
		    	VerintHomePageScreen.selectMenuItem(driver,"Forecasting and Scheduling","ServiceGoals");
		    	Thread.sleep(2000);		    	
		    	//ServiceGoals.selectCampaign(driver,campName);
		    	ServiceGoals.setPeriod(driver, Period);
		    	ServiceGoals.selectworkQueue(driver, wqname);
		    	Thread.sleep(2000);
		    	driver.switchTo().defaultContent();
		    	Thread.sleep(3000);
		    	Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\ans.png","0");
		    	Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\seconds.png","0");
		    	Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\ans.png","60");
		    	//Thread.sleep(1000);
		    	
		    	Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\seconds.png","40");
		    	//Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\seconds.png","10");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Save_scale.png");
		    	Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Save_popup.png");
		    	Thread.sleep(2000);
		    	ServiceGoals.selectworkQueue(driver, wqname);
		    	Thread.sleep(2000);
		    	driver.switchTo().defaultContent();
		    	Thread.sleep(2000);
				
				VerintHomePageScreen.selectMenuItem(driver,"Tracking","Pulse");
				
				PulseScreen.setcampaign(driver, campName);
				PulseScreen.selectqueue(driver, wqname);
				Thread.sleep(2000);
				driver.switchTo().defaultContent();
				Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\CreateViewButton.png");
				/*int var=(int)(Math.random()*100);
				System.out.println("var is: "+ var);*/
				System.out.println(RandomStringUtils.randomAlphabetic(2));
				Utilities.sikuliType(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Name.png", "test"+RandomStringUtils.randomAlphabetic(2));
				//Utilities.sikuliType(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Statistics_Description.png", "test1");
				Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\AddStatisticsButton.png");
				Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Statistics_actual.png");
				Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Statistics_forecasted.png");
				Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Statistics_forecasted.png");
				Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Statistics_forecasted.png");
				Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Save_statistics.png");
				extent.log(LogStatus.INFO,"view is created sucessfully");
				Thread.sleep(3000);
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "views"));
				driver.switchTo().defaultContent();
		    	driver.findElement(By.id("utilityPanePC_LOGOUT_spn_id")).click();
		    	
		    	Thread.sleep(3000);
		    	//login with forecaster
		    	LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("WFMForecasterUserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("WFMForecasterPassword"));
				LoginScreen.clickLogin(driver);
				VerintHomePageScreen.selectMenuItem(driver,"Tracking","Pulse");
				
				PulseScreen.setcampaign(driver, campName);
				PulseScreen.selectqueue(driver, wqname);
				Thread.sleep(2000);
				extent.log(LogStatus.INFO, "view is present on screen in zoom in mode");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "view"));
				driver.switchTo().defaultContent();
				Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Zoom_out_view.png");
				extent.log(LogStatus.INFO, "view is present on screen in zoom in mode");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "view_zoomout"));
				Thread.sleep(2000);
		    	
				
		    	
		    	
				
				
				
	    }
	    catch(Exception e)
	    {
	    	e.printStackTrace();
	    }
	    finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM_REG",HTMLReportName,4,16);
		}
		return flag;
	
}
}
