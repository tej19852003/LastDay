package WFMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;

//import ScreenObjects.AlertRulesOrganizationScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.NewRoleScreen;
import ScreenObjects.OrganizationSettings;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.VerintHomePageScreen;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM28_Notify_Agent_Status {
	
	
	public static ExtentReports extent = ExtentReports.get(WFM28_Notify_Agent_Status.class);
	public static Screen sobj = new Screen ();
	public static boolean Notify_Agent_Status() throws Exception
	{
		
		boolean flag=true;
		String HTMLReportName="WFM28_Notify_Agent_Status"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Notify_Agent_Status");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("WFM_RegressionTestSet");
	    String RuleName = Ws.getCell(37,12).getContents();	    
	    String organizationParent = Ws.getCell(7,12).getContents();  
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"Tracking","Tracking_Organization"))
			
			{
				Utilities.Logout(driver);				
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Tracking","Tracking_Organization"))		
				
				{
					extent.log(LogStatus.WARNING, "Organization section is not displayed. Please try again.");
					return flag=false;
				}
			}
			//select state farm organization
			Utilities.selectLeftTreeFrame(driver);
			if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,organizationParent))
			{
				return flag=false;
			}
			
			/*if (!AlertRulesOrganizationScreen.clickCreateRuleName(driver))
			{
				return flag=false;
			}
			
			if (!AlertRulesOrganizationScreen.setRuleName(driver,RuleName))
			{
				return flag=false;
			}
			if (!AlertRulesOrganizationScreen.selectActionSendEmail(driver))
			{
				return flag=false;
			}
			if (!AlertRulesOrganizationScreen.selectEmployees(driver))
			{
				return flag=false;
			}
			if (!AlertRulesOrganizationScreen.selectDirectSupervisors(driver))
			{
				return flag=false;
			}
			if (!AlertRulesOrganizationScreen.clickSave(driver))
			{
				return flag=false;
			}
			if (!AlertRulesOrganizationScreen.verifyRuleName(driver,RuleName)) //test this method
			{
				return flag=false;
			}			
			if (!AlertRulesOrganizationScreen.clickDelete(driver)) //test this method
			{
				return flag=false;
			}*/
			Thread.sleep(2000);
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Delete_OK.png")!=null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Delete_OK.png");
				flag=true;
				Thread.sleep(6000);							
			}
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM_RegressionTestSet",HTMLReportName,4,12);
		}
		return flag;
	}


}
