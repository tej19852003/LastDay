package WFMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.Screen;

import ScreenObjects.LoginScreen;
import ScreenObjects.RequestsResultsScreen;
import ScreenObjects.VerintHomePageScreen;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM052_053_Send_Recieve_PopUpMessage {
	
	public static ExtentReports extent = ExtentReports.get(WFM052_053_Send_Recieve_PopUpMessage.class);
	
	public static boolean Send_Recieve_PopUp_Message() throws Exception
	{		
		Screen sobj = new Screen ();
		boolean flag=true;
		String mainWinID1="";
		String HTMLReportName="Send_Recieve_PopUp_Message"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Send and Recieve PopUp Message");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("WFM_RegressionTestSet");
	    String agentName=Ws.getCell(13, 60).getContents();
	    
	  
		try
		{				    
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			String mainwindow=driver.getWindowHandle();
			
				WebElement tabName = (new WebDriverWait(driver,20)).until(ExpectedConditions.elementToBeClickable(By.xpath("//button[@id='utilityPanePC_POPUP_SENDMSG_spn_id']")));
				//WebElement tabName = driver.findElement(By.linkText(linkText));
				Actions action = new Actions(driver);
				action.moveToElement(tabName).build().perform();
				Thread.sleep(2000);
				
				
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\menu_internal_message.png") != null)
				{
					
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\menu_internal_message.png");	
					extent.log(LogStatus.INFO, "Internal message menu is selected from Send Message Menu");
					flag=true;
				}			
				Thread.sleep(1000);
				
				
				
				for(String winHandle :driver.getWindowHandles())
				{
	                driver.switchTo().window(winHandle);
	                System.out.println("title:"+driver.getTitle());
	                if(driver.getTitle().equals("Send Message"))
	                {                	
	                	System.out.println("You are in Send Message window");
	                	driver.manage().window().maximize();
	                    break;
	                }	
				}
				driver.findElement(By.xpath("//button[@id='workpaneMediator_toolbar_Employee_GN41_ID']//img[@alt='Employee Selector']")).click();
				Thread.sleep(5000);
				for(String winHandle :driver.getWindowHandles())
				{
	                driver.switchTo().window(winHandle);
	                System.out.println("title:"+driver.getTitle());
	                if(driver.getTitle().equals("Employee Selector"))
	                {                	
	                	System.out.println("Employee Selector windodw");
	                	driver.manage().window().maximize();
	                    break;
	                }	
				}
				Thread.sleep(5000);
				driver.switchTo().defaultContent();
				driver.findElement(By.xpath("//input[@id='firstName_0']")).sendKeys(agentName);
				driver.findElement(By.xpath("//button[@id='workpaneMediator_toolbar_NEXT_ACTIONLabel']")).click();
				driver.findElement(By.xpath("//table[@id='tableRef']//tr[@id='tabler0']//th[@id='tabler0c0']//a")).click();
				driver.findElement(By.xpath("//button[@id='workpaneMediator_toolbar_SET_ACTIONLabel']")).click();
				extent.log(LogStatus.PASS,"Employee is selected Succesfully");
				Thread.sleep(2000);
				for(String winHandle : driver.getWindowHandles())
				{
				    driver.switchTo().window(winHandle);
				    System.out.println("title:"+driver.getTitle());
				}
				driver.findElement(By.xpath("//input[@id='sLText41']")).sendKeys("Test");
				driver.findElement(By.xpath("//textarea[@id='notificationMessageText41']")).sendKeys("Test123");
				driver.findElement(By.xpath("//button[@id='workpaneMediator_toolbar_ACTION_SEND_MESSAGE_INTERNALLabel']")).click();
				
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\message_success.png") != null)
				{				
					Thread.sleep(2000);
					extent.log(LogStatus.PASS, "Success Message:Internal message sent successfully is displayed successfully");
					extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "IntetrnalMessageSucess"));
					System.out.println("success msg");
					flag=true;
					
				}
				else
				{
					extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "InternalMessageFailure"));
					flag=false;
				}
				Thread.sleep(2000);
				driver.findElement(By.xpath("//button[@id='workpaneMediator_toolbar_DONE_ACTIONLabel']")).click();
				System.out.println("clicked on done");
				Thread.sleep(2000);
				System.out.println("done");
				/*for(String winHandle : driver.getWindowHandles())
				{
				    driver.switchTo().window(winHandle);
				    System.out.println("title:"+driver.getTitle());
				}*/
				driver.switchTo().window(mainwindow);
				//driver.switchTo().defaultContent();
		    	driver.findElement(By.id("utilityPanePC_LOGOUT_spn_id")).click();
		    	
		    	Thread.sleep(3000);
		    	//Login with the agent1  and request for shift swap
		    	//driver.findElement(By.id("username")).clear();
		    	LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("Agen1tUserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Agent1Password"));
				LoginScreen.clickLogin(driver);
				
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\icon_message.png") != null)
				{
					
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\icon_message.png");	
					extent.log(LogStatus.INFO, "Icon Message is clicked successfully");
					flag=true;
				}			
				Thread.sleep(1000);
				List<WebElement> li=driver.findElements(By.xpath("//table[@id='MyNotificationTreeWrapper']//tr[starts-with(@id,'MyNotificationTreer')]"));
				System.out.println("size is:" + li.size());
				for(WebElement elt:li)
				{
					if(elt.getText().contains("Unread"))
					{
					List<WebElement> li2=elt.findElements(By.tagName("td"));
					System.out.println("size of list 2 is:" +li2.size());
					for(WebElement elt2:li2)
					{
						System.out.println("element name is::::" + elt2.getText());
						String wname=elt2.getText();
					
						if(wname.contains("Automation ADMIN, OH0798 (Person)"))
						{
							elt2.click();
							
							extent.log(LogStatus.PASS,"Message with user name is selected");
							flag=true;
							break;
						}
						
					}	
					
					}
					
				}
				
				driver.findElement(By.xpath("//button[@id='toolbar_VIEW_ACTIONLabel']")).click();
				Thread.sleep(2000);
				driver.findElement(By.xpath("//button[@id='toolbar_DONE_ACTIONLabel']")).click();
				Thread.sleep(2000);
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "MessageRead"));
				System.out.println("MessageRead");
				
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			
			System.out.println("in finally block");
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM_REG",HTMLReportName,4,60);
		}
		return flag;
	}


	

}
