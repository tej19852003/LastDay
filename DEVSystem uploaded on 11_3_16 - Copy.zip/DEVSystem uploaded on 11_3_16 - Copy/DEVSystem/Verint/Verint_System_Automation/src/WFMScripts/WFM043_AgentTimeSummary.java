package WFMScripts;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.PrintWriter;

import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import ScreenObjects.CalendarScreen;
import ScreenObjects.CampaignSettings;
import ScreenObjects.FSEmployees;
import ScreenObjects.ForecastScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.OrganizationSettings;
import ScreenObjects.ProfilesScreen;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.ScheduleScreen;
import ScreenObjects.ServiceGoals;
import ScreenObjects.WorkQueuesScreen;

import ScreenObjects.VerintHomePageScreen;


import Utilities.Utilities;
import org.sikuli.script.Screen;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class WFM043_AgentTimeSummary 
{
	
	public static ExtentReports extent = ExtentReports.get(WFM043_AgentTimeSummary.class);
	
	public static boolean ViewAgent_Schedule() throws Exception
	{		
		boolean flag=true;
		String windowName="";
		String HTMLReportName="WFM043_AgentTimeSummary"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "View Agent schedules");
				
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 			
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_WFM"));
	    Workbook Wb = Workbook.getWorkbook(fis);
	    Sheet Ws = Wb.getSheet("WFM_RegressionTestSet");
	   // Sheet testID=Wb.getSheet("TestIds");
	    String campName=Ws.getCell(28,43).getContents();
	    String StartDate=Ws.getCell(32,43).getContents();
	    String OrgName=Ws.getCell(5,43).getContents();
	    String Period=Ws.getCell(29,43).getContents();
	    String wqname=Ws.getCell(31,43).getContents();
	    String EmpName =Ws.getCell(16,43).getContents();
	    String workQueue=Ws.getCell(31,43).getContents();
	    String FirstName=Ws.getCell(13,43).getContents();
	    String LastName=Ws.getCell(12,43).getContents();
	    String agentname=Ws.getCell(16,43).getContents();
	    String WqDesc=Ws.getCell(35,43).getContents();	
	    String organizationDesc = Ws.getCell(6,43).getContents();
	    String parentOrganization = Ws.getCell(7,43).getContents();
	    String enddate=Ws.getCell(59,43).getContents();
	    
	    
	    try
	    {
	    	LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
	    	if(!LoginScreen.verifyLoginPageLaunched(driver))
	    	{
	    		return flag=false;
	    	}
	    	
	    	
		    	//login with forecaster
		    	LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("WFMPlannerName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("WFMPlannerPassword"));
				LoginScreen.clickLogin(driver);
				String mainwindow=driver.getWindowHandle();
				
					
					if (!VerintHomePageScreen.selectMenuItem(driver,"Tracking","Tracking_TimeSummary"))
					{
						extent.log(LogStatus.WARNING, "Not able to select Time summary menu. Please try again.");
						return flag=false;
					}
							
				
				
				ProfilesScreen.FindSelect(driver,EmpName);
				Thread.sleep(2000);
				driver.switchTo().defaultContent();
				Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Timeoff_Acrual_calculator.png");
				Thread.sleep(2000);
				for(String winHandle :driver.getWindowHandles()){
	                driver.switchTo().window(winHandle);
	                System.out.println("title:"+driver.getTitle());
	                if(driver.getTitle().contains("Time Off Accrual Calculator"))
	                {
	                	//flag=true;
	                	System.out.println("You are in time off accural calc window");
	                	driver.manage().window().maximize();
	                    break;
	                }			
				}
				
				Thread.sleep(2000);	
				//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Title_TimeOffAccuralCalculator.png");
				driver.switchTo().defaultContent();
				//if (driver.findElements(By.xpath("//table[@id='formTwoColumn_wrapper_tbl_id']/tbody/tr[2]/td[2]/span[@BP_OBJ_TYPE='DATE_PICKER']/input[@name='asOfDate']")).size()!=0)
				if (driver.findElements(By.xpath("//span[@BP_OBJ_TYPE='DATE_PICKER']/input[@name='asOfDate']")).size()!=0)
				{  
					driver.findElement(By.xpath("//span[@BP_OBJ_TYPE='DATE_PICKER']/input[@name='asOfDate']")).click();
					driver.findElement(By.xpath("//span[@BP_OBJ_TYPE='DATE_PICKER']/input[@name='asOfDate']")).clear();
					Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
					Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK1.png");
					driver.findElement(By.xpath("//span[@BP_OBJ_TYPE='DATE_PICKER']/input[@name='asOfDate']")).sendKeys("11/20/2016");
					Thread.sleep(2000);
					Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\WindowsSecurity_OK.png");
				}
				//dropdown
				driver.findElement(By.xpath("//span[@id='activityID_0Wrapper']/nobr/img[@id='activityID_0Button']")).click();
				Thread.sleep(2000);				
				driver.findElement(By.xpath("//span[@id='activityID_0Wrapper']/nobr/img[@id='activityID_0Button']")).sendKeys("Vacation");
				Thread.sleep(3000);
				Robot r1 = new Robot();
				r1.keyPress(KeyEvent.VK_ENTER);
				r1.keyRelease(KeyEvent.VK_ENTER);
				//click on calculate button
				Thread.sleep(2000);
				driver.findElement(By.xpath("//table[@id='workpaneMediator_toolbar_VIEW_ACTIONWrapper']/tbody/tr[1]/td[1]/button[@id='workpaneMediator_toolbar_VIEW_ACTIONLabel']")).click();//calculate
				Thread.sleep(2000);
				extent.log(LogStatus.INFO,"schedule is getting displayed");
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "TimeSummary Screen"));
				//click on done button
				driver.findElement(By.xpath("//table[@id='workpaneMediator_toolbar_DONE_ACTIONWrapper']/tbody/tr[1]/td[1]/button[@id='workpaneMediator_toolbar_DONE_ACTIONLabel']")).click();//done button
				driver.switchTo().window(mainwindow);
		    	
				
		    	
				}   	
				
		
	    catch(Exception e){
			e.printStackTrace();
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			  
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"WFM_REG",HTMLReportName,4,43);
		}
		return flag;
	
	}

}

