package QMScripts;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;
import jxl.Sheet;
import jxl.Workbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.Key;
import org.sikuli.script.KeyModifier;
import org.sikuli.script.Screen;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import ScreenObjects.DataSourceScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.Impact360Screen;
import ScreenObjects.QualityMonitoringSearchScreen;
import Utilities.Utilities;

public class QM128_AddAnnotation_Private {
	public static ExtentReports extent = ExtentReports.get(DataSourceScreen.class);
	public static Screen sobj = new Screen ();
	public static String mainWinID="";
	public static boolean Add_Private_Annotation() throws Exception
	{
		boolean flag=true;
		
		//String mainWinID="";	
		String HTMLReportName="QM128_AddAnnotation_Private"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Add Annotation - Private type");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");	    
	    String NumberOfRecords = Ws.getCell(16,39).getContents();		
		
		try
		{						
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			Thread.sleep(5000);
			if (!VerintHomePageScreen.selectMenuItem(driver,"Interactions","Interactions Contacts"))
			{
				Thread.sleep(5000);
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
				Thread.sleep(6000);
			}
			
			if (!searchRecords_QM_Contacts(driver,NumberOfRecords,"Quality Monitoring"))
			{
				flag=false;
			}
			//select contact start time link
			if (!QualityMonitoringSearchScreen.selectContactsStartTime(driver,""))		//select contact start time	
			{
				return flag=false;
			}			
			
			if (!addAnnotation(driver,"PAnnotation","Private"))
			{
				return flag=false;
			}
			if (!deleteAnnotation(driver,"PAnnotation"))
			{
				return flag=false;
			}
			/*Set<String> windowIds1 = driver.getWindowHandles();
			Iterator<String> itererator = windowIds1.iterator(); 			
			String mainWinID1 = itererator.next();//main window 
			System.out.println(mainWinID1);
			//driver.switchTo().window(mainWinID1).close();
			Thread.sleep(1000);	
			String  popWindow1 = itererator.next();//popup window
			Thread.sleep(2000);	
			driver.switchTo().window(popWindow1);
			driver.close();
			Thread.sleep(3000);
			driver.switchTo().window(mainWinID1);*/
			//Impact360Screen.closeQM(driver);
			}catch(Exception e){
				System.out.println(e);
			}finally{	
				
				Utilities.Logout(driver);
				driver.close();
				driver.quit();
				Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,39);
			}
			return flag;
	}
	public static boolean addAnnotation(WebDriver driver,String AnnotationName,String Type) throws Exception
	{
	
		Thread.sleep(3000);
		driver.switchTo().defaultContent();
		driver.switchTo().frame("FR_PLAYBACK");	
		Thread.sleep(2000);
		driver.switchTo().frame("FR_PLAYBACK");
		
		WebElement oRightPaneContentFrame = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.id("annotationFrame")));
		driver.switchTo().frame(oRightPaneContentFrame);			
		Thread.sleep(3000);
		if (driver.findElements(By.xpath("//img[@title='Add Annotation']")).size()!=0)
		{
			driver.findElement(By.xpath("//img[@title='Add Annotation']")).click();
		}
		Thread.sleep(3000);
		boolean temp=false;
		String parentHandle = driver.getWindowHandle();
		for(String winHandle :driver.getWindowHandles()){
            driver.switchTo().window(winHandle);
            System.out.println("title:"+driver.getTitle());
            if(driver.getTitle().contains("Add Annotation"))
            {
            	temp=true;
            	System.out.println("You are in Annotation window");
            	if (driver.findElements(By.xpath("//table[@class='tableAnnotationsNoBorder']/tbody/tr[3]/td[2]/input[@id='AnnotationNameTextBox']")).size()!=0)
            	{
            		driver.findElement(By.xpath("//table[@class='tableAnnotationsNoBorder']/tbody/tr[3]/td[2]/input[@id='AnnotationNameTextBox']")).sendKeys(AnnotationName);
            	}
            	Thread.sleep(3000);
            	//public
            	if (Type.contains("Public"))
            	{
	            	if (driver.findElements(By.xpath("//table[@id='AnnotationAccessRadioButtonList']/tbody/tr/td[2]/input[@id='AnnotationAccessRadioButtonList_1'][@type='radio']")).size()!=0)
	            	{
	            		driver.findElement(By.xpath("//table[@id='AnnotationAccessRadioButtonList']/tbody/tr/td[2]/input[@id='AnnotationAccessRadioButtonList_1'][@type='radio']")).click();
	            		extent.log(LogStatus.INFO, "Add Annotation type : Public is selected");
	            	}
	            	else
	            	{
	            		extent.log(LogStatus.WARNING, "Add Annotation type : Public is NOT selected");	
	            	}
	            }
            	if (Type.contains("Private"))
            	{
	            	if (driver.findElements(By.xpath("//table[@id='AnnotationAccessRadioButtonList']/tbody/tr/td[1]/input[@id='AnnotationAccessRadioButtonList_0'][@type='radio']")).size()!=0)
	            	{
	            		driver.findElement(By.xpath("//table[@id='AnnotationAccessRadioButtonList']/tbody/tr/td[1]/input[@id='AnnotationAccessRadioButtonList_0'][@type='radio']")).click();
	            		extent.log(LogStatus.INFO, "Add Annotation type : Private is selected");
	            	}
	            	else
	            	{
	            		extent.log(LogStatus.WARNING, "Add Annotation type : Private is NOT selected");	
	            	}
	            }
            	/*if (driver.findElements(By.xpath("//table[@class='tblButtons']/tbody/tr/td/table/tbody/tr/td[2]/a[@id='OKButton_OKButton'][@title='OK']")).size()!=0)
            	{
            		driver.findElement(By.xpath("//table[@class='tblButtons']/tbody/tr/td/table/tbody/tr/td[2]/a[@id='OKButton_OKButton'][@title='OK']")).click();
            		System.out.println("OK without Sik");
            	}*/
            	Thread.sleep(2000);
            	if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_WebPortalPref_OK.png") != null)
    			{
            		System.out.println("inside OK sik");
    				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_WebPortalPref_OK.png");
    			}                	
                break;
            }			
		}
		return temp;
	}
	public static boolean deleteAnnotation(WebDriver driver,String AnnotationName) throws Exception
	{
		
		//delete annotation
		Thread.sleep(2000);
		Set<String> windowIds3 = driver.getWindowHandles();
		Iterator<String> itererator3 = windowIds3.iterator(); 			
		String mainWinID3 = itererator3.next();//main window 			
		Thread.sleep(1000);	
		String  popWindow3 = itererator3.next();//popup window
		Thread.sleep(2000);	
		driver.switchTo().window(popWindow3);
		System.out.println("title:"+driver.getTitle());
		Thread.sleep(2000);
		driver.switchTo().defaultContent();
		driver.switchTo().frame("FR_PLAYBACK");	
		Thread.sleep(2000);
		driver.switchTo().frame("FR_PLAYBACK");
		
		WebElement annotationFrame3 = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.id("annotationFrame")));
		driver.switchTo().frame(annotationFrame3);			
		Thread.sleep(2000);
		boolean Temp3=false;
		int rcAccRt3=driver.findElements(By.xpath("//table[@id='tableAnnotations']/tbody/tr")).size();
		System.out.println("rcAccRt:"+rcAccRt3);
		for (int a=1;a<=rcAccRt3;a++)
		{
			
			String empApp=driver.findElement(By.xpath("//table[@id='tableAnnotations']/tbody/tr["+a+"]/td[2]/a")).getText().trim();
			System.out.println("empApp:"+empApp);
			Thread.sleep(1000);
			if (empApp.contains(AnnotationName))
			{																
				driver.findElement(By.xpath("//table[@id='tableAnnotations']/tbody/tr["+a+"]/td[2]/a")).click();
				Thread.sleep(2000);
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_WebPortalPref_OK.png") != null)
    			{
    				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_WebPortalPref_OK.png");
    				Thread.sleep(2000);
    			}
				Temp3=true;
				break;
			}
		}
		if (Temp3==true)
		{				
			extent.log(LogStatus.PASS, "Name: UpdatedAutomationTest Created/Selected successfully");								
		}
		else
		{
			extent.log(LogStatus.FAIL, "Unable to Create/Select Name: UpdatedAutomationTest");				
			return Temp3 =false;
		}
		if (Temp3==true)
		{
			if (driver.findElements(By.xpath("//img[@title='Delete Annotation']")).size()!=0)
			{
				driver.findElement(By.xpath("//img[@title='Delete Annotation']")).click();
				Thread.sleep(2000);
			}
		}
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Delete_Yes.png") != null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Delete_Yes.png");
		}
		
		return Temp3;
	}
			
	public static boolean searchRecords_QM_Contacts(WebDriver driver,String NumberOfRecords,String MenuItem) throws Exception
	{
				
		boolean temp=true;
		try
		{
			Set<String> windowIds = driver.getWindowHandles();
			System.out.println("windows size:"+windowIds.size());
			if (windowIds.size() ==1)
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return temp=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions",MenuItem);
				Thread.sleep(6000);				
			}			
			mainWinID=Utilities.setWindowFocus(driver);
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png");
			}			
			if (!Impact360Screen.clickQMSearch(driver))	  //click on Search 
			{
				return temp=false;
			}
			Thread.sleep(6000); 
			
			if (NumberOfRecords.contains("30") || NumberOfRecords.contains("7"))
			{
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_DateRange.png")!=null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_DateRange.png");
					sobj.type("a", KeyModifier.CTRL); // select all text			
					sobj.type(Key.BACKSPACE); // delete selection
					sobj.type(NumberOfRecords);
				}
				else
				{
					extent.log(LogStatus.FAIL,"Date Range text field is NOT displayed");
					return temp=false;
				}
			}
			
					
			else if (NumberOfRecords.contains("60") )
				
			{
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_GroupsAndAgents.png")!=null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_GroupsAndAgents.png");				
				}
				Thread.sleep(6000); 
				Robot r = new Robot();
				r.keyPress(KeyEvent.VK_PAGE_DOWN);
				Thread.sleep(1000);
				r.keyRelease(KeyEvent.VK_PAGE_DOWN);
				
				Thread.sleep(1000);
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Advanced.png")!=null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Advanced.png");				
				}
				else
				{
					extent.log(LogStatus.INFO,"Not able to expand Advanced");
					//return flag=false;
				}
				Thread.sleep(1000); 
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png")!=null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png");				
				}
				Thread.sleep(1000);
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Last60mins.png")!=null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Last60mins.png");				
				}
				else
				{
					extent.log(LogStatus.INFO,"Not able to select Last 60mins checkbox");
					//return flag=false;
				}
			}			
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ExecuteSearch.png")!=null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ExecuteSearch.png");
			}
			else
			{
				extent.log(LogStatus.FAIL,"Execute Search field is NOT displayed");
				return temp=false;
			}			
			Thread.sleep(8000); 
		}catch(Exception e){
			System.out.println(e);
		}
		return temp;
	}
	
}
			
		
