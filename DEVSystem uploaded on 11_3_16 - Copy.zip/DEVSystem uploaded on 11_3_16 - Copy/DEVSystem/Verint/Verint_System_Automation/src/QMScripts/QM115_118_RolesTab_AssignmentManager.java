package QMScripts;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;

import ScreenObjects.AssignmentManagerScreen;
import ScreenObjects.Impact360Screen;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;
import Utilities.Utilities;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class QM115_118_RolesTab_AssignmentManager {
	
	public static ExtentReports extent = ExtentReports.get(QM115_118_RolesTab_AssignmentManager.class);
	public static Screen sobj = new Screen ();
	public static boolean VerifyForm_AssignmentManager_Roles() throws Exception
	{		
		boolean flag=true;
		Screen sobj = new Screen ();
		String HTMLReportName="QM115_RolesTab_AssignmentManager"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Verify Form - AssignmentManager - Roles");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	    String RoleName = Ws.getCell(42,50).getContents();		
	    String FormName = Ws.getCell(41,50).getContents();
		
		try
		{		   
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Assignment Manager"))
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					extent.log(LogStatus.FAIL, "Verint Homepage is not displayed");
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Assignment Manager"))
				{
					extent.log(LogStatus.WARNING, "Not able to select Organization Settings menu. Please try again.");
					return flag=false;
				}
			}
			
			if (!Utilities.setWindow(driver, "Assignment Manager"))
			{
				return flag=false;
			}
			//roles
			if (!AssignmentManagerScreen.selectRolesTab(driver))
			{
				return flag=false;
			}
			//select role name
			if (!AssignmentManagerScreen.selectRolesName(driver,RoleName))
			{
				return flag=false;
			}
			//qm for leaders
			if (!AssignmentManagerScreen.selectQualityMonitoringForLeadersTab(driver))
			{
				return flag=false;
			}
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_ContFlags.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_ContFlags.png");
				Thread.sleep(2000);
			}
			
			//form section - start frm here
			
			boolean Temp=false;
			boolean Temp1=false;boolean Temp2=false;
			
			Robot r = new Robot();
			r.keyPress(KeyEvent.VK_PAGE_DOWN);
			Thread.sleep(1000);
			r.keyRelease(KeyEvent.VK_PAGE_DOWN);
			
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_SysAutoFormName.png") != null)
			{
				extent.log(LogStatus.PASS, "Created Form Name: .SystemAutoForm is displayed");
				Thread.sleep(3000);				
			}
			else
			{
				extent.log(LogStatus.FAIL, "Created Form Name: .SystemAutoForm is NOT displayed");
				return flag=false;
			}
			/*if (driver.findElements(By.xpath("//div[@id='ext-comp-1099']/div/div/div")).size()!=0)
			{
				Temp=verifySelectFormName(driver,FormName,"1099");				
			}
			if (Temp==false)
			{
				Temp1=verifySelectFormName(driver,FormName,"1100");
			}
			if (Temp1==false)
			{
				Temp2=verifySelectFormName(driver,FormName,"1101");
			}
			if (Temp==true || Temp1==true || Temp2==true)
			{
				flag=true;
				extent.log(LogStatus.PASS,"Form Name:"+FormName+" is displayed in the form list");
				Thread.sleep(1000);
				extent.log(LogStatus.PASS,"Form Name:"+FormName+" is assigned through Roles tab");
				if (Temp4==true)
				{
					extent.log(LogStatus.PASS,"Form Name:"+FormName+" is already assigned/checkbox is selected");
				}else
				{
					extent.log(LogStatus.PASS,"Form Name:"+FormName+" is assigned through Groups tab");
				}
			}
			else
			{
				extent.log(LogStatus.FAIL,"Form Name:"+FormName+" is NOT displayed in the form list");
				flag=false;
			}*/	
			
			Thread.sleep(4000);
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			 Impact360Screen.closeQM(driver);
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,50);
		}
		return flag;
	}

	public static boolean verifySelectFormName(WebDriver driver,String FormName,String FormId) throws Exception
	{
		
		String formNameApp;
		//boolean Temp=false;
		//boolean Temp1=false;
		boolean Temp2=false;
		//boolean Temp4=false;
	
		//String aid="1101";
		int rc2=driver.findElements(By.xpath("//div[@id='ext-comp-"+FormId+"']/div/div/div")).size();
		System.out.println("rc2"+rc2);
		for (int i=1;i<=rc2;i++)
		{
			
			//System.out.println("form:"+driver.findElement(By.xpath("//div[@id='ext-comp-1101']/div/div/div["+i+"]/div[2]/label")).getText());
			System.out.println("size:"+driver.findElements(By.xpath("//div[@id='ext-comp-"+FormId+"']/div/div/div["+i+"][@class='x-form-check-wrap x-item-disabled']")).size());
			//if (driver.findElements(By.xpath("//div[@id='ext-comp-1099']/div/div/div["+i+"]/div[1]/input[@disabled='']")).size()!=0)
			if (driver.findElements(By.xpath("//div[@id='ext-comp-"+FormId+"']/div/div/div["+i+"][@class='x-form-check-wrap x-item-disabled']")).size()!=0)
			{
				System.out.println("disabled");
			}
			else
			{
				System.out.println("enabled");
				formNameApp=driver.findElement(By.xpath("//div[@id='ext-comp-"+FormId+"']/div/div/div["+i+"]/div[2]/label")).getText();
				System.out.println("formname:"+formNameApp);
				if (formNameApp.contains(FormName))
				{   //off to on
					if (driver.findElements(By.xpath("//div[@id='ext-comp-"+FormId+"']/div/div/div["+i+"]/div[1]/img[@class='x-form-checktristate null']")).size()!=0)
					{
						driver.findElement(By.xpath("//div[@id='ext-comp-"+FormId+"']/div/div/div["+i+"]/div[1]/img[@class='x-form-checktristate null']")).click();
						if (driver.findElement(By.xpath("//table[@id='btnSave']/tbody/tr[2]/td[2]/em/button")).isEnabled())
						{
							driver.findElement(By.xpath("//table[@id='btnSave']/tbody/tr[2]/td[2]/em/button")).click();
							Thread.sleep(5000);
							if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_OK.png") != null)
							{
								sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_OK.png");
								Temp2=true;
								break;
							}
																
						}
					}
					//arrow to off to on
					if (driver.findElements(By.xpath("//div[@id='ext-comp-"+FormId+"']/div/div/div["+i+"]/div[1]/img[@class='x-form-checktristate x-form-checktristate-grayed']")).size()!=0)
					{
						driver.findElement(By.xpath("//div[@id='ext-comp-"+FormId+"']/div/div/div["+i+"]/div[1]/img[@class='x-form-checktristate x-form-checktristate-grayed']")).click();
						Thread.sleep(3000);
						System.out.println("inhert");
						if (driver.findElements(By.xpath("//div[@id='ext-comp-"+FormId+"']/div/div/div["+i+"]/div[1]/img[@class='x-form-checktristate null']")).size()!=0)
						{
							System.out.println("unchecked");
							driver.findElement(By.xpath("//div[@id='ext-comp-"+FormId+"']/div/div/div["+i+"]/div[1]/img[@class='x-form-checktristate null']")).click();
							System.out.println("checked");
						}	
						if (driver.findElement(By.xpath("//table[@id='btnSave']/tbody/tr[2]/td[2]/em/button")).isEnabled())
						{
							driver.findElement(By.xpath("//table[@id='btnSave']/tbody/tr[2]/td[2]/em/button")).click();
							Thread.sleep(5000);
							if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_OK.png") != null)
							{
								sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_OK.png");
								System.out.println("1st save");
								Thread.sleep(3000);
								if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_OK.png") != null)
								{
									sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_OK.png");	
									System.out.println("2nd save");
								}
								Temp2=true;
								break;
							}							
						}
					}
					//already on
					if (driver.findElements(By.xpath("//div[@id='ext-comp-1101']/div/div/div["+i+"]/div[1]/img[@class='x-form-checktristate x-form-checktristate-checked']")).size()!=0)
					{
						Temp2=true;
						extent.log(LogStatus.PASS,"Form Name:"+FormName+" is already assigned/checkbox is selected");
						break;
					}
					
					
				}
				
			}
		
}
		return Temp2;
		}
	}
	


