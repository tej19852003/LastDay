package QMScripts;
//QM052,057,061,062,063
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import ScreenObjects.LoginScreen;

import ScreenObjects.AccessRightsScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.ProfilesScreen;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import org.sikuli.script.Screen;

public class QM05_10_ImportDomainNewUser_AssignRole {
	
	
	public static ExtentReports extent = ExtentReports.get(QM05_10_ImportDomainNewUser_AssignRole.class);
	
	public static boolean Import_Domain_NewUser_AssignRole() throws Exception
	{
		boolean flag=true;
		//String windowName="";
		Screen sobj = new Screen ();
		String HTMLReportName="ImportDomainNewUserAssignRole"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "ImportDomain New User - Assign Role");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	    String organizationName = Ws.getCell(5,4).getContents();
	    String UserAlias = Ws.getCell(11,4).getContents();
	    String UserLastName = Ws.getCell(12,4).getContents();	   	
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Profiles"))			
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Profiles"))
				//if (driver.findElements(By.linkText("Profiles")).size()==0)
				{
					extent.log(LogStatus.WARNING, "Profiles section is not displayed. Please try again");
					return flag=false;
				}				
			}
			//verify User exist or not
			if (!ProfilesScreen.FindSelect(driver, UserLastName))
			{			
				Utilities.selectRightPaneView(driver);				
				if (!ProfilesScreen.clickImportDomainUsers(driver))
				{
					return flag=false;
				}
				Thread.sleep(2000);				
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_EnterObjNameToSelect.png") != null)
				{
					sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_EnterObjNameToSelect.png", UserAlias);
				}				
				Thread.sleep(1000);
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_OK_Btn.png") != null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_OK_Btn.png");
				}				
				Thread.sleep(5000);
				Utilities.selectRightPaneView(driver);
				//System.out.println("err:"+driver.findElement(By.xpath("//div[@id='workPaneWrapper']/table[@id='viewfindPane_tbl_id']/tbody/tr/td[2]/table[@id='pageMessages_bttn_tbl_id']/tbody/tr/td[1]/div")).getText());
				if (!ProfilesScreen.checkErrorMessage(driver))
				{				
						return flag=false;
				}
				Thread.sleep(2000);				
				if (!ProfilesScreen.FindSelect(driver, UserLastName))
				{
					return flag=false;
				}
				
				/*if (!ProfilesScreen.selectProfile(driver,UserLastName))
				{
					return flag=false;
				}*/
			}
			//assign role - QM057
			//select Access Rights tab
			driver.switchTo().defaultContent();
			if (driver.findElements(By.linkText("Access Rights")).size()!=0)
			{
				driver.findElement(By.linkText("Access Rights")).click();
				extent.log(LogStatus.INFO, "Access Rights tab is selected");
			}		
			else
			{
				extent.log(LogStatus.FAIL, "Not able to select Access Rights tab");
				return flag=false;
			}
			if (!AccessRightsScreen.selectEmp_From_AccessRightsFrame(driver,UserLastName))
			{
				return flag=false;
			}
			Utilities.selectRightPaneView(driver);
			if (!AccessRightsScreen.clickEditAccessRights(driver))
			{
				return flag=false;
			}
			
			Robot r = new Robot();
			r.keyPress(KeyEvent.VK_CONTROL);
			r.keyPress(KeyEvent.VK_F);
			r.keyRelease(KeyEvent.VK_CONTROL);
			r.keyRelease(KeyEvent.VK_F);
			Utilities.sikuliType(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\FindText.png", "QM Agent");
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\FindText_Close.png");
			Utilities.selectRightPaneView(driver);
			//select QM Agent role
			int rcRole=driver.findElements(By.xpath("//table[@id='roleTableRef']/tbody/tr")).size();
			System.out.println("rolerc:"+rcRole);
			for (int p=1;p<=rcRole;p++)
			{
				System.out.println("p value:+"+p);
				if (p<31 & p<=rcRole)
				{
					String rName=driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[1]/tr["+p+"]/td[1]/a/span")).getText().trim();
					System.out.println("prevNameApp:"+rName);
					System.out.println("privVal:QM Agent");
					//Thread.sleep(1000);
					if (rName.contains("QM Agent"))
					{
						if (!driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[1]/tr["+p+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).isSelected())
						{
							driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[1]/tr["+p+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).click();
							extent.log(LogStatus.INFO, "Role Name:"+rName+" checkbox is selected");
							System.out.println("checked");				
							flag=true;
							break;
						}						
					}
				}
				if (p>30 & p<61 & p<=rcRole)
				{   
					int q;
					q=p-30;
					String rName=driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[2]/tr["+q+"]/td[1]/a/span")).getText().trim();
					System.out.println("prevNameApp:"+rName);
					System.out.println("privVal:QM Agent");
					System.out.println("q:"+q);
					Thread.sleep(1000);
					if (rName.toUpperCase().contains("QM AGENT"))
					{
						if (!driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[2]/tr["+q+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).isSelected())
						{
							driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[2]/tr["+q+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).click();
							extent.log(LogStatus.INFO, "Role Name:"+rName+" checkbox is selected");
							System.out.println("checked");				
							flag=true;
							break;
						}						
					}
				}
				if (p>60 & p<91 & p<=rcRole)
				{
					int s;
					s=p-60;
					String rName=driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[3]/tr["+s+"]/td[1]/a/span")).getText().trim();
					System.out.println("prevNameApp:"+rName);
					System.out.println("privVal:QM Agent");
					//Thread.sleep(1000);
					if (rName.contains("QM Agent"))
					{
						if (!driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[3]/tr["+s+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).isSelected())
						{
							driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[3]/tr["+s+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).click();
							extent.log(LogStatus.INFO, "Role Name:"+rName+" checkbox is selected");
							System.out.println("checked");				
							flag=true;
							break;
						}						
					}
				}
				if (p>90 & p<=rcRole)
				{
					int t;
					t=p-90;
					String rName=driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[4]/tr["+t+"]/td[1]/a/span")).getText().trim();
					System.out.println("prevNameApp:"+rName);
					System.out.println("privVal:QM Agent");
					//Thread.sleep(1000);
					if (rName.contains("QM Agent"))
					{
						if (!driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[4]/tr["+t+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).isSelected())
						{
							driver.findElement(By.xpath("//table[@id='roleTableRef']/tbody[4]/tr["+t+"]/td[1]/a/span/input[@name='checkedRoleID'][@type='checkbox']")).click();
							extent.log(LogStatus.INFO, "Role Name:"+rName+" checkbox is selected");
							System.out.println("checked");				
							flag=true;
							break;
						}						
					}
				}				
			}
			if (flag==true)
			{
				extent.log(LogStatus.INFO, "Role Name:QM Agent checkbox is selected");
			}
			else
			{
				extent.log(LogStatus.FAIL, "Role Name:QM Agent checkbox is NOT selected");
				return flag=false;
			}
			//QM061
			if (!AccessRightsScreen.select_OrganizationScope_checkbox(driver,organizationName))
			{
				return flag=false;
			}
			if (!AccessRightsScreen.clickSave(driver))
			{
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "AssignRole"));
				return flag=false;
			}
			else
			{
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "AssignRole"));
			}
			//QM062
			if (!AccessRightsScreen.selectEmp_From_AccessRightsFrame(driver,UserLastName))
			{
				return flag=false;
			}
			Utilities.selectRightPaneView(driver);
			if (!AccessRightsScreen.clickEditAccessRights(driver))
			{
				return flag=false;
			}
			if (!AccessRightsScreen.Unselect_OrganizationScope_checkbox(driver,organizationName))
			{
				return flag=false;
			}
			if (!AccessRightsScreen.clickSave(driver))
			{
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "AssignRole"));
				return flag=false;
			}
			else
			{
				extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "AssignRole"));
			}
			//QM063
			//select Profiles tab
			/*driver.switchTo().defaultContent();
			if (driver.findElements(By.linkText("Profiles")).size()!=0)
			{
				driver.findElement(By.linkText("Profiles")).click();
				extent.log(LogStatus.INFO, "Profiles tab is selected");
			}		
			else
			{
				extent.log(LogStatus.FAIL, "Not able to select Profiles tab");
				return flag=false;
			}
			Utilities.selectRightPaneView(driver);
			if (!ProfilesScreen.clickDelete(driver))
			{
				return flag=false;
			}					
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Delete_OK.png");
			Thread.sleep(12000);
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "User"));*/
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			//extent.endTest();
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,4);
		}
		return flag;
	}
	

}
