package QMScripts;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.python.modules.thread.thread;
import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.AccessRightsScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.ScheduleScreen;
import ScreenObjects.VerintHomePageScreen;

import Utilities.Utilities;


public class QM90_Modify_Report {
	
	public static boolean modify_report() throws Exception
	{
		ExtentReports extent = ExtentReports.get(AccessRightsScreen.class);
		boolean flag=true;
		Screen sobj = new Screen ();
		String mainWinID="";
		
		String HTMLReportName="QM90_Modify_Report"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Modify Report");
		
		//Utilities.testcaseSetup("QM12_Reports"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date()), "Reports");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			Thread.sleep(5000);
			VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
			Thread.sleep(5000);
			
			Set<String> windowIds = driver.getWindowHandles();
			System.out.println("windows size:"+windowIds.size());
			if (windowIds.size() ==1)
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
				Thread.sleep(5000);
				
			}
			
			mainWinID=Utilities.setWindowFocus(driver);
			System.out.println(mainWinID);
			
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png");
			}
			Thread.sleep(15000);
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Reports.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Reports.png");
			}
			else
			{
				extent.log(LogStatus.WARNING, "Not able to click on Reports. Please try again");
				return flag=false;
			}			
		
			Thread.sleep(15000);
			Set<String> windowIds1 = driver.getWindowHandles();
			Iterator<String> itererator = windowIds1.iterator(); 			
			String mainWinID1 = itererator.next();//main window 
			String  popWindow1 = itererator.next();//popup window
			String report1 = itererator.next(); //reports window
			driver.switchTo().window(report1);//Switch the driver to the popup window
			driver.manage().window().maximize();
			System.out.println(mainWinID1+";"+popWindow1);
			Thread.sleep(1000);
			Utilities.switchFrame(driver,"headerPlusFrame");
//			driver.switchTo().frame(0);			
			Thread.sleep(1000);
			driver.switchTo().frame("dataFrame");	
			Thread.sleep(1000);
			driver.switchTo().frame("workspaceFrame");
			Thread.sleep(1000);
			driver.switchTo().frame("workspaceBodyFrame");
			Thread.sleep(1000);
			WebElement publicFoldersExpand = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.id("ygtvt4")));
			publicFoldersExpand.click();
			//extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "QMReport"));
			Thread.sleep(3000);
			
			WebElement reportsEnglishExpand = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.id("ygtvt6")));
			reportsEnglishExpand.click();
			//extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "QMReport"));
			Thread.sleep(3000);
			WebElement ActivityReportFolder = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.id("ygtvlabelel9")));
			ActivityReportFolder.click();
			Thread.sleep(3000);
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "QMReport"));
			WebElement blankRowField = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.id("ListingURE_listColumn_0_0_1")));
			/*Actions action = new Actions(driver);
			action.moveToElement(blankRowField).doubleClick().build().perform();*/
			blankRowField.click();
			driver.findElement(By.id("IconImg_iconMenu_arrow_ListingURE_usage0_10")).click();
			Thread.sleep(1000);
			driver.findElement(By.id("iconMenu_menu_ListingURE_usage0_10_span_text_Shared_Schedule_PlatformServices")).click();
			Utilities.switchFrame(driver,"dlgNavFrame");
			driver.findElement(By.xpath("//a[@id='ygtvlabelel3']")).click();
			driver.switchTo().defaultContent();
			Utilities.switchFrame(driver,"headerPlusFrame");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"dataFrame");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"workspaceFrame");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"workspaceBodyFrame");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"dlgContainer");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"frame1");
			Thread.sleep(2000);
			ScheduleScreen.setrecurrence(driver,"Once");
			driver.switchTo().defaultContent();
			driver.switchTo().defaultContent();
			Utilities.switchFrame(driver,"headerPlusFrame");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"dataFrame");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"workspaceFrame");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"workspaceBodyFrame");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"dlgContainer");
			Thread.sleep(2000);
			driver.findElement(By.id("scheduleButton")).click();
			Thread.sleep(10000);
			
			/*driver.findElement(By.id("IconImg_iconMenu_arrow_ListingURE_usage0_10")).click();
			Thread.sleep(1000);
			driver.findElement(By.id("iconMenu_menu_ListingURE_usage0_10_span_text_CrystalReport_History")).click();
			Thread.sleep(5000);*/
			driver.switchTo().defaultContent();
			Utilities.switchFrame(driver,"headerPlusFrame");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"dataFrame");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"workspaceFrame");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"workspaceBodyFrame");
			Thread.sleep(2000);
			
			driver.findElement(By.xpath("//table[@id='UniversalRepositoryExplorer1_listMainTable']//tbody//tr[@id='UniversalRepositoryExplorer1_listNode0_0']")).click();
			Thread.sleep(3000);
			driver.findElement(By.id("IconImg_iconMenu_arrow_UniversalRepositoryExplorer1_menu0_0")).click();
			
			driver.findElement(By.id("iconMenu_menu_UniversalRepositoryExplorer1_menu0_0_span_text_GenericActionType_Reschedule")).click();
			
			Thread.sleep(3000);
			/*Utilities.switchFrame(driver,"dlgNavFrame");
			driver.findElement(By.xpath("//a[@id='ygtvlabelel3']")).click();
			driver.switchTo().defaultContent();*/
			Utilities.switchFrame(driver,"dlgNavFrame");
			driver.findElement(By.xpath("//a[@id='ygtvlabelel5']")).click();
			Thread.sleep(2000);
			driver.switchTo().defaultContent();
			Utilities.switchFrame(driver,"headerPlusFrame");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"dataFrame");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"workspaceFrame");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"workspaceBodyFrame");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"dlgContainer");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"frame3");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"searchservices");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"FR_SEARCH");
			Thread.sleep(2000);
			driver.findElement(By.id("dfd_MS_catGroupsAndAgents__ctl1__CollapseImage")).click();
			Thread.sleep(1000);
			driver.findElement(By.id("dfd_MS_catDateRange__ctl1__CollapseImage")).click();
			Thread.sleep(1000);
			driver.findElement(By.id("dfd_MS_catCD__ctl1__CollapseImage")).click();
			Thread.sleep(1000);
			driver.findElement(By.id("dfd_MS_catDistributionOptions__ctl1__CollapseImage")).click();
			Thread.sleep(1000);
			
			driver.findElement(By.id("dfd_MS_catDistributionOptions__ctl2_ctrlRepReportDistribution_rbAccrossTimeDistribution")).click();
			
			Select sbox=new Select(driver.findElement(By.id("ddlAcrossTime")));
			//sbox.selectByVisibleText("Month(s)");
			sbox.selectByValue("Month");
			
			
			driver.switchTo().defaultContent();
			Utilities.switchFrame(driver,"headerPlusFrame");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"dataFrame");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"workspaceFrame");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"workspaceBodyFrame");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"dlgContainer");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"frame3");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"searchservices");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"FR_FOOTER");
			Thread.sleep(2000);
			
			extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "QMReport"));
			if (driver.findElements(By.xpath("//a[@id='btnExecuteSearch_btnExecuteSearch']")).size()!=0)
			{
				driver.findElement(By.xpath("//a[@id='btnExecuteSearch_btnExecuteSearch']")).click();
			}
			else
			{
				extent.log(LogStatus.WARNING, "QM Report: Not able to click on Generate Report button");
				return flag=false;
			}
			driver.switchTo().defaultContent();
			Utilities.switchFrame(driver,"headerPlusFrame");
			Thread.sleep(1000);
			Utilities.switchFrame(driver,"dataFrame");
			Thread.sleep(1000);
			Utilities.switchFrame(driver,"workspaceFrame");
			Thread.sleep(1000);
			Utilities.switchFrame(driver,"workspaceBodyFrame");
			Thread.sleep(1000);
			Utilities.switchFrame(driver,"dlgContainer");
			Thread.sleep(1000);
			driver.findElement(By.id("scheduleButton")).click();
			Thread.sleep(3000);
			
			driver.switchTo().defaultContent();
			Utilities.switchFrame(driver,"headerPlusFrame");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"dataFrame");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"workspaceFrame");
			Thread.sleep(2000);
			Utilities.switchFrame(driver,"workspaceBodyFrame");
			Thread.sleep(2000);
			
			System.out.println("value is:"+ driver.findElement(By.xpath("//table[@id='UniversalRepositoryExplorer1_listMainTable']//tbody//tr[@id='UniversalRepositoryExplorer1_listNode0_0']//td[2]//div[@id='UniversalRepositoryExplorer1_listColumn_0_0_1']")).getAttribute("title"));
			//Thread.sleep(10000);
		    String status=driver.findElement(By.xpath("//table[@id='UniversalRepositoryExplorer1_listMainTable']//tbody//tr[@id='UniversalRepositoryExplorer1_listNode0_0']//td[7]//div[@id='UniversalRepositoryExplorer1_listColumn_0_0_6']")).getAttribute("title");
		    System.out.println("staus is"+ status );
		    if(status.equals("Running")||status.equals("Pending"))
		    {
		    	driver.findElement(By.xpath("//table[@id='UniversalRepositoryExplorer1_listMainTable']//tbody//tr[@id='UniversalRepositoryExplorer1_listNode0_0']//td[7]//div[@id='UniversalRepositoryExplorer1_listColumn_0_0_6']//a")).click();
		    	Thread.sleep(1000);
		    	driver.findElement(By.className("inputButton")).click();
		    	/*String status1=driver.findElement(By.xpath("//table[@id='UniversalRepositoryExplorer1_listMainTable']//tbody//tr[@id='UniversalRepositoryExplorer1_listNode0_0']//td[7]//div[@id='UniversalRepositoryExplorer1_listColumn_0_0_6']")).getAttribute("title");
			    System.out.println("staus is"+ status1 );*/
		    }
		   
		    status=driver.findElement(By.xpath("//table[@id='UniversalRepositoryExplorer1_listMainTable']//tbody//tr[@id='UniversalRepositoryExplorer1_listNode0_0']//td[7]//div[@id='UniversalRepositoryExplorer1_listColumn_0_0_6']")).getAttribute("title");
		    System.out.println("staus is"+ status );
		    Thread.sleep(5000);
			if(status.equals("Success"))
			{
			driver.findElement(By.xpath("//table[@id='UniversalRepositoryExplorer1_listMainTable']//tbody//tr[@id='UniversalRepositoryExplorer1_listNode0_0']//td[2]//div[@id='UniversalRepositoryExplorer1_listColumn_0_0_1']//a")).click();
			}
			Thread.sleep(3000);
			  extent.log(LogStatus.INFO,"report scheduled sucessfully");
			  
			    extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "QMReport"));
			Thread.sleep(3000);
			/*if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Reports_Historic.png")!=null)
			{
				extent.log(LogStatus.PASS, "QM Report: Historical Average Talk Time per Agent is displayed successfully");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QMReport"));				
			}
			else
			{
				extent.log(LogStatus.FAIL, "QM Report: Historical Average Talk Time per Agent is NOT displayed");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "QMReport"));			
			}
			*/
			driver.close();
			Thread.sleep(2000);
			driver.switchTo().window(popWindow1);
			driver.close();
			driver.switchTo().window(mainWinID1);
			
		}catch(Exception e){
			System.out.println(e);
		}finally{	
//			Utilities.Logout(driver);			
			driver.close();
			driver.quit();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,63);
		}
		
		return flag;
		
		
	}
	
	

	
	
}
