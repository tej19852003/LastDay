package QMScripts;

import java.io.File;
import java.io.FileInputStream;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.DataSourceScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.QualityMonitoringEvaluation;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.Impact360Screen;
import ScreenObjects.QualityMonitoringContactScreen;
import ScreenObjects.QualityMonitoringSearchScreen;
import Utilities.Utilities;

public class QM70_Search_Evaluations {
	public static ExtentReports extent = ExtentReports.get(DataSourceScreen.class);
	
	public static boolean Search_Evaluations() throws Exception
	{
		boolean flag=true;
		Screen sobj = new Screen ();
		String mainWinID="";	
		String HTMLReportName="QM70_Search_Evaluations"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Search Evaluations");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	   	
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("QMAnalystUserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("QMAnalystPassword"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			Thread.sleep(5000);
			if (!VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring"))
			{
				Thread.sleep(5000);
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("QMAnalystUserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("QMAnalystPassword"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
				Thread.sleep(6000);
			}
			Set<String> windowIds = driver.getWindowHandles();
			System.out.println("windows size:"+windowIds.size());
			if (windowIds.size() ==1)
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("QMAnalystUserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("QMAnalystPassword"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
				Thread.sleep(6000);				
			}
						
			
			mainWinID=Utilities.setWindowFocus(driver);
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png");
			}			
			if (!Impact360Screen.clickQMSearch(driver))	  //click on Search 
			{
				return flag=false;
			}
			//select eval radio button
			if (!QualityMonitoringContactScreen.select_SearchFor_Evaluations(driver))	 
			{
				return flag=false;
			}
			
			if (!QualityMonitoringEvaluation.evaluationdata_SelectOption_AvailableGroups(driver))	 
			{
				return flag=false;
			}
			if (!QualityMonitoringEvaluation.evaluationdata_SelectOption_AvailableEvaluators(driver,Utilities.Globlocators.getProperty("QMEvaluatorUserName")))	 
			{
				return flag=false;
			}
			if (!QualityMonitoringEvaluation.evaluationdata_click_RightArrow(driver))	 
			{
				return flag=false;
			}
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ExecuteSearch.png")!=null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ExecuteSearch.png");
			}
			else
			{
				extent.log(LogStatus.FAIL,"Execute Search field is NOT displayed");
				return flag=false;
			}
			Thread.sleep(8000); 			
			if (!QualityMonitoringEvaluation.verifyEvaluationsStartTime(driver))		//verify evaluator start time	
			{
				return flag=false;
			}
		
		 Thread.sleep(2000);
		 Impact360Screen.closeQM(driver);
		}catch(Exception e){
			System.out.println(e);
		}finally{				
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,36);
		}
		return flag;
	}

}
