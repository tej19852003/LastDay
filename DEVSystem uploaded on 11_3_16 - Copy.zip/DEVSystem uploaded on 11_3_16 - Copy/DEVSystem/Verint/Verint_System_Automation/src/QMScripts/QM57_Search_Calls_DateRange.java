package QMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.LoginScreen;

import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.Impact360Screen;
import ScreenObjects.QualityMonitoringContactScreen;

import Utilities.Utilities;


public class QM57_Search_Calls_DateRange {
	public static ExtentReports extent = ExtentReports.get(QM57_Search_Calls_DateRange.class);
	public static Screen sobj = new Screen ();
	
	public static boolean Search_Calls_DateRange() throws Exception
	{
		boolean flag=true;
		
		String mainWinID="";
		String HTMLReportName="QM57_Search_Calls_DateRange"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Search Calls By Date Range");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	    String DateRangeFrom = Ws.getCell(35,32).getContents();
	    String DateRangeTo	= Ws.getCell(36,32).getContents();
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("QMEvaluatorUserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("QMEvaluatorPassword"));
			LoginScreen.clickLogin(driver);
			/*if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}*/
			Thread.sleep(5000);
			if (!VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring"))
			{
				Thread.sleep(5000);
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("QMEvaluatorUserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("QMEvaluatorPassword"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
				Thread.sleep(6000);
			}
						
			mainWinID=Utilities.setWindowFocus(driver);
			System.out.println(mainWinID);			
			
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png");			
					
			if (!Impact360Screen.clickQMSearch(driver))	  //click on Search 
			{
				return flag=false;
			}				
			driver.manage().window().maximize();
			
			if (!QualityMonitoringContactScreen.selectQMSearchContact_Betweenthesedatesandtimes(driver))	
			{
				flag=false;
			}
			
			if (!QualityMonitoringContactScreen.setQMSearchContact_DateRangeFrom(driver,DateRangeFrom))	
			{
				flag=false;
			}
			if (!QualityMonitoringContactScreen.setQMSearchContact_DateRangeTo(driver,DateRangeTo))	
			{
				flag=false;
			}
			
			if (!QualityMonitoringContactScreen.clickExecute(driver))	
			{
				flag=false;
			}
				
			/*if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ExecuteSearch.png")!=null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ExecuteSearch.png");
			}
			else
			{
				extent.log(LogStatus.FAIL,"Execute Search field is NOT displayed");
				return flag=false;
			}*/
					
			Thread.sleep(10000); 		
			
			if (!QualityMonitoringContactScreen.verifyContactsStartTime(driver))		//results	
			{
				flag=false;
			}
					
			Thread.sleep(10000);
			Impact360Screen.closeQM(driver);
			
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			
			Utilities.Logout(driver);
			driver.close();			
			driver.quit();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,32);
		}
		
		return flag;
	}

}
