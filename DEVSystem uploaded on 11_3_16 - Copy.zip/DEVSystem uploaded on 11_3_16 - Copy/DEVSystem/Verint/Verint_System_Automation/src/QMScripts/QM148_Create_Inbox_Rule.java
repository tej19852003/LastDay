package QMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;
import jxl.Sheet;
import jxl.Workbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.DataSourceScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.QualityMonitoringEvaluation;
import ScreenObjects.QualityMonitoringInbox;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.Impact360Screen;
import ScreenObjects.QualityMonitoringContactScreen;
import Utilities.Utilities;

public class QM148_Create_Inbox_Rule {
	public static ExtentReports extent = ExtentReports.get(DataSourceScreen.class);
	
	public static boolean Create_Inbox_Rule() throws Exception
	{
		boolean flag=true;
		Screen sobj = new Screen ();			
		String HTMLReportName="QM148_Create_Inbox_Rule"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Create Inbox Rule");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	    String RuleName = Ws.getCell(37,45).getContents();
	    
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("QMAnalystUserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("QMAnalystPassword"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			Thread.sleep(5000);
			if (!VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring"))
			{
				Thread.sleep(5000);
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("QMAnalystUserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("QMAnalystPassword"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
				Thread.sleep(6000);
			}
			Set<String> windowIds = driver.getWindowHandles();
			System.out.println("windows size:"+windowIds.size());
			if (windowIds.size() ==1)
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("QMAnalystUserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("QMAnalystPassword"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
				Thread.sleep(6000);				
			}
						
			
			Utilities.setWindowFocus(driver);
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png");
			}
			Thread.sleep(8000);		
			//click on Inbox 
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Inbox.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Inbox.png");
				Thread.sleep(5000);	
			}
			else
			{
				extent.log(LogStatus.FAIL,"Not able to click on QM - Inbox");
			}
			//click on Customize inbox
			if (!QualityMonitoringContactScreen.clickCustomizeInbox(driver))
			{
				return flag=false;
			}
			//click on Addrule
			if (!QualityMonitoringInbox.clickAddRule(driver))
			{
				return flag=false;
			}
			//click on Define rule
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_DefineRule.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_DefineRule.png");
				extent.log(LogStatus.INFO,"Clicked on Define Rule button is successful");
				Thread.sleep(4000);	
			}
			else
			{
				extent.log(LogStatus.FAIL,"Not able to click on Define Rule");
				return flag=false;
			}
			//enter rule name
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Inbox_RuleName.png") != null)
			{
				sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Inbox_RuleName.png",RuleName);
				extent.log(LogStatus.INFO,"Rule Name: "+RuleName+" entered succssfully");
				Thread.sleep(4000);
			}
			else
			{
				extent.log(LogStatus.FAIL,"Not able to enter Rule Name: "+RuleName);
				return flag=false;
			}
			
			//if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_WebPortalPref_OK.png") != null)
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\btnok_inboxrule.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\btnok_inboxrule.png");
				extent.log(LogStatus.INFO,"Clicked on Ok button is successful");
				Thread.sleep(5000);
			}
			else
			{
				extent.log(LogStatus.FAIL,"Not able to click on OK button");
				return flag=false;
			}
			//validation
			if (!QualityMonitoringInbox.validateRuleName(driver,RuleName))
			{
				return flag=false;
			}
			if (!QualityMonitoringInbox.deleteInboxRuleName(driver,RuleName))
			{
				return flag=false;
			}			
			Thread.sleep(2000);
			//Impact360Screen.closeQM(driver);
		}catch(Exception e){
			System.out.println(e);
		}finally{				
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,45);
		}
		return flag;
	}

}
