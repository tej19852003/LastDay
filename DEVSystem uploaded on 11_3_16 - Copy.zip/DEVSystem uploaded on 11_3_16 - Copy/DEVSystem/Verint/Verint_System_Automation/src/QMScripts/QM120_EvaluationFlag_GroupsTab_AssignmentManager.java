package QMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;

import ScreenObjects.AssignmentManagerScreen;
import ScreenObjects.Impact360Screen;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;
import Utilities.Utilities;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class QM120_EvaluationFlag_GroupsTab_AssignmentManager {
	
	public static ExtentReports extent = ExtentReports.get(QM120_EvaluationFlag_GroupsTab_AssignmentManager.class);
	public static Screen sobj = new Screen ();
	public static boolean AssignEvaluationFlag_GroupsTab_AssignmentManager() throws Exception
	{		
		boolean flag=true;
		
		String HTMLReportName="QM120_EvaluationFlag_GroupsTab_AssignmentManager"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "EvaluationFlag - GroupsTab - AssignmentManager");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	    String GroupName = Ws.getCell(40,52).getContents();		
	    String EvalFlag = Ws.getCell(41,52).getContents();
		
		try
		{		   
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Assignment Manager"))
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					extent.log(LogStatus.FAIL, "Verint Homepage is not displayed");
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Assignment Manager"))
				{
					extent.log(LogStatus.WARNING, "Not able to select Organization Settings menu. Please try again.");
					return flag=false;
				}
			}
			
			if (!Utilities.setWindow(driver, "Assignment Manager"))
			{
				return flag=false;
			}
			//groups
			/*if (!AssignmentManagerScreen.selectGroupsTab(driver))
			{
				return flag=false;
			}*/
			//select group name
			if (!AssignmentManagerScreen.selectGroupName(driver,GroupName))
			{
				return flag=false;
			}
			//qm for leaders
			if (!AssignmentManagerScreen.selectQualityMonitoringForLeadersTab(driver))
			{
				return flag=false;
			}
			
				
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_Remarkable.png") != null)
			{
				sobj.click( Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_Remarkable.png");				
				Thread.sleep(3000);
				sobj.click( Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_RemarkableUncheck.png");
				Thread.sleep(3000);
				extent.log(LogStatus.PASS, "Clicked on checkbox - Remarkable");
				if (driver.findElement(By.xpath("//table[@id='btnSave']/tbody/tr[2]/td[2]/em/button")).isEnabled())
				{
					driver.findElement(By.xpath("//table[@id='btnSave']/tbody/tr[2]/td[2]/em/button")).click();
					Thread.sleep(5000);
					extent.log(LogStatus.PASS, "Clicked on Save button is successful");
					if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_OK.png") != null)
					{
						sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_OK.png");
						extent.log(LogStatus.PASS, "Clicked on Ok button is successful");									
					}
					if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_OK.png") != null)
					{
						sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_OK.png");
						extent.log(LogStatus.PASS, "Clicked on Ok button is successful");									
					}
				}
				Thread.sleep(5000);
				//revert it back
				if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_RemarkableCheck.png") != null)
				{
					sobj.click( Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_RemarkableCheck.png");
					Thread.sleep(3000);
					if (driver.findElement(By.xpath("//table[@id='btnSave']/tbody/tr[2]/td[2]/em/button")).isEnabled())
					{
						driver.findElement(By.xpath("//table[@id='btnSave']/tbody/tr[2]/td[2]/em/button")).click();
						Thread.sleep(5000);
						//extent.log(LogStatus.PASS, "Clicked on Save button is successful");
						if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_OK.png") != null)
						{
							sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_OK.png");
							//Temp2=true;					
						}														
					}
				}
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to Click on checkbox - Remarkable");
				return flag=false;
			}
			
			
			
			
			
			
			
			
			/*boolean Temp=false;
			boolean Temp1=false;boolean Temp2=false;			
			
			Temp=verifySelectEvalFlag(driver,EvalFlag,"1079");				
			
			if (Temp==false)
			{
				Temp1=verifySelectEvalFlag(driver,EvalFlag,"1080");				
			}
			if (Temp==false && Temp1==false)
			{
				Temp2=verifySelectEvalFlag(driver,EvalFlag,"1081");				
			}
			if (Temp==true || Temp1==true || Temp2==true)
			{
				flag=true;
				//extent.log(LogStatus.PASS,"Evaluation Flag Name:"+FormName+" is displayed in the Evaluation Flag section");
				//extent.log(LogStatus.PASS,"Evaluation Flag Name:"+FormName+" is assigned through Groups tab");
				if (Temp4==true)
				{
					extent.log(LogStatus.PASS,"Form Name:"+FormName+" is already assigned/checkbox is selected");
				}else
				{
					extent.log(LogStatus.PASS,"Form Name:"+FormName+" is assigned through Groups tab");
				}
			}
			else
			{
				extent.log(LogStatus.FAIL,"Evaluation Flag Name:"+EvalFlag+" is NOT displayed in the form list");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "AssignmentMgr"));
				flag=false;
			}	
			
			Thread.sleep(4000);*/
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			 Impact360Screen.closeQM(driver);
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,52);
		}
		return flag;
	}

	public static boolean verifySelectEvalFlag(WebDriver driver,String FormName,String FormId) throws Exception
	{
		boolean Temp2=false;
		try{
			String formNameApp;				
			int rc2=driver.findElements(By.xpath("//div[@id='ext-comp-"+FormId+"']/div/div/div")).size();
			System.out.println("rc2"+rc2);
			for (int i=1;i<=rc2;i++)
			{		
				System.out.println("size:"+driver.findElements(By.xpath("//div[@id='ext-comp-"+FormId+"']/div/div/div["+i+"][@class='x-form-check-wrap x-item-disabled']")).size());				
				formNameApp=driver.findElement(By.xpath("//div[@id='ext-comp-"+FormId+"']/div/div/div["+i+"]/div[2]/label")).getText();
				System.out.println("formname:"+formNameApp);
				if (formNameApp.contains(FormName) && driver.findElements(By.xpath("//div[@id='ext-comp-"+FormId+"']/div/div/div["+i+"][@class='x-form-check-wrap x-item-disabled']")).size()==0)
				{   
					extent.log(LogStatus.PASS,"Evaluation Flag Name:"+FormName+" is displayed in the Evaluation Flag section");
					//off to on					
						if (driver.findElements(By.xpath("//div[@id='ext-comp-"+FormId+"']/div/div/div["+i+"]/div[1]/img[@class='x-form-checktristate null']")).size()!=0)
						{
							driver.findElement(By.xpath("//div[@id='ext-comp-"+FormId+"']/div/div/div["+i+"]/div[1]/img[@class='x-form-checktristate null']")).click();
							if (driver.findElement(By.xpath("//table[@id='btnSave']/tbody/tr[2]/td[2]/em/button")).isEnabled())
							{
								driver.findElement(By.xpath("//table[@id='btnSave']/tbody/tr[2]/td[2]/em/button")).click();
								Thread.sleep(5000);
								if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_OK.png") != null)
								{
									sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_OK.png");
									extent.log(LogStatus.PASS,"Evaluation Flag Name:"+FormName+" is assigned through Groups tab");
									extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "AssignmentMgr"));
									Temp2=true;
									break;
								}																
							}
						}
						//arrow 
						if (driver.findElements(By.xpath("//div[@id='ext-comp-"+FormId+"']/div/div/div["+i+"]/div[1]/img[@class='x-form-checktristate x-form-checktristate-grayed']")).size()!=0)
						{
							Temp2=true;
							extent.log(LogStatus.PASS,"Evaluation Flag Name:"+FormName+" is already assigned/inherited through Groups tab");
							extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "AssignmentMgr"));
							break;
						}
						//already on
						if (driver.findElements(By.xpath("//div[@id='ext-comp-1101']/div/div/div["+i+"]/div[1]/img[@class='x-form-checktristate x-form-checktristate-checked']")).size()!=0)
						{
							Temp2=true;
							extent.log(LogStatus.PASS,"Evaluation Flag Name:"+FormName+" is already assigned through Groups tab");
							extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "AssignmentMgr"));
							break;
						}					
					} //end if				
			}	// for		
		}catch(Exception e){
			System.out.println(e);		
		}
		return Temp2;
	}
}
	


