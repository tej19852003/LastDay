package QMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;

import ScreenObjects.AssignmentManagerScreen;
import ScreenObjects.Impact360Screen;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;
import Utilities.Utilities;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class QM116_119_EntitiesTab_AssignmentManager {
	
	public static ExtentReports extent = ExtentReports.get(QM116_119_EntitiesTab_AssignmentManager.class);
	
	public static boolean Verify_AssignForm_AssignmentManager_Entities() throws Exception
	{		
		boolean flag=true;
		Screen sobj = new Screen ();
		String HTMLReportName="QM116_119_EntitiesTab_AssignmentManager"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Verify Assign Form - AssignmentManager - Entities");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	    //String RoleName = Ws.getCell(40,48).getContents();		
	    String FormName = Ws.getCell(41,48).getContents();
		
		try
		{		   
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Assignment Manager"))
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					extent.log(LogStatus.FAIL, "Verint Homepage is not displayed");
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Assignment Manager"))
				{
					extent.log(LogStatus.WARNING, "Not able to select Organization Settings menu. Please try again.");
					return flag=false;
				}
			}
			
			if (!Utilities.setWindow(driver, "Assignment Manager"))
			{
				return flag=false;
			}
			//select entities tab
			if (!AssignmentManagerScreen.selectEntitiesTab(driver))
			{
				return flag=false;
			}
			
			
			
			
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_QMLeaders.png") != null)
			{
				sobj.doubleClick(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_QMLeaders.png");
				extent.log(LogStatus.PASS, "Quality Monitoring for Leaders expanded successfully");
				Thread.sleep(5000);
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to expand Quality Monitoring for Leaders");
				return flag=false;
			}
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_Forms.png") != null)
			{
				sobj.doubleClick(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_Forms.png");
				extent.log(LogStatus.PASS, "Forms expanded successfully");
				Thread.sleep(5000);
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to expand Forms");
				return flag=false;
			}
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_FormName.png") != null)
			{
				
				extent.log(LogStatus.PASS, "Form Name: .SystemAutoForm is displayed successfully");
				Thread.sleep(5000);
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL, "Form Name: .SystemAutoForm is NOT displayed successfully");
				return flag=false;
			}
			
			
			
			/*//expand qm for leaders 
			if (driver.findElements(By.xpath("//div[@id='ext-comp-1004']/div/div/ul/div/li[4]/div/img[1]")).size()!=0)
			{
				driver.findElement(By.xpath("//div[@id='ext-comp-1004']/div/div//ul/div/li[4]/div/img[1]")).click();
				extent.log(LogStatus.PASS, "Quality Monitoring for Leaders section is expanded successfully");
			}
			else
			{
				extent.log(LogStatus.WARNING, "Not able to expand Quality Monitoring for Leaders section");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "AssignmentMgr"));
				return flag=false;
			}
			Thread.sleep(4000);
			//expand forms folder
			if (driver.findElements(By.xpath("//div[@id='ext-comp-1004']/div/div/ul/div/li[4]/ul/li[4]/div/img[1]")).size()!=0)
			{
				driver.findElement(By.xpath("//div[@id='ext-comp-1004']/div/div/ul/div/li[4]/ul/li[4]/div/img[1]")).click();
				extent.log(LogStatus.PASS, "Forms section is expanded successfully");
			}
			else
			{
				extent.log(LogStatus.WARNING, "Not able to expand Forms section");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "AssignmentMgr"));
				return flag=false;
			}
			Thread.sleep(4000);
			String formnameApp;
			boolean temp=false;
			if (driver.findElements(By.xpath("//div[@id='ext-comp-1004']/div/div/ul/div/li[4]/ul/li[4]/ul/li")).size()!=0)
			{
				int rc=driver.findElements(By.xpath("//div[@id='ext-comp-1004']/div/div/ul/div/li[4]/ul/li[4]/ul/li")).size();
				System.out.println("rc:"+rc);
				for (int i=1;i<=rc;i++)
				{
					formnameApp=driver.findElement(By.xpath("//div[@id='ext-comp-1004']/div/div/ul/div/li[4]/ul/li[4]/ul/li["+i+"]/div/a/span")).getText();
					System.out.println("formnameApp:"+formnameApp);
					System.out.println("formname:"+FormName);
					if (formnameApp.contains(FormName))
					{
						temp=true;
						driver.findElement(By.xpath("//div[@id='ext-comp-1004']/div/div/ul/div/li[4]/ul/li[4]/ul/li["+i+"]/div/a/span")).click();
						extent.log(LogStatus.PASS, "FormName:"+FormName+" is displayed under the Forms section");
						Thread.sleep(4000);
						System.out.println("form exist");
						extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "AssignmentMgr"));
						break;
					}
				}
			}
			if (temp==true)
			{
				boolean option=false;
				boolean option1=false;
				//off to on
				if (driver.findElements(By.xpath("//div[@id='entitiesTabGroupsTree']/div[2]/div/ul/div/li/div/span[2]/div/div/img[@class='x-form-checktristate null']")).size()!=0)
				{
					option=true;
					driver.findElement(By.xpath("//div[@id='entitiesTabGroupsTree']/div[2]/div/ul/div/li/div/span[2]/div/div/img[@class='x-form-checktristate null']")).click();
					System.out.println("off to on checked");
					if (driver.findElement(By.xpath("//table[@id='btnSave']/tbody/tr[2]/td[2]/em/button")).isEnabled())
					{
						driver.findElement(By.xpath("//table[@id='btnSave']/tbody/tr[2]/td[2]/em/button")).click();
						Thread.sleep(5000);
						if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_OK.png") != null)
						{
							sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_OK.png");
							extent.log(LogStatus.PASS, "FormName:"+FormName+" is assigned through Entities");
							extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "AssignmentMgr"));
							
						}															
					}
					else
					{
						extent.log(LogStatus.PASS, "Save button is not enabled");
						return flag=false;
					}
				}
				if (option==false)
				{
					//already checked
					if (driver.findElements(By.xpath("//div[@id='entitiesTabGroupsTree']/div[2]/div/ul/div/li/div/span[2]/div/div/img[@class='x-form-checktristate x-form-checktristate-checked']")).size()!=0)
					{
						option1=true;
						System.out.println("already checked");
						extent.log(LogStatus.PASS, "FormName:"+FormName+" is already assigned through Entities");
						extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "AssignmentMgr"));
					}
				}
				if (option==false && option1==false)
				{
					//already inherited
					if (driver.findElements(By.xpath("//div[@id='entitiesTabGroupsTree']/div[2]/div/ul/div/li/div/span[2]/div/div/img[@class='x-form-checktristate x-form-checktristate-grayed']")).size()!=0)
					{
						System.out.println("already inherited");
						extent.log(LogStatus.PASS, "FormName:"+FormName+" is already inherited/assigned through Entities");
						extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "AssignmentMgr"));
					}
				}
			}
			if (temp==false)
			{
				extent.log(LogStatus.FAIL, "FormName:"+FormName+" is NOT displayed under the Forms section");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "AssignmentMgr"));
				return flag=false;
			}			
*/		}catch(Exception e){
			System.out.println(e);
		}finally{
			 Impact360Screen.closeQM(driver);
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,51);
		}
		return flag;
	}

}
