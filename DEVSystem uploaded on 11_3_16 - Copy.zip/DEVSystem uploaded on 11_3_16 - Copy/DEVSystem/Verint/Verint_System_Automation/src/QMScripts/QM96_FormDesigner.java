package QMScripts;

import java.io.File;
import java.io.FileInputStream;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Key;
import org.sikuli.script.KeyModifier;
import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.DataSourceScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.Impact360Screen;
import ScreenObjects.QualityMonitoringContactScreen;
import ScreenObjects.QualityMonitoringSearchScreen;
import Utilities.Utilities;

public class QM96_FormDesigner {
	public static ExtentReports extent = ExtentReports.get(DataSourceScreen.class);
	
	public static boolean Create_From_Designer() throws Exception
	{
		boolean flag=true;
		Screen sobj = new Screen ();
			
		String HTMLReportName="From_Designer"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Form Designer");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet"); 
	    String FormName = Ws.getCell(43,46).getContents();
		try
		{			
			Process p = Runtime.getRuntime().exec("C:\\Program Files\\I360\\FormDesigner\\Verint.EvaluationPackage.FormManagement.FormManagementUI.exe");
			
			for ( int k=1;k<=20;k++)
			{
				if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Username.png")!= null)
				{
					break;
				}
				else
				{
					Thread.sleep(4000);
				}
			}
			extent.log(LogStatus.INFO, "Create Form Designer ");	
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Username.png") != null)
			{
				sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Username.png",Utilities.Globlocators.getProperty("UserName"));			
				Thread.sleep(1000);
			}
			else
			{
				return flag=false;
			}
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Password.png") != null)
			{
				sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Password.png",Utilities.Globlocators.getProperty("Password"));				
				Thread.sleep(1000);
			}
			else
			{
				return flag=false;
			}
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Login.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Login.png");			
				Thread.sleep(1000);
			}
			else
			{
				return flag=false;
			}
			Thread.sleep(10000);
			for ( int y=1;y<=30;y++)
			{
				if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewForm.png")!= null)
				{
					break;
				}
				else
				{
					Thread.sleep(4000);
				}
			}
			//New form icon
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewForm.png") != null)
			{
				extent.log(LogStatus.PASS, "Form Designer Page is displayed");				
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewForm.png");			
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Form Designer Page is NOT displayed");
				return flag=false;
			}
			//new form name
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewFormName.png") != null)
			{
				sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewFormName.png",FormName);	
				extent.log(LogStatus.PASS, "New Form Name: .AutomationForm entered successfully");	
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to enter New Form Name: .AutomationForm");
				return flag=false;
			}
			//new form OK button
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewFormOK_button.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewFormOK_button.png");	
				extent.log(LogStatus.PASS, "Clicked on OK button successful");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on OK button");
				return flag=false;
			}
			//check for form name already exist or not
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_OK.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_OK.png");	
				extent.log(LogStatus.WARNING, "New Form - This name already exist is displayed");
				Thread.sleep(1000);
				return flag=false;
			}
			//new component icon - section
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewComponent.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewComponent.png");			
				Thread.sleep(3000);
			}
			else
			{
				return flag=false;
			}
			//section1
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Section1.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Section1.png");			
				Thread.sleep(3000);
			}
			else
			{
				return flag=false;
			}
			//section1 Name
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Section1_Name.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Section1_Name.png");
				sobj.type("a", KeyModifier.CTRL); // select all text			
				sobj.type(Key.BACKSPACE); // delete selection
				sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Section1_Name.png",".AutomationSection");
				extent.log(LogStatus.PASS, "Section Name:.AutomationSection entered successfully");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to enter Section Name:.AutomationSection");
				return flag=false;
			}
			//section1 view - enable comment
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Section_View.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Section_View.png");	
				extent.log(LogStatus.INFO, "Section View: Enable commnets selected");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.WARNING, "Section View: Enable commnets NOT selected");
				//return flag=false;
			}
			//new component icon - category
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewComponent.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewComponent.png");			
				Thread.sleep(3000);
			}
			else
			{
				return flag=false;
			}
			//select category1
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Category1.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Category1.png");			
				Thread.sleep(3000);
			}
			else
			{
				return flag=false;
			}
			//category1 name
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Category1_Name.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Category1_Name.png");			
				sobj.type("a", KeyModifier.CTRL); // select all text			
				sobj.type(Key.BACKSPACE); // delete selection
				sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Category1_Name.png",".AutomationCategory");
				extent.log(LogStatus.PASS, "Category Name: .AutomationCategory entered successfully");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to enter Category Name: .AutomationCategory");
				return flag=false;
			}
			//category view - enable comment
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Section_View.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Section_View.png");				
				Thread.sleep(3000);
			}
			else
			{
				return flag=false;
			}
			//new component icon - question
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewComponent.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewComponent.png");			
				Thread.sleep(3000);
			}
			else
			{
				return flag=false;
			}
			//select Question1
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Question1.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Question1.png");			
				Thread.sleep(3000);
			}
			else
			{
				return flag=false;
			}
			//question1 name
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Question1_Name.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Question1_Name.png");			
				sobj.type("a", KeyModifier.CTRL); // select all text			
				sobj.type(Key.BACKSPACE); // delete selection
				sobj.type(".AutomationQuestion");
				extent.log(LogStatus.PASS, "Question Name: .AutomationQuestion entered successfully");
				//sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Question1_Name.png",".AutomationQuestion");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to enter Question Name: .AutomationQuestion");
				return flag=false;
			}
			//Save
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Save.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Save.png");	
				extent.log(LogStatus.PASS, "Clicked on Save button");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on Save button");
				return flag=false;
			}			
			//Back to List
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_BackToList.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_BackToList.png");			
				Thread.sleep(6000);
			}
			else
			{
				return flag=false;
			}
			//AutomationForm Name
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_AutomationForm.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_AutomationForm.png");			
				Thread.sleep(8000);
			}
			else
			{
				return flag=false;
			}
			//change status to Published
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ChangeStatus.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ChangeStatus.png");
				extent.log(LogStatus.PASS, "Clicked on Change Status");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on Change Status");
				return flag=false;
			}
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Published.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Published.png");
				extent.log(LogStatus.PASS, "Change Status : Published is selected");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to select Published");
				return flag=false;
			}
			//QM97		
			extent.log(LogStatus.INFO, "Export the Form ***********");
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ExportForm.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ExportForm.png");
				extent.log(LogStatus.PASS, "Clicked on Export Form icon is successful");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on Export Form icon");
				return flag=false;
			}
			
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ExportXMLFileName.png") != null)
			{
				sobj.type("a", KeyModifier.CTRL); // select all text			
				sobj.type(Key.BACKSPACE);
				sobj.type("C:\\DEVSystem\\AutomationExportForm.xml");
				if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\Windows_Save.png") != null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Windows_Save.png");
					extent.log(LogStatus.PASS, "Clicked on Export Selected Form - Save");
				}
				else
				{
					extent.log(LogStatus.FAIL, "Not able to click on Export Selected Form - Save");
					return flag=false;
				}
				if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\Windows_ConfirmSaveAs_Save.png") != null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Windows_ConfirmSaveAs_Save.png");					
				}
				if (!Utilities.folderExist("C:\\DEVSystem\\AutomationExportForm.xml","file"))
			    {
					return flag=false;
			    }
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on Export Form icon");
				return flag=false;
			}
			//QM98
			extent.log(LogStatus.INFO, "Import the Form ***********");
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Import.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Import.png");
				extent.log(LogStatus.PASS, "Clicked on Import icon is successful");
				Thread.sleep(3000);
				sobj.type(Key.BACKSPACE);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on Import icon");
				return flag=false;
			}
			
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ImportFileName.png") != null)
			{						
				sobj.type("C:\\DEVSystem\\AutomationExportForm.xml");
				
			}
			
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ImportFormOpen.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ImportFormOpen.png");
				extent.log(LogStatus.PASS, "Clicked on Open button");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on Open button");
				return flag=false;
			}
			
			//import - new name
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ImportNewFormName.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ImportNewFormName.png");				
				Thread.sleep(1000);
				sobj.type("a", KeyModifier.CTRL); // select all text	
				sobj.type(Key.BACKSPACE);
				Thread.sleep(1000);
				sobj.type(".ImportNewForm");
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to enter New Form Name");
				return flag=false;
			}
			
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewFormOK_button.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewFormOK_button.png");	
				extent.log(LogStatus.PASS, "Clicked on OK button successful");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on OK button");
				return flag=false;
			}
			//Save
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Save.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Save.png");	
				extent.log(LogStatus.PASS, "Clicked on Save button");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on Save button");
				return flag=false;
			}			
			//Back to List
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_BackToList.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_BackToList.png");			
				Thread.sleep(6000);
			}
			else
			{
				return flag=false;
			}
			
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ImportedForm.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ImportedForm.png");	
				extent.log(LogStatus.PASS, "Form imported successfully");
				Thread.sleep(6000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Form NOT imported");
				return flag=false;
			}
			//QM99
			extent.log(LogStatus.INFO, "Change the status of the Form to Published***********");
			//change status to Published
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ChangeStatus.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ChangeStatus.png");
				extent.log(LogStatus.PASS, "Clicked on Change Status");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on Change Status");
				return flag=false;
			}
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Published.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Published.png");
				extent.log(LogStatus.PASS, "Change Status : Published is selected");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to select Published");
				return flag=false;
			}
			//QM100
			extent.log(LogStatus.INFO, "Open the Form ***********");
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ImportedForm.png") != null)
			{
				sobj.doubleClick(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ImportedForm.png");	
				Thread.sleep(3000);
			}
			
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ChildImportedForm.png") != null)
			{
				//sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ChildImportedForm.png");
				Thread.sleep(3000);
				sobj.doubleClick(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ChildImportedForm.png");	
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to select Form");
				return flag=false;
			}
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_BackToList.png") != null)
			{
				extent.log(LogStatus.PASS, "Form opened successfully");								
				Thread.sleep(6000);				
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to open Form");
				return flag=false;
			}
			System.out.println("QM102");
			//QM102 - modify
			extent.log(LogStatus.INFO, "Modify the Form ***********");
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_SectionModify.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_SectionModify.png");	
				if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_SectionModifyName.png") != null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_SectionModifyName.png");
					Thread.sleep(1000);
					sobj.type("a", KeyModifier.CTRL); // select all text	
					sobj.type(Key.BACKSPACE);
					Thread.sleep(1000);
					sobj.type("SectionNameModify");					
				}
				if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_CategoryModify.png") != null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_CategoryModify.png");	
					if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_CategoryModifyName.png") != null)
					{
						sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_CategoryModifyName.png");
						Thread.sleep(1000);
						sobj.type("a", KeyModifier.CTRL); // select all text	
						sobj.type(Key.BACKSPACE);
						Thread.sleep(1000);
						sobj.type("CategoryNameModify");					
					}
				}
				if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_QuestionModify.png") != null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_QuestionModify.png");	
					if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_QuestionModifyName.png") != null)
					{
						sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_QuestionModifyName.png");
						Thread.sleep(1000);
						sobj.type("a", KeyModifier.CTRL); // select all text	
						sobj.type(Key.BACKSPACE);
						Thread.sleep(1000);
						sobj.type("QuestionNameModify");					
					}
				}
				if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Save.png") != null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Save.png");	
					extent.log(LogStatus.PASS, "Clicked on Save button");
					Thread.sleep(3000);
				}
				else
				{
					extent.log(LogStatus.FAIL, "Not able to click on Save button");
					return flag=false;
				}
				Thread.sleep(6000);				
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to open Form");
				return flag=false;
			}
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ModifyValidation.png") != null)
			{
				extent.log(LogStatus.PASS, "Form Designer modification is successful");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Form Designer modification is NOT successful");
				return flag=false;
			}		
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_BackToList.png") != null)
			{
				extent.log(LogStatus.PASS, "Clicked on Back To List is successful");		
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_BackToList.png");			
				Thread.sleep(6000);				
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on Back To List");
				return flag=false;
			}
			
			/*if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_BackToList.png") != null)
			{
				extent.log(LogStatus.PASS, "Form opened successfully");		
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_BackToList.png");			
				Thread.sleep(5000);				
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to open Form");
				return flag=false;
			}*/
			System.out.println("QM103");
			//QM103
			extent.log(LogStatus.INFO, "Export the Form List to Excel ***********");
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ExportToExcel.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ExportToExcel.png");
				extent.log(LogStatus.PASS, "Clicked on Export List To Excel is successful");		
				Thread.sleep(3000);				
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on Export List To Excel");
				return flag=false;
			}
		
			sobj.type(Key.BACKSPACE);
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ExportExcelFileName.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ExportExcelFileName.png");					
				Thread.sleep(3000);		
				sobj.type("C:\\DEVSystem\\FormsList.xls");
				extent.log(LogStatus.PASS, "File Name: C:\\DEVSystem\\FormsList.xls is entered");	
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to enter Excel File Name");
				return flag=false;
			}
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\Windows_Save.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Windows_Save.png");
				Thread.sleep(2000);	
				extent.log(LogStatus.PASS, "Clicked on Export Selected Form - Save");
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on Export Selected Form - Save");
				return flag=false;
			}
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\Windows_ConfirmSaveAs_Save.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Windows_ConfirmSaveAs_Save.png");					
			}
			if (!Utilities.folderExist("C:\\DEVSystem\\FormsList.xls","file"))
		    {
				return flag=false;
		    }
			Thread.sleep(3000);
			//open excel and verify form name
			String formNameExport;
			boolean key=false;
			FileInputStream fis1 = new FileInputStream("C:\\DEVSystem\\FormsList.xls");
		    Workbook Wb1 = Workbook.getWorkbook(fis1);		
		    Sheet Ws1 = Wb1.getSheet("FormsList"); 
		    for(int row = 1;row < Ws1.getRows();row++)
		    {
		    	 formNameExport = Ws1.getCell(1,row).getContents();
		    	 if (formNameExport.contains("ImportNewForm"))
		    	 {
		    		 key=true;
		    		 break;
		    	 }
		    }
		    Wb1.close();
		    fis1.close();
		    if (key==true)
		    {
		    	extent.log(LogStatus.PASS, "Form Name: ImportNewForm is displayed in Excel sheet");
		    }
		    else
		    {
		    	extent.log(LogStatus.FAIL, "Form Name: ImportNewForm is NOT displayed in Excel sheet");
		    	//return flag=false;
		    }//end of 103
		    //QM104   
		    extent.log(LogStatus.INFO, "Rename the Form ***********");
		    if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ImportedForm.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ImportedForm.png");
				Thread.sleep(1000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to select Form Name: ImportNewForm");
				return flag=false;
			}
			 if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Rename.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Rename.png");
				extent.log(LogStatus.PASS, "Rename button clicked successfully");
				Thread.sleep(1000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on Rename button");
				return flag=false;
			}
			 
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_RenameFormName.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_RenameFormName.png");
				Thread.sleep(1000);
				sobj.type("a", KeyModifier.CTRL); // select all text	
				sobj.type(Key.BACKSPACE);
				Thread.sleep(1000);
				sobj.type(".RenameFormName");					
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to Rename Form Name");
				return flag=false;
			}
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewFormOK_button.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewFormOK_button.png");	
				extent.log(LogStatus.PASS, "Clicked on OK button successful");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on OK button");
				return flag=false;
			}
			//QM105
			extent.log(LogStatus.INFO, "Refresh the Form ***********");
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Refresh.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Refresh.png");	
				extent.log(LogStatus.PASS, "Able to Refresh the Form Designer");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to Refresh the Form Designer");
				return flag=false;
			}
			 
			//QM101
			extent.log(LogStatus.INFO, "Delete the Form ***********");
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_RenameForm_Homepage.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_RenameForm_Homepage.png");	
				extent.log(LogStatus.PASS, ".RenameFormName is selected");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to select .RenameFormName");
				return flag=false;
			}
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Delete.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Delete.png");
				extent.log(LogStatus.PASS, "Clicked on Delete button");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on Delete button");
				return flag=false;
			}
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Delete_Yes.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Delete_Yes.png");			
				Thread.sleep(3000);
			}
			else
			{
				return flag=false;
			}
			/*if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Close.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Close.png");
				extent.log(LogStatus.INFO, "Form Designer window is closed");
				Thread.sleep(3000);
			}*/
			
			
			
			
			
			
			
			
			
			
			
			
		}catch(Exception e){
			System.out.println(e);
		}finally{	
			String KILL = "taskkill /IM ";
		    String processName = "Verint.EvaluationPackage.FormManagement.FormManagementUI.exe"; //IE process
		    Runtime.getRuntime().exec(KILL + processName); 
		    Thread.sleep(3000);
		    driver.quit();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,46);
		}
		return flag;
	}

}
