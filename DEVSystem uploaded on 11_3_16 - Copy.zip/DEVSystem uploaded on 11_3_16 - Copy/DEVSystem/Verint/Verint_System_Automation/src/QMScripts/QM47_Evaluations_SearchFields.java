package QMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;

import java.util.Set;
import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import ScreenObjects.LoginScreen;
import ScreenObjects.PreferenceScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.Impact360Screen;
import ScreenObjects.QualityMonitoringContactScreen;

import Utilities.Utilities;

public class QM47_Evaluations_SearchFields {
	public static ExtentReports extent = ExtentReports.get(QM47_Evaluations_SearchFields.class);
	public static Screen sobj = new Screen ();
	
	public static boolean Evaluations_SearchFields() throws Exception
	{
		boolean flag=true;
		
		String mainWinID="";
		String HTMLReportName="QM45_Evaluations_SearchFields"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Evaluations Search Fileds");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	    String Minimum = Ws.getCell(17,70).getContents();
	    String Maximum = Ws.getCell(18,70).getContents();
	    String DateRangeFrom = Ws.getCell(35,70).getContents();
	    String DateRangeTo	= Ws.getCell(36,70).getContents();
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("QMEvaluatorUserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("QMEvaluatorPassword"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			Thread.sleep(5000);
			if (!VerintHomePageScreen.selectMenuItem(driver,"Interactions","Interactions Contacts"))
			{
				Thread.sleep(5000);
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("QMEvaluatorUserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("QMEvaluatorPassword"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
				Thread.sleep(6000);
			}
			Set<String> windowIds = driver.getWindowHandles();
			System.out.println("windows size:"+windowIds.size());
			if (windowIds.size() ==1)
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("QMEvaluatorUserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("QMEvaluatorPassword"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
				Thread.sleep(6000);				
			}
			
			Thread.sleep(6000);
			mainWinID=Utilities.setWindowFocus(driver);
			System.out.println(mainWinID);			
			
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png");
				Thread.sleep(3000); 
			}	
			driver.manage().window().maximize();
			if (!Impact360Screen.clickQMSearch(driver))	  //click on Search 
			{
				return flag=false;
			}
			if (!QualityMonitoringContactScreen.selectQMSearchContact_Betweenthesedatesandtimes(driver))	
			{
				flag=false;
			}
			
			if (!QualityMonitoringContactScreen.setQMSearchContact_DateRangeFrom(driver,DateRangeFrom))	
			{
				flag=false;
			}
			if (!QualityMonitoringContactScreen.setQMSearchContact_DateRangeTo(driver,DateRangeTo))	
			{
				flag=false;
			}
			
			if (!QualityMonitoringContactScreen.clickExecute(driver))	
			{
				flag=false;
			}
			if(QualityMonitoringContactScreen.verifycriteria(driver,"Number of Evaluations"))
			{
				extent.log(LogStatus.PASS,"criteria already present on screen");
				
			}
			else
			{
				
			
			if (!QualityMonitoringContactScreen.clickPreference(driver))
			{
				flag=false;
			}
			if(!PreferenceScreen.selectserachcriteria(driver,"Number of Evaluations"))
			{
				flag=false;
			}
			if(!PreferenceScreen.clickok(driver))
			{
				flag=false;
			}
			if(!QualityMonitoringContactScreen.verifycriteria(driver, "Number of Evaluations"))
			{
				flag=false;
			}
			}
			if(!QualityMonitoringContactScreen.clickSearch(driver))
			{
				flag=false;
			}
			driver.switchTo().defaultContent();
			Utilities.switchFrame(driver,"FR_SEARCH");
			Thread.sleep(1000);
			driver.findElement(By.id("dfd_MS_catDRC__ctl1__CollapseImage")).click();
			Thread.sleep(1000);
			driver.findElement(By.id("dfd_MS_catCD__ctl1__CollapseImage")).click();
			Thread.sleep(1000);
			driver.findElement(By.id("dfd_MS_catAD__ctl1__CollapseImage")).click();
			Thread.sleep(1000);
			/*if (!QualityMonitoringContactScreen.expandQMSearchAdvancedData(driver))		//expand adv.data	
			{
				return flag=false;
			}*/
			
			if (!QualityMonitoringContactScreen.setNumberOfEvaluations(driver,Minimum,Maximum))		//set min and max no.of holds	
			{
				return flag=false;
			}		
			if(!QualityMonitoringContactScreen.clickExecutesearch(driver))
			{
				flag=false;
			}
			
			
			/*if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ExecuteSearch.png")!=null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ExecuteSearch.png");
			}
			else
			{
				extent.log(LogStatus.FAIL,"Execute Search field is NOT displayed");
				return flag=false;
			}		*/	
			Thread.sleep(5000); 		
			
			if (!QualityMonitoringContactScreen.verifyContactsStartTime(driver))		//select contact start time	
			{
				flag=false;
			}
			
			if(!QualityMonitoringContactScreen.clickPreference(driver))
			{
				flag=false;
			}
			
			if(!PreferenceScreen.deselectserachcriteria(driver,"Number of Evaluations"))
			{
				flag=false;
			}
			if(!PreferenceScreen.clickok(driver))
			{
				flag=false;
			}
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Set<String> windowIds2 = driver.getWindowHandles();
			Iterator<String> itererator2 = windowIds2.iterator(); 			
			String mainWinID2 = itererator2.next();//main window 
			Thread.sleep(1000);	
			String  popWindow2 = itererator2.next();//popup window
			Thread.sleep(2000);	
			driver.switchTo().window(popWindow2);
			driver.close();
			Thread.sleep(3000);
			driver.switchTo().window(mainWinID2);
			Utilities.Logout(driver);
			driver.close();			
			driver.quit();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,70);
		}
		
		return flag;
	}

}
