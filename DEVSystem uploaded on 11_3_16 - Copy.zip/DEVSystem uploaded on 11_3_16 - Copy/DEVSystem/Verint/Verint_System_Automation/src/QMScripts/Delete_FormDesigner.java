package QMScripts;

import java.io.File;
import java.io.FileInputStream;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.FindFailed;
import org.sikuli.script.Key;
import org.sikuli.script.KeyModifier;
import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.DataSourceScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.Impact360Screen;
import ScreenObjects.QualityMonitoringContactScreen;
import ScreenObjects.QualityMonitoringSearchScreen;
import Utilities.Utilities;

public class Delete_FormDesigner {
	public static ExtentReports extent = ExtentReports.get(DataSourceScreen.class);
	public static Screen sobj = new Screen ();
	public static boolean DeleteFormDesigner() throws Exception
	{
		boolean flag=true;
		
			
		String HTMLReportName="From_Designer"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Form Designer");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet"); 
	    //String FormName = Ws.getCell(43,69).getContents();
		try
		{			
			Runtime.getRuntime().exec("C:\\Program Files\\I360\\FormDesigner\\Verint.EvaluationPackage.FormManagement.FormManagementUI.exe");
			for ( int k=1;k<=20;k++)
			{
				if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Username.png")!= null)
				{
					break;
				}
				else
				{
					Thread.sleep(4000);
				}
			}
			extent.log(LogStatus.INFO, "Create Form Designer ");	
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Username.png") != null)
			{
				sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Username.png",Utilities.Globlocators.getProperty("UserName"));			
				Thread.sleep(1000);
			}
			else
			{
				return flag=false;
			}
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Password.png") != null)
			{
				sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Password.png",Utilities.Globlocators.getProperty("Password"));				
				Thread.sleep(1000);
			}
			else
			{
				return flag=false;
			}
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Login.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Login.png");			
				Thread.sleep(1000);
			}
			else
			{
				return flag=false;
			}
			Thread.sleep(10000);
			for ( int y=1;y<=30;y++)
			{
				if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewForm.png")!= null)
				{
					break;
				}
				else
				{
					Thread.sleep(4000);
				}
			}

			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_AutomationForm.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_AutomationForm.png");	
				extent.log(LogStatus.PASS, ".AutomationForm is selected");
				Thread.sleep(3000);
				delete(driver);	
			}	
			else
			{
				extent.log(LogStatus.FAIL, ".AutomationForm is NOT displayed");
				flag=false;
			}
					
			boolean key=false;
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_SystemAutoFormWhite.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_SystemAutoFormWhite.png");	
				extent.log(LogStatus.PASS, ".AutomationForm is selected");
				Thread.sleep(3000);
				delete(driver);	
				key=true;
				
			}
			if (key==false)
			{
				extent.log(LogStatus.FAIL, ".SystemAutoForm is NOT displayed");
				flag=false;
			}
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_AutomationFormWhite.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_AutomationFormWhite.png");	
				extent.log(LogStatus.PASS, ".AutomationForm is selected");
				Thread.sleep(3000);
				delete(driver);	
			}
			
			
			
		}catch(Exception e){
			System.out.println(e);
		}finally{	
			String KILL = "taskkill /IM ";
		    String processName = "Verint.EvaluationPackage.FormManagement.FormManagementUI.exe"; //IE process
		    Runtime.getRuntime().exec(KILL + processName); 
		    Thread.sleep(3000);
		    driver.quit();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,69);
		}
		return flag;
	}
	public static void delete(WebDriver driver) throws Exception
	{
		if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Delete.png") != null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Delete.png");
			extent.log(LogStatus.PASS, "Clicked on Delete button");
			Thread.sleep(3000);
		}			
		if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Delete_Yes.png") != null)
		{
			sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Delete_Yes.png");			
			Thread.sleep(3000);
		}
	}

}
