package QMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import ScreenObjects.LoginScreen;

import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.ProfilesScreen;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;


public class QM08_09_Filters {
	
	
	public static ExtentReports extent = ExtentReports.get(QM08_09_Filters.class);
	
	public static boolean Filter() throws Exception
	{
		boolean flag=true;
		//String windowName="";
	
		String HTMLReportName="Filter"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Create Edit Delete User");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	    String FilterName = Ws.getCell(14,7).getContents();
	    //String FilterEditName = Ws.getCell(15,7).getContents();	
	    String organizatioName = Ws.getCell(5,7).getContents();	
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Profiles"))			
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Profiles"))				
				{
					extent.log(LogStatus.WARNING, "Profiles section is not displayed. Please try again");
					return flag=false;
				}				
			}
			if (!ProfilesScreen.selectView(driver,"Create Filter")) //select Create Filter view from View list box
			{
				return flag=false;
			}
			Thread.sleep(8000);
			//windowName=Utilities.setWindowFocus(driver);
			for(String winHandle :driver.getWindowHandles()){
                driver.switchTo().window(winHandle);
                System.out.println("title:"+driver.getTitle());
                if(driver.getTitle().contains("Employees Filter Configuration"))
                {
                	//flag=true;
                	System.out.println("You are in Filter window");
                	driver.manage().window().maximize();
                    break;
                }			
			}		
			ProfilesScreen.selectOrg_CreateFilter(driver,organizatioName);
			ProfilesScreen.clickSaveAs(driver);
			ProfilesScreen.setFilterNewName(driver,FilterName);
			ProfilesScreen.clickFilterNewNameSave(driver);
			Thread.sleep(6000);
			for(String winHandle : driver.getWindowHandles()){
			    driver.switchTo().window(winHandle);
			}
			//edit filter
			/*if (!ProfilesScreen.selectView(driver,"Create Filter")) //select Create Filter view from View list box
			{
				return flag=false;
			}
			Thread.sleep(8000);			
			for(String winHandle :driver.getWindowHandles()){
                driver.switchTo().window(winHandle);
                System.out.println("title:"+driver.getTitle());
                if(driver.getTitle().contains("Employees Filter Configuration"))
                {                	
                	System.out.println("You are in Filter window");
                	driver.manage().window().maximize();
                    break;
                }			
			}
			ProfilesScreen.clickSaveAs(driver);
			ProfilesScreen.setFilterNewName(driver,FilterEditName);
			ProfilesScreen.clickFilterNewNameSave(driver);
			Thread.sleep(6000);
			for(String winHandle : driver.getWindowHandles()){
			    driver.switchTo().window(winHandle);
			}*/
			//delete
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			//extent.endTest();
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,7);
		}
		return flag;
	}
	

}
