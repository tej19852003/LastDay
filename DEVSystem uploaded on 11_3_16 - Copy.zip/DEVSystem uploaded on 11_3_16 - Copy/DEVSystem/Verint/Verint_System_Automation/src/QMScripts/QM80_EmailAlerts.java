package QMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.AccessRightsScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.ProfilesScreen;
import ScreenObjects.VerintHomePageScreen;

import Utilities.Utilities;


public class QM80_EmailAlerts {
	
	public static boolean EmailAlerts() throws Exception
	{
		ExtentReports extent = ExtentReports.get(AccessRightsScreen.class);
		boolean flag=true;
		Screen sobj = new Screen ();
		
		
		String HTMLReportName="QM_EmailAlerts"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Quality Monitoring - Email Alerts");
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	    
	    String UserAlias = Ws.getCell(11,29).getContents();
	    String UserLastName = Ws.getCell(12,29).getContents();
	    String Email = Ws.getCell(34,29).getContents();
	    
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Profiles"))			
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Profiles"))				
				{
					extent.log(LogStatus.WARNING, "Profiles section is not displayed. Please try again");
					return flag=false;
				}				
			}
			//verify User exist or not
			if (!ProfilesScreen.FindSelect(driver, UserLastName))
			{			
				Utilities.selectRightPaneView(driver);				
				if (!ProfilesScreen.clickImportDomainUsers(driver))
				{
					return flag=false;
				}
				Thread.sleep(2000);				
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_EnterObjNameToSelect.png") != null)
				{
					sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_EnterObjNameToSelect.png", UserAlias);
				}				
				Thread.sleep(1000);
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_OK_Btn.png") != null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_OK_Btn.png");
				}				
				Thread.sleep(5000);
				Utilities.selectRightPaneView(driver);				
				if (!ProfilesScreen.checkErrorMessage(driver))
				{				
						return flag=false;
				}
				Thread.sleep(2000);				
				if (!ProfilesScreen.FindSelect(driver, UserLastName))
				{
					return flag=false;
				}			
			}
			Utilities.selectRightPaneView(driver);
			if (!ProfilesScreen.setContactInfo_Email(driver,Email))
			{
				return flag=false;
			}
			if (!ProfilesScreen.clickSave(driver))
			{
				return flag=false;
			}
			if (!ProfilesScreen.verifySuccessMessage(driver))
			{
				return flag=false;
			}
			
		}catch(Exception e){
			System.out.println(e);
		}finally{	
			Utilities.Logout(driver);			
			driver.close();
			driver.quit();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,29);
		}
		
		return flag;
		
	}
	

}
