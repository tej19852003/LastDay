package QMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;

import ScreenObjects.LoginScreen;

import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.ManageCoaching;
import ScreenObjects.OrganizationSettings;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class QM150_151_152_Coaching {
	
	public static ExtentReports extent = ExtentReports.get(QM150_151_152_Coaching.class);
	public static Screen sobj = new Screen ();
	public static boolean Coaching() throws Exception
	{				
		boolean flag=true;
		//Screen sobj = new Screen ();
		String HTMLReportName="Coahing"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Create Edit Delete Coaching");
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	    String organizationName = Ws.getCell(5,26).getContents();    
	    String organizationDesc = Ws.getCell(6,26).getContents();
	    String parentOrganization = Ws.getCell(7,26).getContents();
	    //String UserAlias = Ws.getCell(11,26).getContents();
	    //String UserLastName = Ws.getCell(12,26).getContents();
		
		try
		{			    
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Organization Settings"))
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Organization Settings"))				
				{
					extent.log(LogStatus.WARNING, "Not able to select Organization Settings. Please try again");
					return flag=false;
				}			
			}
			//verify whether Organization name is already exist or not, if not create organization
			if (!OrganizationSettings.verifyOrganizationFromLeftTreeFrame(driver,organizationName))
			{
				Utilities.selectLeftTreeFrame(driver);
				if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,parentOrganization))
				{
					return flag=false;
				}
				Utilities.selectRightPaneView(driver);
				if (!OrganizationSettings.clickCreateOrganization(driver))
				{
					return flag=false;
				}
				OrganizationSettings.setOrganizationName(driver,organizationName);
				OrganizationSettings.setOrganizationDescription(driver,organizationDesc);
				OrganizationSettings.isSelectedDaysAndHoursOfOperation(driver);
				if (!OrganizationSettings.clickSave(driver))
				{
					return flag=false;
				}
				//validation
				Utilities.selectLeftTreeFrame(driver);
				if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,organizationName))
				{
					return flag=false;
				}
			}
			/*//add user to organization
			driver.switchTo().defaultContent();
			if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Profiles"))
			{
				extent.log(LogStatus.WARNING, "Profiles section is not displayed. Please try again");
				return flag=false;
			}
			//verify User exist or not
			if (!ProfilesScreen.FindSelect(driver, UserLastName))
			{			
				Utilities.selectRightPaneView(driver);				
				if (!ProfilesScreen.clickImportDomainUsers(driver))
				{
					return flag=false;
				}
				Thread.sleep(2000);				
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_EnterObjNameToSelect.png") != null)
				{
					sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_EnterObjNameToSelect.png", UserAlias);
				}				
				Thread.sleep(1000);
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_OK_Btn.png") != null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_OK_Btn.png");
				}				
				Thread.sleep(5000);
				Utilities.selectRightPaneView(driver);
				if (!ProfilesScreen.checkErrorMessage(driver))
				{				
						return flag=false;
				}
				Thread.sleep(2000);				
				if (!ProfilesScreen.FindSelect(driver, UserLastName))
				{
					return flag=false;
				}				
			}
			//assign organization to user
			Utilities.selectRightPaneView(driver);
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Scrollbar.png");						
			if (!ProfilesScreen.clickOrganizationEdit(driver)) // click on organization edit icon
			{
				return flag=false;
			}
			Thread.sleep(6000);			
			String windowName=Utilities.setWindowFocus(driver);			
			ProfilesScreen.selectOrganizationFromListbox(driver,organizationName);		
				
			driver.switchTo().window(windowName);
			RolesSetupScreen.selectRightPaneView(driver);
			if (!ProfilesScreen.clickSave(driver))
			{
				return flag=false;
			}
			ProfilesScreen.verifySuccessMessage(driver);*/
			//coaching for agents
			driver.switchTo().defaultContent();
			if (!VerintHomePageScreen.selectMenuItem(driver,"Coaching","Manage Coaching"))
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Coaching","Manage Coaching"))
				{
					extent.log(LogStatus.WARNING, "Not able to select Coaching menu. Please try again");
					return flag=false;
				}			
			}
			Utilities.selectRightPaneView(driver);
			if (!ManageCoaching.clickCreate(driver))
			{
				return flag=false;
			}
			ManageCoaching.setReason(driver,"Reason");
			DateFormat dateFormat= new SimpleDateFormat("MM/dd/YYYY hh:mm a");

			Calendar c = Calendar.getInstance();    
			c.setTime(new Date());
			c.add(Calendar.DATE, 5);
			String datetime=dateFormat.format(c.getTime());
			
			ManageCoaching.setDateTime(driver,datetime);
			ManageCoaching.setLocation(driver,"Location");
			if (!ManageCoaching.clickSave(driver))
			{
				return flag=false;
			}
			if (!ManageCoaching.clickPending(driver))
			{
				return flag=false;
			}
			ManageCoaching.verifyStatus(driver,datetime,"Pending");
			//edit coaching
			/*driver.switchTo().defaultContent();
			if (!VerintHomePageScreen.selectMenuItem(driver,"Coaching","Manage Coaching"))
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Coaching","Manage Coaching"))
				{
					extent.log(LogStatus.WARNING, "Not able to select Coaching menu. Please try again");
					return flag=false;
				}			
			}
			//select organization from left frame
			Utilities.selectLeftTreeFrame(driver);
			if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,organizationName))
			{
				return flag=false;
			}
			Utilities.selectRightPaneView(driver);
			if (!ManageCoaching.selectCoaching(driver,datetime)) //select coaching
			{
				return flag=false;
			}*/
			if (!ManageCoaching.clickEdit(driver))
			{
				return flag=false;
			}
			Utilities.selectRightPaneView(driver);
			ManageCoaching.setReason(driver,"Updated Reason");
			ManageCoaching.setLocation(driver,"Updated Location");
			if (!ManageCoaching.clickSave(driver))
			{
				return flag=false;
			}
			if (!ManageCoaching.clickEditPending(driver))
			{
				return flag=false;
			}
			//delete coaching
			if (!ManageCoaching.selectCoaching(driver,datetime)) //select coaching
			{
				return flag=false;
			}
			if (!ManageCoaching.clickDelete(driver))
			{
				return flag=false;
			}
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Delete_OK1.png")!=null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Delete_OK1.png");				
			}
			//Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Delete_OK1.png");	
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,26);
		}
		return flag;
	}


	

}
