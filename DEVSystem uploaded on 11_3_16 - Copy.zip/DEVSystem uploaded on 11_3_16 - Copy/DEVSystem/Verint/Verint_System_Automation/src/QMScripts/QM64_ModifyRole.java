package QMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import ScreenObjects.LoginScreen;
import ScreenObjects.NewRoleScreen;
import ScreenObjects.RolesSetupScreen;
import ScreenObjects.VerintHomePageScreen;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class QM64_ModifyRole {
	
	
	public static ExtentReports extent = ExtentReports.get(QM64_ModifyRole.class);
	
	public static boolean ModifyRole() throws Exception
	{
		
		boolean flag=true;
		String HTMLReportName="QM64_ModifyRole"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Modify Role");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	    String ParentOrganization = Ws.getCell(7,22).getContents();
	    String RoleName = Ws.getCell(8,22).getContents();
	    String RoleDesc = Ws.getCell(9,22).getContents();  
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Role Setup"))			
			{
				Utilities.Logout(driver);				
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Role Setup"))					
				{
					extent.log(LogStatus.WARNING, "Roles Setup section is not displayed. Please try again.");
					return flag=false;
				}
			}
				
			RolesSetupScreen.selectNodeFromLeftTreePane(driver,ParentOrganization);
			RolesSetupScreen.selectRightPaneView(driver);
			
			//verify role name already exist or not
			if (!RolesSetupScreen.verifyRoleName(driver,RoleName))
			{			
				if (!RolesSetupScreen.clickCreateNewRole(driver))
				{
					return flag=false;
				}
				
				if (!NewRoleScreen.setTextInRolename(driver,RoleName))
				{
					return flag=false;
				}
				NewRoleScreen.setTextInRoleDescription(driver,RoleDesc);
				//NewRoleScreen.expandPrivilege(driver);
				NewRoleScreen.selectInteractionsContactsPlaybackPrivilege(driver,"ON");
				if (!NewRoleScreen.clickSave(driver))			
				{
					return flag=false;
				}
				RolesSetupScreen.selectRightPaneView(driver);
				//validation- role created or not
				
			}
			
			if (!RolesSetupScreen.selectRoleName(driver,RoleName))
			{
				return flag=false;
			}
			//Edit Role
			if (!RolesSetupScreen.clickViewEditRole(driver))
			{
				return flag=false;
			}
			NewRoleScreen.selectInteractionsContactsPlaybackPrivilege(driver,"OFF");
			if (!NewRoleScreen.clickSave(driver))			
			{
				return flag=false;
			}
			
			//delete role
			RolesSetupScreen.selectRightPaneView(driver);
			if (!RolesSetupScreen.selectRoleName(driver,RoleName))
			{
				return flag=false;
			}
			if (!RolesSetupScreen.clickDeleteRole(driver))
			{
				return flag=false;
			}
			
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,22);
		}
		return flag;
	}


}
