package QMScripts;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStreamReader;

import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.sikuli.script.Screen;


import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class QM_Issuance_Install_Workstation {
	
	public static ExtentReports extent = ExtentReports.get(QM_Issuance_Install_Workstation.class);
	public static Screen sobj = new Screen ();
	public static boolean Issuance_Install_Workstation() throws Exception
	{		
		String HTMLReportName="QM_Issuance_Install_Workstation"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Issuance Install In The Workstation");
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	    String sysType = Ws.getCell(44,1).getContents();
		boolean flag=true;
		try{	
			//QM001 - playback
			//if (!Utilities.folderExist(Utilities.Globlocators.getProperty("PlaybackFolderPath"),"Folder"))
			//{
				File prodDir=new File(Utilities.Globlocators.getProperty("PlaybackFolderPath"));
				boolean exists = prodDir.exists();
			    if (exists) 
			    {
			    	extent.log(LogStatus.PASS, Utilities.Globlocators.getProperty("PlaybackFolderPath")+" "+"Folder"+" exists");	    	
			    }
			    else
			    {
			    	extent.log(LogStatus.FAIL, Utilities.Globlocators.getProperty("PlaybackFolderPath")+" "+"Folder"+" does not exists");
			    	return flag=false;
			    }
				//extent.log(LogStatus.FAIL, "Playback folder does not exist");
		    	//flag=false;
			//}  
			File currentDirPB = new File(Utilities.Globlocators.getProperty("PlaybackFolderPath")+"\\");
			Utilities.displayDirectoryContents(currentDirPB);
			
			//QM007 - formdesigner
			//if (!Utilities.folderExist(Utilities.Globlocators.getProperty("FormDesignerFolderPath"),"Folder"))
		    	//flag=false;
			File prodDirFD=new File(Utilities.Globlocators.getProperty("FormDesignerFolderPath"));
			boolean existsFD = prodDirFD.exists();
		    if (existsFD) 
		    {
		    	extent.log(LogStatus.PASS, Utilities.Globlocators.getProperty("FormDesignerFolderPath")+" "+"Folder"+" exists");	    	
		    }
		    else
		    {
		    	extent.log(LogStatus.FAIL, Utilities.Globlocators.getProperty("FormDesignerFolderPath")+" "+"Folder"+" does not exists");
		    	return flag=false;
		    }
		    	    
			File currentDirForm = new File(Utilities.Globlocators.getProperty("FormDesignerFolderPath")+"\\");
			Utilities.displayDirectoryContents(currentDirForm);
			
			//QM013 - Screen capture
			//if (!Utilities.folderExist(Utilities.Globlocators.getProperty("ScreenCaptureFolderPath"),"Folder"))
		    	//flag=false;
			File prodDirSC=new File(Utilities.Globlocators.getProperty("ScreenCaptureFolderPath"));
			boolean existsSC = prodDirSC.exists();
		    if (existsSC) 
		    {
		    	extent.log(LogStatus.PASS, Utilities.Globlocators.getProperty("ScreenCaptureFolderPath")+" "+"Folder"+" exists");	    	
		    }
		    else
		    {
		    	extent.log(LogStatus.FAIL, Utilities.Globlocators.getProperty("ScreenCaptureFolderPath")+" "+"Folder"+" does not exists");
		    	return flag=false;
		    }
			
		    	    
			File currentDir = new File(Utilities.Globlocators.getProperty("ScreenCaptureFolderPath")+"\\");
			Utilities.displayDirectoryContents(currentDir);
			//QM019 - pop up client
			//if (!Utilities.folderExist(Utilities.Globlocators.getProperty("PopupClientFolderPath"),"Folder"))
		    	//flag=false;
			File prodDirPC=new File(Utilities.Globlocators.getProperty("PopupClientFolderPath"));
			boolean existsPC = prodDirPC.exists();
		    if (existsPC) 
		    {
		    	extent.log(LogStatus.PASS, Utilities.Globlocators.getProperty("PopupClientFolderPath")+" "+"Folder"+" exists");	    	
		    }
		    else
		    {
		    	extent.log(LogStatus.FAIL, Utilities.Globlocators.getProperty("PopupClientFolderPath")+" "+"Folder"+" does not exists");
		    	return flag=false;
		    }
			
		    	    
			File currentDirPC = new File(Utilities.Globlocators.getProperty("PopupClientFolderPath")+"\\");
			Utilities.displayDirectoryContents(currentDirPC);
			
			//QM025 - AIM			
			File prodDirAIM=new File(Utilities.Globlocators.getProperty("AIMFolderPath"));
			if (prodDirAIM.canExecute())		   
		    {
		    	extent.log(LogStatus.PASS, Utilities.Globlocators.getProperty("AIMFolderPath")+" "+"File"+" exists");	    	
		    }
		    else
		    {
		    	extent.log(LogStatus.FAIL, Utilities.Globlocators.getProperty("AIMFolderPath")+" "+"File"+" does not exists");
		    	flag=false;
		    }
			 //QM027 - AIM logs
		    if (!Issuance(Utilities.Globlocators.getProperty("AIMLogiFileName"),"QM027_AIMIssuance_Logs", "AIMIssuance_QM026", "AIM IssuanceIn The Workstation"))	
			{
				extent.log(LogStatus.FAIL, "The installation was successful message is NOT displayed");
				flag=false;
			}
			//QM002 - play back issuance logs
			if (!Issuance(Utilities.Globlocators.getProperty("PlaybackLogFileName"),"QM002_PlaybackIssuance_Logs", "PlaybackIssuance_QM002", "Playback IssuanceIn The Workstation"))	
			{
				extent.log(LogStatus.FAIL, "The installation was successful message is NOT displayed");
				flag=false;
			}
			//QM008 - form designer issuance logs
			if (!Issuance(Utilities.Globlocators.getProperty("FormDesignerFileName"),"QM008_FormDesignerIssuance_Logs", "FormDesignerIssuance_QM008", "FormDesigner Issuance In The Workstation"))
			{
				extent.log(LogStatus.FAIL, "The installation was successful message is NOT displayed");
				flag=false;
			}
			//QM014 - screen capture logs
			if (!Issuance(Utilities.Globlocators.getProperty("ScreenCaptureLogFileName"),"QM014_ScreenCapture_Issuance_Logs", "ScreenCapture_QM014", "Screen Capture IssuanceIn The Workstation"))	
			{
				extent.log(LogStatus.FAIL, "The installation was successful message is NOT displayed");
				flag=false;
			}
			//QM020 - PopupClient Issuance Logs
			if (!Issuance(Utilities.Globlocators.getProperty("PopupClientLogFileName"),"QM020_PopupClient_Issuance_Logs", "PopupClientIssuance_QM020", "Popup Client Issuance In The Workstation"))	
			{
				extent.log(LogStatus.FAIL, "The installation was successful message is NOT displayed");
				flag=false;
			}
			//QM09
			if (sysType.contains("32"))
			{
				Process p = Runtime.getRuntime().exec("C:\\Program Files\\I360\\FormDesigner\\Verint.EvaluationPackage.FormManagement.FormManagementUI.exe");
			}
			else
			{
				Process p = Runtime.getRuntime().exec("C:\\Program Files (x86)\\I360\\FormDesigner\\Verint.EvaluationPackage.FormManagement.FormManagementUI.exe");
			}
			Thread.sleep(6000);
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Username.png") != null)
			{
				sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Username.png",Utilities.Globlocators.getProperty("UserName"));			
				Thread.sleep(1000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Form Designer Username is NOT displayed");
				return flag=false;
			}
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Password.png") != null)
			{
				sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Password.png",Utilities.Globlocators.getProperty("Password"));				
				Thread.sleep(1000);
			}
			else
			{
				return flag=false;
			}
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Login.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Login.png");			
				Thread.sleep(1000);
			}
			else
			{
				return flag=false;
			}
			Thread.sleep(10000);
			Thread.sleep(10000);
			//New form icon
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewForm.png") != null)
			{
				extent.log(LogStatus.PASS, "Form Designer Page is displayed");	
				
			}
			else
			{
				extent.log(LogStatus.FAIL, "Form Designer Page is NOT displayed");
				flag=false;				
			}
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Close.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Close.png");
				extent.log(LogStatus.INFO, "Form Designer window is closed");
				Thread.sleep(3000);
			}
			String KILL = "taskkill /IM ";
		    String processName = "iexplore.exe"; //IE process
		    Runtime.getRuntime().exec(KILL + processName); 
		    Thread.sleep(3000);
		   
		} catch (Exception err) {
	        err.printStackTrace();
	    }finally
	    {
	    	Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,1);
	    }
		return flag;
	}
	
	public static boolean Issuance(String LogFileName,String FolderName,String HTMLReportName,String TestcaseName) throws Exception
	{
		
		boolean flag=true;
		try{
		//Utilities.testcaseSetup(FolderName, HTMLReportName, TestcaseName);
		//Utilities.testcaseSetup("QM002_Issuance", "PlaybackIssuance_QM002", "Playback IssuanceIn The Workstation_QM002");
		System.out.println("LogFileName:"+"C:\\PROD\\ISS\\LOGS\\"+LogFileName);
	    if (!Utilities.folderExist("C:\\PROD","Folder"))
	    	return flag=false;
	    if (!Utilities.folderExist("C:\\PROD\\ISS","Folder"))
	    	return flag=false;
	    if (!Utilities.folderExist("C:\\PROD\\ISS\\LOGS","Folder"))
	    	return flag=false;
	    if (!Utilities.folderExist("C:\\PROD\\ISS\\LOGS\\"+LogFileName, "File"))
	    	return flag=false;
	    //check time of log file
	    String path="C:\\PROD\\ISS\\LOGS\\"+LogFileName;
	    System.out.println(path);
	    Process proc = Runtime.getRuntime().exec("cmd /c dir \"" + path + "\" /tc");
 		BufferedReader br = 
 		   new BufferedReader(
 		      new InputStreamReader(proc.getInputStream()));
 		
 		String data ="";
 		for(int i=0; i<6; i++){
 			data = br.readLine();
 			System.out.println(data);
 		}
 		extent.log(LogStatus.INFO, "Time of creation of log file:"+data);
 		System.out.println("Extracted value : " + data);
	    //read Installation was successful
 		FileReader FR = new FileReader("C:\\PROD\\ISS\\LOGS\\"+Utilities.Globlocators.getProperty("PlaybackLogFileName"));
		BufferedReader BR = new BufferedReader(FR);
		String Content = "";
		boolean temp=false;
		//Loop to read all lines one by one from file and print It.
		while((Content = BR.readLine())!= null)
		{
			if (Content.contains("The installation was successful"))
			{
				temp=true;
				break;
			}
			
		}
		if (temp)
			extent.log(LogStatus.PASS, "The installation was successful message is displayed as Expected");
		else
		{
			extent.log(LogStatus.FAIL, "The installation was successful message is NOT displayed");
			return flag=false;
		}
		}catch(Exception e){
			System.out.println(e);
		}
			
		return flag;
	}
	
}
