package QMScripts;

import java.io.File;
import java.io.FileInputStream;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.sikuli.script.Key;
import org.sikuli.script.KeyModifier;
import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.DataSourceScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.Impact360Screen;
import ScreenObjects.QualityMonitoringContactScreen;
import ScreenObjects.QualityMonitoringSearchScreen;
import Utilities.Utilities;

public class QM71_72_73_74_Annotation {
	public static ExtentReports extent = ExtentReports.get(DataSourceScreen.class);
	public static Screen sobj = new Screen ();
	public static String mainWinID="";
	public static boolean Add_Modify_Delete_Annotation() throws Exception
	{
		boolean flag=true;
		
		String mainWinID="";	
		String HTMLReportName="QM71_72_73_74_Annotation"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Add Modify Delete - Annotation");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	    
	    String NumberOfRecords = Ws.getCell(16,27).getContents();		
		
		try
		{			
			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			Thread.sleep(5000);
			if (!VerintHomePageScreen.selectMenuItem(driver,"Interactions","Interactions Contacts"))
			{
				Thread.sleep(5000);
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
				Thread.sleep(6000);
			}
			
			if (!searchRecords_QM_Contacts(driver,NumberOfRecords,"Quality Monitoring"))
			{
				flag=false;
			}
			//select contact start time link
			/*if (!QualityMonitoringSearchScreen.selectContactsStartTime(driver,""))		//select contact start time	
			{
				return flag=false;
			}*/
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Play.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Play.png");
			}
			//click on Annotation
			
			Thread.sleep(3000);
			driver.switchTo().defaultContent();
			driver.switchTo().frame("FR_PLAYBACK");	
			Thread.sleep(2000);
			driver.switchTo().frame("FR_PLAYBACK");
			
			WebElement oRightPaneContentFrame = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.id("annotationFrame")));
			driver.switchTo().frame(oRightPaneContentFrame);
			
			Thread.sleep(3000);
			
			/*if (driver.findElements(By.xpath("//div[@id='Annotations1_AnnotationToolbar1']/div/a/img[@id='Annotations1_AnnotationToolbar1_imgAddAnnotation']")).size()!=0)
			{
				driver.findElement(By.xpath("//div[@id='Annotations1_AnnotationToolbar1']/div/a/img[@id='Annotations1_AnnotationToolbar1_imgAddAnnotation']")).click();
			}
			if (driver.findElements(By.xpath("//div[@id='Annotations1_AnnotationToolbar1_divNewAnnotation']/a/img[@id='Annotations1_AnnotationToolbar1_imgAddAnnotation][@alt='Add Annotation']")).size()!=0)
			{
				driver.findElement(By.xpath("//div[@id='Annotations1_AnnotationToolbar1_divNewAnnotation']/a/img[@id='Annotations1_AnnotationToolbar1_imgAddAnnotation][@alt='Add Annotation']")).click();
			}*/
			//driver.findElement(By.xpath("//div[@id='Annotations1_AnnotationToolbar1']/div/a/img[@alt='Add Annotation']")).click();
			if (driver.findElements(By.xpath("//img[@title='Add Annotation']")).size()!=0)
			{
				driver.findElement(By.xpath("//img[@title='Add Annotation']")).click();
			}
			
			//driver.findElement(By.xpath("//a[@title='Add Annotation'][@id='aNewAnnotation']")).click();
			
			/*if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_AddAnnotation.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_AddAnnotation.png");
			}*/
			Thread.sleep(3000);
			boolean temp=false;
			String parentHandle = driver.getWindowHandle();
			for(String winHandle :driver.getWindowHandles()){
                driver.switchTo().window(winHandle);
                System.out.println("title:"+driver.getTitle());
                if(driver.getTitle().contains("Add Annotation"))
                {
                	temp=true;
                	System.out.println("You are in Annotation window");
                	driver.findElement(By.xpath("//table[@class='tableAnnotationsNoBorder']/tbody/tr[3]/td[2]/input[@id='AnnotationNameTextBox']")).sendKeys("AutomationTest");
                	//remarks
                	/*WebElement remarksFrame = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.id("editor1_WYSIWYG_Editor")));
        			driver.switchTo().frame(remarksFrame);
        			
        			//driver.findElement(By.xpath("//table[@id='editor1_table']/tbody/tr[1]/td[1]/iframe/html/body")).sendKeys("hello");
        			
                	//driver.findElement(By.xpath("//table[@id='editor1_table']/tbody/tr[1]/td[1]")).sendKeys("Remarks");
                	//driver.findElement(By.xpath("//html/body")).sendKeys("Remarks");
        			WebElement element = driver.findElement(By.cssSelector("body"));
        			element.sendKeys("Send keys");*/
        			//driver.findElement(By.xpath("//a[@id='OKButton_OKButton']")).click();
                	if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_WebPortalPref_OK.png") != null)
        			{
        				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_WebPortalPref_OK.png");
        			}
                	//driver.manage().window().maximize();
                    break;
                }			
			}
			
			
			if (temp==false)
			{
				return flag=false;
			}
			
			//edit annotation
			Thread.sleep(2000);
			Set<String> windowIds2 = driver.getWindowHandles();
			Iterator<String> itererator2 = windowIds2.iterator(); 			
			String mainWinID2 = itererator2.next();//main window 
			
			//driver.switchTo().window(mainWinID1).close();
			Thread.sleep(1000);	
			String  popWindow2 = itererator2.next();//popup window
			Thread.sleep(2000);	
			driver.switchTo().window(popWindow2);
			
			Thread.sleep(3000);
			driver.switchTo().defaultContent();
			driver.switchTo().frame("FR_PLAYBACK");	
			Thread.sleep(2000);
			driver.switchTo().frame("FR_PLAYBACK");
			
			WebElement oRightPaneContentFrame1 = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.id("annotationFrame")));
			driver.switchTo().frame(oRightPaneContentFrame1);			
			Thread.sleep(3000);
			boolean Temp1=false;
			int rcAccRt=driver.findElements(By.xpath("//table[@id='tableAnnotations']/tbody/tr")).size();
			System.out.println("rcAccRt:"+rcAccRt);
			for (int a=1;a<=rcAccRt;a++)
			{
				
				String empApp=driver.findElement(By.xpath("//table[@id='tableAnnotations']/tbody/tr["+a+"]/td[2]/a")).getText().trim();
				System.out.println("empApp:"+empApp);
				Thread.sleep(1000);
				if (empApp.contains("AutomationTest"))
				{					
					//driver.findElement(By.xpath("//table[@id='tableAnnotations']/tbody/tr["+a+"]/td[1]/img[@title='Select Private Annotation']")).click();										
					driver.findElement(By.xpath("//table[@id='tableAnnotations']/tbody/tr["+a+"]/td[2]/a")).click();
					Thread.sleep(2000);
					if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_WebPortalPref_OK.png") != null)
        			{
        				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_WebPortalPref_OK.png");
        			}
					Temp1=true;
					break;
				}
			}
			if (Temp1==true)
			{				
				extent.log(LogStatus.PASS, "Name: AutomationTest Created/Selected successfully");								
			}
			else
			{
				extent.log(LogStatus.FAIL, "Unable to Create/Select Name: AutomationTest");
				
				return Temp1 =false;
			}
			if (Temp1==true)
			{
				if (driver.findElements(By.xpath("//img[@title='Edit Annotation']")).size()!=0)
				{
					driver.findElement(By.xpath("//img[@title='Edit Annotation']")).click();
				}
			}
			boolean temp2=false;
			String parentHandle1 = driver.getWindowHandle();
			for(String winHandle :driver.getWindowHandles()){
                driver.switchTo().window(winHandle);
                System.out.println("title:"+driver.getTitle());
                if(driver.getTitle().contains("Edit Annotation"))
                {
                	temp2=true;
                	System.out.println("You are in Annotation window");
                	driver.findElement(By.xpath("//table[@class='tableAnnotationsNoBorder']/tbody/tr[3]/td[2]/input[@id='AnnotationNameTextBox']")).clear();
                	driver.findElement(By.xpath("//table[@class='tableAnnotationsNoBorder']/tbody/tr[3]/td[2]/input[@id='AnnotationNameTextBox']")).sendKeys("UpdatedAutomationTest");
                	/*//remarks
                	WebElement remarksFrame = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.id("editor1_WYSIWYG_Editor")));
        			driver.switchTo().frame(remarksFrame);
        			
                	driver.findElement(By.xpath("//html/body")).clear();
                	driver.findElement(By.cssSelector("body")).sendKeys("Updated Remarks");
        			//driver.findElement(By.xpath("//a[@id='OKButton_OKButton']")).click();
*/                	if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_WebPortalPref_OK.png") != null)
        			{
        				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_WebPortalPref_OK.png");
        			}
                	//driver.manage().window().maximize();
                    break;
                }			
			}
			//verify updatedAutomationTest
			
			
			//delete annotation
			Thread.sleep(2000);
			Set<String> windowIds3 = driver.getWindowHandles();
			Iterator<String> itererator3 = windowIds3.iterator(); 			
			String mainWinID3 = itererator3.next();//main window 
			
			//driver.switchTo().window(mainWinID1).close();
			Thread.sleep(1000);	
			String  popWindow3 = itererator3.next();//popup window
			Thread.sleep(2000);	
			driver.switchTo().window(popWindow3);
			
			Thread.sleep(3000);
			driver.switchTo().defaultContent();
			driver.switchTo().frame("FR_PLAYBACK");	
			Thread.sleep(2000);
			driver.switchTo().frame("FR_PLAYBACK");
			
			WebElement annotationFrame3 = (new WebDriverWait(driver,10)).until(ExpectedConditions.elementToBeClickable(By.id("annotationFrame")));
			driver.switchTo().frame(annotationFrame3);			
			Thread.sleep(3000);
			boolean Temp3=false;
			int rcAccRt3=driver.findElements(By.xpath("//table[@id='tableAnnotations']/tbody/tr")).size();
			System.out.println("rcAccRt:"+rcAccRt3);
			for (int a=1;a<=rcAccRt3;a++)
			{
				
				String empApp=driver.findElement(By.xpath("//table[@id='tableAnnotations']/tbody/tr["+a+"]/td[2]/a")).getText().trim();
				System.out.println("empApp:"+empApp);
				Thread.sleep(1000);
				if (empApp.contains("Updated"))
				{					
					//driver.findElement(By.xpath("//table[@id='tableAnnotations']/tbody/tr["+a+"]/td[1]/img[@title='Select Private Annotation']")).click();										
					driver.findElement(By.xpath("//table[@id='tableAnnotations']/tbody/tr["+a+"]/td[2]/a")).click();
					Thread.sleep(2000);
					if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_WebPortalPref_OK.png") != null)
        			{
        				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_WebPortalPref_OK.png");
        			}
					Temp1=true;
					break;
				}
			}
			if (Temp1==true)
			{				
				extent.log(LogStatus.PASS, "Name: UpdatedAutomationTest Created/Selected successfully");								
			}
			else
			{
				extent.log(LogStatus.FAIL, "Unable to Create/Select Name: UpdatedAutomationTest");
				
				return Temp1 =false;
			}
			if (Temp1==true)
			{
				if (driver.findElements(By.xpath("//img[@title='Delete Annotation']")).size()!=0)
				{
					driver.findElement(By.xpath("//img[@title='Delete Annotation']")).click();
					Thread.sleep(2000);
				}
			}
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Delete_Yes.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Delete_Yes.png");
			}
			
			
			Thread.sleep(2000);
			Set<String> windowIds4 = driver.getWindowHandles();
			Iterator<String> itererator4 = windowIds4.iterator(); 			
			String mainWinID4 = itererator4.next();//main window 
			
			//driver.switchTo().window(mainWinID1).close();
			Thread.sleep(1000);	
			String  popWindow4 = itererator4.next();//popup window
			Thread.sleep(2000);	
			driver.switchTo().window(popWindow4);
			driver.close();
			Thread.sleep(3000);
			driver.switchTo().window(mainWinID4);
			
			}catch(Exception e){
				System.out.println(e);
			}finally{	
				
				Utilities.Logout(driver);
				driver.close();
				driver.quit();
				Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,27);
			}
			return flag;
	}

	
			
	public static boolean searchRecords_QM_Contacts(WebDriver driver,String NumberOfRecords,String MenuItem) throws Exception
	{
				
		boolean temp=true;
		try
		{
			Set<String> windowIds = driver.getWindowHandles();
			System.out.println("windows size:"+windowIds.size());
			if (windowIds.size() ==1)
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return temp=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions",MenuItem);
				Thread.sleep(6000);				
			}
						
			
			mainWinID=Utilities.setWindowFocus(driver);
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png");
			}			
			if (!Impact360Screen.clickQMSearch(driver))	  //click on Search 
			{
				return temp=false;
			}
			Thread.sleep(6000); 
			
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_DateRange.png")!=null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_DateRange.png");
				sobj.type("a", KeyModifier.CTRL); // select all text			
				sobj.type(Key.BACKSPACE); // delete selection
				sobj.type(NumberOfRecords);
			}
			/*else
			{
				extent.log(LogStatus.FAIL,"Date Range text field is NOT displayed");
				return temp=false;
			}*/
			
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ExecuteSearch.png")!=null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ExecuteSearch.png");
			}
			else
			{
				extent.log(LogStatus.FAIL,"Execute Search field is NOT displayed");
				return temp=false;
			}			
			Thread.sleep(8000); 			
			/*if (!verifyContactsResults(driver))
			{
				temp=false;
			}*/
			
			
		}catch(Exception e){
			System.out.println(e);
		}
		return temp;
	}
	
	public static boolean verifyContactsResults(WebDriver driver) throws Exception
	{
		Boolean flag=false;
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_NoContacts.png")==null)
		{
			Thread.sleep(5000);
			driver.switchTo().frame(0);
		    driver.switchTo().frame("Grid");		   
			
			int rcCall=driver.findElements(By.xpath("//table[@id='POG1']/tbody/tr")).size();
			System.out.println("callRC:"+rcCall);			
			if (rcCall>1)
			{
				extent.log(LogStatus.PASS, "Contact results are displayed successfully");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QMCall"));
				flag=true;			
			}
			else
			{
				extent.log(LogStatus.WARNING,"Contacts results were not displayed");
				extent.log(LogStatus.WARNING, "", "", Utilities.captureScreenShot(driver, "QMCall"));
				return flag =false;
			}				
		}
		else
		{
			extent.log(LogStatus.WARNING, "Message : No contacts were found. Try to broaden the search parameters. is diplayed ");
			extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QMCall"));	
			return flag=false;
		}
		return flag; 
	}
	
}

			
		
