package QMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import jxl.Sheet;
import jxl.Workbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Key;
import org.sikuli.script.KeyModifier;
import org.sikuli.script.Screen;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import ScreenObjects.DataSourceScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.QualityMonitoringEvaluation;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.Impact360Screen;
import ScreenObjects.QualityMonitoringContactScreen;
import ScreenObjects.QualityMonitoringSearchScreen;
import Utilities.Utilities;

public class QM76_77_Create_Delete_DraftEvaluations {
	public static ExtentReports extent = ExtentReports.get(DataSourceScreen.class);
	
	public static boolean Create_Delete_DraftEvaluations() throws Exception
	{
		boolean flag=true;
		Screen sobj = new Screen ();
		String mainWinID="";	
		String HTMLReportName="QM76_77_Create_Delete_DraftEvaluations"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Create Delete Draft Evaluations");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	    	        
	    String EvalFormOption = Ws.getCell(33,37).getContents();	
	    String DateRangeFrom = Ws.getCell(35,37).getContents();
	    String DateRangeTo	= Ws.getCell(36,37).getContents();
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			Thread.sleep(5000);
			if (!VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring"))
			{
				Thread.sleep(5000);
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
				Thread.sleep(6000);
			}
			Set<String> windowIds = driver.getWindowHandles();
			System.out.println("windows size:"+windowIds.size());
			if (windowIds.size() ==1)
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
				Thread.sleep(6000);				
			}
						
			
			mainWinID=Utilities.setWindowFocus(driver);
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png");
			}			
			if (!Impact360Screen.clickQMSearch(driver))	  //click on Search 
			{
				return flag=false;
			}
			Thread.sleep(6000); 
			//driver.manage().window().maximize();			
			if (!QualityMonitoringContactScreen.selectQMSearchContact_Betweenthesedatesandtimes(driver))	
			{
				flag=false;
			}
			
			if (!QualityMonitoringContactScreen.setQMSearchContact_DateRangeFrom(driver,DateRangeFrom))	
			{
				flag=false;
			}
			if (!QualityMonitoringContactScreen.setQMSearchContact_DateRangeTo(driver,DateRangeTo))	
			{
				flag=false;
			}
			
			if (!QualityMonitoringContactScreen.clickExecute(driver))	
			{
				flag=false;
			}			
			Thread.sleep(8000); 			
			if (!QualityMonitoringSearchScreen.selectContactsStartTime(driver,""))		//select contact start time	
			{
				return flag=false;
			}
			
			Thread.sleep(10000);
			//eval form
					    
			if (!QualityMonitoringContactScreen.selectItemFromEvalForm(driver, EvalFormOption))
			{
				driver.switchTo().defaultContent();
				driver.switchTo().frame(1);			
				driver.switchTo().frame("FR_EVALUATION");
				if (QualityMonitoringContactScreen.selectItemFromEvalForm(driver, "Quality Monitoring Form - Scored (Filled)"))
				{				
					if (driver.findElements(By.xpath("//img[@id='toolBar_delete']")).size()!=0)
					 {
						 driver.findElement(By.xpath("//img[@id='toolBar_delete']")).click();
						 extent.log(LogStatus.PASS,"Clicked on Delete button is succesful");
					 }
					 else
					 {
						 extent.log(LogStatus.FAIL,"Delete button is NOT displayed");
						 return flag=false;
					 }
					 Thread.sleep(2000);
					 
					 if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Confirmation_Yes.png")!=null)
					 {
						 sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Confirmation_Yes.png");
						 extent.log(LogStatus.PASS,"Clicked on Delete Confirmation - Yes button is successful");
					 }
					 else
					 {
						 extent.log(LogStatus.FAIL,"Not able to click on Delete Confirmation - Yes button");
						 return flag=false;
					 }
				}
				 Thread.sleep(5000);
				if (!QualityMonitoringContactScreen.selectItemFromEvalForm(driver, EvalFormOption))
				{
				 	return flag=false;
				}
			}
		  Thread.sleep(4000);
		  driver.switchTo().defaultContent();
		  driver.switchTo().frame(1);
		  Thread.sleep(1000);
		  driver.switchTo().frame("FR_EVALUATION");
		  Thread.sleep(4000);
		 
		  List<WebElement> li=driver.findElements(By.xpath("//div[@class='element_div']"));
			System.out.println("list size is:" + li.size());
			List<WebElement> li1=driver.findElements(By.xpath("//div[@class='element_div']//input[@type='radio']"));
			System.out.println("size of input tag is:" + li1.size());
			for(WebElement elt:li1)
			{
				String text=elt.findElement(By.xpath("..//label")).getText();
				//System.out.println("text is:"+ text);
				if(text.equalsIgnoreCase("Achieved"))
				{
					elt.click();
				}
			}
		  
		  Thread.sleep(3000);
		  if (driver.findElements(By.xpath("//input[@id='toolBar_save']")).size()!=0)
		  {
			  if (driver.findElement(By.xpath("//input[@id='toolBar_save']")).isEnabled())
			  {
				  driver.findElement(By.xpath("//input[@id='toolBar_save']")).click();
				  extent.log(LogStatus.PASS,"Clicked on Save button is successful");
			  }
			  else
			  {
				  extent.log(LogStatus.FAIL,"Save button is NOT enabled");
				  return flag=false;
			  }
			  
		  }
		  else
		  {
			  extent.log(LogStatus.FAIL,"Save button is NOT displayed");
			  return flag=false;
		  }
		  /*//click on Home button
		  driver.switchTo().defaultContent();
		  driver.switchTo().frame(1);
		  Thread.sleep(1000);
		  driver.switchTo().frame(1);
		  Thread.sleep(1000);
		  if (driver.findElements(By.xpath("//a[@id='PlaybackHeader__ctl5__ctl0']")).size()!=0)
		  {
			driver.findElement(By.xpath("//a[@id='PlaybackHeader__ctl5__ctl0']")).click();
			extent.log(LogStatus.PASS,"Clicked on Home button is successful");
		  }
		  else
		  {
			extent.log(LogStatus.FAIL,"Not able to click on Home button");
			return flag=false;
		  }
		  Thread.sleep(5000);*/// -----------------------------------------------------------------------
		  Thread.sleep(5000);  
		  Impact360Screen.closeQM(driver);
		  Utilities.Logout(driver);
		  //driver.close();
		  //LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			Thread.sleep(5000);
			if (!VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring"))
			{
				Thread.sleep(5000);
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
				Thread.sleep(6000);
			}
			
						
			
			mainWinID=Utilities.setWindowFocus(driver);
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png");
			}		
			Thread.sleep(6000); 
		  
		  
		  
		  //-------------------------------------------------------------------------------------------------------
		  if (!Impact360Screen.clickEvaluations_DraftsEvaluations(driver))	  
			{
				return flag=false;
			}
		  
		  if (!QualityMonitoringEvaluation.selectDraftEvaluationStartTime(driver))	  
		  {
			return flag=false;
		  }
		  Thread.sleep(4000);
		 
		  //delete
		driver.switchTo().defaultContent();
		driver.switchTo().frame(1);
		 Thread.sleep(1000);  
		driver.switchTo().frame("FR_EVALUATION");
		Thread.sleep(1000);
		if (driver.findElements(By.xpath("//img[@id='toolBar_delete']")).size()!=0)
		 {
			 driver.findElement(By.xpath("//img[@id='toolBar_delete']")).click();
			 extent.log(LogStatus.PASS,"Clicked on Delete button is succesful");
		 }
		 else
		 {
			 extent.log(LogStatus.FAIL,"Delete button is NOT displayed");
			 return flag=false;
		 }
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Confirmation_Yes.png")!=null)
		 {
			 sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Confirmation_Yes.png");
			 extent.log(LogStatus.PASS,"Clicked on Delete Confirmation - Yes button is successful");
		 }
		 else
		 {
			 extent.log(LogStatus.FAIL,"Not able to click on Delete Confirmation - Yes button");
			 return flag=false;
		 }
		 Thread.sleep(5000);  
		 Impact360Screen.closeQM(driver);
		}catch(Exception e){
			System.out.println(e);
		}finally{	
			
			
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,37);
		}
		return flag;
	}

}
