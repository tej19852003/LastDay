package QMScripts;

import java.io.File;
import java.io.FileInputStream;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;
import com.relevantcodes.extentreports.ExtentReports;
import ScreenObjects.DataSourceScreen;
import ScreenObjects.Impact360WebPortalPreferencesScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.Impact360Screen;
import ScreenObjects.QualityMonitoringContactScreen;
import ScreenObjects.QualityMonitoringSearchScreen;
import Utilities.Utilities;

public class QM73_SetDefault_Eval_Form {
	public static ExtentReports extent = ExtentReports.get(DataSourceScreen.class);
	
	public static boolean SetDefault_Eval_Form() throws Exception
	{
		boolean flag=true;
		Screen sobj = new Screen ();
		String mainWinID="";	
		String HTMLReportName="QM75_EvaluateCall_Flag"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "SetDefault Evaluation Form");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	    
	    String NumberOfDays = Ws.getCell(16,25).getContents();	     
	    String EvalFormOption = Ws.getCell(33,25).getContents();			
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("QMAnalystUserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("QMAnalystPassword"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			Thread.sleep(5000);
			if (!VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring"))
			{
				Thread.sleep(5000);
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("QMAnalystUserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("QMAnalystPassword"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
				Thread.sleep(6000);
			}
			Set<String> windowIds = driver.getWindowHandles();
			System.out.println("windows size:"+windowIds.size());
			if (windowIds.size() ==1)
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("QMAnalystUserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("QMAnalystPassword"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
				Thread.sleep(6000);				
			}
						
			
			mainWinID=Utilities.setWindowFocus(driver);
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png");
			}
			//click on preferences
			Thread.sleep(4000);
			if (!Impact360Screen.clickPreferences(driver))	  //click on Search 
			{
				return flag=false;
			}
			//select option from default form list box
			if (!Impact360WebPortalPreferencesScreen.selectOption_QMDefaultForm(driver, EvalFormOption))
			{
				return flag=false;
			}
			if (!Impact360WebPortalPreferencesScreen.clickOK(driver)) //preferences - OK button
			{
				return flag=false;
			}
			
			
			if (!Impact360Screen.clickQMSearch(driver))	  //click on Search 
			{
				return flag=false;
			}
			//enter 30days
			if (!QualityMonitoringSearchScreen.setDateRange_Days(driver,NumberOfDays))		//	
			{
				return flag=false;
			}			
			if (!QualityMonitoringSearchScreen.clickExecuteSearch(driver))		//click Execute Search
			{
				return flag=false;
			}			
			Thread.sleep(8000); 			
			if (!QualityMonitoringSearchScreen.selectContactsStartTime(driver,""))		//select contact start time	
			{
				return flag=false;
			}			
			Thread.sleep(10000);
			//get selected option from eval form
			if (!QualityMonitoringContactScreen.getSelectItemFromEvalForm(driver, EvalFormOption))
			{	
				return flag=false;
			}
			//click on Home
			
			/*if (!QualityMonitoringContactScreen.clickQMEvalForm_Home(driver))
			{	
				return flag=false;
			}*/
			
			if (!QualityMonitoringContactScreen.clickEvalPreferences(driver))
			{	
				return flag=false;
			}
			
			if (!Impact360WebPortalPreferencesScreen.selectOption_QMDefaultForm_PlaybackPref(driver, "No Default Form"))
			{
				return flag=false;
			}
			if (!Impact360WebPortalPreferencesScreen.clickOK(driver)) //preferences - OK button
			{
				return flag=false;
			}
			Thread.sleep(2000);
			Impact360Screen.closeQM(driver);
		}catch(Exception e){
			System.out.println(e);
		}finally{				
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,25);
		}
		return flag;
	}

}
