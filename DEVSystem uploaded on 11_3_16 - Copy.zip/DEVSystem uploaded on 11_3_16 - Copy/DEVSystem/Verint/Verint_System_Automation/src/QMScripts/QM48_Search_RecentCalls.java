package QMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;

import java.util.Set;
import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.Impact360Screen;
import ScreenObjects.QualityMonitoringContactScreen;
import Utilities.Utilities;

public class QM48_Search_RecentCalls {
	public static ExtentReports extent = ExtentReports.get(QM48_Search_RecentCalls.class);
	public static Screen sobj = new Screen ();
	
	public static boolean Search_RecentCalls() throws Exception
	{
		boolean flag=true;
		
		String mainWinID="";
		String HTMLReportName="QM48_Search_RecentCalls"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Search Recent Calls - 60 minutes Call");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	    String DateRangeFrom = Ws.getCell(35,16).getContents();
	    String DateRangeTo	= Ws.getCell(36,16).getContents();
	   
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			Thread.sleep(5000);
			if (!VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring"))
			{
				Thread.sleep(5000);
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
				Thread.sleep(6000);
			}
			Set<String> windowIds = driver.getWindowHandles();
			System.out.println("windows size:"+windowIds.size());
			if (windowIds.size() ==1)
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
				Thread.sleep(6000);				
			}
			
			Thread.sleep(6000);
			mainWinID=Utilities.setWindowFocus(driver);
			System.out.println(mainWinID);			
			
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png");
				Thread.sleep(3000); 
			}			
			if (!Impact360Screen.clickQMSearch(driver))	  //click on Search 
			{
				return flag=false;
			}
			Thread.sleep(6000);
			if (!QualityMonitoringContactScreen.selectQMSearchContact_Betweenthesedatesandtimes(driver))	
			{
				flag=false;
			}
			
			if (!QualityMonitoringContactScreen.setQMSearchContact_DateRangeFrom(driver,DateRangeFrom))	
			{
				flag=false;
			}
			if (!QualityMonitoringContactScreen.setQMSearchContact_DateRangeTo(driver,DateRangeTo))	
			{
				flag=false;
			}
			
			if (!QualityMonitoringContactScreen.clickExecute(driver))	
			{
				flag=false;
			}
			/*if (!QualityMonitoringContactScreen.expandQMSearchAdvancedData(driver))		//expand adv.data	
			{
				 flag=false;
			}
			
			Thread.sleep(1000);
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Last60mins.png")!=null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Last60mins.png");				
			}
			else
			{
				extent.log(LogStatus.INFO,"Not able to select Last 60mins checkbox");
				//return flag=false;
			}
			
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ExecuteSearch.png")!=null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ExecuteSearch.png");
			}
			else
			{
				extent.log(LogStatus.FAIL,"Execute Search field is NOT displayed");
				 flag=false;
			}			*/
			Thread.sleep(10000); 		
			if (!QualityMonitoringContactScreen.verifyContactsStartTime(driver))		//select contact start time	
			{
				flag=false;
			}
			Set<String> windowIds2 = driver.getWindowHandles();
			Iterator<String> itererator2 = windowIds2.iterator(); 			
			String mainWinID2 = itererator2.next();//main window 
			Thread.sleep(1000);	
			String  popWindow2 = itererator2.next();//popup window
			Thread.sleep(2000);	
			driver.switchTo().window(popWindow2);
			driver.close();
			Thread.sleep(3000);
			driver.switchTo().window(mainWinID2);
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();			
			driver.quit();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,16);
		}
		
		return flag;
	}

}
