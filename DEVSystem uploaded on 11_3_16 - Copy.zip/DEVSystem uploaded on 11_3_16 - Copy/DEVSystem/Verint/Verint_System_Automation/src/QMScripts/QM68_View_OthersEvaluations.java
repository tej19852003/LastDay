package QMScripts;

import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

import javax.imageio.ImageIO;

import jxl.Sheet;
import jxl.Workbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;
import com.relevantcodes.extentreports.ExtentReports;
import ScreenObjects.DataSourceScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.QualityMonitoringEvaluation;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.Impact360Screen;
import ScreenObjects.QualityMonitoringContactScreen;
import Utilities.Utilities;

public class QM68_View_OthersEvaluations {
	public static ExtentReports extent = ExtentReports.get(DataSourceScreen.class);
	
	public static boolean View_OthersEvaluations() throws Exception
	{
		boolean flag=true;
		Screen sobj = new Screen ();			
		String HTMLReportName="QM68_View_OthersEvaluations"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "View Others Evaluations");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	    		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("QMEvaluatorUserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("QMEvaluatorPassword"));
			LoginScreen.clickLogin(driver);
			
			Thread.sleep(5000);
			if (!VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring"))
			{
				Thread.sleep(5000);
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("QMEvaluatorUserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("QMEvaluatorPassword"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
				Thread.sleep(6000);
			}
			Set<String> windowIds = driver.getWindowHandles();
			System.out.println("windows size:"+windowIds.size());
			if (windowIds.size() ==1)
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("QMEvaluatorUserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("QMEvaluatorPassword"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
				Thread.sleep(6000);				
			}
						
			
			Utilities.setWindowFocus(driver);
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png");
			}
			Thread.sleep(8000);		
			//eval-others eval 
			
			if (!Impact360Screen.clickEvaluations_OthersEvaluations(driver))	  
			{
				return flag=false;
			}
			if (!QualityMonitoringEvaluation.selectEvaluationsStartTime(driver))	  
			{
				return flag=false;
			}
			 Thread.sleep(4000);
			 //check eval form name with filled by or not 
			if (!QualityMonitoringContactScreen.getSelectItemFromEvalForm(driver,"Filled by"))	  
			{
				return flag=false;
			}				
			Thread.sleep(2000);
			Impact360Screen.closeQM(driver);
		}catch(Exception e){
			System.out.println(e);
		}finally{				
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,34);
		}
		return flag;
	}
	
}
