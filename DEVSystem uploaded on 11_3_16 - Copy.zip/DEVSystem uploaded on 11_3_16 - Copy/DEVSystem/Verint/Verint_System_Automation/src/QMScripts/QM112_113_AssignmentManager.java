package QMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;

import ScreenObjects.AssignmentManagerScreen;
import ScreenObjects.Impact360Screen;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;
import Utilities.Utilities;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class QM112_113_AssignmentManager {
	
	public static ExtentReports extent = ExtentReports.get(QM112_113_AssignmentManager.class);
	
	public static boolean Navigate_Modify_EntityAssignment() throws Exception
	{		
		boolean flag=true;
		Screen sobj = new Screen ();
		String HTMLReportName="QM112_113_AssignmentManager"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Navigate - Modify - Entity Assignment");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	   	
		
		try
		{		   
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Assignment Manager"))
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					extent.log(LogStatus.FAIL, "Verint Homepage is not displayed");
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Assignment Manager"))
				{
					extent.log(LogStatus.WARNING, "Not able to select Organization Settings menu. Please try again.");
					return flag=false;
				}
			}
			
			if (!Utilities.setWindow(driver, "Assignment Manager"))
			{
				return flag=false;
			}
			//roles tab
			if (!AssignmentManagerScreen.selectRolesTab(driver))
			{
				return flag=false;
			}
			//all roles
			if (!AssignmentManagerScreen.selectRolesName(driver,"All Roles"))
			{
				return flag=false;
			}
			//qm for leaders
			if (!AssignmentManagerScreen.selectQualityMonitoringForLeadersTab(driver))
			{
				return flag=false;
			}
			//verify checkbox is selected or not
			if (!AssignmentManagerScreen.verifyChkboxSearchForAnyForm(driver))
			{
				return flag=false;
			}
			//if (!AssignmentManagerScreen.verifyChkboxSearchForAnyFormSelected(driver))
			//{			
				//check box - search for any form
				if (!AssignmentManagerScreen.selectChkboxSearchForAnyForm(driver))
				{
					return flag=false;
				}			
				//save - 
				if (!AssignmentManagerScreen.clickSave(driver))
				{
					return flag=false;
				}
				if (!AssignmentManagerScreen.clickChangealltoNotAssigned(driver))
				{
					return flag=false;
				}
				
				if (!AssignmentManagerScreen.clickOK(driver))
				{
					return flag=false;
				}
				if (!AssignmentManagerScreen.clickOK(driver))
				{
					return flag=false;
				}	
			
			//revert it back to original
			//check box - search for any form
			if (!AssignmentManagerScreen.selectChkboxSearchForAnyForm(driver))
			{
				return flag=false;
			}	
			
			if (!AssignmentManagerScreen.clickSave(driver))
			{
				return flag=false;
			}
			/*if (!AssignmentManagerScreen.clickChangealltoNotAssigned(driver))
			{
				return flag=false;
			}*/
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Impact360_Text.png")!=null)
			 {
				 sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Impact360_Text.png");				 
				 Thread.sleep(4000);				 
			 }
			
			if (!AssignmentManagerScreen.clickOK(driver))
			{
				return flag=false;
			}
			
			//}
			
			Thread.sleep(4000);
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			 Impact360Screen.closeQM(driver);
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,38);
		}
		return flag;
	}

}
