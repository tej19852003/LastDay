package QMScripts;

import java.io.File;
import java.io.FileInputStream;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;
import jxl.Sheet;
import jxl.Workbook;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import org.sikuli.script.Screen;
import com.relevantcodes.extentreports.ExtentReports;
import ScreenObjects.DataSourceScreen;
import ScreenObjects.Impact360WebPortalPreferencesScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.Impact360Screen;

import Utilities.Utilities;

public class QM42_Preferences_SearchFields {
	public static ExtentReports extent = ExtentReports.get(DataSourceScreen.class);
	public static Screen sobj = new Screen ();
	public static String mainWinID="";
	
	public static boolean Preferences_SearchFields() throws Exception
	{
		boolean flag=true;
		
		String mainWinID="";	
		String HTMLReportName="QM42_Preferences_Search"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Preferences SearchFields");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	    
	    //String NumberOfRecords = Ws.getCell(16,8).getContents();		
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			Thread.sleep(5000);
			if (!VerintHomePageScreen.selectMenuItem(driver,"Interactions","Interactions Contacts"))
			{
				Thread.sleep(5000);
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Interactions Contacts");
				Thread.sleep(6000);
			}
			
			Thread.sleep(6000);
			mainWinID=Utilities.setWindowFocus(driver);
			System.out.println(mainWinID);			
			 
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png");
				Thread.sleep(3000); 
			}
			if (!Impact360Screen.clickPreferences(driver))	  //click on preferences 
			{
				return flag=false;
			}
			driver.manage().window().maximize();
			if (!Impact360WebPortalPreferencesScreen.selectOptionContactAppearance(driver,"Default"))	  //click on preferences 
			{
				return flag=false;
			}			
			// close preferences window and then main window
			Set<String> windowIds1 = driver.getWindowHandles();
			Iterator<String> itererator = windowIds1.iterator(); 			
			String mainWinID1 = itererator.next();//main window 
			System.out.println(mainWinID1);
			//driver.switchTo().window(mainWinID1).close();
			Thread.sleep(1000);	
			String  popWindow1 = itererator.next();//popup window
			Thread.sleep(2000);	
			driver.switchTo().window(popWindow1);
			driver.close();
			Thread.sleep(3000);
			driver.switchTo().window(mainWinID1);		
			
			}catch(Exception e){
				System.out.println(e);
			}finally{	
				
				Utilities.Logout(driver);
				driver.close();
				driver.quit();
				Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,11);
			}
			return flag;
	}
}
	
	