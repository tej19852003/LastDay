package QMScripts;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import java.util.Set;
import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Key;
import org.sikuli.script.KeyModifier;
import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.Impact360Screen;

import ScreenObjects.QualityMonitoringSearchScreen;
import Utilities.Utilities;



public class QM32_PlaybackCall {
	public static ExtentReports extent = ExtentReports.get(QM32_PlaybackCall.class);
	public static Screen sobj = new Screen ();
	public static boolean Call_Playback() throws Exception
	{
		boolean flag=true;
		
		String mainWinID="";
		String HTMLReportName="QM32_PlaybackCall"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Call Playback");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	    String NumberOfRecords = Ws.getCell(16,10).getContents();
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			Thread.sleep(5000);
			if (!VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring"))
			{
				Thread.sleep(5000);
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
				Thread.sleep(6000);
			}
			Set<String> windowIds = driver.getWindowHandles();
			System.out.println("windows size:"+windowIds.size());
			if (windowIds.size() ==1)
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
				Thread.sleep(6000);				
			}
			
			Thread.sleep(3000);
			mainWinID=Utilities.setWindowFocus(driver);
			System.out.println(mainWinID);			
			 
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png");
				Thread.sleep(10000); 
			}			
			if (!Impact360Screen.clickQMSearch(driver))	  //click on Search 
			{
				return flag=false;
			}
			Thread.sleep(6000); 
			
			if (NumberOfRecords.contains("30") || NumberOfRecords.contains("7"))
			{
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_DateRange.png")!=null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_DateRange.png");
					sobj.type("a", KeyModifier.CTRL); // select all text			
					sobj.type(Key.BACKSPACE); // delete selection
					sobj.type(NumberOfRecords);
				}
				else
				{
					extent.log(LogStatus.FAIL,"Date Range text field is NOT displayed");
					return flag=false;
				}
			}
			
					
			else if (NumberOfRecords.contains("60") )
				
			{
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_GroupsAndAgents.png")!=null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_GroupsAndAgents.png");				
				}
				Thread.sleep(6000); 
				Robot r = new Robot();
				r.keyPress(KeyEvent.VK_PAGE_DOWN);
				Thread.sleep(1000);
				r.keyRelease(KeyEvent.VK_PAGE_DOWN);
				
				Thread.sleep(1000);
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Advanced.png")!=null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Advanced.png");				
				}
				else
				{
					extent.log(LogStatus.INFO,"Not able to expand Advanced");
					//return flag=false;
				}
				Thread.sleep(1000); 
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png")!=null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QualityMonitoring.png");				
				}
				Thread.sleep(1000);
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Last60mins.png")!=null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_Last60mins.png");				
				}
				else
				{
					extent.log(LogStatus.INFO,"Not able to select Last 60mins checkbox");
					//return flag=false;
				}
			}
			
			
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ExecuteSearch.png")!=null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ExecuteSearch.png");
			}
			else
			{
				extent.log(LogStatus.FAIL,"Execute Search field is NOT displayed");
				return flag=false;
			}			
			Thread.sleep(10000); 		
			
			
			if (!QualityMonitoringSearchScreen.selectContactsStartTime(driver,""))		//select contact start time	
			
			{
				return flag=false;
			}
			extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QM05_07_14_Playback_EvalForm_RemarksBy"));
			Thread.sleep(5000);
			
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Play.png")!=null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Play.png");
				Thread.sleep(4000);
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Pause.png")!=null)
				{
					extent.log(LogStatus.PASS,"Call is in Playback state");	
					extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QM05_07_14_Playback_EvalForm_RemarksBy"));
				}
				else
				{
					extent.log(LogStatus.FAIL,"Call is NOT in Playback state");
					extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "QM05_07_14_Playback_EvalForm_RemarksBy"));
					flag=false;
				}
			}
			else
			{
				extent.log(LogStatus.FAIL,"Not able to click on Play icon");
				return flag=false;
			}
			

			
			driver.close();
			driver.switchTo().window(mainWinID);
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();			
			driver.quit();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,10);
		}
		
		return flag;
	}

}
