package QMScripts;

import java.io.File;
import java.io.FileInputStream;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Key;
import org.sikuli.script.KeyModifier;
import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.DataSourceScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.Impact360Screen;

import Utilities.Utilities;

public class QM66_67_Search_QM_Contacts {
	public static ExtentReports extent = ExtentReports.get(DataSourceScreen.class);
	public static Screen sobj = new Screen ();
	public static String mainWinID="";
	public static boolean Search_Records_In_QM_Contacts() throws Exception
	{
		boolean flag=true;
		
		//String mainWinID="";	
		String HTMLReportName="QM66_67_Search_Records_In_QM_Contacts"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Search Records In QM Contacts");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	    
	    String NumberOfRecords = Ws.getCell(16,8).getContents();		
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("QMAnalystUserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("QMAnalystPassword"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			Thread.sleep(5000);
			if (!VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring"))
			{
				Thread.sleep(5000);
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("QMAnalystUserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("QMAnalystPassword"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
				Thread.sleep(6000);
			}
			
			searchRecords_QM_Contacts(driver,NumberOfRecords,"Quality Monitoring");
			
			Set<String> windowIds1 = driver.getWindowHandles();
			Iterator<String> itererator = windowIds1.iterator(); 			
			String mainWinID1 = itererator.next();//main window 
			System.out.println(mainWinID1);
			//driver.switchTo().window(mainWinID1).close();
			Thread.sleep(1000);	
			String  popWindow1 = itererator.next();//popup window
			Thread.sleep(2000);	
			driver.switchTo().window(popWindow1);
			driver.close();
			Thread.sleep(3000);
			driver.switchTo().window(mainWinID1);
			
			
			/*for(String winHandle :driver.getWindowHandles()){
                driver.switchTo().window(winHandle);
                System.out.println("title:"+driver.getTitle());               
                if(driver.getTitle().contains("Impact 360 Web Portal"))
                {
                	//flag=true;
                	System.out.println("You are in Impact 360 Web Portal window");
                	driver.close();                   
                }          		
			}*/	
			/*for(String winHandle : driver.getWindowHandles()){
				 System.out.println("title:"+driver.getTitle());  
			    driver.switchTo().window(winHandle);
			}*/
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			Thread.sleep(5000);
			if (!VerintHomePageScreen.selectMenuItem(driver,"Interactions","Interactions Contacts"))
			{
				Thread.sleep(5000);
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Interactions Contacts");
				Thread.sleep(6000);
			}
			
			searchRecords_QM_Contacts(driver,NumberOfRecords,"Interactions Contacts");
			Thread.sleep(2000);
			Set<String> windowIds2 = driver.getWindowHandles();
			Iterator<String> itererator2 = windowIds2.iterator(); 			
			String mainWinID2 = itererator2.next();//main window 
			System.out.println(mainWinID1);
			//driver.switchTo().window(mainWinID1).close();
			Thread.sleep(1000);	
			String  popWindow2 = itererator2.next();//popup window
			Thread.sleep(2000);	
			driver.switchTo().window(popWindow2);
			driver.close();
			Thread.sleep(3000);
			driver.switchTo().window(mainWinID2);
			
			}catch(Exception e){
				System.out.println(e);
			}finally{	
				
				Utilities.Logout(driver);
				driver.close();
				driver.quit();
				Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,8);
			}
			return flag;
	}

	
			
	public static boolean searchRecords_QM_Contacts(WebDriver driver,String NumberOfRecords,String MenuItem) throws Exception
	{
				
		boolean temp=true;
		try
		{
			Set<String> windowIds = driver.getWindowHandles();
			System.out.println("windows size:"+windowIds.size());
			if (windowIds.size() ==1)
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return temp=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions",MenuItem);
				Thread.sleep(6000);				
			}
						
			
			mainWinID=Utilities.setWindowFocus(driver);
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png");
			}			
			if (!Impact360Screen.clickQMSearch(driver))	  //click on Search 
			{
				return temp=false;
			}
			Thread.sleep(6000); 
			
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_DateRange.png")!=null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_DateRange.png");
				sobj.type("a", KeyModifier.CTRL); // select all text			
				sobj.type(Key.BACKSPACE); // delete selection
				sobj.type(NumberOfRecords);
			}
			/*else
			{
				extent.log(LogStatus.FAIL,"Date Range text field is NOT displayed");
				return temp=false;
			}*/
			
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ExecuteSearch.png")!=null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ExecuteSearch.png");
			}
			else
			{
				extent.log(LogStatus.FAIL,"Execute Search field is NOT displayed");
				return temp=false;
			}			
			Thread.sleep(8000); 			
			verifyContactsResults(driver);		//contact results
			
			
		}catch(Exception e){
			System.out.println(e);
		}
		return temp;
	}
	
	public static boolean verifyContactsResults(WebDriver driver) throws Exception
	{
		Boolean flag=false;
		if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_NoContacts.png")==null)
		{
			Thread.sleep(5000);
			driver.switchTo().frame(0);
		    driver.switchTo().frame("Grid");		   
			
			int rcCall=driver.findElements(By.xpath("//table[@id='POG1']/tbody/tr")).size();
			System.out.println("callRC:"+rcCall);			
			if (rcCall>1)
			{
				extent.log(LogStatus.PASS, "Contact results are displayed successfully");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QMCall"));
				flag=true;			
			}
			else
			{
				extent.log(LogStatus.WARNING,"Contacts results were not displayed");
				extent.log(LogStatus.WARNING, "", "", Utilities.captureScreenShot(driver, "QMCall"));
				return flag =false;
			}				
		}
		else
		{
			extent.log(LogStatus.WARNING, "Message : No contacts were found. Try to broaden the search parameters. is diplayed ");
			extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "QMCall"));	
			return flag=false;
		}
		return flag; 
	}
	
}

			
		
