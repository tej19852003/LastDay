package QMScripts;

import java.io.File;
import java.io.FileInputStream;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;
import jxl.Sheet;
import jxl.Workbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;
import com.relevantcodes.extentreports.ExtentReports;
import ScreenObjects.DataSourceScreen;
import ScreenObjects.Impact360WebPortalPreferencesScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.Impact360Screen;

import Utilities.Utilities;

public class QM93_SendReport_PortalPage {
	public static ExtentReports extent = ExtentReports.get(DataSourceScreen.class);
	public static Screen sobj = new Screen ();
	public static String mainWinID="";
	
	public static boolean SendReport_PortalPage() throws Exception
	{
		boolean flag=true;
		
		String mainWinID="";	
		String HTMLReportName="QM93_SendReport_PortalPage"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Send Report to the Portal Page");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	   
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("QMAnalystUserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("QMAnalystPassword"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			Thread.sleep(5000);
			if (!VerintHomePageScreen.selectMenuItem(driver,"Interactions","Interactions Contacts"))
			{
				Thread.sleep(5000);
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("QMAnalystUserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("QMAnalystPassword"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Interactions Contacts");
				Thread.sleep(6000);
			}
			
			Thread.sleep(6000);
			mainWinID=Utilities.setWindowFocus(driver);
			System.out.println(mainWinID);			
			 
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png");
				Thread.sleep(3000); 
			}
			if (!Impact360Screen.clickPreferences(driver))	  //click on preferences 
			{
				return flag=false;
			}
			Utilities.setWindow(driver, "Impact 360 Web");
			
			if (!Impact360WebPortalPreferencesScreen.clickAddReport(driver))	  //click on Add Report 
			{
				return flag=false;
			}
					
			Thread.sleep(3000);
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png");
			
			if (!Impact360WebPortalPreferencesScreen.deleteReport(driver,"Agent Productivity"))	  //click on Add Report 
			{
				return flag=false;
			}		
			
					
			// close preferences window and then main window
			//Utilities.closeWindow(driver, "Impact 360 Web");		
			//Utilities.setFocus(driver, "My Home");	
			
			}catch(Exception e){
				System.out.println(e);
			}finally{	
				
				Utilities.Logout(driver);
				driver.close();
				driver.quit();
				Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,31);
			}
			return flag;
	}
}
	
	