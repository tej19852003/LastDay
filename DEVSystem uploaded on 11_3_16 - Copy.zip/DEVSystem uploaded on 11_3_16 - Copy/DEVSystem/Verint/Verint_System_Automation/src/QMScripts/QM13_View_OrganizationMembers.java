package QMScripts;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;

import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import ScreenObjects.AccessRightsScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class QM13_View_OrganizationMembers {
	
	public static ExtentReports extent = ExtentReports.get(QM13_View_OrganizationMembers.class);
	
	public static boolean View_OrganizationMembers() throws Exception
	{		
		boolean flag=true;
		String HTMLReportName="QM13_View_OrganizationMembers"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "View Organization Members");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
		String orgName = Ws.getCell(5,58).getContents();
	    String UserLastName = Ws.getCell(12,58).getContents();
		
		try
		{		   
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Access Rights"))
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					extent.log(LogStatus.FAIL, "Verint Homepage is not displayed");
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Access Rights"))
				{
					extent.log(LogStatus.WARNING, "Not able to select User Management menu. Please try again.");
					return flag=false;
				}
			}
			//click tree display button
			Utilities.selectLeftTreeFrame(driver);
			if (!AccessRightsScreen.clickEmployeeTreeDisplay(driver))
			{
				return flag=false;
			}
			
			int rc=driver.findElements(By.xpath("//table[@id='orgTree_id']/tbody/tr")).size();
			//System.out.println("rc:"+rc);
			String orgNameApp;String userNameApp;int k;boolean Temp=false;boolean option=false;String nameUser;boolean key=false;
			if (rc>=2)
			{
				driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr[2]/td/a/span/span")).click();
			}
			for (int j=1;j<=rc;j++)
			{
				k=j+1;
				
				if (j==rc/2)
				{
					Robot r = new Robot();
					r.keyPress(KeyEvent.VK_PAGE_DOWN);
					Thread.sleep(1000);
					r.keyRelease(KeyEvent.VK_PAGE_DOWN);
					Thread.sleep(1000);
				}
				orgNameApp=driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a/span/span")).getText();
				System.out.println("orgnameApp:"+orgNameApp);
				if (orgNameApp.contains(orgName) && driver.findElements(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/img[@class='treeNorgie']")).size()!=0)
				{
					userNameApp=driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+k+"]/td/a/span/span")).getText();
					System.out.println("userApp:"+userNameApp);
					if (userNameApp.contains(UserLastName) && driver.findElements(By.xpath("//table[@id='orgTree_id']/tbody/tr["+k+"]/td/img[@class='treeNorgie']")).size()==0)
					{
						key=true;
					}
					if (driver.findElements(By.xpath("//table[@id='orgTree_id']/tbody/tr["+k+"]/td/img[@class='treeNorgie']")).size()==0)
					{
						for (int a=k;a<=rc;a++)
						{
							Temp=true;
							if (driver.findElements(By.xpath("//table[@id='orgTree_id']/tbody/tr["+a+"]/td/img[@class='treeNorgie']")).size()==0)
							{
								nameUser=driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+a+"]/td/a/span/span")).getText();
								System.out.println("nameuser:"+nameUser);
								driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+a+"]/td/a/span/span")).click();
								Thread.sleep(1000);
								extent.log(LogStatus.INFO, "User Name: "+nameUser+" is displayed under Organization Name:"+orgName+" in tree view structure");
							}
							else
							{
								option=true;
								break;
							}	
						}
					}
				}
				if (option==true)
				{
					break;
				}
			}
			if (key==true)
			{
				extent.log(LogStatus.PASS, "User Name:"+UserLastName+" is displayed under Organization Name:"+orgName+" in tree view structure as Expected");
			}
			else
			{
				extent.log(LogStatus.FAIL, "User Name:"+UserLastName+" is NOT displayed under Organization Name:"+orgName+" in tree view structure");
			}
			
			if (Temp==true)
			{
				extent.log(LogStatus.PASS, "Users were displayed under Organization Name:"+orgName+" in tree view structure");
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "ViewOrgMembers"));
				flag=true;
			}
			else
			{
				extent.log(LogStatus.FAIL, "Users were NOT displayed under Organization Name:"+orgName+" in tree view structure");
				extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "ViewOrgMembers"));
				return flag=false;
			}
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();			
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,58);
		}
		return flag;
	}

}
