package QMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;

import ScreenObjects.LoginScreen;

import ScreenObjects.RolesSetupScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.ProfilesScreen;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;


public class QM07_Import_User {
	
	
	public static ExtentReports extent = ExtentReports.get(QM07_Import_User.class);
	public static Screen sobj = new Screen ();
	public static boolean Import_User() throws Exception
	{
		boolean flag=true;
		//String windowName="";
		//Screen sobj = new Screen ();
		String HTMLReportName="ImportUser"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Import User");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	    String UserAlias = Ws.getCell(11,4).getContents();
	    String UserLastName = Ws.getCell(12,4).getContents();	   	
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Profiles"))
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"User Management","Profiles"))				
				{
					extent.log(LogStatus.WARNING, "Profiles section is not displayed. Please try again");
					return flag=false;
				}				
			}
			RolesSetupScreen.selectRightPaneView(driver);
			if (!ProfilesScreen.clickImport(driver))
				return flag=false;
			//windowName=Utilities.setWindowFocus(driver);
			
			for(String winHandle :driver.getWindowHandles()){
                driver.switchTo().window(winHandle);
                System.out.println("title:"+driver.getTitle());
                if(driver.getTitle().contains("Import"))
                {
                	//flag=true;
                	//System.out.println("You are in Import - SF window");
                	Thread.sleep(5000);
                	driver.manage().window().maximize();
                    break;
                }			
			}
			
			Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Browse.png");			
			Utilities.sikuliType(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\FileName_To_Upload.png","C:\\DEVSystem\\Verint\\Verint_System_Automation\\src\\TestData\\Import.txt");
			
			Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Open_To_Upload.png");			
			Thread.sleep(5000);
			ProfilesScreen.setNumberOfLinesStartOfFile(driver,"1");			
			ProfilesScreen.clickSelectAll(driver);
			Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\Save.png");			
			Thread.sleep(3000);			
			ProfilesScreen.verifyImportSuccessMessage(driver);
			driver.close();
			
			for(String winHandle : driver.getWindowHandles()){
			    driver.switchTo().window(winHandle);
			}
			
			/*if (ProfilesScreen.FindSelect(driver, "Automation, Test"))
			{
				if (ProfilesScreen.clickDelete(driver))
				{
					Thread.sleep(2000);
					if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Delete_OK.png")!=null)
					{
						sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Delete_OK.png");
						flag=true;
						Thread.sleep(6000);							
					}
				}
			}*/
			
			//driver.switchTo().window(windowName);
			
			/*//verify User exist or not
			if (!ProfilesScreen.FindSelect(driver, UserLastName))
			{			
				Utilities.selectRightPaneView(driver);				
				if (!ProfilesScreen.clickImportDomainUsers(driver))
				{
					return flag=false;
				}
				Thread.sleep(2000);				
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_EnterObjNameToSelect.png") != null)
				{
					sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_EnterObjNameToSelect.png", UserAlias);
				}				
				Thread.sleep(1000);
				if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_OK_Btn.png") != null)
				{
					sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\SelectUsers_OK_Btn.png");
				}				
				Thread.sleep(5000);
				Utilities.selectRightPaneView(driver);
				
				if (!ProfilesScreen.checkErrorMessage(driver))
				{				
						return flag=false;
				}
				Thread.sleep(2000);				
				if (!ProfilesScreen.FindSelect(driver, UserLastName))
				{
					return flag=false;
				}
				
				if (!ProfilesScreen.selectProfile(driver,UserLastName))
				{
					return flag=false;
				}
			}*/
			/*RolesSetupScreen.selectRightPaneView(driver);
			
			sobj.click("C:\\DEV\\VerintAutomation\\Verint_Automation\\img\\Scrollbar.png");
			Thread.sleep(1000);
			
			
			ProfilesScreen.clickOrganizationEdit(driver); // click on organization edit icon
			Thread.sleep(3000);			
			windowName=Utilities.setWindowFocus(driver);
			ProfilesScreen.selectOrganizationFromListbox(driver,".Automation_Organization");		
			
			driver.switchTo().window(windowName);
			RolesSetupScreen.selectRightPaneView(driver);
			ProfilesScreen.clickSave(driver);
			RolesSetupScreen.selectRightPaneView(driver);
			ProfilesScreen.verifySuccessMessage(driver);*/
			/*//delete imported user/profile
			if (!ProfilesScreen.selectProfile(driver,"Bandaru"))
			{
				return flag=false;
			}
			
			RolesSetupScreen.selectRightPaneView(driver);
			ProfilesScreen.clickDelete(driver);
			Thread.sleep(2000);
			Utilities.sikuliClick(driver,"C:\\DEV\\VerintAutomation\\Verint_Automation\\img\\Delete_OK.png");
			Thread.sleep(2000);*/
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			//extent.endTest();
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,6);
		}
		return flag;
	}
	

}
