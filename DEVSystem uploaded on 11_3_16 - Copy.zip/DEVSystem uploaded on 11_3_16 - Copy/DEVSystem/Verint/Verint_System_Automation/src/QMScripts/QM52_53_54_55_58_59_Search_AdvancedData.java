package QMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import ScreenObjects.LoginScreen;
import ScreenObjects.PreferenceScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.Impact360Screen;
import ScreenObjects.QualityMonitoringContactScreen;

import Utilities.Utilities;


public class QM52_53_54_55_58_59_Search_AdvancedData {
	public static ExtentReports extent = ExtentReports.get(QM52_53_54_55_58_59_Search_AdvancedData.class);
	public static Screen sobj = new Screen ();
	
	public static boolean Search_AdvancedData() throws Exception
	{
		boolean flag=true;
		
		String mainWinID="";
		String HTMLReportName="QM52_53_54_55_58_59_Search_AdvancedData"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Search AdvancedData");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	    String MinWrapupTime = Ws.getCell(21,19).getContents();
	    String MaxWrapupTime = Ws.getCell(22,19).getContents();
	    
		String MinTotalHoldTime = Ws.getCell(23,19).getContents();
	    String MaxTotalHoldTime = Ws.getCell(24,19).getContents();
	    
	    String MinNoOfTransfers = Ws.getCell(25,19).getContents();
	    String MaxNoOfTransfers = Ws.getCell(26,19).getContents();
	    	   
	    String MinNoOfConf = Ws.getCell(27,19).getContents();
	    String MaxNoOfConf = Ws.getCell(28,19).getContents();
	    
	    String contactID = Ws.getCell(29,19).getContents();
	    String MediaComponent = Ws.getCell(30,19).getContents();
	    String DateRangeFrom = Ws.getCell(35,19).getContents();
	    String DateRangeTo	= Ws.getCell(36,19).getContents();
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			Thread.sleep(5000);
			if (!VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring"))
			{
				Thread.sleep(5000);
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
				Thread.sleep(6000);
			}
						
			mainWinID=Utilities.setWindowFocus(driver);
			System.out.println(mainWinID);			
			
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png");			
					
			if (!Impact360Screen.clickQMSearch(driver))	  //click on Search 
			{
				return flag=false;
			}
			driver.manage().window().maximize();
			if (!QualityMonitoringContactScreen.selectQMSearchContact_Betweenthesedatesandtimes(driver))	
			{
				flag=false;
			}
			
			if (!QualityMonitoringContactScreen.setQMSearchContact_DateRangeFrom(driver,DateRangeFrom))	
			{
				flag=false;
			}
			if (!QualityMonitoringContactScreen.setQMSearchContact_DateRangeTo(driver,DateRangeTo))	
			{
				flag=false;
			}
			
			if (!QualityMonitoringContactScreen.clickExecute(driver))	
			{
				flag=false;
			}
			if(QualityMonitoringContactScreen.verifycriteria(driver,"Wrap-up Time"))
			{
				extent.log(LogStatus.PASS,"criteria already present on screen");
				
			}
			else
			{
				
			
			if (!QualityMonitoringContactScreen.clickPreference(driver))
			{
				flag=false;
			}
			if(!PreferenceScreen.selectserachcriteria(driver,"Wrap-up Time"))
			{
				flag=false;
			}
			if(!PreferenceScreen.clickok(driver))
			{
				flag=false;
			}
			if(!QualityMonitoringContactScreen.verifycriteria(driver, "Wrap-up Time"))
			{
				flag=false;
			}
			}
			if(!QualityMonitoringContactScreen.clickSearch(driver))
			{
				flag=false;
			}
			Thread.sleep(2000);
			if (!QualityMonitoringContactScreen.expandQMSearchAdvancedData(driver))		//go to Advanced data	
			{
				flag=false;
			}
			//wrap up time
			if (!QualityMonitoringContactScreen.setQMSearch_AdvancedData_WrapupTime(driver,MinWrapupTime,MaxWrapupTime))		//set min and max no.of holds	
			{
				flag=false;
			}
			if (!Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ExecuteSearch.png"))
			{
				extent.log(LogStatus.FAIL,"Execute Search field is NOT displayed");
				flag=false;
			}					
			Thread.sleep(10000); 		
			if(QualityMonitoringContactScreen.verifycriteria(driver,"Total Hold Time"))
			{
				extent.log(LogStatus.PASS,"criteria already present on screen");
				
			}
			else
			{
				
			
			if (!QualityMonitoringContactScreen.clickPreference(driver))
			{
				flag=false;
			}
			if(!PreferenceScreen.selectserachcriteria(driver,"Total Hold Time"))
			{
				flag=false;
			}
			if(!PreferenceScreen.clickok(driver))
			{
				flag=false;
			}
			if(!QualityMonitoringContactScreen.verifycriteria(driver, "Total Hold Time"))
			{
				flag=false;
			}
			}
			if (!QualityMonitoringContactScreen.verifyContactsStartTime(driver))		//verify contact start time	
			{
				flag=false;
			}
			if (!Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\QM_HomeSearch.png")) //click on search
			{
				extent.log(LogStatus.FAIL,"Search field is NOT displayed");
				flag=false;
			}
			if (!QualityMonitoringContactScreen.setQMSearch_AdvancedData_WrapupTime(driver,"",""))		//set min and max no.of holds	
			{
				flag=false;
			}
			//total hold time
			if (!QualityMonitoringContactScreen.setQMSearch_AdvancedData_TotalHoldTime(driver,MinTotalHoldTime,MaxTotalHoldTime))		//set min and max no.of holds	
			{
				flag=false;
			}
			if (!Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ExecuteSearch.png"))
			{
				extent.log(LogStatus.FAIL,"Execute Search field is NOT displayed");
				flag=false;
			}					
			Thread.sleep(10000); 		
			if(QualityMonitoringContactScreen.verifycriteria(driver,"Number of Transfers"))
			{
				extent.log(LogStatus.PASS,"criteria already present on screen");
				
			}
			else
			{
				
			
			if (!QualityMonitoringContactScreen.clickPreference(driver))
			{
				flag=false;
			}
			if(!PreferenceScreen.selectserachcriteria(driver,"Number of Transfers"))
			{
				flag=false;
			}
			if(!PreferenceScreen.clickok(driver))
			{
				flag=false;
			}
			if(!QualityMonitoringContactScreen.verifycriteria(driver, "Number of Transfers"))
			{
				flag=false;
			}
			}
			if (!QualityMonitoringContactScreen.verifyContactsStartTime(driver))		//verify contact start time	
			{
				flag=false;
			}
			if (!Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\QM_HomeSearch.png")) //click on search
			{
				extent.log(LogStatus.FAIL,"Search field is NOT displayed");
				flag=false;
			}
			if (!QualityMonitoringContactScreen.setQMSearch_AdvancedData_TotalHoldTime(driver,"",""))		//set min and max no.of holds	
			{
				flag=false;
			}
			
			
			//no.of transfers
			if (!QualityMonitoringContactScreen.setQMSearch_AdvancedData_NumberOfTransfers(driver,MinNoOfTransfers,MaxNoOfTransfers))		//set min and max no.of holds	
			{
				flag=false;
			}
			if (!Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ExecuteSearch.png"))
			{
				extent.log(LogStatus.FAIL,"Execute Search field is NOT displayed");
				flag=false;
			}					
			Thread.sleep(10000); 		
			if(QualityMonitoringContactScreen.verifycriteria(driver,"Number of Conferences"))
			{
				extent.log(LogStatus.PASS,"criteria already present on screen");
				
			}
			else
			{
				
			
			if (!QualityMonitoringContactScreen.clickPreference(driver))
			{
				flag=false;
			}
			if(!PreferenceScreen.selectserachcriteria(driver,"Number of Conferences"))
			{
				flag=false;
			}
			if(!PreferenceScreen.clickok(driver))
			{
				flag=false;
			}
			if(!QualityMonitoringContactScreen.verifycriteria(driver, "Number of Conferences"))
			{
				flag=false;
			}
			}
			if (!QualityMonitoringContactScreen.verifyContactsStartTime(driver))		//verify contact start time	
			{
				flag=false;
			}
			if (!Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\QM_HomeSearch.png")) //click on search
			{
				extent.log(LogStatus.FAIL,"Search field is NOT displayed");
				flag=false;
			}
			if (!QualityMonitoringContactScreen.setQMSearch_AdvancedData_NumberOfTransfers(driver,"",""))		//set min and max no.of holds	
			{
				flag=false;
			}
			
			
			//no.of conferences
			if (!QualityMonitoringContactScreen.setQMSearch_AdvancedData_NumberOfConferences(driver,MinNoOfConf,MaxNoOfConf))		//set min and max no.of holds	
			{
				flag=false;
			}
			if (!Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ExecuteSearch.png"))
			{
				extent.log(LogStatus.FAIL,"Execute Search field is NOT displayed");
				flag=false;
			}					
			Thread.sleep(10000); 		
			if(QualityMonitoringContactScreen.verifycriteria(driver,"Contact ID"))
			{
				extent.log(LogStatus.PASS,"criteria already present on screen");
				
			}
			else
			{
				
			
			if (!QualityMonitoringContactScreen.clickPreference(driver))
			{
				flag=false;
			}
			if(!PreferenceScreen.selectserachcriteria(driver,"Contact ID"))
			{
				flag=false;
			}
			if(!PreferenceScreen.clickok(driver))
			{
				flag=false;
			}
			if(!QualityMonitoringContactScreen.verifycriteria(driver, "Contact ID"))
			{
				flag=false;
			}
			}
			
			if (!QualityMonitoringContactScreen.verifyContactsStartTime(driver))		//verify contact start time	
			{
				flag=false;
			}	
			if (!Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\QM_HomeSearch.png")) //click on search
			{
				extent.log(LogStatus.FAIL,"Search field is NOT displayed");
				flag=false;
			}
			if (!QualityMonitoringContactScreen.setQMSearch_AdvancedData_NumberOfConferences(driver,"",""))		//set min and max no.of holds	
			{
				flag=false;
			}
			//QM59 - Adv.data - contact id
			if (!QualityMonitoringContactScreen.setQMSearch_AdvancedData_ContactID(driver,contactID))		//set min and max no.of holds	
			{
				flag=false;
			}
			if (!Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ExecuteSearch.png"))
			{
				extent.log(LogStatus.FAIL,"Execute Search field is NOT displayed");
				flag=false;
			}					
			Thread.sleep(10000); 		
			
			if (!QualityMonitoringContactScreen.verifyContactsStartTime(driver))		//verify contact start time	
			{
				flag=false;
			}	
			if (!Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\QM_HomeSearch.png")) //click on search
			{
				extent.log(LogStatus.FAIL,"Search field is NOT displayed");
				flag=false;
			}
			if (!QualityMonitoringContactScreen.setQMSearch_AdvancedData_NumberOfConferences(driver,"",""))		//set min and max no.of holds	
			{
				flag=false;
			}
			//QM58
			if (!QualityMonitoringContactScreen.setQMSearch_AdvancedData_MediaComponents(driver,MediaComponent))		//set min and max no.of holds	
			{
				flag=false;
			}
			if (!Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ExecuteSearch.png"))
			{
				extent.log(LogStatus.FAIL,"Execute Search field is NOT displayed");
				flag=false;
			}					
			Thread.sleep(10000); 		
			
			if (!QualityMonitoringContactScreen.verifyContactsStartTime(driver))		//verify contact start time	
			{
				flag=false;
			}
			if(!QualityMonitoringContactScreen.clickPreference(driver))
			{
				flag=false;
			}
			
			if(!PreferenceScreen.deselectserachcriteria(driver,"Wrap-up Time"))
			{
				flag=false;
			}
			if(!PreferenceScreen.deselectserachcriteria(driver,"Total Hold Time"))
			{
				flag=false;
			}
			if(!PreferenceScreen.deselectserachcriteria(driver,"Number of Transfers"))
			{
				flag=false;
			}
			if(!PreferenceScreen.deselectserachcriteria(driver,"Number of Conferences"))
			{
				flag=false;
			}
			if(!PreferenceScreen.deselectserachcriteria(driver,"Contact ID"))
			{
				flag=false;
			}
			if(!PreferenceScreen.clickok(driver))
			{
				flag=false;
			}
			Impact360Screen.closeQM(driver);
			
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			
			Utilities.Logout(driver);
			driver.close();			
			driver.quit();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,19);
		}
		
		return flag;
	}

}
