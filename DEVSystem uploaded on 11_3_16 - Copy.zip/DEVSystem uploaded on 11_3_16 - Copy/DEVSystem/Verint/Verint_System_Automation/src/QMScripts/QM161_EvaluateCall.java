package QMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.LoginScreen;

import ScreenObjects.QualityMonitoringEvaluation;
import ScreenObjects.QualityMonitoringSearchScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.Impact360Screen;
import ScreenObjects.QualityMonitoringContactScreen;

import Utilities.Utilities;


public class QM161_EvaluateCall {
	public static ExtentReports extent = ExtentReports.get(QM161_EvaluateCall.class);
	public static Screen sobj = new Screen ();
	
	public static boolean Evaluate_Call() throws Exception
	{
		boolean flag=true;
		
		String mainWinID="";
		String HTMLReportName="QM161_EvaluateCall"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Evaluate Call");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	    String FormName = Ws.getCell(33,65).getContents();
	    String DateRangeFrom = Ws.getCell(35,65).getContents();
	    String DateRangeTo	= Ws.getCell(36,65).getContents();
	    String form=Ws.getCell(43,65).getContents();
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			Thread.sleep(5000);
			if (!VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring"))
			{
				Thread.sleep(5000);
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
				Thread.sleep(6000);
			}
						
			mainWinID=Utilities.setWindowFocus(driver);
			System.out.println(mainWinID);			
			
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png");			
					
			if (!Impact360Screen.clickQMSearch(driver))	  //click on Search 
			{
				return flag=false;
			}				
			driver.manage().window().maximize();
			
			/*if (!QualityMonitoringContactScreen.setDays(driver,"30"))	
			{
				flag=false;
			}*/
			if (!QualityMonitoringContactScreen.selectQMSearchContact_Betweenthesedatesandtimes(driver))	
			{
				flag=false;
			}
			
			if (!QualityMonitoringContactScreen.setQMSearchContact_DateRangeFrom(driver,DateRangeFrom))	
			{
				flag=false;
			}
			if (!QualityMonitoringContactScreen.setQMSearchContact_DateRangeTo(driver,DateRangeTo))	
			{
				flag=false;
			}
			
			if (!QualityMonitoringContactScreen.clickExecute(driver))	
			{
				flag=false;
			}
			
			/*if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ExecuteSearch.png")!=null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ExecuteSearch.png");
			}
			else
			{
				extent.log(LogStatus.FAIL,"Execute Search field is NOT displayed");
				return flag=false;
			}			*/
			Thread.sleep(8000); 
			if (!QualityMonitoringSearchScreen.selectContactsStartTime(driver,""))		//select contact start time	
			{
				return flag=false;
			}
			
			Thread.sleep(10000);
			if(QualityMonitoringContactScreen.getvaluefromform(driver,form))
			{
				extent.log(LogStatus.INFO,"Form is already evaluated");
			}
			else
			{
				QualityMonitoringContactScreen.selectItemFromEvalForm(driver,FormName);
				
				
				Thread.sleep(4000);
				driver.switchTo().defaultContent();
				driver.switchTo().frame(1);			
				driver.switchTo().frame("FR_EVALUATION");
				Thread.sleep(4000);
				
				
				List<WebElement> li=driver.findElements(By.xpath("//div[@class='element_div']"));
				System.out.println("list size is:" + li.size());
				List<WebElement> li1=driver.findElements(By.xpath("//div[@class='element_div']//input[@type='radio']"));
				System.out.println("size of input tag is:" + li1.size());
				for(WebElement elt:li1)
				{
					String text=elt.findElement(By.xpath("..//label")).getText();
					//System.out.println("text is:"+ text);
					if(text.equalsIgnoreCase("Achieved"))
					{
						elt.click();
					}
				}
				if (!QualityMonitoringContactScreen.clickSubmitform(driver)) //click on submit form icon
				{
					return flag=false;
				}
			}
			
			QualityMonitoringEvaluation.clickremark(driver);
			QualityMonitoringEvaluation.setremark(driver);
			QualityMonitoringEvaluation.verifyRemark(driver);
			QualityMonitoringEvaluation.clickSave(driver);
			
			driver.switchTo().defaultContent();
			Utilities.switchFrame(driver,"FR_PLAYBACK");
			Utilities.switchFrame(driver, "FR_EVALUATION");
			
			if (driver.findElements(By.xpath("//img[@id='toolBar_delete']")).size()!=0)
			{
				driver.findElement(By.xpath("//img[@id='toolBar_delete']")).click();
				extent.log(LogStatus.PASS,"Clicked on Delete button is succesful");
			}
			else
			{
				extent.log(LogStatus.FAIL,"Delete button is NOT displayed");
				return flag=false;
			}
			Thread.sleep(2000);
			 
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Confirmation_Yes.png")!=null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Confirmation_Yes.png");
				extent.log(LogStatus.PASS,"Clicked on Delete Confirmation - Yes button is successful");
			}
			else
			{
				extent.log(LogStatus.FAIL,"Not able to click on Delete Confirmation - Yes button");
				return flag=false;
			}
			//List<WebElement> li2=li.
			/*if (!QualityMonitoringContactScreen.evaluateEvaluationForm(driver)) //fill evaluation form - Quality Monitoring Form - Scored (New) 
			{
			 	return flag=false;
			}
			if (!QualityMonitoringContactScreen.clickSubmitform(driver)) //click on submit form icon
			{
				return flag=false;
			}
			
			QualityMonitoringEvaluation.clickremark(driver);
			QualityMonitoringEvaluation.setremark(driver,"chandni");
			QualityMonitoringEvaluation.clickSave(driver);
			
			if (driver.findElements(By.xpath("//img[@id='toolBar_delete']")).size()!=0)
			{
				driver.findElement(By.xpath("//img[@id='toolBar_delete']")).click();
				extent.log(LogStatus.PASS,"Clicked on Delete button is succesful");
			}
			else
			{
				extent.log(LogStatus.FAIL,"Delete button is NOT displayed");
				return flag=false;
			}
			Thread.sleep(2000);
			 
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\Confirmation_Yes.png")!=null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\Confirmation_Yes.png");
				extent.log(LogStatus.PASS,"Clicked on Delete Confirmation - Yes button is successful");
			}
			else
			{
				extent.log(LogStatus.FAIL,"Not able to click on Delete Confirmation - Yes button");
				return flag=false;
			}
		*/
		 Thread.sleep(2000);
		 Impact360Screen.closeQM(driver);
		 
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			
			Utilities.Logout(driver);
			driver.close();			
			driver.quit();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,65);
		}
		
		return flag;
	}

}
