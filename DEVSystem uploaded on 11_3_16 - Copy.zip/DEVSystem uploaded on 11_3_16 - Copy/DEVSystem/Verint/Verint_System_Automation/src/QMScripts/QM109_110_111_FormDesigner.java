package QMScripts;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;

import java.text.SimpleDateFormat;
import java.util.Date;
import jxl.Sheet;
import jxl.Workbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Key;
import org.sikuli.script.KeyModifier;
import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.AssignmentManagerScreen;
import ScreenObjects.DataSourceScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.Impact360Screen;

import Utilities.Utilities;

public class QM109_110_111_FormDesigner {
	public static ExtentReports extent = ExtentReports.get(DataSourceScreen.class);
	
	public static boolean Publish_From_Designer() throws Exception
	{
		boolean flag=true;
		Screen sobj = new Screen ();
			
		String HTMLReportName="From_Designer"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Form Designer");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet"); 
	    String FormName = Ws.getCell(43,48).getContents();
		try
		{			
			Runtime.getRuntime().exec("C:\\Program Files\\I360\\FormDesigner\\Verint.EvaluationPackage.FormManagement.FormManagementUI.exe");
			for ( int k=1;k<=20;k++)
			{
				if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Username.png")!= null)
				{
					break;
				}
				else
				{
					Thread.sleep(4000);
				}
			}
			extent.log(LogStatus.INFO, "Create Form Designer ");	
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Username.png") != null)
			{
				sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Username.png",Utilities.Globlocators.getProperty("UserName"));			
				Thread.sleep(1000);
			}
			else
			{
				return flag=false;
			}
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Password.png") != null)
			{
				sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Password.png",Utilities.Globlocators.getProperty("Password"));				
				Thread.sleep(1000);
			}
			else
			{
				return flag=false;
			}
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Login.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Login.png");			
				Thread.sleep(1000);
			}
			else
			{
				return flag=false;
			}
			Thread.sleep(10000);
			for ( int y=1;y<=30;y++)
			{
				if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewForm.png")!= null)
				{
					break;
				}
				else
				{
					Thread.sleep(4000);
				}
			}
			//New form icon
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewForm.png") != null)
			{
				extent.log(LogStatus.PASS, "Form Designer Page is displayed");				
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewForm.png");			
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Form Designer Page is NOT displayed");
				return flag=false;
			}
			//new form name
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewFormName.png") != null)
			{
				sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewFormName.png",FormName);	
				extent.log(LogStatus.PASS, "New Form Name: .AutomationForm entered successfully");	
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to enter New Form Name: .AutomationForm");
				return flag=false;
			}
			//new form OK button
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewFormOK_button.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewFormOK_button.png");	
				extent.log(LogStatus.PASS, "Clicked on OK button successful");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on OK button");
				return flag=false;
			}
			//check for form name already exist or not
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_OK.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_OK.png");	
				extent.log(LogStatus.WARNING, "New Form - This name already exist is displayed");
				Thread.sleep(1000);
				return flag=false;
			}
			//new component icon - section
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewComponent.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewComponent.png");			
				Thread.sleep(3000);
			}
			else
			{
				return flag=false;
			}
			//section1
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Section1.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Section1.png");			
				Thread.sleep(3000);
			}
			else
			{
				return flag=false;
			}
			//section1 Name
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Section1_Name.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Section1_Name.png");
				sobj.type("a", KeyModifier.CTRL); // select all text			
				sobj.type(Key.BACKSPACE); // delete selection
				sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Section1_Name.png",".AutomationSection");
				extent.log(LogStatus.PASS, "Section Name:.AutomationSection entered successfully");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to enter Section Name:.AutomationSection");
				return flag=false;
			}
			//section1 view - enable comment
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Section_View.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Section_View.png");	
				extent.log(LogStatus.INFO, "Section View: Enable commnets selected");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.WARNING, "Section View: Enable commnets NOT selected");
				//return flag=false;
			}
			//new component icon - category
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewComponent.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewComponent.png");			
				Thread.sleep(3000);
			}
			else
			{
				return flag=false;
			}
			//select category1
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Category1.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Category1.png");			
				Thread.sleep(3000);
			}
			else
			{
				return flag=false;
			}
			//category1 name
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Category1_Name.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Category1_Name.png");			
				sobj.type("a", KeyModifier.CTRL); // select all text			
				sobj.type(Key.BACKSPACE); // delete selection
				sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Category1_Name.png",".AutomationCategory");
				extent.log(LogStatus.PASS, "Category Name: .AutomationCategory entered successfully");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to enter Category Name: .AutomationCategory");
				return flag=false;
			}
			//category view - enable comment
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Section_View.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Section_View.png");				
				Thread.sleep(3000);
			}
			else
			{
				return flag=false;
			}
			//new component icon - question
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewComponent.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_NewComponent.png");			
				Thread.sleep(3000);
			}
			else
			{
				return flag=false;
			}
			//select Question1
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Question1.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Question1.png");			
				Thread.sleep(3000);
			}
			else
			{
				return flag=false;
			}
			//question1 name
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Question1_Name.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Question1_Name.png");			
				sobj.type("a", KeyModifier.CTRL); // select all text			
				sobj.type(Key.BACKSPACE); // delete selection
				sobj.type(".AutomationQuestion");
				extent.log(LogStatus.PASS, "Question Name: .AutomationQuestion entered successfully");
				//sobj.type(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Question1_Name.png",".AutomationQuestion");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to enter Question Name: .AutomationQuestion");
				return flag=false;
			}
			//Save
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Save.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Save.png");	
				extent.log(LogStatus.PASS, "Clicked on Save button");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on Save button");
				return flag=false;
			}			
			//Back to List
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_BackToList.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_BackToList.png");			
				Thread.sleep(6000);
			}
			else
			{
				return flag=false;
			}
			//AutomationForm Name
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_AutomationForm1.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_AutomationForm1.png");			
				Thread.sleep(8000);
			}
			else
			{
				return flag=false;
			}
			//change status to Published
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ChangeStatus.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_ChangeStatus.png");
				extent.log(LogStatus.PASS, "Clicked on Change Status");
				Thread.sleep(2000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to click on Change Status");
				return flag=false;
			}
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Published.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Published.png");
				extent.log(LogStatus.PASS, "Change Status : Published is selected");
				Thread.sleep(3000);
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to select Published");
				return flag=false;
			}
				
			//QM111
			extent.log(LogStatus.INFO, "Verify fileds of the Form designer ***********");
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_AutomationForm1.png") != null)
			{
				sobj.doubleClick(Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_AutomationForm1.png");	
				Thread.sleep(3000);
			}
			
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\FormDesigner_Fields.png") != null)
			{
				extent.log(LogStatus.PASS, "Version: 1; Status: Published; Form Type: Evaluation is displayed");
				Thread.sleep(3000);				
			}
			else
			{
				extent.log(LogStatus.PASS, "Version: 1; Status: Published; Form Type: Evaluation is NOT displayed");
				return flag=false;
			}
			//close FD
			String KILL = "taskkill /IM ";
		    String processName = "Verint.EvaluationPackage.FormManagement.FormManagementUI.exe"; //IE process
		    Runtime.getRuntime().exec(KILL + processName); 
			
			//QM110 - Assignment Manager
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Assignment Manager"))
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					extent.log(LogStatus.FAIL, "Verint Homepage is not displayed");
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Assignment Manager"))
				{
					extent.log(LogStatus.WARNING, "Not able to select Organization Settings menu. Please try again.");
					return flag=false;
				}
			}
			
			if (!Utilities.setWindow(driver, "Assignment Manager"))
			{
				return flag=false;
			}
			//roles tab
			if (!AssignmentManagerScreen.selectRolesTab(driver))
			{
				return flag=false;
			}
			//all roles
			if (!AssignmentManagerScreen.selectRolesName(driver,"All Roles"))
			{
				return flag=false;
			}
			//qm for leaders
			if (!AssignmentManagerScreen.selectQualityMonitoringForLeadersTab(driver))
			{
				return flag=false;
			}
			//check for created Form Designer
			if (sobj.exists(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_ContFlags.png") != null)
			{
				sobj.click(Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_ContFlags.png");
				Thread.sleep(2000);
			}	
			
			Robot r = new Robot();
			r.keyPress(KeyEvent.VK_PAGE_DOWN);
			Thread.sleep(1000);
			r.keyRelease(KeyEvent.VK_PAGE_DOWN);
			
			if (sobj.exists( Utilities.Globlocators.getProperty("imagesPath")+"\\AssignmentMgr_SysAutoFormName.png") != null)
			{
				extent.log(LogStatus.PASS, "Created Form Name: .SystemAutoForm is displayed");
				Thread.sleep(3000);				
			}
			else
			{
				extent.log(LogStatus.FAIL, "Created Form Name: .SystemAutoForm is NOT displayed");
				return flag=false;
			}
			
			/*String fdname1=driver.findElement(By.xpath("//div[@id='ext-gen695']")).getText();
			System.out.println("fdname:"+fdname1);
			
			
			
			if (driver.findElements(By.xpath("//div[@id='ext-gen648']/label")).size()!=0)
			{				
				if (driver.findElement(By.xpath("//div[@class='x-form-cb-indentDiv'][@id='ext-gen648']/label")).getText().contains(".SystemAutoForm"))
				{
				extent.log(LogStatus.PASS, "Form Desinger : .SystemAutoForm is displayed");
				Thread.sleep(4000);
				flag=true;
				
				}else
				{
					extent.log(LogStatus.FAIL, "Form Desinger : .SystemAutoForm is NOT displayed");
					flag=false;
				}
			}*/
		}catch(Exception e){
			System.out.println(e);
		}finally{	
			/*String KILL = "taskkill /IM ";
		    String processName = "Verint.EvaluationPackage.FormManagement.FormManagementUI.exe"; //IE process
		    Runtime.getRuntime().exec(KILL + processName); */
			Impact360Screen.closeQM(driver);
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,48);
		}
		return flag;
	}

}
