package QMScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;
import ScreenObjects.LoginScreen;
import ScreenObjects.PreferenceScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.Impact360Screen;
import ScreenObjects.QualityMonitoringContactScreen;

import Utilities.Utilities;


public class QM49_Search_CallsByDuration {
	public static ExtentReports extent = ExtentReports.get(QM49_Search_CallsByDuration.class);
	public static Screen sobj = new Screen ();
	
	public static boolean Search_CallsByDuration() throws Exception
	{
		boolean flag=true;
		
		String mainWinID="";
		String HTMLReportName="QM49_Search_CallsByDuration"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "QM NumberOfHolds SearchFields");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 
		
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_QM"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("QM_TestSet");
	    String Minimum = Ws.getCell(17,17).getContents();
	    String Maximum = Ws.getCell(18,17).getContents();
	    String DateRangeFrom = Ws.getCell(35,17).getContents();
	    String DateRangeTo	= Ws.getCell(36,17).getContents();
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			Thread.sleep(5000);
			if (!VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring"))
			{
				Thread.sleep(5000);
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				Thread.sleep(5000);
				VerintHomePageScreen.selectMenuItem(driver,"Interactions","Quality Monitoring");
				Thread.sleep(6000);
			}
						
			mainWinID=Utilities.setWindowFocus(driver);
			System.out.println(mainWinID);			
			
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\EvaluationFlag_OK.png");			
					
			if (!Impact360Screen.clickQMSearch(driver))	  //click on Search 
			{
				return flag=false;
			}
			driver.manage().window().maximize();
			if (!QualityMonitoringContactScreen.selectQMSearchContact_Betweenthesedatesandtimes(driver))	
			{
				flag=false;
			}
			
			if (!QualityMonitoringContactScreen.setQMSearchContact_DateRangeFrom(driver,DateRangeFrom))	
			{
				flag=false;
			}
			if (!QualityMonitoringContactScreen.setQMSearchContact_DateRangeTo(driver,DateRangeTo))	
			{
				flag=false;
			}
			
			if (!QualityMonitoringContactScreen.clickExecute(driver))	
			{
				flag=false;
			}
			if(QualityMonitoringContactScreen.verifycriteria(driver,"Duration"))
			{
				extent.log(LogStatus.PASS,"criteria already present on screen");
				
			}
			else
			{
				
			
			if (!QualityMonitoringContactScreen.clickPreference(driver))
			{
				flag=false;
			}
			if(!PreferenceScreen.selectserachcriteria(driver,"Duration"))
			{
				flag=false;
			}
			if(!PreferenceScreen.clickok(driver))
			{
				flag=false;
			}
			if(!QualityMonitoringContactScreen.verifycriteria(driver, "Duration"))
			{
				flag=false;
			}
			}
			if(!QualityMonitoringContactScreen.clickSearch(driver))
			{
				flag=false;
			}
			if (!QualityMonitoringContactScreen.selectQMSearchContactData(driver))		//go to contact data	
			{
				flag=false;
			}
			
			if (!QualityMonitoringContactScreen.setQMSearchContactDataDuration(driver,Minimum,Maximum))		//set min and max no.of holds	
			{
				flag=false;
			}		
			
			if (!Utilities.sikuliClick(driver,Utilities.Globlocators.getProperty("imagesPath")+"\\QM_ExecuteSearch.png"))
			{
				extent.log(LogStatus.FAIL,"Execute Search field is NOT displayed");
				flag=false;
			}
			
					
			Thread.sleep(10000); 		
			
			if (!QualityMonitoringContactScreen.verifyContactsStartTime(driver))		//select contact start time	
			{
				flag=false;
			}	
			
			Impact360Screen.closeQM(driver);
			
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			
			Utilities.Logout(driver);
			driver.close();			
			driver.quit();
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,17);
		}
		
		return flag;
	}

}
