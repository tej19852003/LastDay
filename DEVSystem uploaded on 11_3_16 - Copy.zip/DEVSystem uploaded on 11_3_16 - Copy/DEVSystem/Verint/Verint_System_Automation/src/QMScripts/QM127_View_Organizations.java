package QMScripts;

import java.io.File;

import java.text.SimpleDateFormat;
import java.util.Date;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;

import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class QM127_View_Organizations {
	
	public static ExtentReports extent = ExtentReports.get(QM127_View_Organizations.class);
	
	public static boolean View_Organizations() throws Exception
	{		
		boolean flag=true;
		String HTMLReportName="ViewOrganizationQM065"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "View Organization");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		Thread.sleep(5000);
		driver = new InternetExplorerDriver(capabilities); 	
	
		
		try
		{		   
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Organization Settings"))
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					extent.log(LogStatus.FAIL, "Verint Homepage is not displayed");
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Organization Settings"))
				{
					extent.log(LogStatus.WARNING, "Not able to select Organization Settings menu. Please try again.");
					return flag=false;
				}
			}
			
			//verify whether Organization name is already exist or not		
			Utilities.selectLeftTreeFrame(driver);			
			//String organizationName=".Automation_Organization";
			if (driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size()!=0)
			{
				extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "ViewOrg"));
				int rc1=driver.findElements(By.xpath("//*[@id='workContentWrapper']/div/div/table/tbody/tr")).size();
				System.out.println("rc1:"+rc1);
				if (rc1>0)
				{
					for (int j=1;j<=rc1;j++)
					{
						if (j<=15)
						{
						String orgName=driver.findElement(By.xpath("//table[@id='orgTree_id']/tbody/tr["+j+"]/td/a/span/span")).getText();					
						Thread.sleep(1000);
						extent.log(LogStatus.INFO, "Organization Name: "+orgName+" is displayed under Organization Name section ");						
						}
					}
				}
				else
				{
					extent.log(LogStatus.FAIL, "Organization Names were not displyed under Organization Name section");
				}			
			}
			else
			{
				extent.log(LogStatus.FAIL, "Organization Names were not displyed");
			}
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();			
			Utilities.verintScriptStatus(flag,"QM",HTMLReportName,4,9);
		}
		return flag;
	}

}
