package Driver;


import Utilities.Utilities;

//Class Name    : Verint_Driver
//Purpose		 : Driver method is used to execute Automation Scripts based on Test Set 'Run' parameter
//Date			 : 8/3/2015
//Author		 : d9ix
public class QM_Driver {
		
	public static void main(String[] args) throws Exception
	{		
		Utilities.Verint_Execution("QM");		
	}
}

