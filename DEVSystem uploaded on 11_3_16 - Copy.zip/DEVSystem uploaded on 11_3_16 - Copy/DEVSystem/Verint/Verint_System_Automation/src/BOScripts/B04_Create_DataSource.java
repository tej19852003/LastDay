package BOScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.DataSourceScreen;
import ScreenObjects.LoginScreen;

import ScreenObjects.VerintHomePageScreen;
import Utilities.Utilities;

public class B04_Create_DataSource {
	
	public static ExtentReports extent = ExtentReports.get(B04_Create_DataSource.class);
	
	public static boolean CreateDataSource() throws Exception
	{
		boolean flag=true;
		String HTMLReportName="Create_DataSource_"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Create Data Source");
				
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_BO"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("BO_TestSet");
	  
	    String DataSourceType = Ws.getCell(12,4).getContents();
	    String DataSourceName = Ws.getCell(13,4).getContents();
	    String DSNDescription = Ws.getCell(14,4).getContents();
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"System Management","Data Sources"))
			{
				Utilities.Logout(driver);				
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"System Management","Data Sources"))		
				{
					extent.log(LogStatus.WARNING, "Not able to select Data Sources. Please try again.");
					return flag=false;
				}
			}	
			String[] DSName=DataSourceName.split(",");
			System.out.println("dsname:"+DSName.length);
			for (int r=0;r<DSName.length;r++)
			{
				//check whether data source exist or not			
				if (!DataSourceScreen.verifyDataSourceName(driver, DSName[r]))
				{
					Utilities.selectRightPaneView(driver);
					if (!DataSourceScreen.clickCreateDataSource(driver))
					{
						return flag=false;
					}
					if (!DataSourceScreen.selectDataSourceType(driver, DataSourceType)) //select operations from dropdown
					{
						return flag=false;
					}
					if (!DataSourceScreen.clickSelect(driver)) //click on Select button
					{
						return flag=false;
					}
					if (!DataSourceScreen.setDataSourcename(driver, DSName[r]))//dsn name
					{
						return flag=false;
					}
					if (!DataSourceScreen.setDataSourcedescription(driver, DSNDescription))//data source description
					{
						return flag=false;
					}
					if (!DataSourceScreen.clickSave(driver))//click on Save button
					{
						return flag=false;
					}
					if (!DataSourceScreen.selectDataSourceName(driver, DSName[r]))
					{
						return flag=false;
					}
				}
			}
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"BO",HTMLReportName,4,4);
		}
		return flag;
	}
}
