package BOScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.DataSourceScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;

import Utilities.Utilities;

public class BO7_Create_DataSourceGroups_VCT {
	
	public static ExtentReports extent = ExtentReports.get(BO7_Create_DataSourceGroups_VCT.class);
	
	public static boolean CreateDataSourceGroups_VCT() throws Exception
	{
		boolean flag=true;
		
		String HTMLReportName="Create_DataSourceGroups_VCT"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Create DataSourceGroups VCT");
				
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_BO"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("BO_TestSet");
	    //String organizationName = Ws.getCell(5,6).getContents();
	    String DataSourceName = Ws.getCell(13,7).getContents();
	    //String WorkqueueName = Ws.getCell(11,5).getContents();
	    String DataSourceGroupName = Ws.getCell(15,7).getContents();
	    String DataSourceGroupDesc = Ws.getCell(16,7).getContents();
	    String DataSourceAvgWorkTime = Ws.getCell(17,7).getContents();    
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"System Management","Data Sources"))
			{
				Utilities.Logout(driver);				
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"System Management","Data Sources"))
				{
					extent.log(LogStatus.WARNING, "Settings section is not displayed. Please try again.");
					return flag=false;
				}
			}			
			Utilities.selectLeftTreeFrame(driver);
			if (!DataSourceScreen.selectDataSourceName(driver, DataSourceName))
			{
				return flag=false;
			}	
			//select Data source groups link/tab
			driver.switchTo().defaultContent();
			//span id -- 3_BBM_ORG_WORKLOADS_GROUPS_spn_id
			if (driver.findElements(By.linkText("Data Source Groups")).size()!=0)
			{
				driver.findElement(By.linkText("Data Source Groups")).click();
				extent.log(LogStatus.INFO, "Data Source Groups link/tab is selected");				
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to select Data Source Groups link/tab");	
				return flag=false;
			}
			
			String[] dsgName=DataSourceGroupName.split(",");
			System.out.println("dsgName:"+dsgName.length);
			for (int r=0;r<dsgName.length;r++)
			{
				if (!DataSourceScreen.verifyDataSourceGroupName(driver,dsgName[r]))
				{				
					if (!DataSourceScreen.clickCreateGroup(driver))
					{
						return flag=false;
					}
					if (!DataSourceScreen.setDataSourceGroupName(driver,dsgName[r]))
					{
						return flag=false;
					}
					if (!DataSourceScreen.setDataSourceGroupDescription(driver,DataSourceGroupDesc))
					{
						return flag=false;
					}
					if (!DataSourceScreen.setDataSourceGroupAvgWorkTime(driver,DataSourceAvgWorkTime))
					{
						return flag=false;
					}
					if (!DataSourceScreen.clickDateSourceGroupSave(driver))
					{
						return flag=false;
					}
				}
			}
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"BO",HTMLReportName,4,6);
		}
		return flag;
	}
}
