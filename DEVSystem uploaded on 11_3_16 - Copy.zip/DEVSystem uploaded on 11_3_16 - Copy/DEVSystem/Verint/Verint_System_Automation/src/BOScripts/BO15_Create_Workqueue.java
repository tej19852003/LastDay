package BOScripts;


import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.LoginScreen;
import ScreenObjects.OrganizationSettings;

import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.WorkQueuesScreen;
import Utilities.Utilities;

public class BO15_Create_Workqueue {
	
	public static ExtentReports extent = ExtentReports.get(BO15_Create_Workqueue.class);
	public static Screen sobj = new Screen ();
	public static boolean CreateWorkqueue() throws Exception
	{
		boolean flag=true;
		boolean temp=false;
		String HTMLReportName="Create_Workqueue_"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Create Workqueue");
				
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_BO"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("BO_TestSet");
	  
	    String OrganizatioName = Ws.getCell(5,9).getContents();
	    String WorkqueueName = Ws.getCell(18,9).getContents();
	    String WorkqueueDesc = Ws.getCell(19,9).getContents();
	    String WorkqueueMedia = Ws.getCell(20,9).getContents();
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Work Queues Settings"))
			//if (driver.findElements(By.linkText("Settings")).size()==0)
			{
				Utilities.Logout(driver);				
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Work Queues Settings"))
				//if (driver.findElements(By.linkText("Settings")).size()==0)
				{
					extent.log(LogStatus.WARNING, "Work Queues Settings menu is not selected. Please try again.");
					return flag=false;
				}
			}
			
			String[] WQName=WorkqueueName.split(",");
			System.out.println("WorkqueueName:"+WQName.length);
			for (int r=0;r<WQName.length;r++)
			{			
				Utilities.selectLeftTreeFrame(driver);
				if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,OrganizatioName))
				{
					return flag=false;
				}
				//checking whether exist or not
				Utilities.selectRightPaneView(driver);
				int valrcWq=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr")).size();
				System.out.println("valrcPriv:"+valrcWq);
				for (int j=1;j<=valrcWq;j++)
				{
					if (j<=15)
					{
					String WqnameApp=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/th/a/span")).getText().trim();
					//System.out.println("WqnameAppApp:"+WqnameApp);
					//System.out.println("WqnameAppCreated:"+WorkqueueName);
					Thread.sleep(1000);
					if (WqnameApp.contains(WQName[r]))
					{
						driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/th/a/span")).click();					
						extent.log(LogStatus.INFO, "Work Queue Name:"+WQName[r]+" already exist");
						extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Workqueue"));
						temp=true;
						break;
					}}
				}		
				//end of checking
				Utilities.selectRightPaneView(driver);
				if (temp==false)
				{			
					if (!WorkQueuesScreen.clickworkqueue(driver))
					{
						return flag=false;
					}
					if (!WorkQueuesScreen.setWorkqueueName(driver,WQName[r]))
					{
						return flag=false;
					}
					WorkQueuesScreen.setWorkqueueDescription(driver,WorkqueueDesc);			
					if (!WorkQueuesScreen.selectWorkqueueMedia(driver,WorkqueueMedia))
					{
						return flag=false;
					}
					if (!WorkQueuesScreen.clickSave(driver))
					{
						return flag=false;
					}
					if (driver.findElements(By.xpath("//div[@id='workPaneWrapper']/table[@id='viewfindPane_tbl_id']/tbody/tr/td[2]/div[@id='pageMessages']/div[@Class='stdError']")).size()!=0)
					{
						String message=driver.findElement(By.xpath("//div[@id='workPaneWrapper']/table[@id='viewfindPane_tbl_id']/tbody/tr/td[2]/div[@id='pageMessages']/div[@Class='stdError']")).getText();
						if (message.contains("Failed") && (message.contains("already exists")))
						{
							extent.log(LogStatus.WARNING, "Workqueue"+WQName[r]+" already exist");
							extent.log(LogStatus.WARNING, "", "", Utilities.captureScreenShot(driver, "Workqueue"));
						}
						else
						{
							extent.log(LogStatus.INFO, message+" is displayed");
							extent.log(LogStatus.INFO, "", "", Utilities.captureScreenShot(driver, "Workqueue"));
						}
						
					}
					//validation
					if (!WorkQueuesScreen.selectWorkqueue(driver,WQName[r]))
					{
						return flag=false;
					}	
				}
				/*//delete work queue
				if (!WorkQueuesScreen.clickDeleteworkqueue(driver))
				{
					return flag=false;
				}*/
			}
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"BO",HTMLReportName,4,9);
		}
		return flag;
	}
}
