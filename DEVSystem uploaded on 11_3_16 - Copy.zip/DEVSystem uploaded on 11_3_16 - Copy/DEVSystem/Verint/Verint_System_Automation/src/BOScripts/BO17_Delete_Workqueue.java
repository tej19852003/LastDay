package BOScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.LoginScreen;
import ScreenObjects.OrganizationSettings;

import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.WorkQueuesScreen;
import Utilities.Utilities;

public class BO17_Delete_Workqueue {
	
	public static ExtentReports extent = ExtentReports.get(BO17_Delete_Workqueue.class);
	public static Screen sobj = new Screen ();
	public static boolean DeleteWorkqueue() throws Exception
	{
		boolean flag=true;
		boolean temp=false;
		String HTMLReportName="Delete_Workqueue_"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Delete Workqueue");
				
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_BO"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("BO_TestSet");
	  
	    String OrganizatioName = Ws.getCell(5,11).getContents();
	    String WorkqueueName = Ws.getCell(11,11).getContents();
	    		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Work Queues Settings"))
			//Thread.sleep(5000);
			//if (driver.findElements(By.linkText("Settings")).size()==0)
			{
				Utilities.Logout(driver);				
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Work Queues Settings"))
				//if (driver.findElements(By.linkText("Settings")).size()==0)
				{
					extent.log(LogStatus.WARNING, "Settings section is not displayed. Please try again.");
					return flag=false;
				}
			}			
			Utilities.selectLeftTreeFrame(driver);
			if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,OrganizatioName))
			{
				return flag=false;
			}
			//checking whether exist or not
			Utilities.selectRightPaneView(driver);
			int valrcWq=driver.findElements(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr")).size();
			System.out.println("valrcPriv:"+valrcWq);
			for (int j=1;j<=valrcWq;j++)
			{
				if (j<=15)
				{
				String WqnameApp=driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/th/a/span")).getText().trim();
				System.out.println("WqnameAppApp:"+WqnameApp);
				System.out.println("WqnameAppCreated:"+WorkqueueName);
				Thread.sleep(1000);
				if (WqnameApp.contains(WorkqueueName))
				{
					driver.findElement(By.xpath("//table[@id='workpaneListWrapper']/tbody/tr["+j+"]/th/a/span")).click();					
					extent.log(LogStatus.INFO, "Work Queue Name:"+WorkqueueName+" is selected");
					temp=true;
					break;
				}}
			}
						
			//end of checking
			Utilities.selectRightPaneView(driver);
			if (temp==true)
			{			
				if (!WorkQueuesScreen.clickDeleteworkqueue(driver))
				{
					return flag=false;
				}					
			}
			else
			{
				extent.log(LogStatus.FAIL, "Work Queue Name:"+WorkqueueName+" does not exist/not able to delete");
				return flag=false;
			}
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"BO",HTMLReportName,4,11);
		}
		return flag;
	}
}
