package BOScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

import ScreenObjects.DataSourceScreen;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;

import Utilities.Utilities;

public class BO5_9_10_Edit_Delete_DSN_DSG {
	
	public static ExtentReports extent = ExtentReports.get(BO5_9_10_Edit_Delete_DSN_DSG.class);
	
	public static boolean Edit_Delete_DSN_DSG() throws Exception
	{
		boolean flag=true;
		
		String HTMLReportName="Edit_Delete_DSN_DSG"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Edit Delete DSN DataSourceGroups");
				
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_BO"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("BO_TestSet");
	    String DataSourceType = Ws.getCell(12,5).getContents();
	    String DataSourceName = Ws.getCell(13,5).getContents();
	    String DSNDescription = Ws.getCell(14,5).getContents();
	    String DataSourceGroupName = Ws.getCell(15,5).getContents();
	    String DataSourceGroupDesc = Ws.getCell(16,5).getContents();
	    String DataSourceAvgWorkTime = Ws.getCell(17,5).getContents();    
		
		try
		{			
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));
			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"System Management","Data Sources"))
			{
				Utilities.Logout(driver);				
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"System Management","Data Sources"))
				{
					extent.log(LogStatus.WARNING, "Settings section is not displayed. Please try again.");
					return flag=false;
				}
			}
			
			//check whether data source name exist or not, if not create and then delete
			
			if (!DataSourceScreen.verifyDataSourceName(driver,DataSourceName))
			{
				Utilities.selectRightPaneView(driver);
				if (!DataSourceScreen.clickCreateDataSource(driver))
				{
					return flag=false;
				}
				if (!DataSourceScreen.selectDataSourceType(driver, DataSourceType)) //select operations from dropdown
				{
					return flag=false;
				}
				if (!DataSourceScreen.clickSelect(driver)) //click on Select button
				{
					return flag=false;
				}
				if (!DataSourceScreen.setDataSourcename(driver, DataSourceName))//dsn name
				{
					return flag=false;
				}
				if (!DataSourceScreen.setDataSourcedescription(driver, DSNDescription))//data source description
				{
					return flag=false;
				}
				if (!DataSourceScreen.clickSave(driver))//click on Save button
				{
					return flag=false;
				}
				if (!DataSourceScreen.selectDataSourceName(driver, DataSourceName))
				{
					return flag=false;
				}
			}			
			
			Utilities.selectLeftTreeFrame(driver);
			if (!DataSourceScreen.selectDataSourceName(driver, DataSourceName))
			{
				return flag=false;
			}	
			//select Data source groups link/tab
			driver.switchTo().defaultContent();			
			if (driver.findElements(By.linkText("Data Source Groups")).size()!=0)
			{
				driver.findElement(By.linkText("Data Source Groups")).click();
				extent.log(LogStatus.INFO, "Data Source Groups link/tab is selected");				
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to select Data Source Groups link/tab");	
				return flag=false;
			}
			
			String[] dsgName=DataSourceGroupName.split(",");
			System.out.println("dsgName:"+dsgName.length);
			for (int r=0;r<dsgName.length;r++)
			{
				if (!DataSourceScreen.verifyDataSourceGroupName(driver,dsgName[r]))
				{				
					if (!DataSourceScreen.clickCreateGroup(driver))
					{
						return flag=false;
					}
					if (!DataSourceScreen.setDataSourceGroupName(driver,dsgName[r]))
					{
						return flag=false;
					}
					if (!DataSourceScreen.setDataSourceGroupDescription(driver,DataSourceGroupDesc))
					{
						return flag=false;
					}
					if (!DataSourceScreen.setDataSourceGroupAvgWorkTime(driver,DataSourceAvgWorkTime))
					{
						return flag=false;
					}
					if (!DataSourceScreen.clickDateSourceGroupSave(driver))
					{
						return flag=false;
					}
				}
				//edit data source group
				if (DataSourceScreen.verifyDataSourceGroupName(driver,dsgName[r]))
				{					
					if (!DataSourceScreen.clickEditDataSourceEditGroup(driver))
					{
						return flag=false;
					}
					if (!DataSourceScreen.setDataSourceGroupName(driver,dsgName[r]+"_Modified"))
					{
						return flag=false;
					}
					if (!DataSourceScreen.clickSave(driver))
					{
						return flag=false;
					}
					if (DataSourceScreen.verifyDataSourceGroupName(driver,dsgName[r]))
					{
						if (!DataSourceScreen.clickDataSourceDeleteGroup(driver))
						{
							return flag=false;
						}
					}
				}
			}
			Utilities.selectLeftTreeFrame(driver);
			if (!DataSourceScreen.selectDataSourceName(driver, DataSourceName))
			{
				return flag=false;
			}
			driver.switchTo().defaultContent();			
			if (driver.findElements(By.linkText("Settings")).size()!=0)
			{
				driver.findElement(By.linkText("Settings")).click();
				extent.log(LogStatus.INFO, "Settings link/tab is selected");				
			}
			else
			{
				extent.log(LogStatus.FAIL, "Not able to select Data Source Groups link/tab");	
				return flag=false;
			}
			Utilities.selectRightPaneView(driver);
			if (!DataSourceScreen.clickDeleteDataSource(driver))
			{
				extent.log(LogStatus.FAIL, "Data Source Name:"+DataSourceName+" does not exist/not able to delete");
				return flag=false;
			}
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"BO",HTMLReportName,4,5);
		}
		return flag;
	}
}
