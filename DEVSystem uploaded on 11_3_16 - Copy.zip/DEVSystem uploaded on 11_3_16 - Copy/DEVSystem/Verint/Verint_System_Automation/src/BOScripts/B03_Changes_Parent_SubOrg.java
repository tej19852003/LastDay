package BOScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.sikuli.script.Screen;

import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;
import ScreenObjects.OrganizationSettings;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class B03_Changes_Parent_SubOrg {
	
	public static ExtentReports extent = ExtentReports.get(B03_Changes_Parent_SubOrg.class);
	public static Screen sobj = new Screen ();
	
	public static boolean Assign_Changes_Parent_SubOrg() throws Exception
	{		
		boolean flag=true;
		String HTMLReportName="Assign_Changes_Parent_SubOrg"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Assign Changes ParentOrg To SubOrg");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_BO"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("BO_TestSet");
	    String organizationName = Ws.getCell(5,3).getContents();
	    String organizationDesc = Ws.getCell(6,3).getContents();
	    String organizationParent = Ws.getCell(7,3).getContents();	
	    String SubOrganizatioName = Ws.getCell(11,3).getContents();
	    String WeekStartDay = Ws.getCell(9,3).getContents();
	    String DayBoundary = Ws.getCell(10,3).getContents();	
		
		try
		{		   
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Organization Settings"))
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Organization Settings"))
				{
					extent.log(LogStatus.WARNING, "Not able to select Organization Settings menu. Please try again");
					return flag=false;
				}			
			}
			//1st organization
			if (!mapOrganization(driver,organizationName,organizationParent,organizationDesc,""))
			{
				return flag=false;
			}
			//child organization
			if (!mapOrganization(driver,SubOrganizatioName,organizationName,organizationDesc,""))
			{
				return flag=false;
			}
			//select 1st organization
			Utilities.selectLeftTreeFrame(driver);
			if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,organizationName))
			{
				return flag=false;
			}
			Utilities.selectRightPaneView(driver);
			
			if (WeekStartDay!="")
			{
				if (!OrganizationSettings.setWeekStartDay(driver,WeekStartDay))
				{
					flag=false;
				}
			}
			if (DayBoundary!=null)
			{
				if (!OrganizationSettings.setDayBoundary(driver,DayBoundary))
				{
					flag=false;
				}
			}
			Thread.sleep(2000);
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\SaveApplyToSuborg.png");			
			Utilities.sikuliClick(driver, Utilities.Globlocators.getProperty("imagesPath")+"\\Delete_OK.png");				
			
			//OrganizationSettings.clickSaveApplySubOrg(driver);
			//select child organization
			Utilities.selectLeftTreeFrame(driver);
			if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,SubOrganizatioName))
			{
				return flag=false;
			}
			//verify week start day
			Utilities.selectRightPaneView(driver);
			if (driver.findElements(By.xpath("//input[@id='weekStartDay_0']")).size()!=0)
			{
				if (driver.findElement(By.xpath("//input[@id='weekStartDay_0']")).getText().contains(WeekStartDay))
				{
					extent.log(LogStatus.PASS, "Parent Organization:"+organizationName+" Week Start Day:"+WeekStartDay +"mapped successfully to Sub Organization:"+SubOrganizatioName);
					extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "OrganizationWeekDay"));
				}
				else
				{
					extent.log(LogStatus.FAIL, "Parent Organization:"+organizationName+" Week Start Day:"+WeekStartDay +" NOT mapped to Sub Organization:"+SubOrganizatioName);
					extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "OrganizationWeekDay"));
					flag=false;
				}
			}
			else
			{
				extent.log(LogStatus.FAIL, "Week Start Day field is NOT displayed");
				flag=false;
			}
			if (driver.findElements(By.xpath("//input[@id='dayBoundaryOffset_0']")).size()!=0)
			{
				if (driver.findElement(By.xpath("//input[@id='dayBoundaryOffset_0']")).getText().contains("1:00 AM"))
				{
					extent.log(LogStatus.PASS, "Parent Organization:"+organizationName+" Day boundary: 1:00 AM mapped successfully to Sub Organization:"+SubOrganizatioName);
					extent.log(LogStatus.PASS, "", "", Utilities.captureScreenShot(driver, "OrganizationWeekDayoundary"));
				}
				else
				{
					extent.log(LogStatus.FAIL, "Parent Organization:"+organizationName+" Day boundary: 1:00 AM NOT mapped to Sub Organization:"+SubOrganizatioName);
					extent.log(LogStatus.FAIL, "", "", Utilities.captureScreenShot(driver, "OrganizationWeekDayoundary"));
					flag=false;
				}
			}
			else
			{
				extent.log(LogStatus.FAIL, "Day boundary field is NOT displayed");
				flag=false;
			}
			//del sub org
			if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,SubOrganizatioName))
			{
				return flag=false;
			}
			if (!OrganizationSettings.clickDelete(driver))
			{
				return flag=false;
			}
			if (!OrganizationSettings.clickDeleteOrg(driver))
			{
				return flag=false;
			}
			//del parent org
			if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,organizationName))
			{
				return flag=false;
			}
			if (!OrganizationSettings.clickDelete(driver))
			{
				return flag=false;
			}
			if (!OrganizationSettings.clickDeleteOrg(driver))
			{
				return flag=false;
			}
			
			
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"BO",HTMLReportName,4,3);
		}
		return flag;
	}
	
	public static boolean mapOrganization(WebDriver driver,String organizationName,String organizationParent,String organizationDesc,String WeekStartDay) throws Exception
	{
		boolean option=false;
		//verify whether Organization name is already exist or not			
		if (!OrganizationSettings.verifyOrganizationFromLeftTreeFrame(driver,organizationName))
		{
			Utilities.selectLeftTreeFrame(driver);
			if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,organizationParent))
			{
				return option=false;
			}
			Utilities.selectRightPaneView(driver);
			if (!OrganizationSettings.clickCreateOrganization(driver))
			{
				return option=false;
			}
			OrganizationSettings.setOrganizationName(driver,organizationName);
			OrganizationSettings.setOrganizationDescription(driver,organizationDesc);
			if (WeekStartDay!="")
			{
				if (!OrganizationSettings.setWeekStartDay(driver,WeekStartDay))
				{
					option=false;
				}
			}
			/*if (DayBoundary!=null)
			{
			OrganizationSettings.setDayBoundary(driver,DayBoundary)
			}*/
			
			//OrganizationSettings.isSelectedDaysAndHoursOfOperation(driver);
			if (!OrganizationSettings.clickSave(driver))
			{
				return option=false;
			}
			//validation
			Utilities.selectLeftTreeFrame(driver);
			if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,organizationName))
			{
				option=false;
			}
			else
			{
				option=true;
			}
		}
		return option;
	}

}
