package BOScripts;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import jxl.Sheet;
import jxl.Workbook;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import ScreenObjects.LoginScreen;
import ScreenObjects.VerintHomePageScreen;

import ScreenObjects.OrganizationSettings;
import Utilities.Utilities;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.LogStatus;

public class BO2_Edit_Organization {
	
	public static ExtentReports extent = ExtentReports.get(BO2_Edit_Organization.class);
	
	public static boolean Edit_Organization() throws Exception
	{		
		boolean flag=true;
		String HTMLReportName="CreateEditOrganization"+new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss").format(new Date());
		Utilities.testcaseSetup(HTMLReportName, "Create Edit Organization");
		
		File file = new File(Utilities.Globlocators.getProperty("IEDriverServerPath"));
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		
		WebDriver driver;
		DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		driver = new InternetExplorerDriver(capabilities); 	
		
		FileInputStream fis = new FileInputStream(Utilities.Globlocators.getProperty("testDataPath_BO"));
	    Workbook Wb = Workbook.getWorkbook(fis);		
	    Sheet Ws = Wb.getSheet("BO_TestSet");
	    String organizationName = Ws.getCell(5,2).getContents();
	    String organizationDesc = Ws.getCell(6,2).getContents();
	    String organizationParent = Ws.getCell(7,2).getContents();
	    String ModifiedOrgName = Ws.getCell(8,2).getContents();
	    String WeekStartDay = Ws.getCell(9,2).getContents();
	    String DayBoundary = Ws.getCell(10,2).getContents();	
		
		try
		{		   
			LoginScreen.launchVerint(driver,Utilities.Globlocators.getProperty("VerintURL"));			 
			if (!LoginScreen.verifyLoginPageLaunched(driver))
			{
				return flag=false;
			}
			LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
			LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
			LoginScreen.clickLogin(driver);
			if (!VerintHomePageScreen.verifyVerintHomePage(driver))
			{
				return flag=false;
			}
			if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Organization Settings"))
			{
				Utilities.Logout(driver);
				LoginScreen.setTextInUsername(driver,Utilities.Globlocators.getProperty("UserName"));
				LoginScreen.setTextInPassword(driver,Utilities.Globlocators.getProperty("Password"));
				LoginScreen.clickLogin(driver);
				if (!VerintHomePageScreen.verifyVerintHomePage(driver))
				{
					extent.log(LogStatus.FAIL, "Verint Homepage is not displayed");
					return flag=false;
				}
				if (!VerintHomePageScreen.selectMenuItem(driver,"Organization Management","Organization Settings"))
				{
					extent.log(LogStatus.WARNING, "Not able to select Organization Settings menu. Please try again.");
					return flag=false;
				}		
			}
			String[] OrgName=organizationName.split(",");
			System.out.println("orgname:"+OrgName.length);
			for (int r=0;r<OrgName.length;r++)
			{
				System.out.println("org:"+OrgName[r]);
				//boolean Temp1=true;
				//verify whether Organization name is already exist or not		
				if (!OrganizationSettings.verifyOrganizationFromLeftTreeFrame(driver,OrgName[r]))
				{					
					Utilities.selectLeftTreeFrame(driver);
					if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,organizationParent))
					{
						return flag=false;
					}
					Utilities.selectRightPaneView(driver);
					if (!OrganizationSettings.clickCreateOrganization(driver))
					{
						return flag=false;
					}
					OrganizationSettings.setOrganizationName(driver,OrgName[r]);
					OrganizationSettings.setOrganizationDescription(driver,organizationDesc);
					OrganizationSettings.isSelectedDaysAndHoursOfOperation(driver);
					if (!OrganizationSettings.clickSave(driver))
					{
						return flag=false;
					}
					//validation
					Utilities.selectLeftTreeFrame(driver);
					if (!OrganizationSettings.selectOrganizationFromLeftTreeFrame(driver,OrgName[r]))
					{
						return flag=false;
					}
				}
				String[] modOrgName=ModifiedOrgName.split(",");
				if (!editOrganization(driver,modOrgName[r],WeekStartDay,DayBoundary))
				{
					extent.log(LogStatus.FAIL, "Not able to modify Organization Name:"+OrgName[r]+ "to"+modOrgName[r]);
					return flag=false;
				}
			}
		}catch(Exception e){
			System.out.println(e);
		}finally{
			Utilities.Logout(driver);
			driver.close();
			driver.quit();
			Wb.close();
			fis.close();
			Utilities.verintScriptStatus(flag,"BO",HTMLReportName,4,2);
		}
		return flag;
	}

	public static boolean editOrganization(WebDriver driver, String OrgName,String WeekStartDay,String DayBoundary) throws Exception
	{
		boolean flag=true;
		try{
			Utilities.selectRightPaneView(driver);
			OrganizationSettings.setOrganizationName(driver,OrgName);
			if (WeekStartDay!="")
			{
				if (!OrganizationSettings.setWeekStartDay(driver,WeekStartDay))
				{
					flag=false;
				}
			}
			if (DayBoundary!=null)
			{
				if (!OrganizationSettings.setDayBoundary(driver,DayBoundary))
				{
					flag=false;
				}
			}
			if (!OrganizationSettings.clickSave(driver))
			{
				return flag=false;
			}
	}catch(Exception e){
		System.out.println(e);
	}
		return flag;
	}
}
